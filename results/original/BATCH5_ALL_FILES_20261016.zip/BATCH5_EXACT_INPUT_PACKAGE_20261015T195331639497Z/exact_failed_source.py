# Batch 5 — packet-accounting control for the already completed Capture-1-1 injection.
# Reuses the exact existing INJ_k1/k3 PCAPs and the same capture's linked baseline.
# Tests:
#   1. Packet-multiset accounting: injected duplicates are counted explicitly.
#   2. UID-to-original-flow accounting: flags mixed/ambiguous connection membership.
#   3. Frozen-HGB outcome comparison on packet-mapped descendants.
#
# This does NOT regenerate attacks, retrain models, or claim application functionality.

from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
import hashlib
import json
import shutil
import struct
import subprocess
import traceback
import zipfile

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits


WORK = Path("/kaggle/working")
OWNER = Path("/kaggle/input/datasets/mdhamidborkottulla")
OUT = WORK / (
    "LINEAGE_INJECTION_BATCH5_"
    + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
)
OUT.mkdir(parents=True, exist_ok=False)

CAPTURE = "CTU-IoT-Malware-Capture-1-1"
ZEKE = shutil.which("zeek") or "/opt/zeek/bin/zeek"
SEEDS = [7]
K_VALUES = [1, 3]
NUMERIC = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts",
    "resp_pkts", "orig_ip_bytes", "resp_ip_bytes", "missed_bytes",
]
FEATURES = NUMERIC + ["proto"]
BYTE_LIMIT = 512 * 1024**2

receipt = {
    "status": "STARTED",
    "tests": {},
    "models_retrained": False,
    "attacks_regenerated": False,
    "new_PCAP_replays": 0,
    "historical_outputs_overwritten": False,
    "application_functionality_tested": False,
    "output_directory": str(OUT),
}


class Stop(Exception):
    pass


def save_json(path, value):
    path.write_text(
        json.dumps(value, indent=2, default=str),
        encoding="utf-8",
    )


def sha_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()


def read_frame(path):
    path = Path(path)
    if path.stat().st_size > BYTE_LIMIT:
        raise Stop("Refusing oversized table: " + str(path))
    with open(path, "rb") as handle:
        data = handle.read(BYTE_LIMIT + 1)
    if data[:2] == b"\x1f\x8b":
        import gzip
        data = gzip.decompress(data)
        if len(data) > BYTE_LIMIT:
            raise Stop("Decompressed table exceeds limit.")
    return pd.read_csv(
        __import__("io").BytesIO(data),
        dtype=str,
        keep_default_na=False,
    )


def norm(frame):
    frame = frame.copy()
    missing = set(FEATURES) - set(frame.columns)
    if missing:
        raise Stop("Missing feature columns: " + ", ".join(sorted(missing)))

    for column in NUMERIC:
        values = pd.to_numeric(
            frame[column].replace({"-": "0", "": "0"}),
            errors="raise",
        ).astype(float)
        if not np.isfinite(values).all() or (values < 0).any():
            raise Stop("Invalid numeric feature: " + column)
        frame[column] = values

    frame["proto"] = frame.proto.astype(str).str.lower()
    return frame


def row_key(row):
    ts_us = int(
        (Decimal(str(row["ts"])) * Decimal(1_000_000))
        .to_integral_value(rounding=ROUND_HALF_EVEN)
    )
    return (
        ts_us,
        str(row["id.orig_h"]),
        str(row["id.orig_p"]),
        str(row["id.resp_h"]),
        str(row["id.resp_p"]),
        str(row["proto"]).lower(),
    )


def read_conn(path):
    fields = None
    rows = []
    with open(path, encoding="utf-8", errors="strict") as handle:
        for line in handle:
            if line.startswith("#fields"):
                fields = line.rstrip("\n").split("\t")[1:]
            elif line.startswith("#") or not line.strip():
                continue
            else:
                if fields is None:
                    raise Stop("Zeek conn log has no #fields header.")
                values = line.rstrip("\n").split("\t")
                if len(values) != len(fields):
                    raise Stop("Malformed Zeek conn.log row.")
                rows.append(dict(zip(fields, values)))
    if not rows:
        raise Stop("Zeek conn.log contains no connection rows.")
    return pd.DataFrame(rows)


def classic_pcap(path):
    magics = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1),
    }
    with open(path, "rb") as handle:
        header = handle.read(24)
        if len(header) != 24 or header[:4] not in magics:
            raise Stop("Expected classic PCAP; PCAPNG is not accepted.")
        endian, unit = magics[header[:4]]
        link = struct.unpack(endian + "I", header[20:24])[0] & 0xFFFF
        packet_hashes = Counter()
        packet_count = 0
        for _ in range(100_000_000):
            record = handle.read(16)
            if not record:
                break
            if len(record) != 16:
                raise Stop("Truncated PCAP record.")
            sec, fraction, captured, wire = struct.unpack(
                endian + "IIII", record
            )
            payload = handle.read(captured)
            if len(payload) != captured:
                raise Stop("Truncated PCAP payload.")
            digest = hashlib.sha256(payload).digest()
            packet_hashes[(digest, wire)] += 1
            packet_count += 1
        else:
            raise Stop("PCAP packet safety limit exceeded.")

    return packet_count, packet_hashes, link


def find_unique(root, name):
    found = []
    for path in root.rglob(name):
        if path.is_file() and not path.is_symlink():
            found.append(path)
    unique = {str(path.resolve()): path.resolve() for path in found}
    if len(unique) != 1:
        raise Stop(
            f"Expected exactly one {name} under {root}; "
            f"found {len(unique)}. No arbitrary copy selected."
        )
    return next(iter(unique.values()))


def main():
    zeek_path = Path(ZEKE)
    if not zeek_path.is_file():
        raise Stop("Zeek 8.0.10 is unavailable.")
    version = subprocess.run(
        [str(zeek_path), "--version"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    version_text = (version.stdout + version.stderr).strip()
    if "8.0.10" not in version_text:
        raise Stop("Expected validated Zeek 8.0.10; found " + version_text)

    print("[1/3] Locating the exact completed Capture-1-1 injection artifacts.",
          flush=True)

    injection_root = WORK / (
        "TRACE_PACKET_INJECTION_1_1_20261012T115115809570Z"
    )
    linkage_root = WORK / "TRACE_LINKAGE_BATCH_v1" / CAPTURE

    if not injection_root.is_dir() or not linkage_root.is_dir():
        raise Stop("Required existing Capture-1-1 result/linkage directory missing.")

    linked_path = find_unique(linkage_root, "linked_records.csv")
    receipt_path = find_unique(linkage_root, "candidate_receipt.json")
    linkage_receipt = json.loads(receipt_path.read_text())

    if linkage_receipt.get("status") != "FULL_LOG_LINKAGE_COMPUTED":
        raise Stop("Capture linkage receipt is not complete.")
    capture = Path(linkage_receipt["capture"])
    if not capture.is_file():
        raise Stop("Original Capture-1-1 PCAP is unavailable.")
    if sha_file(capture) != linkage_receipt["pcap_sha256"]:
        raise Stop("Original capture hash differs from linkage receipt.")
    if sha_file(linked_path) != linkage_receipt["linked_records_sha256"]:
        raise Stop("Linked-record table hash differs from linkage receipt.")

    generated_conn = linkage_root / "replay" / "conn.log"
    if not generated_conn.is_file():
        raise Stop("Validated source conn.log is unavailable.")
    if sha_file(generated_conn) != linkage_receipt["generated_log_sha256"]:
        raise Stop("Source conn.log hash mismatch.")

    baseline = read_conn(generated_conn)
    baseline["key"] = [row_key(row) for row in baseline.to_dict("records")]
    if baseline.key.duplicated().any():
        raise Stop(
            "Source Zeek conn.log contains duplicate timestamp/tuple keys; "
            "the requested one-to-one audit is not valid."
        )

    linked = read_frame(linked_path)
    required_link = set(FEATURES + ["label", "generated_line"])
    if required_link - set(linked.columns):
        raise Stop(
            "Linked-record table lacks required fields: "
            + ", ".join(sorted(required_link - set(linked.columns)))
        )

    linked["generated_line"] = pd.to_numeric(
        linked.generated_line, errors="raise"
    ).astype(int)
    linked["label"] = linked.label.astype(str).str.lower()
    linked = linked[linked.label.isin(["benign", "malicious"])].copy()
    linked["y"] = linked.label.eq("malicious").astype(int)

    required_backup = (
        OWNER / "full-backup"
        / "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    model_path = (
        required_backup
        / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
        / "frozen_source_models.joblib"
    )
    if not model_path.is_file():
        raise Stop("Frozen historical injection models unavailable.")

    # Read only small historical result tables. Never inspect model scores
    # when selecting input files.
    result_tables = {}
    packet_checks = {}
    for k in K_VALUES:
        job = injection_root / f"injection_{k}"
        pcap = job / "transformed.pcap"
        if not pcap.is_file():
            raise Stop(f"Saved injection_{k} PCAP is missing.")
        table_path = injection_root / "real_packet_injection_1_1_results.csv"
        if not table_path.is_file():
            raise Stop("Historical injection result table is missing.")
        result_tables[k] = pd.read_csv(table_path)
        packet_checks[k] = classic_pcap(pcap)
        result_tables[k] = result_tables[k][
            result_tables[k].injected_packets_per_flow.eq(k)
        ].copy()

    baseline_pcap_count, baseline_multiset, linktype = classic_pcap(capture)
    baseline_lookup = baseline.set_index("key")
    linked_by_line = linked.set_index("generated_line")

    # Recreate the exact label/split rule documented by the saved experiment:
    # half split, stratified by class, random_state=7.
    from sklearn.model_selection import train_test_split

    split_rows = linked.sort_values("generated_line").reset_index(drop=True)
    train_part, held_part = train_test_split(
        split_rows,
        test_size=0.5,
        stratify=split_rows.y,
        random_state=7,
    )
    held_lines = set(held_part.generated_line.astype(int))
    y_by_line = dict(
        zip(
            split_rows.generated_line.astype(int),
            split_rows.y.astype(int),
        )
    )

    outputs = []
    model_bundle_bytes = model_path.stat().st_size
    if model_bundle_bytes > BYTE_LIMIT:
        raise Stop("Frozen model bundle exceeds safe loading limit.")
    import io
    bundle = joblib.load(io.BytesIO(model_path.read_bytes()))
    models = bundle.get("models") if isinstance(bundle, dict) else None
    if not isinstance(models, dict) or 7 not in models:
        raise Stop("Unexpected frozen injection model bundle.")
    hgb_all9 = models[7].get("WITHIN_HGB_ALL9")
    hgb_no_proto = models[7].get("WITHIN_HGB_NO_PROTO")
    if hgb_all9 is None or hgb_no_proto is None:
        raise Stop("Required frozen HGB detectors are missing.")

    def model_matrix(frame, use_proto):
        x = frame[NUMERIC].to_numpy(float)
        if use_proto:
            x = np.column_stack([
                x,
                *[
                    frame.proto.eq(p).to_numpy(float)
                    for p in ["tcp", "udp", "icmp"]
                ],
            ])
        return x

    with threadpool_limits(limits=2):
        for k in K_VALUES:
            print(f"[2/3] Auditing injection_{k} packet accounting and UIDs.",
                  flush=True)

            job = injection_root / f"injection_{k}"
            injected_pcap = job / "transformed.pcap"
            transformed_conn_path = job / "conn.log"

            # If the original run did not retain conn.log, perform exactly
            # one replay of the already-saved transformed PCAP.
            if not transformed_conn_path.is_file():
                run = subprocess.run(
                    [
                        str(zeek_path), "-C", "-r",
                        str(injected_pcap.resolve()),
                    ],
                    cwd=OUT,
                    capture_output=True,
                    text=True,
                    timeout=2400,
                )
                receipt["new_PCAP_replays"] += 1
                if run.returncode:
                    (OUT / f"zeek_injection_{k}_stderr.txt").write_text(
                        run.stderr, encoding="utf-8"
                    )
                    raise Stop(
                        f"Zeek replay failed for saved injection_{k}."
                    )
                generated = OUT / "conn.log"
                if not generated.is_file():
                    raise Stop(
                        f"Zeek produced no conn.log for injection_{k}."
                    )
                transformed_conn_path = OUT / f"conn_injection_{k}.log"
                shutil.move(str(generated), transformed_conn_path)

            transformed = read_conn(transformed_conn_path)
            transformed["key"] = [
                row_key(row)
                for row in transformed.to_dict("records")
            ]

            # Map each transformed record to a source original by:
            # 1) matching the exact original start key, or
            # 2) matching endpoints/protocol and its declared eligible
            #    original time interval.
            original_rows = linked.copy()
            if "ts" not in original_rows.columns:
                original_rows = original_rows.merge(
                    baseline[["key", "ts", "id.orig_h", "id.orig_p",
                              "id.resp_h", "id.resp_p", "proto",
                              "orig_pkts", "resp_pkts"]],
                    left_on="generated_line",
                    right_index=True,
                    how="left",
                    suffixes=("", "_source"),
                )

            # Reconstruct source row metadata by generated line; this is
            # from the validated source conn.log, not inferred from outcomes.
            line_to_source = {}
            for pos, row in enumerate(baseline.to_dict("records")):
                line_number = pos + int(linkage_receipt.get("conn_log_header_lines", 0)) + 1
                if line_number in y_by_line:
                    line_to_source[line_number] = row

            eligible_lines = set()
            for line_number, source_row in line_to_source.items():
                y = y_by_line[line_number]
                if y != 1 or line_number not in held_lines:
                    continue
                if source_row["proto"].lower() != "tcp":
                    continue
                if int(float(source_row["orig_pkts"])) < 2:
                    continue
                eligible_lines.add(line_number)

            injected_records = result_tables[k]
            if injected_records.empty:
                raise Stop(f"No historical injection_{k} detector results.")

            # Identify injected source flows from the saved experiment's
            # modified-key list, if present.
            modified_path = job / "injected_flow_manifest.csv"
            if not modified_path.is_file():
                modified_path = job / "injected_flows.csv"

            modified_lines = None
            if modified_path.is_file():
                modified = pd.read_csv(modified_path)
                line_col = next(
                    (c for c in ["generated_line", "source_line"]
                     if c in modified.columns),
                    None,
                )
                if line_col:
                    modified_lines = set(
                        pd.to_numeric(modified[line_col], errors="raise")
                        .astype(int)
                    )

            if modified_lines is None:
                # Require a saved PCAP-level injection receipt listing
                # selected flow keys; do not infer eligibility from model
                # predictions or altered features.
                candidate_manifests = [
                    p for p in job.glob("*.json")
                    if "receipt" in p.name.lower()
                ]
                manifest = None
                for path in candidate_manifests:
                    try:
                        value = json.loads(path.read_text())
                    except (OSError, ValueError):
                        continue
                    if any(
                        key in value
                        for key in [
                            "injected_generated_lines",
                            "selected_generated_lines",
                            "eligible_generated_lines",
                        ]
                    ):
                        manifest = value
                        break

                if manifest is None:
                    raise Stop(
                        f"injection_{k}: no saved eligible-flow/packet "
                        "manifest. Refusing to infer injected units."
                    )

                modified_lines = set(
                    manifest.get("injected_generated_lines")
                    or manifest.get("selected_generated_lines")
                    or manifest.get("eligible_generated_lines")
                )

            if not modified_lines.issubset(eligible_lines):
                raise Stop(
                    f"injection_{k}: saved modified-flow set violates "
                    "the original eligibility/split rule."
                )

            # Count injected packets from PCAP multiset differences.
            _, transformed_multiset, _ = classic_pcap(injected_pcap)
            difference = transformed_multiset - baseline_multiset
            added_packets = sum(difference.values())

            expected_added = k * len(modified_lines)
            packet_multiset_ok = added_packets == expected_added

            # Build UID membership using exact original tuple starts plus
            # conservative time/endpoints for descendants.
            line_to_key = {
                line: "|".join(map(str, row_key(source_row)))
                for line, source_row in line_to_source.items()
            }
            key_to_line = {v: k for k, v in line_to_key.items()}

            descendants = defaultdict(set)
            ambiguous_uids = set()
            mixed_uids = set()

            for row in transformed.to_dict("records"):
                exact_line = key_to_line.get("|".join(map(str, row["key"])))
                if exact_line in modified_lines:
                    descendants[exact_line].add(row["uid"])
                    continue

                endpoint_matches = []
                for line in modified_lines:
                    source_row = line_to_source[line]
                    same_endpoints = {
                        (source_row["id.orig_h"], int(source_row["id.orig_p"])),
                        (source_row["id.resp_h"], int(source_row["id.resp_p"])),
                    } == {
                        (row["id.orig_h"], int(row["id.orig_p"])),
                        (row["id.resp_h"], int(row["id.resp_p"])),
                    }
                    if not same_endpoints:
                        continue
                    start = float(source_row["ts"])
                    end = start + max(0.0, float(source_row["duration"]))
                    t = float(row["ts"])
                    if start - 0.001 <= t <= end + 10.001:
                        endpoint_matches.append(line)

                if len(endpoint_matches) == 1:
                    descendants[endpoint_matches[0]].add(row["uid"])
                elif len(endpoint_matches) > 1:
                    ambiguous_uids.add(row["uid"])
                    for line in endpoint_matches:
                        descendants[line].add(row["uid"])

            uid_members = defaultdict(set)
            for line, uids in descendants.items():
                for uid in uids:
                    uid_members[uid].add(line)
            mixed_uids = {
                uid for uid, members in uid_members.items()
                if len(members) != 1
            }

            # Evaluate the frozen detector on actual transformed descendant
            # records. This uses the historically trained HGB models.
            transformed_numeric = transformed.copy()
            for column in NUMERIC:
                transformed_numeric[column] = pd.to_numeric(
                    transformed_numeric[column].replace(
                        {"-": "0", "": "0"}
                    ),
                    errors="raise",
                ).astype(float)
            transformed_numeric["proto"] = (
                transformed_numeric.proto.str.lower()
            )

            p_all = hgb_all9.predict(
                model_matrix(transformed_numeric, True)
            )
            p_no = hgb_no_proto.predict(
                model_matrix(transformed_numeric, False)
            )
            uid_alarm = dict(zip(
                transformed.uid.astype(str),
                (p_all == 1) | (p_no == 1),
            ))

            summary_rows = []
            for line in sorted(modified_lines):
                uids = descendants.get(line, set())
                usable = bool(uids) and not (
                    uids & mixed_uids
                ) and not (uids & ambiguous_uids)
                alarm = (
                    any(uid_alarm.get(uid, False) for uid in uids)
                    if usable else None
                )
                summary_rows.append({
                    "injected_packets_per_flow": k,
                    "generated_line": line,
                    "descendant_uid_count": len(uids),
                    "association_usable": usable,
                    "any_descendant_alarm": alarm,
                })

            per_flow = pd.DataFrame(summary_rows)
            per_flow.to_csv(
                OUT / f"injection_{k}_per_flow.csv", index=False
            )

            usable = per_flow.association_usable
            alarms = per_flow.any_descendant_alarm.fillna(False)
            outcomes = {
                "injected_packets_per_flow": k,
                "modified_flows": len(modified_lines),
                "expected_added_packets": expected_added,
                "observed_added_packets": added_packets,
                "packet_multiset_matches": packet_multiset_ok,
                "transformed_records": len(transformed),
                "eligible_flows": len(eligible_lines),
                "validated_modified_flows": int(usable.sum()),
                "unresolved_modified_flows": int((~usable).sum()),
                "descendant_alarm_flows": int(
                    (usable & alarms).sum()
                ),
                "descendant_no_alarm_flows": int(
                    (usable & ~alarms).sum()
                ),
                "descendant_detection_fraction_lower": (
                    int((usable & alarms).sum())
                    / max(len(modified_lines), 1)
                ),
                "descendant_detection_fraction_upper": (
                    int((usable & alarms).sum())
                    + int((~usable).sum())
                ) / max(len(modified_lines), 1),
                "mixed_uid_count": len(mixed_uids),
                "ambiguous_uid_count": len(ambiguous_uids),
                "functionality_preservation_tested": False,
            }
            outputs.append(outcomes)

    results = pd.DataFrame(outputs)
    results.to_csv(
        OUT / "injection_packet_accounting_summary.csv",
        index=False,
    )

    receipt.update({
        "status": "INJECTION_PACKET_ACCOUNTING_COMPLETE",
        "tests": {
            "saved_artifact_integrity": "PASSED",
            "injected_packet_multiset": "COMPLETED",
            "UID_descendant_accounting": "COMPLETED",
            "frozen_HGB_descendant_screen": "COMPLETED",
        },
        "zeek_version": version_text,
        "source_capture_sha256": linkage_receipt["pcap_sha256"],
        "injection_results": outputs,
    })

    print("\nBATCH 5 — INJECTION PACKET ACCOUNTING")
    print(results.to_string(index=False))

except Exception as error:
    receipt["status"] = (
        "BLOCKED" if isinstance(error, Stop)
        else "FAILED_WITH_SAVED_TRACEBACK"
    )
    receipt["reason"] = str(error)
    (OUT / "error.txt").write_text(
        traceback.format_exc(), encoding="utf-8"
    )
    print("\nBATCH 5 STOPPED:", error)

finally:
    save_json(OUT / "receipt.json", receipt)
    print(
        "\nBATCH 5 RECEIPT\n"
        + json.dumps(receipt, indent=2, default=str)
    )