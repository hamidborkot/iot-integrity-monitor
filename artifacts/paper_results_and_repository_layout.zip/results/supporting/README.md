# Supporting results

Upload supporting tables with source, cohort, model-bank and policy identities. Keep NF-ToN-IoT-v2 tabular report-corruption classification separate from paired Zeek/NFStream extraction counts. A recovered printed table is not independently validated raw ground truth. Do not rename this directory as an exact supplement release without checking S1-S8.
