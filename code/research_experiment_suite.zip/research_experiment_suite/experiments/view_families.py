# =============================================================================
# NEXT EXPERIMENT: VIEW-MODEL FAMILY REPLICATION
#
# Real saved datasets only. No synthetic data.
#
# Frozen across comparisons:
#   Primary detector, primary threshold, source/test splits, feature schema,
#   attack budgets, attack records, and evaluation windows.
#
# View families:
#   Existing logistic views.
#   Newly trained MLP views.
#   Newly trained histogram-gradient-boosted views.
#
# Includes:
#   Clean and natural-shift evaluation.
#   White-box-primary, surrogate-transfer, sparse-transfer attacks.
#   AC/DoC/ATC and primary-agreement estimator ablations.
#   Differential estimation error.
#   Two-profile abstention and matched-coverage risk.
#   Actual serialized bank size and measured inference latency.
#
# Results are descriptive development evidence.
# Negative results and zero-damage attacks remain in every output.
# =============================================================================

import gc
import hashlib
import json
import time
import traceback
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


# =============================================================================
# 1. FIXED SETTINGS
# =============================================================================

BASE = Path("/kaggle/working/fresh_all_datasets_v1")
OUT = BASE / "view_family_replication_v1"
OUT.mkdir(parents=True, exist_ok=True)

DATASETS = ["CICIoT2023", "CICIoMT2024", "CSE", "NSL", "TONIoT"]

VIEW_SEEDS = [10, 11, 12]
ATTACK_SEEDS = [10, 11, 12]
EPSILONS = [0.25, 0.50]

WINDOW_SIZE = 128
REFERENCE_WINDOWS = 128
TARGET_FPR = 0.05
SPARSE_K = 3
COVERAGES = [0.25, 0.50, 0.75, 0.85, 1.00]

CONFIGURATIONS = (
    [("logistic_existing", 10)]
    + [("MLP", seed) for seed in VIEW_SEEDS]
    + [("GBDT", seed) for seed in VIEW_SEEDS]
)

SETTINGS = {
    "datasets": DATASETS,
    "configurations": CONFIGURATIONS,
    "attack_seeds": ATTACK_SEEDS,
    "epsilons": EPSILONS,
    "window_size": WINDOW_SIZE,
    "reference_windows": REFERENCE_WINDOWS,
    "target_fpr": TARGET_FPR,
    "sparse_k": SPARSE_K,
    "coverages": COVERAGES,
    "MLP": {
        "hidden_layer_sizes": [32, 16],
        "alpha": 0.001,
        "max_iter": 200,
        "early_stopping": True,
        "validation_fraction": 0.10,
    },
    "GBDT": {
        "max_iter": 100,
        "max_leaf_nodes": 15,
        "learning_rate": 0.08,
        "l2_regularization": 1.0,
        "early_stopping": False,
    },
}

configuration_hash = hashlib.sha256(
    json.dumps(SETTINGS, sort_keys=True).encode()
).hexdigest()

configuration_file = OUT / "configuration.json"

if configuration_file.exists():
    previous = json.loads(configuration_file.read_text())

    if previous["configuration_sha256"] != configuration_hash:
        raise RuntimeError("Settings changed. Use a new OUT directory.")

configuration_file.write_text(json.dumps({
    "configuration_sha256": configuration_hash,
    "settings": SETTINGS,
}, indent=2))


# =============================================================================
# 2. LOCAL HELPERS
# =============================================================================

def save_csv(rows, path):
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    temporary = path.with_suffix(".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def make_model(family, seed):
    if family == "MLP":
        classifier = MLPClassifier(
            hidden_layer_sizes=(32, 16),
            alpha=0.001,
            max_iter=200,
            early_stopping=True,
            validation_fraction=0.10,
            n_iter_no_change=15,
            random_state=seed,
        )

    elif family == "GBDT":
        classifier = HistGradientBoostingClassifier(
            max_iter=100,
            max_leaf_nodes=15,
            learning_rate=0.08,
            l2_regularization=1.0,
            early_stopping=False,
            random_state=seed,
        )

    elif family == "logistic":
        classifier = LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=seed,
        )

    else:
        raise ValueError(f"Unknown model family: {family}")

    return Pipeline([
        ("imputer", SimpleImputer(
            strategy="median",
            keep_empty_features=True,
        )),
        ("scaler", StandardScaler()),
        ("classifier", classifier),
    ])


def threshold_at_fpr(probability):
    values = np.sort(np.asarray(probability))
    allowed = int(np.floor(TARGET_FPR * len(values)))

    return float(values[max(0, len(values) - allowed - 1)])


def window_indices(n, bootstrap=False, seed=1002):
    rng = np.random.default_rng(seed)

    if bootstrap:
        if n < WINDOW_SIZE:
            raise ValueError("Reference partition is smaller than one window.")

        return [
            rng.choice(n, WINDOW_SIZE, replace=False)
            for _ in range(REFERENCE_WINDOWS)
        ]

    order = rng.permutation(n)

    return [
        order[start:start + WINDOW_SIZE]
        for start in range(0, n - WINDOW_SIZE + 1, WINDOW_SIZE)
    ]


def bank_probabilities(bundle, bank, frame):
    primary = bundle["primary_model"].predict_proba(
        frame[bundle["primary_features"]]
    )[:, 1]

    views = np.vstack([
        bank["models"][view].predict_proba(frame[columns])[:, 1]
        for view, columns in bundle["semantic_views"].items()
    ])

    return primary, views


def signatures(bundle, bank, primary, views, windows):
    rows = []

    for indices in windows:
        primary_decision = (
            primary[indices] > bundle["primary_threshold"]
        )

        view_decision = (
            views[:, indices]
            > np.asarray(bank["thresholds"])[:, None]
        )

        row = [
            primary_decision.mean(),
            np.maximum(
                primary[indices], 1 - primary[indices]
            ).mean(),
        ]

        for index in range(len(views)):
            row.extend([
                view_decision[index].mean(),
                np.maximum(
                    views[index, indices],
                    1 - views[index, indices],
                ).mean(),
                (
                    view_decision[index] == primary_decision
                ).mean(),
            ])

        for left in range(len(views)):
            for right in range(left + 1, len(views)):
                row.append(
                    (
                        view_decision[left] == view_decision[right]
                    ).mean()
                )

        rows.append(row)

    return np.asarray(rows, dtype=float)


def build_profiles(bundle, bank):
    profiles = {}

    allocations = [
        (
            "normal",
            "normal_profile_fit_df",
            "normal_profile_calibration_df",
        ),
        (
            "known",
            "known_reference_df",
            "known_profile_calibration_df",
        ),
    ]

    for name, fit_key, calibration_key in allocations:
        fit_frame = bundle[fit_key]
        calibration_frame = bundle[calibration_key]

        primary, views = bank_probabilities(bundle, bank, fit_frame)

        fit_signatures = signatures(
            bundle,
            bank,
            primary,
            views,
            window_indices(len(fit_frame), True, 1003),
        )

        median = np.median(fit_signatures, axis=0)

        scale = np.maximum(
            1.4826 * np.median(
                np.abs(fit_signatures - median),
                axis=0,
            ),
            1 / WINDOW_SIZE,
        )

        primary, views = bank_probabilities(
            bundle, bank, calibration_frame
        )

        calibration_signatures = signatures(
            bundle,
            bank,
            primary,
            views,
            window_indices(len(calibration_frame), True, 1004),
        )

        scores = np.mean(
            np.abs((calibration_signatures - median) / scale),
            axis=1,
        )

        profiles[name] = (
            median,
            scale,
            max(float(np.quantile(scores, 0.95)), 1e-12),
        )

    return profiles


def support_scores(bundle, bank, primary, views, windows):
    matrix = signatures(bundle, bank, primary, views, windows)
    scores = []

    for name in ["normal", "known"]:
        median, scale, threshold = bank["profiles"][name]

        scores.append(
            np.mean(
                np.abs((matrix - median) / scale),
                axis=1,
            ) / threshold
        )

    return np.min(np.vstack(scores), axis=0)


# =============================================================================
# 3. FIXED PRIMARY-SCALE ATTACKS, IDENTICAL ACROSS VIEW FAMILIES
# =============================================================================

def make_attack(bundle, source_model, epsilon, sparse=False):
    train = bundle["train_df"]
    clean = bundle["source_test_df"]
    features = list(bundle["primary_features"])

    primary_scales = dict(zip(
        features,
        bundle["primary_model"].named_steps["scaler"].scale_,
    ))

    source_scales = source_model.named_steps["scaler"].scale_
    source_coefficients = source_model.named_steps["classifier"].coef_[0]

    gradients = dict(zip(
        features,
        source_coefficients / source_scales,
    ))

    columns = list(bundle["mutable_columns"])

    if sparse:
        columns = sorted(
            columns,
            key=lambda column: abs(
                gradients[column] * primary_scales[column]
            ),
            reverse=True,
        )[:SPARSE_K]

    attacked = clean.copy()
    malicious = clean["label"].to_numpy() == 1

    for column in columns:
        original = clean[column].to_numpy(dtype=float)
        values = train[column].dropna().to_numpy(dtype=float)
        values = values[np.isfinite(values)]

        eligible = malicious & np.isfinite(original)

        if not len(values) or not eligible.any():
            continue

        origin = original[eligible]
        budget = epsilon * primary_scales[column]
        qlow, qhigh = np.quantile(values, [0.001, 0.999])

        low = np.maximum(
            origin - budget,
            np.minimum(origin, qlow),
        )
        high = np.minimum(
            origin + budget,
            np.maximum(origin, qhigh),
        )

        candidate = np.clip(
            origin - budget * np.sign(gradients[column]),
            low,
            high,
        )

        if np.all(np.isclose(values, np.round(values), atol=1e-8)):
            rounded = np.round(candidate)

            candidate = np.where(
                (rounded >= low) & (rounded <= high),
                rounded,
                origin,
            )

        if np.any(np.abs(candidate - origin) > budget + 1e-7):
            raise AssertionError("Attack exceeded its fixed budget.")

        modified = original.copy()
        modified[eligible] = candidate
        attacked[column] = modified

    if not attacked.loc[~malicious].equals(clean.loc[~malicious]):
        raise AssertionError("Benign records changed.")

    return attacked


def prepare_attack_sources(bundle):
    sources = {}
    train = bundle["train_df"]

    for seed in ATTACK_SEEDS:
        rng = np.random.default_rng(seed)
        selected = []

        for label in [0, 1]:
            indices = np.flatnonzero(
                train["label"].to_numpy() == label
            )

            selected.extend(
                rng.choice(
                    indices,
                    max(1, int(0.50 * len(indices))),
                    replace=False,
                ).tolist()
            )

        subset = train.iloc[selected]
        model = make_model("logistic", seed)
        model.fit(subset[bundle["primary_features"]], subset["label"])
        sources[seed] = model

    return sources


# =============================================================================
# 4. CONDITIONAL ESTIMATOR ABLATIONS
#
# Agreement quantities are explicitly named as proxies.
# These are not claimed to reproduce GDE or ALine.
# =============================================================================

def estimates(bundle, bank, primary, views, reference):
    reference_primary, reference_views, reference_y = reference

    primary_decision = primary > bundle["primary_threshold"]

    view_decision = (
        views > np.asarray(bank["thresholds"])[:, None]
    )

    reference_primary_decision = (
        reference_primary > bundle["primary_threshold"]
    )

    reference_view_decision = (
        reference_views > np.asarray(bank["thresholds"])[:, None]
    )

    reference_accuracy = float(
        (reference_primary_decision == reference_y).mean()
    )

    confidence = np.maximum(primary, 1 - primary)
    reference_confidence = np.maximum(
        reference_primary, 1 - reference_primary
    )

    competence = np.clip(
        (reference_view_decision == reference_y).mean(axis=1),
        0.51,
        0.99,
    )

    competence_weights = np.maximum(
        np.log(competence / (1 - competence)),
        0.05,
    )

    drift = (
        reference_view_decision.mean(axis=1)
        - view_decision.mean(axis=1)
    )

    lower_half = drift[drift <= np.median(drift)]

    tau = max(
        0.02,
        2 * 1.4826 * np.median(
            np.abs(lower_half - np.median(lower_half))
        ),
    )

    excess = np.maximum(
        drift - np.quantile(drift, 0.20),
        0,
    )

    drift_weights = np.exp(
        -np.minimum((excess / tau) ** 2, 50)
    )

    def agreement(weights):
        vote = np.average(
            view_decision.astype(float),
            axis=0,
            weights=weights,
        ) > 0.5

        return float((vote == primary_decision).mean())

    return {
        "AC": float(confidence.mean()),
        "DoC": float(np.clip(
            reference_accuracy
            + confidence.mean()
            - reference_confidence.mean(),
            0,
            1,
        )),
        "ATC": float(
            (
                confidence >= np.quantile(
                    reference_confidence,
                    1 - reference_accuracy,
                )
            ).mean()
        ),
        "primary_view_agreement_proxy": float(
            (view_decision == primary_decision).mean()
        ),
        "MAJ_primary_agreement": agreement(np.ones(len(views))),
        "WACC_primary_agreement": agreement(competence_weights),
        "DRIFTONLY_primary_agreement": agreement(drift_weights),
        "ANCH_primary_agreement": agreement(
            competence_weights * drift_weights
        ),
    }


# =============================================================================
# 5. EXECUTE EACH DATASET/FAMILY/SEED CONFIGURATION
# =============================================================================

verification_path = (
    BASE
    / "real_data_hard_gate_spsa_v1"
    / "real_data_provenance_checks.csv"
)

if not verification_path.exists():
    raise FileNotFoundError(
        "Run the real-data provenance verification cell first."
    )

verification = pd.read_csv(verification_path)

verified_datasets = set(
    verification.loc[
        verification["status"].eq("RAW_RECORD_MATCH"),
        "dataset",
    ]
)

statuses = []

for dataset in DATASETS:
    dataset_directory = OUT / dataset
    dataset_directory.mkdir(parents=True, exist_ok=True)

    try:
        if dataset not in verified_datasets:
            raise RuntimeError(
                f"{dataset}: no prior successful raw-record verification."
            )

        bundle_path = BASE / dataset / f"{dataset}_bundle.joblib"
        bundle = joblib.load(bundle_path)

        bundle_hash = hashlib.sha256(
            bundle_path.read_bytes()
        ).hexdigest()

        source = bundle["source_test_df"]
        source_windows = window_indices(len(source))
        attack_sources = prepare_attack_sources(bundle)

        for family, view_seed in CONFIGURATIONS:
            directory = dataset_directory / f"{family}_seed_{view_seed}"
            directory.mkdir(parents=True, exist_ok=True)

            completion = directory / "completion.json"

            if completion.exists():
                saved = json.loads(completion.read_text())

                if saved["bundle_sha256"] != bundle_hash:
                    raise RuntimeError(
                        "Dataset bundle changed. Use a new output directory."
                    )

                if all(
                    (directory / filename).exists()
                    for filename in [
                        "condition_summary.csv",
                        "estimator_summary.csv",
                        "risk_coverage.csv",
                        "resources.csv",
                    ]
                ):
                    print(
                        dataset,
                        family,
                        f"seed={view_seed}",
                        "already complete",
                        flush=True,
                    )
                    continue

            print("\n" + "=" * 90)
            print(
                f"RUNNING {dataset}: {family}, view_seed={view_seed}"
            )
            print("=" * 90, flush=True)

            training_start = time.perf_counter()

            if family == "logistic_existing":
                models = dict(bundle["view_models"])

            else:
                models = {}

                for view, columns in bundle["semantic_views"].items():
                    model = make_model(family, view_seed)

                    model.fit(
                        bundle["train_df"][columns],
                        bundle["train_df"]["label"],
                    )

                    models[view] = model

                    print(
                        dataset,
                        family,
                        f"view={view}",
                        "trained",
                        flush=True,
                    )

            training_seconds = time.perf_counter() - training_start

            thresholds = [
                threshold_at_fpr(
                    models[view].predict_proba(
                        bundle["view_threshold_df"][columns]
                    )[:, 1]
                )
                for view, columns in bundle["semantic_views"].items()
            ]

            bank = {
                "models": models,
                "thresholds": thresholds,
            }

            bank["profiles"] = build_profiles(bundle, bank)

            bank_path = directory / "view_bank.joblib"
            joblib.dump(bank, bank_path, compress=3)

            reference_frame = bundle["known_reference_df"]

            reference_primary, reference_views = bank_probabilities(
                bundle, bank, reference_frame
            )

            reference = (
                reference_primary,
                reference_views,
                reference_frame["label"].to_numpy(),
            )

            # Model-quality screening; never used to select views post hoc.
            quality_rows = []

            for index, (view, columns) in enumerate(
                bundle["semantic_views"].items()
            ):
                probability = models[view].predict_proba(
                    source[columns]
                )[:, 1]

                prediction = probability > thresholds[index]

                quality_rows.append({
                    "dataset": dataset,
                    "family": family,
                    "view_seed": view_seed,
                    "view": view,
                    "features": len(columns),
                    "source_accuracy": float(
                        (prediction == source["label"].to_numpy()).mean()
                    ),
                    "source_balanced_accuracy": float(
                        balanced_accuracy_score(
                            source["label"], prediction
                        )
                    ),
                })

            save_csv(quality_rows, directory / "view_quality.csv")

            window_rows = []
            estimator_rows = []
            risk_rows = []
            clean_errors = {}

            def evaluate(frame, condition, attack_seed, paired):
                primary, views = bank_probabilities(
                    bundle, bank, frame
                )

                windows = (
                    source_windows
                    if paired
                    else window_indices(len(frame))
                )

                if not windows:
                    return

                labels = frame["label"].to_numpy()
                scores = support_scores(
                    bundle, bank, primary, views, windows
                )

                accuracy = np.asarray([
                    (
                        (primary[indices] > bundle["primary_threshold"])
                        == labels[indices]
                    ).mean()
                    for indices in windows
                ])

                confidence_scores = np.asarray([
                    -np.maximum(
                        primary[indices], 1 - primary[indices]
                    ).mean()
                    for indices in windows
                ])

                for window, indices in enumerate(windows):
                    estimated = estimates(
                        bundle,
                        bank,
                        primary[indices],
                        views[:, indices],
                        reference,
                    )

                    window_rows.append({
                        "dataset": dataset,
                        "family": family,
                        "view_seed": view_seed,
                        "condition": condition,
                        "attack_seed": attack_seed,
                        "window": window,
                        "primary_accuracy": float(accuracy[window]),
                        "support_score": float(scores[window]),
                        "trusted": int(scores[window] <= 1),
                    })

                    for estimator, estimate in estimated.items():
                        error = estimate - accuracy[window]

                        if condition == "clean_source":
                            clean_errors[(estimator, window)] = error

                        differential = (
                            error - clean_errors[(estimator, window)]
                            if paired
                            else np.nan
                        )

                        estimator_rows.append({
                            "dataset": dataset,
                            "family": family,
                            "view_seed": view_seed,
                            "condition": condition,
                            "attack_seed": attack_seed,
                            "window": window,
                            "estimator": estimator,
                            "estimated_accuracy": estimate,
                            "true_accuracy": float(accuracy[window]),
                            "signed_error": float(error),
                            "differential_absolute_error": (
                                float(abs(differential))
                                if paired
                                else np.nan
                            ),
                        })

                for ranking_name, ranking_scores in [
                    ("two_profile_support", scores),
                    ("primary_confidence", confidence_scores),
                ]:
                    order = np.argsort(ranking_scores, kind="stable")

                    for coverage in COVERAGES:
                        count = max(
                            1, int(np.ceil(coverage * len(order)))
                        )
                        retained = order[:count]

                        risk_rows.append({
                            "dataset": dataset,
                            "family": family,
                            "view_seed": view_seed,
                            "condition": condition,
                            "attack_seed": attack_seed,
                            "ranking": ranking_name,
                            "target_coverage": coverage,
                            "actual_coverage": count / len(order),
                            "trusted_risk": float(
                                1 - accuracy[retained].mean()
                            ),
                        })

            evaluate(source, "clean_source", -1, paired=True)

            for domain, frame in bundle["evaluation_domains"].items():
                evaluate(
                    frame,
                    domain,
                    -1,
                    paired=False,
                )

            for attack_seed in ATTACK_SEEDS:
                for epsilon in EPSILONS:
                    for attack_name in [
                        "whitebox_primary",
                        "surrogate_transfer",
                        "sparse_transfer",
                    ]:
                        attack_model = (
                            bundle["primary_model"]
                            if attack_name == "whitebox_primary"
                            else attack_sources[attack_seed]
                        )

                        attacked = make_attack(
                            bundle,
                            attack_model,
                            epsilon,
                            sparse=attack_name == "sparse_transfer",
                        )

                        evaluate(
                            attacked,
                            f"{attack_name}_eps_{epsilon:.2f}",
                            attack_seed,
                            paired=True,
                        )

                        del attacked

            windows_frame = pd.DataFrame(window_rows)
            estimators_frame = pd.DataFrame(estimator_rows)

            save_csv(
                windows_frame,
                directory / "window_results.csv",
            )
            save_csv(
                estimators_frame,
                directory / "estimator_results.csv",
            )
            save_csv(
                risk_rows,
                directory / "risk_coverage.csv",
            )

            condition_summary = (
                windows_frame
                .groupby([
                    "dataset", "family", "view_seed", "condition"
                ])
                .agg(
                    primary_accuracy=("primary_accuracy", "mean"),
                    trusted_coverage=("trusted", "mean"),
                    mean_support_score=("support_score", "mean"),
                )
                .reset_index()
            )

            save_csv(
                condition_summary,
                directory / "condition_summary.csv",
            )

            estimator_summary = (
                estimators_frame
                .groupby([
                    "dataset", "family", "view_seed",
                    "condition", "estimator",
                ])
                .agg(
                    estimated_accuracy=("estimated_accuracy", "mean"),
                    true_accuracy=("true_accuracy", "mean"),
                    signed_error=("signed_error", "mean"),
                    differential_absolute_error=(
                        "differential_absolute_error", "mean"
                    ),
                )
                .reset_index()
            )

            save_csv(
                estimator_summary,
                directory / "estimator_summary.csv",
            )

            # Resource measurement includes primary + views + support scoring.
            sample = source.iloc[:min(1024, len(source))].copy()
            measurement_windows = window_indices(len(sample))

            primary, views = bank_probabilities(bundle, bank, sample)
            support_scores(
                bundle, bank, primary, views, measurement_windows
            )

            timings = []

            for _ in range(5):
                started = time.perf_counter()

                primary, views = bank_probabilities(
                    bundle, bank, sample
                )
                support_scores(
                    bundle, bank, primary, views, measurement_windows
                )

                timings.append(time.perf_counter() - started)

            # Identical output fingerprints reveal deterministic repetitions.
            source_primary, source_views = bank_probabilities(
                bundle, bank, source
            )

            prediction_hash = hashlib.sha256(
                np.round(source_views, 10).tobytes()
            ).hexdigest()

            save_csv([{
                "dataset": dataset,
                "family": family,
                "view_seed": view_seed,
                "training_seconds": training_seconds,
                "compressed_bank_bytes": bank_path.stat().st_size,
                "primary_views_monitor_ms_per_1000": (
                    np.median(timings) * 1000 * 1000 / len(sample)
                ),
                "source_view_probability_sha256": prediction_hash,
                "energy_measured": False,
            }], directory / "resources.csv")

            completion.write_text(json.dumps({
                "dataset": dataset,
                "family": family,
                "view_seed": view_seed,
                "bundle_sha256": bundle_hash,
                "configuration_sha256": configuration_hash,
                "status": "DEVELOPMENT_CONFIGURATION_COMPLETE",
            }, indent=2))

            print(
                dataset,
                family,
                f"seed={view_seed}",
                "COMPLETE",
                flush=True,
            )

            del bank, models
            gc.collect()

        statuses.append({
            "dataset": dataset,
            "status": "VIEW_FAMILY_REPLICATION_COMPLETE",
            "detail": "",
        })

    except Exception as error:
        statuses.append({
            "dataset": dataset,
            "status": "FAILED",
            "detail": str(error),
        })

        (dataset_directory / "error.txt").write_text(
            traceback.format_exc()
        )

        print(f"{dataset}: FAILED: {error}", flush=True)

    save_csv(statuses, OUT / "dataset_status.csv")


# =============================================================================
# 6. CONSOLIDATE ALL DATASETS — NO CHERRY-PICKING
# =============================================================================

successful = {
    row["dataset"]
    for row in statuses
    if row["status"] == "VIEW_FAMILY_REPLICATION_COMPLETE"
}

for filename in [
    "condition_summary.csv",
    "estimator_summary.csv",
    "risk_coverage.csv",
    "resources.csv",
    "view_quality.csv",
]:
    frames = []

    for dataset in sorted(successful):
        for family, seed in CONFIGURATIONS:
            path = (
                OUT
                / dataset
                / f"{family}_seed_{seed}"
                / filename
            )

            if path.exists():
                frames.append(pd.read_csv(path))

    if frames:
        save_csv(
            pd.concat(frames, ignore_index=True),
            OUT / f"all_datasets_{filename}",
        )

resource_file = OUT / "all_datasets_resources.csv"

if resource_file.exists():
    resources = pd.read_csv(resource_file)

    diversity = (
        resources
        .groupby(["dataset", "family"])
        .agg(
            recorded_seeds=("view_seed", "nunique"),
            distinct_prediction_fingerprints=(
                "source_view_probability_sha256", "nunique"
            ),
        )
        .reset_index()
    )

    save_csv(
        diversity,
        OUT / "effective_prediction_diversity.csv",
    )

protocol = {
    "data": "Existing real-data bundles; prior sampled raw-record verification required",
    "primary_detector": "Unchanged across all view-family comparisons",
    "view_families": ["logistic_existing", "MLP", "GBDT"],
    "attack_budgets": "Fixed primary-model training scales",
    "attack_inputs": "Identical across view families for each attack setting",
    "profile_calibration": "Existing disjoint reference allocations only",
    "results": "Descriptive development evidence",
    "limitations": [
        "No test-based selection of models, views, or thresholds",
        "Agreement estimators are explicitly named proxies",
        "Shared source split is not independent dataset replication",
        "Deterministic GBDT seed repetitions may have identical predictions",
        "Matched coverage is ranking analysis, not deployment calibration",
        "No packet-validity claim",
        "No energy or hardware-specific edge deployment claim",
        "No confirmatory p-values or clustered confidence intervals",
        "Zero-damage attacks do not establish successful-collapse detection",
        "All negative results remain in the consolidated outputs",
    ],
}

(OUT / "protocol.json").write_text(
    json.dumps(protocol, indent=2)
)

print("\n" + "=" * 90)
print("ALL-DATASET VIEW-FAMILY REPLICATION STATUS")
print("=" * 90)
print(pd.DataFrame(statuses).to_string(index=False))

summary_file = OUT / "all_datasets_condition_summary.csv"

if summary_file.exists():
    summary = pd.read_csv(summary_file)

    display_table = (
        summary
        .groupby(["dataset", "family", "condition"])
        .agg(
            primary_accuracy=("primary_accuracy", "mean"),
            trusted_coverage=("trusted_coverage", "mean"),
            mean_support_score=("mean_support_score", "mean"),
        )
        .reset_index()
    )

    print("\nVIEW-FAMILY CLEAN / SHIFT / ATTACK SUMMARY")
    print(display_table.round(4).to_string(index=False))