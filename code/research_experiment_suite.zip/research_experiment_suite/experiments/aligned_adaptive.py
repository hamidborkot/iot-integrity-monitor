# =============================================================================
# ADAPTIVE RE-EVALUATION AGAINST THE ALIGNED GATES
#
# All five REAL datasets; all seven saved view-bank configurations.
# Models, reference profiles, thresholds, and attack budgets remain fixed.
#
# Includes:
#   Fresh SPSA queries against each aligned monitor.
#   Per-window linear-detector reachability bounds.
#   Explicit query counts and skipped-window reasons.
#   Best observed trusted-damage candidates.
#   Existing clean-calibration failures retained.
#
# Attack scope:
#   Shared mutable-feature offsets within each window.
#   Only malicious records are modified.
#   Primary-model training scales define all budgets.
#   Range/type feature-space constraints, not packet validity.
#
# No synthetic data. No test-based threshold adjustment.
# No claim of global adaptive optimality or confirmatory inference.
# =============================================================================

import hashlib
import json
import traceback
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


# =============================================================================
# 1. SETTINGS
# =============================================================================

RG_BASE = Path("/kaggle/working/fresh_all_datasets_v1")
RG_CAL = RG_BASE / "reference_mixture_calibration_audit_v1"
RG_OUT = RG_BASE / "aligned_gate_adaptive_evaluation_v1"
RG_OUT.mkdir(parents=True, exist_ok=True)

RG_DATASETS = [
    "CICIoT2023", "CICIoMT2024", "CSE", "NSL", "TONIoT"
]

RG_CONFIGURATIONS = (
    [("logistic_existing", 10)]
    + [("MLP", seed) for seed in [10, 11, 12]]
    + [("GBDT", seed) for seed in [10, 11, 12]]
)

RG_SEARCH_SEEDS = [10, 11, 12]
RG_EPSILONS = [0.25, 0.50]
RG_LAMBDAS = [0.25, 1.0]

RG_WINDOW_SIZE = 128
RG_STEPS = 30
RG_RESTARTS = 2
RG_STEP_SIZE = 0.15
RG_PROBE_SIZE = 0.10
RG_COLLAPSE_DAMAGE = 0.05

RG_SETTINGS = {
    "datasets": RG_DATASETS,
    "configurations": RG_CONFIGURATIONS,
    "search_seeds": RG_SEARCH_SEEDS,
    "epsilons": RG_EPSILONS,
    "lambdas": RG_LAMBDAS,
    "window_size": RG_WINDOW_SIZE,
    "steps": RG_STEPS,
    "restarts": RG_RESTARTS,
    "step_size": RG_STEP_SIZE,
    "probe_size": RG_PROBE_SIZE,
    "collapse_damage": RG_COLLAPSE_DAMAGE,
    "attack_parameterization": "Shared per-window offsets",
    "skip_rule": (
        "Skip SPSA only when the wider per-record box/type "
        "damage upper bound is below the collapse threshold"
    ),
}

RG_SETTINGS_HASH = hashlib.sha256(
    json.dumps(RG_SETTINGS, sort_keys=True).encode()
).hexdigest()

settings_file = RG_OUT / "settings.json"

if settings_file.exists():
    saved = json.loads(settings_file.read_text())

    if saved["settings_sha256"] != RG_SETTINGS_HASH:
        raise RuntimeError("Settings changed. Use a new RG_OUT directory.")

settings_file.write_text(json.dumps({
    "settings_sha256": RG_SETTINGS_HASH,
    "settings": RG_SETTINGS,
}, indent=2))


# =============================================================================
# 2. SELF-CONTAINED HELPERS
# =============================================================================

def rg_save(rows, path):
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    temporary = path.with_suffix(".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def rg_predict(bundle, bank, frame):
    primary = bundle["primary_model"].predict_proba(
        frame[bundle["primary_features"]]
    )[:, 1]

    views = np.vstack([
        bank["models"][view].predict_proba(frame[columns])[:, 1]
        for view, columns in bundle["semantic_views"].items()
    ])

    return primary, views


def rg_gate(bundle, bank, primary, views):
    count = len(primary) // RG_WINDOW_SIZE

    p = primary.reshape(count, RG_WINDOW_SIZE)
    v = views.reshape(len(views), count, RG_WINDOW_SIZE)

    primary_decision = p > bundle["primary_threshold"]
    view_decision = (
        v > np.asarray(bank["thresholds"])[:, None, None]
    )

    columns = [
        primary_decision.mean(axis=1),
        np.maximum(p, 1 - p).mean(axis=1),
    ]

    for index in range(len(views)):
        columns.extend([
            view_decision[index].mean(axis=1),
            np.maximum(v[index], 1 - v[index]).mean(axis=1),
            (
                view_decision[index] == primary_decision
            ).mean(axis=1),
        ])

    for left in range(len(views)):
        for right in range(left + 1, len(views)):
            columns.append(
                (
                    view_decision[left] == view_decision[right]
                ).mean(axis=1)
            )

    matrix = np.column_stack(columns)
    scores = []

    for profile in ["normal", "known"]:
        median, scale, threshold = bank["profiles"][profile]

        scores.append(
            np.mean(
                np.abs((matrix - median) / scale),
                axis=1,
            ) / threshold
        )

    return np.min(np.vstack(scores), axis=0)


def rg_context(bundle, epsilon):
    source = bundle["source_test_df"]

    order = np.random.default_rng(1002).permutation(len(source))
    usable = len(source) // RG_WINDOW_SIZE * RG_WINDOW_SIZE

    if not usable:
        raise ValueError("No complete real-data evaluation windows.")

    frame = source.iloc[order[:usable]].reset_index(drop=True).copy()

    features = list(bundle["primary_features"])
    mutable = list(bundle["mutable_columns"])

    primary = bundle["primary_model"]
    scaler = primary.named_steps["scaler"]
    classifier = primary.named_steps["classifier"]

    positions = [features.index(column) for column in mutable]
    scales = scaler.scale_[positions]
    coefficients = classifier.coef_[0, positions]

    original = frame[mutable].to_numpy(dtype=float)
    low = original.copy()
    high = original.copy()
    integer_columns = []

    for index, column in enumerate(mutable):
        values = bundle["train_df"][column].dropna().to_numpy(
            dtype=float
        )
        values = values[np.isfinite(values)]

        if not len(values):
            raise ValueError(f"No finite training values for {column}.")

        qlow, qhigh = np.quantile(values, [0.001, 0.999])
        budget = epsilon * scales[index]

        low[:, index] = np.maximum(
            original[:, index] - budget,
            np.minimum(original[:, index], qlow),
        )
        high[:, index] = np.minimum(
            original[:, index] + budget,
            np.maximum(original[:, index], qhigh),
        )

        integer_columns.append(
            bool(np.all(np.isclose(
                values, np.round(values), atol=1e-8
            )))
        )

    labels = frame["label"].to_numpy(dtype=int)

    clean_probability = primary.predict_proba(
        frame[features]
    )[:, 1]

    clean_accuracy = (
        (clean_probability > bundle["primary_threshold"]) == labels
    ).reshape(-1, RG_WINDOW_SIZE).mean(axis=1)

    return {
        "frame": frame,
        "original": original,
        "low": low,
        "high": high,
        "integer_columns": integer_columns,
        "mutable": mutable,
        "scales": scales,
        "coefficients": coefficients,
        "labels": labels,
        "epsilon": epsilon,
        "windows": usable // RG_WINDOW_SIZE,
        "clean_accuracy": clean_accuracy,
    }


def rg_attack_frame(context, offsets):
    repeated = np.repeat(offsets, RG_WINDOW_SIZE, axis=0)

    proposed = (
        context["original"]
        + repeated * context["scales"][None, :]
    )

    values = np.clip(
        proposed,
        context["low"],
        context["high"],
    )

    for index, integer in enumerate(context["integer_columns"]):
        if integer:
            rounded = np.round(values[:, index])

            feasible = (
                (rounded >= context["low"][:, index])
                & (rounded <= context["high"][:, index])
            )

            values[:, index] = np.where(
                feasible,
                rounded,
                context["original"][:, index],
            )

    eligible = (
        (context["labels"] == 1)[:, None]
        & np.isfinite(context["original"])
    )

    values = np.where(
        eligible, values, context["original"]
    )

    displacement = np.abs(values - context["original"])
    budget = (
        context["epsilon"] * context["scales"][None, :]
    )

    if np.any(eligible & (displacement > budget + 1e-7)):
        raise AssertionError("Perturbation budget violation.")

    attacked = context["frame"].copy()
    attacked[context["mutable"]] = values

    benign = context["labels"] == 0

    if not attacked.loc[benign].equals(
        context["frame"].loc[benign]
    ):
        raise AssertionError("Benign records changed.")

    return attacked


def rg_damage_upper_bound(bundle, context):
    # Wider per-record box/type threat set.
    # Therefore also an upper bound for shared-window-offset attacks.
    gradients = (
        context["coefficients"] / context["scales"]
    )

    optimum = np.where(
        gradients[None, :] >= 0,
        context["low"],
        context["high"],
    )

    for index, integer in enumerate(context["integer_columns"]):
        if not integer:
            continue

        lower = np.ceil(context["low"][:, index])
        upper = np.floor(context["high"][:, index])

        candidate = (
            lower if gradients[index] >= 0 else upper
        )

        candidate = np.where(
            lower <= upper,
            candidate,
            context["original"][:, index],
        )

        improvement = (
            gradients[index]
            * (candidate - context["original"][:, index])
            <= 0
        )

        optimum[:, index] = np.where(
            improvement,
            candidate,
            context["original"][:, index],
        )

    eligible = (
        (context["labels"] == 1)[:, None]
        & np.isfinite(context["original"])
    )

    optimum = np.where(
        eligible, optimum, context["original"]
    )

    attacked = context["frame"].copy()
    attacked[context["mutable"]] = optimum

    probability = bundle["primary_model"].predict_proba(
        attacked[bundle["primary_features"]]
    )[:, 1]

    minimum_accuracy = (
        (
            probability > bundle["primary_threshold"]
        ) == context["labels"]
    ).reshape(-1, RG_WINDOW_SIZE).mean(axis=1)

    return context["clean_accuracy"] - minimum_accuracy


def rg_evaluate(bundle, bank, context, offsets, lambda_value):
    frame = rg_attack_frame(context, offsets)

    primary, views = rg_predict(bundle, bank, frame)
    scores = rg_gate(bundle, bank, primary, views)

    malicious = (
        context["labels"] == 1
    ).reshape(context["windows"], RG_WINDOW_SIZE)

    p = primary.reshape(
        context["windows"], RG_WINDOW_SIZE
    )

    evasion = ((1 - p) * malicious).mean(axis=1)

    # Exact hard abstention decision, not a smooth gate surrogate.
    objective = (
        evasion
        - lambda_value * (scores > 1).astype(float)
    )

    accuracy = (
        (primary > bundle["primary_threshold"])
        == context["labels"]
    ).reshape(-1, RG_WINDOW_SIZE).mean(axis=1)

    return objective, scores, accuracy


# =============================================================================
# 3. FRESH SEARCH AGAINST THE REVISED MONITOR
# =============================================================================

def rg_search(bundle, bank, context, seed, lambda_value, upper_bound):
    rng = np.random.default_rng(seed)

    shape = (context["windows"], len(context["mutable"]))

    best_objective = np.full(context["windows"], -np.inf)
    best_score = np.full(context["windows"], np.nan)
    best_accuracy = np.full(context["windows"], np.nan)
    best_offsets = np.zeros(shape)

    trusted_found = np.zeros(context["windows"], dtype=bool)
    best_trusted_damage = np.full(context["windows"], np.nan)
    best_trusted_offsets = np.zeros(shape)

    query_counts = np.zeros(context["windows"], dtype=int)

    active = upper_bound >= RG_COLLAPSE_DAMAGE - 1e-12

    def record(offsets, objective, scores, accuracy):
        improve = objective > best_objective

        best_objective[improve] = objective[improve]
        best_score[improve] = scores[improve]
        best_accuracy[improve] = accuracy[improve]
        best_offsets[improve] = offsets[improve]

        damage = context["clean_accuracy"] - accuracy
        feasible = scores <= 1

        better_trusted = feasible & (
            ~trusted_found
            | (damage > np.nan_to_num(
                best_trusted_damage, nan=-np.inf
            ))
        )

        best_trusted_damage[better_trusted] = damage[better_trusted]
        best_trusted_offsets[better_trusted] = offsets[better_trusted]
        trusted_found[better_trusted] = True

    # Query the actual revised gate at clean and primary-evasion corners.
    initializations = [
        np.zeros(shape),
        np.tile(
            -context["epsilon"] * np.sign(context["coefficients"]),
            (context["windows"], 1),
        ),
    ]

    for offsets in initializations:
        objective, scores, accuracy = rg_evaluate(
            bundle, bank, context, offsets, lambda_value
        )
        query_counts += 1
        record(offsets, objective, scores, accuracy)

    if active.any():
        for restart in range(RG_RESTARTS):
            offsets = initializations[restart].copy()

            for step in range(RG_STEPS):
                direction = rng.choice([-1.0, 1.0], size=shape)
                direction[~active] = 0

                probe = (
                    RG_PROBE_SIZE * context["epsilon"]
                    / (step + 1) ** 0.101
                )

                positive = np.clip(
                    offsets + probe * direction,
                    -context["epsilon"],
                    context["epsilon"],
                )
                negative = np.clip(
                    offsets - probe * direction,
                    -context["epsilon"],
                    context["epsilon"],
                )

                # Inactive windows stay fixed; their repeated evaluations
                # below are computation, not additional adaptive searches.
                positive[~active] = best_offsets[~active]
                negative[~active] = best_offsets[~active]

                plus_objective, plus_score, plus_accuracy = rg_evaluate(
                    bundle, bank, context, positive, lambda_value
                )
                minus_objective, minus_score, minus_accuracy = rg_evaluate(
                    bundle, bank, context, negative, lambda_value
                )

                query_counts += 2
                record(
                    positive, plus_objective, plus_score, plus_accuracy
                )
                record(
                    negative, minus_objective, minus_score, minus_accuracy
                )

                gradient = (
                    (plus_objective - minus_objective)[:, None]
                    / (2 * probe)
                ) * direction

                learning_rate = (
                    RG_STEP_SIZE * context["epsilon"]
                    / (step + 1) ** 0.602
                )

                offsets = np.clip(
                    offsets + learning_rate * np.sign(gradient),
                    -context["epsilon"],
                    context["epsilon"],
                )

                offsets[~active] = best_offsets[~active]

                objective, scores, accuracy = rg_evaluate(
                    bundle, bank, context, offsets, lambda_value
                )

                query_counts += 1
                record(offsets, objective, scores, accuracy)

    return {
        "score": best_score,
        "accuracy": best_accuracy,
        "offsets": best_offsets,
        "trusted_found": trusted_found,
        "best_trusted_damage": best_trusted_damage,
        "best_trusted_offsets": best_trusted_offsets,
        "queries": query_counts,
        "searched": active,
    }


# =============================================================================
# 4. EXECUTE ALL DATASETS / BANKS
# =============================================================================

clean_path = RG_CAL / "clean_calibration_gate_results.csv"

if not clean_path.exists():
    raise FileNotFoundError(clean_path)

clean_audit = pd.read_csv(clean_path)

all_rows = []
status_rows = []

for dataset in RG_DATASETS:
    dataset_out = RG_OUT / dataset
    dataset_out.mkdir(parents=True, exist_ok=True)

    try:
        bundle_path = (
            RG_BASE / dataset / f"{dataset}_bundle.joblib"
        )
        bundle = joblib.load(bundle_path)

        bundle_hash = hashlib.sha256(
            bundle_path.read_bytes()
        ).hexdigest()

        contexts = {
            epsilon: rg_context(bundle, epsilon)
            for epsilon in RG_EPSILONS
        }

        bounds = {
            epsilon: rg_damage_upper_bound(bundle, context)
            for epsilon, context in contexts.items()
        }

        for family, view_seed in RG_CONFIGURATIONS:
            bank_path = (
                RG_CAL
                / dataset
                / f"{family}_seed_{view_seed}"
                / "aligned_view_bank.joblib"
            )

            bank = joblib.load(bank_path)

            bank_hash = hashlib.sha256(
                bank_path.read_bytes()
            ).hexdigest()

            clean_row = clean_audit[
                clean_audit["dataset"].eq(dataset)
                & clean_audit["family"].eq(family)
                & clean_audit["view_seed"].eq(view_seed)
                & clean_audit["profile_version"].eq(
                    "training_mixture_aligned"
                )
            ]

            if len(clean_row) != 1:
                raise ValueError("Missing or ambiguous clean-calibration result.")

            clean_gate_pass = int(
                clean_row.iloc[0]["clean_calibration_gate_pass"]
            )

            directory = (
                dataset_out / f"{family}_seed_{view_seed}"
            )
            directory.mkdir(parents=True, exist_ok=True)

            fingerprint = {
                "settings_sha256": RG_SETTINGS_HASH,
                "bundle_sha256": bundle_hash,
                "bank_sha256": bank_hash,
            }

            fingerprint_path = directory / "artifact_fingerprint.json"

            if fingerprint_path.exists():
                if json.loads(fingerprint_path.read_text()) != fingerprint:
                    raise RuntimeError(
                        "Saved inputs changed. Use a new output directory."
                    )

            fingerprint_path.write_text(
                json.dumps(fingerprint, indent=2)
            )

            for epsilon in RG_EPSILONS:
                context = contexts[epsilon]
                upper_bound = bounds[epsilon]

                for search_seed in RG_SEARCH_SEEDS:
                    for lambda_value in RG_LAMBDAS:
                        checkpoint = directory / (
                            f"eps_{epsilon:.2f}"
                            f"_search_{search_seed}"
                            f"_lambda_{lambda_value:.2f}.csv"
                        )

                        if checkpoint.exists():
                            all_rows.extend(
                                pd.read_csv(checkpoint).to_dict("records")
                            )
                            continue

                        result = rg_search(
                            bundle,
                            bank,
                            context,
                            search_seed,
                            lambda_value,
                            upper_bound,
                        )

                        damage = (
                            context["clean_accuracy"]
                            - result["accuracy"]
                        )

                        rows = []

                        for window in range(context["windows"]):
                            found = bool(result["trusted_found"][window])
                            trusted_damage = (
                                float(result["best_trusted_damage"][window])
                                if found
                                else np.nan
                            )

                            rows.append({
                                "dataset": dataset,
                                "family": family,
                                "view_seed": view_seed,
                                "epsilon": epsilon,
                                "search_seed": search_seed,
                                "lambda": lambda_value,
                                "window": window,
                                "clean_calibration_pass": clean_gate_pass,
                                "clean_accuracy": float(
                                    context["clean_accuracy"][window]
                                ),
                                "attacked_accuracy": float(
                                    result["accuracy"][window]
                                ),
                                "objective_selected_damage": float(
                                    damage[window]
                                ),
                                "objective_selected_support": float(
                                    result["score"][window]
                                ),
                                "objective_selected_trusted": int(
                                    result["score"][window] <= 1
                                ),
                                "box_type_damage_upper_bound": float(
                                    upper_bound[window]
                                ),
                                "spsa_search_performed": int(
                                    result["searched"][window]
                                ),
                                "collapse_unreachable_under_box_bound": int(
                                    upper_bound[window]
                                    < RG_COLLAPSE_DAMAGE - 1e-12
                                ),
                                "trusted_candidate_found": int(found),
                                "best_observed_trusted_damage": trusted_damage,
                                "hidden_collapse_found": int(
                                    found
                                    and trusted_damage
                                    >= RG_COLLAPSE_DAMAGE
                                ),
                                "window_oracle_evaluations": int(
                                    result["queries"][window]
                                ),
                            })

                        rg_save(rows, checkpoint)
                        all_rows.extend(rows)

                        np.savez_compressed(
                            checkpoint.with_suffix(".npz"),
                            objective_selected_offsets=result["offsets"],
                            best_trusted_offsets=result["best_trusted_offsets"],
                            trusted_candidate_found=result["trusted_found"],
                            source_row_ids=context["frame"][
                                "_row_id"
                            ].to_numpy(dtype=str),
                            mutable_columns=np.asarray(
                                context["mutable"], dtype=str
                            ),
                        )

                        print(
                            dataset,
                            family,
                            f"view_seed={view_seed}",
                            f"eps={epsilon}",
                            f"search_seed={search_seed}",
                            f"lambda={lambda_value}",
                            f"damage={damage.mean():.4f}",
                            "trusted="
                            f"{(result['score'] <= 1).mean():.4f}",
                            "hidden_collapse="
                            f"{np.mean([
                                row['hidden_collapse_found']
                                for row in rows
                            ]):.4f}",
                            flush=True,
                        )

                        rg_save(
                            all_rows,
                            RG_OUT / "all_window_results.csv",
                        )

        status_rows.append({
            "dataset": dataset,
            "status": "ALIGNED_GATE_ADAPTIVE_EVALUATION_COMPLETE",
            "detail": "",
        })

    except Exception as error:
        status_rows.append({
            "dataset": dataset,
            "status": "FAILED",
            "detail": str(error),
        })

        (dataset_out / "error.txt").write_text(
            traceback.format_exc()
        )

        print(f"{dataset}: FAILED: {error}", flush=True)

    rg_save(status_rows, RG_OUT / "dataset_status.csv")


# =============================================================================
# 5. COMPLETE TABLES — ALL POSITIVE AND NEGATIVE RESULTS
# =============================================================================

if all_rows:
    results = pd.DataFrame(all_rows)
    rg_save(results, RG_OUT / "all_window_results.csv")

    summary = (
        results
        .groupby([
            "dataset", "family", "view_seed", "epsilon", "lambda"
        ])
        .agg(
            clean_calibration_pass=("clean_calibration_pass", "first"),
            objective_selected_damage=(
                "objective_selected_damage", "mean"
            ),
            trusted_coverage=(
                "objective_selected_trusted", "mean"
            ),
            trusted_candidate_fraction=(
                "trusted_candidate_found", "mean"
            ),
            best_observed_trusted_damage=(
                "best_observed_trusted_damage", "mean"
            ),
            hidden_collapse_fraction=(
                "hidden_collapse_found", "mean"
            ),
            box_unreachable_fraction=(
                "collapse_unreachable_under_box_bound", "mean"
            ),
            searched_window_fraction=(
                "spsa_search_performed", "mean"
            ),
            max_window_oracle_evaluations=(
                "window_oracle_evaluations", "max"
            ),
        )
        .reset_index()
    )

    rg_save(summary, RG_OUT / "configuration_summary.csv")

    # Search seeds are repeated searches, not independent model/data units.
    candidate_frontier = (
        results
        .groupby([
            "dataset", "family", "view_seed", "epsilon", "window"
        ])
        .agg(
            clean_calibration_pass=("clean_calibration_pass", "first"),
            box_type_damage_upper_bound=(
                "box_type_damage_upper_bound", "first"
            ),
            any_trusted_candidate=("trusted_candidate_found", "max"),
            maximum_observed_trusted_damage=(
                "best_observed_trusted_damage", "max"
            ),
            any_hidden_collapse=("hidden_collapse_found", "max"),
        )
        .reset_index()
    )

    rg_save(
        candidate_frontier,
        RG_OUT / "combined_search_window_frontier.csv",
    )

    print("\n" + "=" * 90)
    print("ALIGNED-GATE ADAPTIVE EVALUATION")
    print("=" * 90)
    print(summary.round(4).to_string(index=False))

protocol = {
    "experiment": "Fresh adaptive evaluation of aligned gates",
    "settings_sha256": RG_SETTINGS_HASH,
    "real_data_only": True,
    "models_and_thresholds": "Frozen before this evaluation",
    "objective": "Soft evasion minus exact hard-gate alarm penalty",
    "attack_parameterization": "Shared mutable-feature offset per window",
    "bound": "Wider per-record linear-detector box/type reachability bound",
    "query_accounting": (
        "Counts every evaluated window, including repeated fixed "
        "inactive windows; search status is recorded separately"
    ),
    "candidate_frontier": (
        "Best observed trusted damage across encountered candidates; "
        "not an optimality certificate"
    ),
    "clean_calibration_failures": "Retained without threshold changes",
    "limitations": [
        "Development evaluation, not confirmation",
        "No synthetic feature vectors or generated labels",
        "No packet-semantic validity claim",
        "Search seeds are not independent model or dataset replications",
        "The box bound can prove collapse unreachable only in its stated threat set",
        "Failure to find a hidden attack is not proof of adaptive robustness",
        "NaN trusted damage means no trusted candidate was found",
        "Negative signed damage is retained",
        "No clean-calibration failure is converted into a passing result",
    ],
}

(RG_OUT / "protocol.json").write_text(
    json.dumps(protocol, indent=2)
)

print("\nDATASET STATUS")
print(pd.DataFrame(status_rows).to_string(index=False))