# Manifests

Upload result provenance, original artifact checksums, archive URLs, sizes, access restrictions, paper mappings and explicit missing-data entries here. A reported checksum is not independently verified unless the matching bytes were read and checked.
