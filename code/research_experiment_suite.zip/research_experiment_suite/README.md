# Recovered development experiment suite

This package consolidates actual code from the supplied iotj-integrity-monitoring.ipynb.
It is NOT a completed confirmatory A-G study. No numerical outcome has been fabricated.
All original modules remain exploratory/development implementations with their original limitations.

## Included
13 extracted experiment scripts, a protected runner, a six-cell paired statistics tool,
and a source manifest with hashes and original cell numbers.

## Runner
Use Python run_suite.py --base <restored development directory> to list tasks.
Use --tasks task1 task2 to run explicit tasks in a newly copied and checksum-verified worktree.
Original restored files are not overwritten. Old stage outputs in the worktree are archived.
--allow-training is required for tasks that may fit auxiliary models.
--allow-attacks is required for tasks that optimize attacks.
Use --worktree <registered worktree root> to resume in that working copy.
The runner stops on process errors or FAILED/BLOCKED status rows. A zero exit code is NOT scientific completion.
Check per-task numerical outputs and method fidelity, not merely status strings.
The runner may require substantial CPU time and disk. No completion-time promise is made.

Example read-only status:
python run_suite.py --base /kaggle/working/research_resume_20261010T150010065402Z/development

Example computational review/replay batch:
python run_suite.py --base <restored development> --tasks witness mixture_order neural_replay algebraic_screen resources

Example MD3 baseline recomputation:
Install Menelaus if absent and record the installed version, then:
python run_suite.py --base <restored development> --worktree <registered worktree> --tasks md3_bounds --allow-training
MD3 may train its own baseline classifier; it does not retrain the original primary detector.
The runner disables automatic package installation and private archive creation.

## Dependencies and order
Existing restored outputs can supply prerequisites. If rebuilding development work, use:
spsa -> view_families -> aligned_profiles -> aligned_adaptive -> witness -> mixture_order.
md3_bounds uses saved aligned attacks/profiles.
neural_attacks uses existing full-feature neural banks from aline_gde_published_equations_v1.
neural_replay -> estimator_banks; algebraic_screen uses saved neural/shared attacks.
resources uses saved aligned banks and neural models.
packet_timing is only a byte/order/timing validation, NOT packet-valid evasion.
Do not infer dataset identity from ambiguous uploaded PCAP names.

## Deliberately NOT presented as solved
- Feature-source semantics, units, primitive control and extractor formula approvals.
- New prospective model/source-pair confirmation and a fully specified final protocol.
- NF/ToN lineage independence, a frozen eligible split, and the untouched boundary experiment.
- Original PCAP-to-feature-to-label-to-model-row linkage and functionality-preserving packet attacks.
- The IDS-specific attainability proof and final weighted-integrity proposition.
- Published-baseline fidelity merely from running existing implementation code.
- Manuscript novelty, acceptance, or uniformly positive outcomes.

The notebook has an ALine/GDE dependency-patch cell without the complete earlier baseline-runner
source definition. This package does not pretend that incomplete patch is runnable by itself.
The included neural modules contain their actual ALine/GDE computations; their scope needs review.

## Statistics
paired_statistics.py requires one preaggregated real row per dataset/attack/pair/model-seed.
Columns: dataset,attack,pair_id,model_seed,baseline,baseline_error,monitor_error.
Exactly CICIoT2023 and CICIoMT2024 x whitebox,transfer,sparse.
It refuses duplicate units, missing cells and attack-specific baseline changes.
It reports unit-bootstrap intervals and paired sign-flip p-values (symmetry assumption),
plus six-test Holm correction, explicitly labeled development, not confirmation.
It does not create missing units, independence or preregistration.

## Source safety
Do not execute all cells of the original notebook. Use explicit isolated tasks only.
No NF dataset is loaded by these extracted tasks, but packet_timing searches file paths.
Back up new outputs separately and verify ZIP integrity and SHA256 after download.
