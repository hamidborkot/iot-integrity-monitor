# Bulk archive locations

Do not commit 20+GB of Kaggle ZIP backups here. Retain the archives in an appropriate external artifact store and record their links, bytes and SHA-256 values under ../manifests/. Preserve original archives; do not merge conflicting experiment versions or delete copies merely because names match. Check redistribution and private-information restrictions before making archives public.
