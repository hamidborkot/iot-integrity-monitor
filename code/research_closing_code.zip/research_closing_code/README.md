# Consolidated closing code

Run closing_analyses.py in one Kaggle cell. It uses the exact saved worktree path and
source-verified numerical helpers from uploaded notebook cell 77. It fits no models,
optimizes no attacks, changes no thresholds and loads no NF records.

It completes executable closing analyses:
- window integrity evidence with estimates, weights, drift, diagnostic suspect channels,
  abstention state and reference/schema/model hashes;
- separate offline outcome tables so current labels never enter emitted monitoring records;
- unique realized-candidate handling within each bank and budget;
- matched coverage ranking comparison against confidence and view agreement;
- full and accepted-window estimator errors;
- diagnostic changed-feature-channel attribution precision/recall/F1;
- separation of unlabeled MD3 warnings from label-assisted confirmation.

These analyses are descriptive development evidence, NOT prospectively independent tests.
Matched target-score ranking is an evaluation curve, not a deployable threshold tuned on the target.
A non-improving result must remain in the paper. No robustness or accuracy certificate is implied.
Source definitions remain review-required; declared feature groups are not causal packet sources.

formal_results_and_limits.md contains the generic identifiability proof and a corrected
conditional weighted-vote error bound. The planned positive-margin condition alone does not
prove majority error below 1/2. Adaptive runtime weights require justified conditional errors.
The empirical near-blindness witnesses do not prove exact IDS traffic-space indistinguishability.

boundary_schema_and_lineage.py reads only Parquet schema, creates a source-review table,
and records the same-parent ToN/NF lineage. It does not fabricate source groups or a boundary result.
An eligible source-group split or an explicit narrower scope amendment remains required.

paired_statistics.py is executable on real, preaggregated paired error units only.
Read its required columns and warnings. Existing observed cases remain development evidence.
It cannot manufacture prospective independence or preregistration.

prospective_protocol_DRAFT.json lists the exact missing design decisions. It is intentionally
not marked frozen. It is NOT an experiment result or a hidden confirmation approval.
No fresh confirmation runner can be validly instantiated until its allocations, baseline,
constraints, budgets and method are fixed. These are not facts Python can invent.

verified_backup.py creates an experiment-result ZIP, validates every member's CRC, and writes
SHA256. It excludes source data and models; preserve the already verified input model backup.
Example:
python verified_backup.py --root <closing result directory> --output /kaggle/working/closing_results.zip

Remaining original-plan claims NOT completed by this package:
source-approved constraints; prospective source-pair confirmation; eligible untouched boundary
experiment; packet-valid attacks; literature novelty/attribution review; final manuscript.
This package deliberately does not relabel failures as successful defense or promise acceptance.
