# Manuscript

Upload the final LaTeX source, bibliography, figure source/PDFs and compiled manuscript. Record the version used to map results. Do not publish author placeholders as final metadata.
