# Supplementary material

Upload the actual final supplement and its S1-S8 table-to-artifact mapping. Current supporting exports do not certify that every supplementary row, method definition or original precision value has been provided. Preserve strict/slack definitions, corruption/gate rules and all relevant denominator identities.
