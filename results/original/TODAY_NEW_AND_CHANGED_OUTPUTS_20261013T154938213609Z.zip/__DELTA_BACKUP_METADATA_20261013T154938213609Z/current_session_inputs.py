# ===== CELL INPUT 1 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import os
import shutil
import zipfile

INPUT_ROOTS = [
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
]
WORK = Path("/kaggle/working")
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"RESTORE_INPUT_INVENTORY_{STAMP}.json"

REQUIRED_MARKERS = [
    "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z",
    "E4_COMPACT_INJECTIONS_v2",
    "E4_COMPACT_PACING_v1",
    "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
]

def gib(value):
    return round(value / 1024**3, 4)

def zip_summary(path):
    result = {
        "path": str(path),
        "name": path.name,
        "bytes": path.stat().st_size,
        "GiB": gib(path.stat().st_size),
        "readable": False,
        "members": None,
        "uncompressed_bytes": None,
        "marker_hits": [],
        "contains_full_workspace_snapshot": False,
        "error": None,
    }

    try:
        with zipfile.ZipFile(path, "r") as archive:
            entries = archive.infolist()
            names = [entry.filename for entry in entries]
            joined = "\n".join(names)

            result["readable"] = True
            result["members"] = len(entries)
            result["uncompressed_bytes"] = sum(
                entry.file_size for entry in entries
            )
            result["marker_hits"] = [
                marker for marker in REQUIRED_MARKERS
                if marker in joined
            ]
            result["contains_full_workspace_snapshot"] = any(
                name.startswith("__BACKUP_METADATA_")
                or name == "BACKUP_MANIFEST.json"
                for name in names
            )

    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"

    return result

all_files = []
zip_files = []
split_parts = []
missing_roots = []

for root in INPUT_ROOTS:
    if not root.is_dir():
        missing_roots.append(str(root))
        continue

    for current, dirs, names in os.walk(root):
        current = Path(current)
        for name in names:
            path = current / name
            try:
                size = path.stat().st_size
            except FileNotFoundError:
                continue

            record = {
                "path": str(path),
                "name": path.name,
                "bytes": size,
                "GiB": gib(size),
            }
            all_files.append(record)

            if path.suffix.lower() == ".zip":
                zip_files.append(zip_summary(path))
            elif path.suffix.lower().startswith(".z"):
                split_parts.append(record)

zip_files.sort(
    key=lambda row: (
        row["readable"],
        len(row["marker_hits"]),
        row["contains_full_workspace_snapshot"],
        row["bytes"],
    ),
    reverse=True
)
all_files.sort(key=lambda row: row["bytes"], reverse=True)
split_parts.sort(key=lambda row: row["bytes"], reverse=True)

report = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "input_roots_checked": [str(p) for p in INPUT_ROOTS],
    "missing_input_roots": missing_roots,
    "disk_free_GiB": gib(shutil.disk_usage(WORK).free),
    "all_uploaded_files": all_files,
    "readable_zip_candidates_ranked": zip_files,
    "split_archive_parts": split_parts,
    "required_restore_markers": REQUIRED_MARKERS,
}
OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")

print("INPUT ROOTS")
for root in INPUT_ROOTS:
    print(f"{'FOUND ' if root.is_dir() else 'MISSING'} {root}")

print("\nTOP UPLOADED FILES")
for row in all_files[:20]:
    print(f"{row['GiB']:8.4f} GiB  {row['path']}")

print("\nREADABLE ZIP CANDIDATES — BEST FIRST")
for index, row in enumerate(zip_files, start=1):
    print(
        f"{index:2d}. {row['GiB']:8.4f} GiB | "
        f"members={row['members']} | "
        f"markers={len(row['marker_hits'])}/{len(REQUIRED_MARKERS)} | "
        f"snapshot={row['contains_full_workspace_snapshot']} | "
        f"{row['path']}"
    )
    if row["marker_hits"]:
        print("    contains:", ", ".join(row["marker_hits"]))
    if row["error"]:
        print("    error:", row["error"])

if split_parts:
    print("\nSPLIT-ARCHIVE PARTS — NOT EXTRACTED AUTOMATICALLY")
    for row in split_parts:
        print(f"{row['GiB']:8.4f} GiB  {row['path']}")

print(f"\nInventory saved: {OUT}")
print(f"Free working disk: {gib(shutil.disk_usage(WORK).free):.4f} GiB")

# ===== CELL INPUT 2 =====
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import zipfile

WORK = Path("/kaggle/working").resolve()

inventory_files = sorted(
    WORK.glob("RESTORE_INPUT_INVENTORY_*.json"),
    key=lambda p: p.stat().st_mtime_ns,
    reverse=True
)
if not inventory_files:
    raise RuntimeError("Run Cell 1 first; no restore inventory JSON exists.")

inventory_path = inventory_files[0]
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
required_markers = inventory["required_restore_markers"]

candidates = [
    item for item in inventory["readable_zip_candidates_ranked"]
    if item.get("readable")
]

if not candidates:
    raise RuntimeError(
        "No readable ZIP backup was found in the five /kaggle/input paths."
    )

def rank_candidate(item):
    name = item["name"].lower()
    name_bonus = (
        3 if "complete_research_backup" in name else
        2 if "complete" in name else
        1 if "full" in name else
        0
    )
    return (
        len(item.get("marker_hits", [])),
        int(item.get("contains_full_workspace_snapshot", False)),
        name_bonus,
        item["bytes"],
    )

selected = sorted(candidates, key=rank_candidate, reverse=True)[0]
source_zip = Path(selected["path"])

if len(selected.get("marker_hits", [])) < 3:
    raise RuntimeError(
        "The best candidate contains fewer than three required frozen-workspace "
        "markers. Do not restore a partial archive. Inspect Cell 1 output."
    )

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
receipt_path = WORK / f"WORKSPACE_RESTORE_RECEIPT_{stamp}.json"

def sha256_path(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def valid_member(member_name):
    part = PurePosixPath(member_name)
    return not part.is_absolute() and ".." not in part.parts

def member_sha256(archive, member):
    digest = hashlib.sha256()
    with archive.open(member, "r") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def detect_workspace_prefix(names):
    """
    Backups made by the final backup cell have entries directly under working/.
    Older backups may put everything under one wrapper directory such as
    trace_confirmatory_today/. This strips exactly one common wrapper only
    when all non-metadata content shares it.
    """
    meaningful = [
        PurePosixPath(name)
        for name in names
        if name and not name.endswith("/")
        and not name.startswith("__BACKUP_METADATA_")
        and name != "BACKUP_MANIFEST.json"
    ]
    top_levels = {parts.parts[0] for parts in meaningful if parts.parts}
    if len(top_levels) != 1:
        return None

    candidate = next(iter(top_levels))
    marker_under_prefix = any(
        len(parts.parts) >= 2
        and parts.parts[0] == candidate
        and any(marker in str(parts) for marker in required_markers)
        for parts in meaningful
    )
    return candidate if marker_under_prefix else None

print("SELECTED BACKUP")
print(source_zip)
print(f"Size: {source_zip.stat().st_size / 1024**3:.4f} GiB")
print("Frozen-workspace markers:")
for marker in selected["marker_hits"]:
    print(" -", marker)

with zipfile.ZipFile(source_zip, "r") as archive:
    members = archive.infolist()
    names = [member.filename for member in members]

    unsafe = [name for name in names if not valid_member(name)]
    if unsafe:
        raise RuntimeError(
            "Unsafe ZIP path detected; refusing restore:\n"
            + "\n".join(unsafe[:20])
        )

    wrapper = detect_workspace_prefix(names)
    print(
        "Archive layout:",
        f"one wrapper directory stripped: {wrapper}" if wrapper
        else "direct /kaggle/working layout"
    )

    restore_members = []
    for member in members:
        raw = PurePosixPath(member.filename)

        if raw.name == "" or member.is_dir():
            continue

        if raw.parts and raw.parts[0].startswith("__BACKUP_METADATA_"):
            continue
        if member.filename == "BACKUP_MANIFEST.json":
            continue

        relative = (
            PurePosixPath(*raw.parts[1:])
            if wrapper and raw.parts[0] == wrapper
            else raw
        )

        if not relative.parts:
            continue

        restore_members.append((member, relative))

    estimated_bytes = sum(member.file_size for member, _ in restore_members)
    free_bytes = shutil.disk_usage(WORK).free

    print(f"Files to restore: {len(restore_members):,}")
    print(f"Extraction size: {estimated_bytes / 1024**3:.4f} GiB")
    print(f"Free disk:       {free_bytes / 1024**3:.4f} GiB")

    if free_bytes < estimated_bytes + 512 * 1024**2:
        raise RuntimeError(
            "Not enough free working-disk space for safe restore. "
            "Nothing was extracted."
        )

    conflicts = []
    identical_existing = 0

    for member, relative in restore_members:
        destination = WORK / relative

        if destination.exists():
            if not destination.is_file():
                conflicts.append(str(relative) + " [existing non-file]")
                continue

            if destination.stat().st_size != member.file_size:
                conflicts.append(str(relative) + " [size differs]")
                continue

            if sha256_path(destination) != member_sha256(archive, member):
                conflicts.append(str(relative) + " [SHA-256 differs]")
                continue

            identical_existing += 1

    if conflicts:
        raise RuntimeError(
            "Restore stopped. Existing files differ from the selected backup; "
            "nothing was overwritten. First conflicts:\n"
            + "\n".join(conflicts[:30])
        )

    restored = 0
    skipped = 0

    for index, (member, relative) in enumerate(restore_members, start=1):
        destination = WORK / relative
        destination.parent.mkdir(parents=True, exist_ok=True)

        if destination.exists():
            skipped += 1
            continue

        with archive.open(member, "r") as source, open(destination, "wb") as target:
            shutil.copyfileobj(source, target, length=8 * 1024**2)

        restored += 1

        if index % 250 == 0 or index == len(restore_members):
            print(
                f"Restored/checked {index:,}/{len(restore_members):,}",
                flush=True
            )

marker_status = {}
for marker in required_markers:
    matches = [str(path) for path in WORK.rglob(marker)]
    marker_status[marker] = {
        "present": bool(matches),
        "matches": matches[:5],
    }

receipt = {
    "status": "WORKSPACE_RESTORE_COMPLETE",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "source_zip": str(source_zip),
    "source_zip_sha256": sha256_path(source_zip),
    "archive_wrapper_removed": wrapper,
    "restored_new_files": restored,
    "identical_existing_files_skipped": skipped,
    "all_required_markers_present": all(
        item["present"] for item in marker_status.values()
    ),
    "marker_status": marker_status,
    "existing_different_files_overwritten": False,
}
receipt_path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

print("\nRESTORE COMPLETE")
print(json.dumps(receipt, indent=2))
print(f"\nReceipt: {receipt_path}")

# ===== CELL INPUT 3 =====
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import zipfile

WORK = Path("/kaggle/working").resolve()

inventory_files = sorted(
    WORK.glob("RESTORE_INPUT_INVENTORY_*.json"),
    key=lambda p: p.stat().st_mtime_ns,
    reverse=True
)
if not inventory_files:
    raise RuntimeError("Run Cell 1 first; no restore inventory JSON exists.")

inventory_path = inventory_files[0]
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
required_markers = inventory["required_restore_markers"]

candidates = [
    item for item in inventory["readable_zip_candidates_ranked"]
    if item.get("readable")
]

if not candidates:
    raise RuntimeError(
        "No readable ZIP backup was found in the five /kaggle/input paths."
    )

def rank_candidate(item):
    name = item["name"].lower()
    name_bonus = (
        3 if "complete_research_backup" in name else
        2 if "complete" in name else
        1 if "full" in name else
        0
    )
    return (
        len(item.get("marker_hits", [])),
        int(item.get("contains_full_workspace_snapshot", False)),
        name_bonus,
        item["bytes"],
    )

selected = sorted(candidates, key=rank_candidate, reverse=True)[0]
source_zip = Path(selected["path"])

if len(selected.get("marker_hits", [])) < 3:
    raise RuntimeError(
        "The best candidate contains fewer than three required frozen-workspace "
        "markers. Do not restore a partial archive. Inspect Cell 1 output."
    )

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
receipt_path = WORK / f"WORKSPACE_RESTORE_RECEIPT_{stamp}.json"

def sha256_path(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def valid_member(member_name):
    part = PurePosixPath(member_name)
    return not part.is_absolute() and ".." not in part.parts

def member_sha256(archive, member):
    digest = hashlib.sha256()
    with archive.open(member, "r") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def detect_workspace_prefix(names):
    """
    Backups made by the final backup cell have entries directly under working/.
    Older backups may put everything under one wrapper directory such as
    trace_confirmatory_today/. This strips exactly one common wrapper only
    when all non-metadata content shares it.
    """
    meaningful = [
        PurePosixPath(name)
        for name in names
        if name and not name.endswith("/")
        and not name.startswith("__BACKUP_METADATA_")
        and name != "BACKUP_MANIFEST.json"
    ]
    top_levels = {parts.parts[0] for parts in meaningful if parts.parts}
    if len(top_levels) != 1:
        return None

    candidate = next(iter(top_levels))
    marker_under_prefix = any(
        len(parts.parts) >= 2
        and parts.parts[0] == candidate
        and any(marker in str(parts) for marker in required_markers)
        for parts in meaningful
    )
    return candidate if marker_under_prefix else None

print("SELECTED BACKUP")
print(source_zip)
print(f"Size: {source_zip.stat().st_size / 1024**3:.4f} GiB")
print("Frozen-workspace markers:")
for marker in selected["marker_hits"]:
    print(" -", marker)

with zipfile.ZipFile(source_zip, "r") as archive:
    members = archive.infolist()
    names = [member.filename for member in members]

    unsafe = [name for name in names if not valid_member(name)]
    if unsafe:
        raise RuntimeError(
            "Unsafe ZIP path detected; refusing restore:\n"
            + "\n".join(unsafe[:20])
        )

    wrapper = detect_workspace_prefix(names)
    print(
        "Archive layout:",
        f"one wrapper directory stripped: {wrapper}" if wrapper
        else "direct /kaggle/working layout"
    )

    restore_members = []
    for member in members:
        raw = PurePosixPath(member.filename)

        if raw.name == "" or member.is_dir():
            continue

        if raw.parts and raw.parts[0].startswith("__BACKUP_METADATA_"):
            continue
        if member.filename == "BACKUP_MANIFEST.json":
            continue

        relative = (
            PurePosixPath(*raw.parts[1:])
            if wrapper and raw.parts[0] == wrapper
            else raw
        )

        if not relative.parts:
            continue

        restore_members.append((member, relative))

    estimated_bytes = sum(member.file_size for member, _ in restore_members)
    free_bytes = shutil.disk_usage(WORK).free

    print(f"Files to restore: {len(restore_members):,}")
    print(f"Extraction size: {estimated_bytes / 1024**3:.4f} GiB")
    print(f"Free disk:       {free_bytes / 1024**3:.4f} GiB")

    if free_bytes < estimated_bytes + 512 * 1024**2:
        raise RuntimeError(
            "Not enough free working-disk space for safe restore. "
            "Nothing was extracted."
        )

    conflicts = []
    identical_existing = 0

    for member, relative in restore_members:
        destination = WORK / relative

        if destination.exists():
            if not destination.is_file():
                conflicts.append(str(relative) + " [existing non-file]")
                continue

            if destination.stat().st_size != member.file_size:
                conflicts.append(str(relative) + " [size differs]")
                continue

            if sha256_path(destination) != member_sha256(archive, member):
                conflicts.append(str(relative) + " [SHA-256 differs]")
                continue

            identical_existing += 1

    if conflicts:
        raise RuntimeError(
            "Restore stopped. Existing files differ from the selected backup; "
            "nothing was overwritten. First conflicts:\n"
            + "\n".join(conflicts[:30])
        )

    restored = 0
    skipped = 0

    for index, (member, relative) in enumerate(restore_members, start=1):
        destination = WORK / relative
        destination.parent.mkdir(parents=True, exist_ok=True)

        if destination.exists():
            skipped += 1
            continue

        with archive.open(member, "r") as source, open(destination, "wb") as target:
            shutil.copyfileobj(source, target, length=8 * 1024**2)

        restored += 1

        if index % 250 == 0 or index == len(restore_members):
            print(
                f"Restored/checked {index:,}/{len(restore_members):,}",
                flush=True
            )

marker_status = {}
for marker in required_markers:
    matches = [str(path) for path in WORK.rglob(marker)]
    marker_status[marker] = {
        "present": bool(matches),
        "matches": matches[:5],
    }

receipt = {
    "status": "WORKSPACE_RESTORE_COMPLETE",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "source_zip": str(source_zip),
    "source_zip_sha256": sha256_path(source_zip),
    "archive_wrapper_removed": wrapper,
    "restored_new_files": restored,
    "identical_existing_files_skipped": skipped,
    "all_required_markers_present": all(
        item["present"] for item in marker_status.values()
    ),
    "marker_status": marker_status,
    "existing_different_files_overwritten": False,
}
receipt_path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

print("\nRESTORE COMPLETE")
print(json.dumps(receipt, indent=2))
print(f"\nReceipt: {receipt_path}")

# ===== CELL INPUT 4 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

WORK = Path("/kaggle/working")
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
AUDIT = WORK / f"RESUME_AUDIT_{STAMP}"
AUDIT.mkdir(exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def newest_directory(name):
    matches = [
        path for path in WORK.rglob(name)
        if path.is_dir()
    ]
    return max(matches, key=lambda p: p.stat().st_mtime_ns) if matches else None

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"read_error": f"{type(error).__name__}: {error}"}

pacing_root = newest_directory("E4_COMPACT_PACING_v1")
injection_root = newest_directory("E4_COMPACT_INJECTIONS_v2")
clean_root = newest_directory(
    "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z"
)
model_root = newest_directory("TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1")

pacing_rows = []
for scenario in TARGETS:
    job = pacing_root / scenario if pacing_root else None
    receipt_path = job / "receipt.json" if job else None
    result_path = job / "detector_results.csv" if job else None
    failure_path = job / "failure.json" if job else None

    receipt = read_json(receipt_path) if receipt_path and receipt_path.is_file() else {}
    failure = read_json(failure_path) if failure_path and failure_path.is_file() else {}

    complete = bool(
        receipt.get("status") == "PACING_JOB_COMPLETE"
        and result_path is not None
        and result_path.is_file()
    )

    pacing_rows.append({
        "scenario": scenario,
        "status": (
            "COMPLETE" if complete
            else "FAILED_OR_INCOMPLETE" if failure
            else "PENDING"
        ),
        "receipt_present": bool(receipt_path and receipt_path.is_file()),
        "detector_results_present": bool(result_path and result_path.is_file()),
        "eligible_flows": receipt.get("eligible_flows"),
        "delayed_packets": receipt.get("delayed_packets"),
        "mapping_fraction": receipt.get("mapping_fraction"),
        "seconds": receipt.get("seconds"),
        "failure": failure.get("error"),
    })

pacing = pd.DataFrame(pacing_rows)
pacing.to_csv(AUDIT / "pacing_status.csv", index=False)

injection_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job = injection_root / scenario / attack if injection_root else None
        receipt_path = job / "receipt.json" if job else None
        outputs_path = job / "primary_outputs.npz" if job else None
        receipt = read_json(receipt_path) if receipt_path and receipt_path.is_file() else {}

        injection_rows.append({
            "scenario": scenario,
            "attack": attack,
            "receipt_status": receipt.get("status", "MISSING"),
            "outputs_present": bool(outputs_path and outputs_path.is_file()),
            "complete": bool(
                receipt.get("status") == "INJECTION_JOB_COMPLETE"
                and outputs_path is not None
                and outputs_path.is_file()
            )
        })

injections = pd.DataFrame(injection_rows)
injections.to_csv(AUDIT / "injection_status.csv", index=False)

completed_pace = pacing.loc[
    pacing.status.eq("COMPLETE"), "scenario"
].tolist()
pending_pace = pacing.loc[
    ~pacing.status.eq("COMPLETE"), "scenario"
].tolist()

summary = {
    "audit_directory": str(AUDIT),
    "pacing_root": str(pacing_root) if pacing_root else None,
    "injection_root": str(injection_root) if injection_root else None,
    "clean_target_root": str(clean_root) if clean_root else None,
    "source_model_root": str(model_root) if model_root else None,
    "pacing_completed": len(completed_pace),
    "pacing_pending_or_failed": pending_pace,
    "injections_completed": int(injections.complete.sum()),
    "injections_expected": 16,
    "next_pacing_target": pending_pace[0] if pending_pace else None,
    "remaining_scientific_work": [
        "E4 PACE_1s only for targets without a valid completed receipt",
        "E5 adaptive real-PCAP experiment",
        "Faithful published MD3 baseline",
        "E6 full monitor overhead including preprocessing",
        "E6 actual edge-device measurement, if hardware is available",
        "Original three-transformation primary statistics",
        "Theory/repository/manuscript reconciliation"
    ]
}
(AUDIT / "resume_summary.json").write_text(
    json.dumps(summary, indent=2),
    encoding="utf-8"
)

print("PACE_1s STATUS")
print(pacing.to_string(index=False))

print("\nINJECTION STATUS")
print(injections.to_string(index=False))

print("\nRESUME SUMMARY")
print(json.dumps(summary, indent=2))

# ===== CELL INPUT 5 =====
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from collections import defaultdict
import gzip
import json
import os
import shutil
import tarfile
import zipfile

INPUT_ROOTS = [
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
]

WORK = Path("/kaggle/working")
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
AUDIT_DIR = WORK / f"DEEP_BACKUP_AUDIT_{STAMP}"
AUDIT_DIR.mkdir(parents=True, exist_ok=False)

# These are the assets needed to continue the actual unfinished experiments.
REQUIRED = {
    "frozen_source_models": [
        "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
        "frozen_source_models.joblib",
    ],
    "clean_targets": [
        "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z",
        "frozen_clean_target_sample.csv.gz",
    ],
    "target_asset_resolution": [
        "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2",
        "target_asset_resolution.csv",
    ],
    "streaming_runner": [
        "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
    ],
    "compact_injections": [
        "E4_COMPACT_INJECTIONS_v2",
        "INJ_k1",
        "INJ_k3",
    ],
    "pacing_outputs": [
        "E4_COMPACT_PACING_v1",
        "PACE_1s",
        "PACING_JOB_COMPLETE",
    ],
    "consistency_verification": [
        "E4_CONSISTENCY_VERIFICATION_FIXED",
        "prediction_consistency.csv",
    ],
    "adaptive_E5": [
        "adaptive",
        "E5",
    ],
    "faithful_MD3": [
        "MD3",
        "margin_density",
    ],
    "full_monitor_E6": [
        "monitor",
        "overhead",
        "benchmark",
    ],
    "original_protocol_statistics": [
        "holm",
        "sign_flip",
        "three_transformation",
    ],
    "manuscript_repository": [
        "manuscript",
        "README",
        "paper",
        "repository",
    ],
}

INTERESTING_TERMS = sorted({
    "E4_COMPACT_INJECTIONS_v2",
    "E4_COMPACT_PACING_v1",
    "PACE_1s",
    "PACING_JOB_COMPLETE",
    "INJECTION_JOB_COMPLETE",
    "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    "frozen_source_models.joblib",
    "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z",
    "frozen_clean_target_sample.csv.gz",
    "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2",
    "target_asset_resolution.csv",
    "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
    "adaptive",
    "MD3",
    "margin_density",
    "monitor",
    "overhead",
    "benchmark",
    "holm",
    "sign_flip",
    "three_transformation",
    "manuscript",
    "paper",
    "README",
    "receipt.json",
    "failure.json",
    "detector_results.csv",
    "primary_outputs.npz",
})

ARCHIVE_SUFFIXES = {
    ".zip", ".jar", ".whl",
    ".tar", ".tgz", ".gz", ".bz2", ".xz",
}

def gib(value):
    return round(value / 1024**3, 5)

def archive_type(path):
    name = path.name.lower()
    if name.endswith((".zip", ".jar", ".whl")):
        return "zip"
    if name.endswith((
        ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2",
        ".tar.xz", ".txz"
    )):
        return "tar"
    if name.endswith(".gz"):
        return "gzip"
    return None

def interesting_hits(path_text):
    lower = path_text.lower()
    return [
        term for term in INTERESTING_TERMS
        if term.lower() in lower
    ]

def requirement_hits(path_text):
    lower = path_text.lower()
    found = []
    for label, terms in REQUIRED.items():
        if any(term.lower() in lower for term in terms):
            found.append(label)
    return found

def inspect_zip(path):
    rows = []
    summary = {
        "kind": "zip",
        "readable": False,
        "members": 0,
        "member_bytes": 0,
        "error": None,
    }
    try:
        with zipfile.ZipFile(path, "r") as archive:
            info_list = archive.infolist()
            summary["readable"] = True
            summary["members"] = len(info_list)
            summary["member_bytes"] = sum(
                member.file_size for member in info_list
            )

            for member in info_list:
                if member.is_dir():
                    continue
                name = member.filename
                rows.append({
                    "archive": str(path),
                    "member": name,
                    "member_bytes": member.file_size,
                    "compressed_bytes": member.compress_size,
                    "interesting_hits": interesting_hits(name),
                    "requirement_hits": requirement_hits(name),
                    "nested_archive": archive_type(Path(name)),
                })

    except Exception as error:
        summary["error"] = f"{type(error).__name__}: {error}"

    return summary, rows

def inspect_tar(path):
    rows = []
    summary = {
        "kind": "tar",
        "readable": False,
        "members": 0,
        "member_bytes": 0,
        "error": None,
    }
    try:
        with tarfile.open(path, "r:*") as archive:
            members = archive.getmembers()
            summary["readable"] = True
            summary["members"] = len(members)
            summary["member_bytes"] = sum(
                member.size for member in members if member.isfile()
            )

            for member in members:
                if not member.isfile():
                    continue
                name = member.name
                rows.append({
                    "archive": str(path),
                    "member": name,
                    "member_bytes": member.size,
                    "compressed_bytes": None,
                    "interesting_hits": interesting_hits(name),
                    "requirement_hits": requirement_hits(name),
                    "nested_archive": archive_type(Path(name)),
                })

    except Exception as error:
        summary["error"] = f"{type(error).__name__}: {error}"

    return summary, rows

def inspect_gzip(path):
    summary = {
        "kind": "gzip",
        "readable": False,
        "members": 1,
        "member_bytes": None,
        "error": None,
    }
    rows = []
    try:
        with gzip.open(path, "rb") as handle:
            handle.read(1)
        summary["readable"] = True
        rows.append({
            "archive": str(path),
            "member": path.stem,
            "member_bytes": None,
            "compressed_bytes": path.stat().st_size,
            "interesting_hits": interesting_hits(path.name),
            "requirement_hits": requirement_hits(path.name),
            "nested_archive": None,
        })
    except Exception as error:
        summary["error"] = f"{type(error).__name__}: {error}"

    return summary, rows

def inspect_archive(path):
    kind = archive_type(path)
    if kind == "zip":
        return inspect_zip(path)
    if kind == "tar":
        return inspect_tar(path)
    if kind == "gzip":
        return inspect_gzip(path)

    return (
        {
            "kind": "not_archive",
            "readable": None,
            "members": 0,
            "member_bytes": 0,
            "error": None,
        },
        []
    )

all_files = []
archive_summaries = []
archive_members = []
direct_artifact_hits = []
missing_roots = []

print("SCANNING ALL FIVE INPUT LOCATIONS", flush=True)

for root in INPUT_ROOTS:
    if not root.is_dir():
        missing_roots.append(str(root))
        print(f"MISSING: {root}", flush=True)
        continue

    print(f"\nSCANNING: {root}", flush=True)

    root_file_count = 0
    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)

        for name in names:
            path = current / name

            try:
                stat_info = path.stat()
            except FileNotFoundError:
                continue

            root_file_count += 1
            relative = str(path.relative_to(root))
            item = {
                "input_root": str(root),
                "path": str(path),
                "relative_path": relative,
                "bytes": stat_info.st_size,
                "GiB": gib(stat_info.st_size),
                "suffix": path.suffix.lower(),
                "interesting_hits": interesting_hits(relative),
                "requirement_hits": requirement_hits(relative),
                "archive_type": archive_type(path),
            }
            all_files.append(item)

            if item["interesting_hits"] or item["requirement_hits"]:
                direct_artifact_hits.append(item)

            kind = archive_type(path)
            if kind is not None:
                summary, members = inspect_archive(path)
                summary.update({
                    "input_root": str(root),
                    "path": str(path),
                    "relative_path": relative,
                    "bytes": stat_info.st_size,
                    "GiB": gib(stat_info.st_size),
                })
                archive_summaries.append(summary)
                archive_members.extend(members)

    print(f"Files scanned in this input: {root_file_count:,}", flush=True)

# Convert list fields to JSON strings for compact CSV output.
def compact_row(row):
    row = dict(row)
    for field in ["interesting_hits", "requirement_hits"]:
        if field in row:
            row[field] = "|".join(row[field])
    return row

try:
    import pandas as pd

    pd.DataFrame(
        [compact_row(row) for row in all_files]
    ).sort_values(
        "bytes", ascending=False
    ).to_csv(AUDIT_DIR / "all_uploaded_files.csv", index=False)

    pd.DataFrame(
        archive_summaries
    ).sort_values(
        ["readable", "bytes"], ascending=[False, False]
    ).to_csv(AUDIT_DIR / "archive_summary.csv", index=False)

    pd.DataFrame(
        [compact_row(row) for row in archive_members]
    ).to_csv(AUDIT_DIR / "archive_members.csv", index=False)

    pd.DataFrame(
        [compact_row(row) for row in direct_artifact_hits]
    ).to_csv(AUDIT_DIR / "direct_artifact_hits.csv", index=False)

except Exception as error:
    raise RuntimeError(f"Could not write audit CSVs: {error}")

# Build exact presence maps across direct files and archive members.
presence = defaultdict(list)

for row in direct_artifact_hits:
    for label in row["requirement_hits"]:
        presence[label].append({
            "location_type": "direct_input_file",
            "container": row["input_root"],
            "path": row["relative_path"],
            "bytes": row["bytes"],
        })

for row in archive_members:
    for label in row["requirement_hits"]:
        presence[label].append({
            "location_type": "archive_member",
            "container": row["archive"],
            "path": row["member"],
            "bytes": row["member_bytes"],
        })

required_status = {}
for label in REQUIRED:
    locations = presence.get(label, [])
    required_status[label] = {
        "found": bool(locations),
        "locations_count": len(locations),
        "first_25_locations": locations[:25],
    }

best_archives = sorted(
    archive_summaries,
    key=lambda row: (
        row["readable"] is True,
        sum(
            1 for label in REQUIRED
            if any(
                label in hit.get("requirement_hits", [])
                for hit in archive_members
                if hit["archive"] == row["path"]
            )
        ),
        row["bytes"],
    ),
    reverse=True
)

report = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "input_roots": [str(root) for root in INPUT_ROOTS],
    "missing_roots": missing_roots,
    "free_working_GiB": gib(shutil.disk_usage(WORK).free),
    "direct_files_scanned": len(all_files),
    "archives_scanned": len(archive_summaries),
    "archive_members_catalogued": len(archive_members),
    "required_asset_status": required_status,
    "best_archives_ranked": [
        {
            "path": row["path"],
            "kind": row["kind"],
            "readable": row["readable"],
            "bytes": row["bytes"],
            "GiB": row["GiB"],
            "members": row["members"],
            "member_bytes": row["member_bytes"],
            "error": row["error"],
        }
        for row in best_archives
    ],
    "audit_outputs": {
        "all_files": str(AUDIT_DIR / "all_uploaded_files.csv"),
        "archive_summary": str(AUDIT_DIR / "archive_summary.csv"),
        "archive_members": str(AUDIT_DIR / "archive_members.csv"),
        "direct_artifact_hits": str(AUDIT_DIR / "direct_artifact_hits.csv"),
    },
}
(AUDIT_DIR / "deep_audit_report.json").write_text(
    json.dumps(report, indent=2),
    encoding="utf-8"
)

print("\n" + "=" * 78)
print("REQUIRED CONTINUATION ASSETS — FOUND ANYWHERE")
print("=" * 78)
for label, status in required_status.items():
    print(
        f"{label:30s} "
        f"{'FOUND' if status['found'] else 'NOT FOUND':10s} "
        f"locations={status['locations_count']}"
    )
    for location in status["first_25_locations"][:3]:
        print(
            f"  - [{location['location_type']}] "
            f"{location['container']} :: {location['path']}"
        )

print("\n" + "=" * 78)
print("ARCHIVES INSPECTED — LARGEST FIRST")
print("=" * 78)
for row in sorted(
    archive_summaries, key=lambda item: item["bytes"], reverse=True
):
    print(
        f"{row['GiB']:8.4f} GiB | {row['kind']:5s} | "
        f"readable={row['readable']} | members={row['members']:,} | "
        f"{row['path']}"
    )
    if row["error"]:
        print(f"  ERROR: {row['error']}")

print("\n" + "=" * 78)
print("AUDIT COMPLETE")
print("=" * 78)
print(f"Direct files scanned:       {len(all_files):,}")
print(f"Archives inspected:         {len(archive_summaries):,}")
print(f"Archive members catalogued: {len(archive_members):,}")
print(f"Audit directory:            {AUDIT_DIR}")
print(f"Free working disk:          {gib(shutil.disk_usage(WORK).free):.4f} GiB")

# ===== CELL INPUT 6 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import json
import os
import shutil
import pandas as pd

INPUT_ROOTS = [
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
]

WORK = Path("/kaggle/working")
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"RESUME_DIRECT_AUDIT_{STAMP}"
OUT.mkdir(parents=True, exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

REQUIRED_PATH_MARKERS = {
    "source_models": "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    "frozen_model_bundle": "frozen_source_models.joblib",
    "clean_targets": (
        "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_"
        "20261012T181242007570Z"
    ),
    "target_assets": "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2",
    "asset_resolution_csv": "target_asset_resolution.csv",
    "streaming_runner": "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
    "compact_injections": "E4_COMPACT_INJECTIONS_v2",
    "pacing_root": "E4_COMPACT_PACING_v1",
    "consistency_check": "E4_CONSISTENCY_VERIFICATION_FIXED",
}

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

def find_all(root, needle):
    needle = needle.lower()
    found = []
    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)
        if needle in current.name.lower():
            found.append(current)
        for name in names:
            if needle in name.lower():
                found.append(current / name)
    return found

def locate_exact(root, relative_suffix):
    matches = []
    suffix = Path(relative_suffix)
    for candidate in root.rglob(suffix.name):
        try:
            if candidate.relative_to(root).as_posix().endswith(
                suffix.as_posix()
            ):
                matches.append(candidate)
        except ValueError:
            pass
    return matches

root_rows = []
artifact_rows = []
pacing_rows = []
injection_rows = []
receipt_rows = []

for root in INPUT_ROOTS:
    if not root.is_dir():
        root_rows.append({
            "input_root": str(root),
            "exists": False,
            "files": 0,
            "bytes": 0,
            "GiB": 0.0,
            "core_marker_hits": 0,
            "complete_pacing_jobs": 0,
            "complete_injection_jobs": 0,
        })
        continue

    file_count = 0
    total_bytes = 0
    all_paths_lower = []

    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)
        all_paths_lower.append(str(current.relative_to(root)).lower())

        for name in names:
            path = current / name
            try:
                total_bytes += path.stat().st_size
                file_count += 1
                rel = path.relative_to(root).as_posix()
                all_paths_lower.append(rel.lower())
            except FileNotFoundError:
                continue

    marker_hits = 0
    for label, marker in REQUIRED_PATH_MARKERS.items():
        matches = find_all(root, marker)
        found = bool(matches)
        marker_hits += int(found)

        artifact_rows.append({
            "input_root": str(root),
            "asset": label,
            "marker": marker,
            "found": found,
            "matches": len(matches),
            "first_match": (
                str(matches[0].relative_to(root))
                if matches else None
            ),
        })

    # Locate all completed/failed PACE runs by their own receipt contents.
    root_pace_complete = 0
    for receipt_path in root.rglob("receipt.json"):
        lower_path = str(receipt_path.relative_to(root)).lower()
        if "pace" not in lower_path and "pacing" not in lower_path:
            continue

        receipt = read_json(receipt_path)
        if receipt.get("attack") != "PACE_1s":
            continue

        scenario = receipt.get("scenario")
        status = receipt.get("status")
        result_path = receipt_path.parent / "detector_results.csv"
        complete = (
            status == "PACING_JOB_COMPLETE"
            and result_path.is_file()
            and scenario in TARGETS
        )
        root_pace_complete += int(complete)

        pacing_rows.append({
            "input_root": str(root),
            "scenario": scenario,
            "receipt_path": str(receipt_path.relative_to(root)),
            "status": status,
            "detector_results_present": result_path.is_file(),
            "complete": complete,
            "eligible_flows": receipt.get("eligible_flows"),
            "delayed_packets": receipt.get("delayed_packets"),
            "mapping_fraction": receipt.get("mapping_fraction"),
            "seconds": receipt.get("seconds"),
        })

    # Locate all injection jobs by their own receipt contents.
    root_injection_complete = 0
    for receipt_path in root.rglob("receipt.json"):
        lower_path = str(receipt_path.relative_to(root)).lower()
        if "inj_k1" not in lower_path and "inj_k3" not in lower_path:
            continue

        receipt = read_json(receipt_path)
        status = receipt.get("status")
        outputs = receipt_path.parent / "primary_outputs.npz"
        complete = (
            status == "INJECTION_JOB_COMPLETE"
            and outputs.is_file()
        )
        root_injection_complete += int(complete)

        injection_rows.append({
            "input_root": str(root),
            "scenario": receipt.get("scenario"),
            "attack": receipt.get("attack"),
            "receipt_path": str(receipt_path.relative_to(root)),
            "status": status,
            "primary_outputs_present": outputs.is_file(),
            "complete": complete,
        })

    # Record E5, MD3, E6, statistics, and manuscript-related file hits.
    for label, terms in {
        "adaptive_E5": ["adaptive", "e5"],
        "faithful_MD3": ["md3"],
        "full_monitor_E6": ["monitor", "overhead", "benchmark"],
        "original_statistics": ["holm", "sign_flip", "three_transformation"],
        "manuscript_repository": ["manuscript", "paper", "readme"],
    }.items():
        matches = []
        for current, dirs, names in os.walk(root, followlinks=False):
            current = Path(current)
            candidates = [current] + [current / name for name in names]
            for candidate in candidates:
                text = str(candidate.relative_to(root)).lower()
                if any(term in text for term in terms):
                    matches.append(candidate)

        receipt_rows.append({
            "input_root": str(root),
            "category": label,
            "matches": len(matches),
            "first_10_matches": " | ".join(
                str(p.relative_to(root)) for p in matches[:10]
            ),
        })

    root_rows.append({
        "input_root": str(root),
        "exists": True,
        "files": file_count,
        "bytes": total_bytes,
        "GiB": round(total_bytes / 1024**3, 4),
        "core_marker_hits": marker_hits,
        "complete_pacing_jobs": root_pace_complete,
        "complete_injection_jobs": root_injection_complete,
    })

root_table = pd.DataFrame(root_rows).sort_values(
    [
        "core_marker_hits",
        "complete_pacing_jobs",
        "complete_injection_jobs",
        "bytes",
    ],
    ascending=[False, False, False, False],
    na_position="last",
)
artifact_table = pd.DataFrame(artifact_rows)
pacing_table = pd.DataFrame(pacing_rows)
injection_table = pd.DataFrame(injection_rows)
other_table = pd.DataFrame(receipt_rows)

root_table.to_csv(OUT / "backup_root_ranking.csv", index=False)
artifact_table.to_csv(OUT / "required_asset_locations.csv", index=False)
pacing_table.to_csv(OUT / "pacing_receipts_found.csv", index=False)
injection_table.to_csv(OUT / "injection_receipts_found.csv", index=False)
other_table.to_csv(OUT / "other_work_locations.csv", index=False)

# Use the highest-ranked source only as the recommended initial restore source.
# This does not extract or copy anything.
best = root_table[
    root_table.exists
].iloc[0].to_dict() if root_table.exists.any() else None

report = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "recommended_initial_restore_root": (
        best["input_root"] if best else None
    ),
    "recommended_root_reason": (
        "Highest number of required continuation assets, then completed "
        "PACE jobs, then completed injection jobs, then total content size."
        if best else "No mounted input root exists."
    ),
    "required_marker_count": len(REQUIRED_PATH_MARKERS),
    "completed_pacing_receipts_found": int(
        pacing_table.complete.sum()
    ) if not pacing_table.empty else 0,
    "completed_injection_receipts_found": int(
        injection_table.complete.sum()
    ) if not injection_table.empty else 0,
    "free_working_GiB": round(
        shutil.disk_usage(WORK).free / 1024**3, 4
    ),
    "audit_directory": str(OUT),
}
(OUT / "resume_direct_audit.json").write_text(
    json.dumps(report, indent=2),
    encoding="utf-8"
)

print("\nBACKUP ROOT RANKING")
print(root_table.to_string(index=False))

print("\nPACE RECEIPTS FOUND")
if pacing_table.empty:
    print("No PACE_1s receipts found in any uploaded directory.")
else:
    print(
        pacing_table[
            [
                "input_root", "scenario", "status",
                "detector_results_present", "complete",
                "eligible_flows", "delayed_packets"
            ]
        ].to_string(index=False)
    )

print("\nINJECTION RECEIPTS FOUND")
if injection_table.empty:
    print("No INJ_k1 / INJ_k3 receipts found in any uploaded directory.")
else:
    print(
        injection_table[
            [
                "input_root", "scenario", "attack",
                "status", "primary_outputs_present", "complete"
            ]
        ].to_string(index=False)
    )

print("\nRECOMMENDED INITIAL RESTORE ROOT")
print(json.dumps(report, indent=2))

# ===== CELL INPUT 7 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil

SOURCE_DATASET = Path(
    "/kaggle/input/datasets/mdhamidborkottulla/full-backup"
).resolve()
WORK = Path("/kaggle/working").resolve()
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
RECEIPT = WORK / f"FULL_BACKUP_RESTORE_RECEIPT_{STAMP}.json"

REQUIRED_TOP_LEVEL = [
    "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z",
    "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2",
    "E4_COMPACT_INJECTIONS_v2",
    "E4_COMPACT_PACING_v1",
    "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def workspace_score(candidate):
    return sum((candidate / item).exists() for item in REQUIRED_TOP_LEVEL)

# The uploaded dataset may have a wrapper directory. Locate the actual
# workspace root from the frozen model directory rather than assuming layout.
model_paths = list(SOURCE_DATASET.rglob("frozen_source_models.joblib"))
if not model_paths:
    raise FileNotFoundError(
        "Could not find frozen_source_models.joblib in full-backup."
    )

candidate_roots = set()
for model_path in model_paths:
    model_dir = model_path.parent
    if model_dir.name == "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1":
        candidate_roots.add(model_dir.parent)

if not candidate_roots:
    raise RuntimeError("Could not infer a workspace root from the model path.")

SOURCE_ROOT = max(
    candidate_roots,
    key=lambda path: (
        workspace_score(path),
        -len(path.parts)
    )
)

source_files = []
source_dirs = []

for root, dirs, names in os.walk(SOURCE_ROOT, followlinks=False):
    root = Path(root)

    for dirname in dirs:
        path = root / dirname
        if not path.is_symlink():
            source_dirs.append(path)

    for name in names:
        path = root / name
        if path.is_file() or path.is_symlink():
            source_files.append(path)

source_files.sort(key=lambda p: p.relative_to(SOURCE_ROOT).as_posix())
source_dirs.sort(key=lambda p: p.relative_to(SOURCE_ROOT).as_posix())

source_bytes = sum(
    path.lstat().st_size if path.is_symlink() else path.stat().st_size
    for path in source_files
)
free_bytes = shutil.disk_usage(WORK).free

print(f"SOURCE WORKSPACE ROOT: {SOURCE_ROOT}")
print(f"Required top-level markers found: {workspace_score(SOURCE_ROOT)}/"
      f"{len(REQUIRED_TOP_LEVEL)}")
print(f"Files to restore: {len(source_files):,}")
print(f"Source data: {source_bytes / 1024**3:.4f} GiB")
print(f"Free working disk: {free_bytes / 1024**3:.4f} GiB")

if free_bytes < source_bytes + 512 * 1024**2:
    raise RuntimeError(
        "Insufficient free working disk for the restored workspace. "
        "No files were copied."
    )

# Preflight all file collisions before copying anything.
conflicts = []
identical_existing = 0

for source in source_files:
    relative = source.relative_to(SOURCE_ROOT)
    destination = WORK / relative

    if not destination.exists() and not destination.is_symlink():
        continue

    if source.is_symlink() or destination.is_symlink():
        if (
            source.is_symlink()
            and destination.is_symlink()
            and os.readlink(source) == os.readlink(destination)
        ):
            identical_existing += 1
            continue
        conflicts.append(relative.as_posix())
        continue

    if (
        source.is_file()
        and destination.is_file()
        and source.stat().st_size == destination.stat().st_size
        and sha256_file(source) == sha256_file(destination)
    ):
        identical_existing += 1
    else:
        conflicts.append(relative.as_posix())

if conflicts:
    raise RuntimeError(
        "Restore aborted. Existing non-identical files would be overwritten.\n"
        "First conflicts:\n" + "\n".join(conflicts[:30])
    )

copied = 0
skipped = 0

for directory in source_dirs:
    (WORK / directory.relative_to(SOURCE_ROOT)).mkdir(
        parents=True, exist_ok=True
    )

for index, source in enumerate(source_files, start=1):
    relative = source.relative_to(SOURCE_ROOT)
    destination = WORK / relative
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists() or destination.is_symlink():
        skipped += 1
        continue

    if source.is_symlink():
        os.symlink(os.readlink(source), destination)
    else:
        shutil.copy2(source, destination)
        if source.stat().st_size != destination.stat().st_size:
            raise RuntimeError(f"Copy-size validation failed: {relative}")

    copied += 1

    if index % 250 == 0 or index == len(source_files):
        print(
            f"Restored {index:,}/{len(source_files):,} files",
            flush=True
        )

marker_status = {
    marker: (WORK / marker).exists()
    for marker in REQUIRED_TOP_LEVEL
}

receipt = {
    "status": "FULL_BACKUP_RESTORE_COMPLETE",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "source_dataset": str(SOURCE_DATASET),
    "source_workspace_root": str(SOURCE_ROOT),
    "source_files": len(source_files),
    "source_bytes": source_bytes,
    "copied_files": copied,
    "identical_existing_files_skipped": skipped,
    "all_preexisting_files_were_identical": True,
    "required_marker_status": marker_status,
    "all_required_markers_present": all(marker_status.values()),
    "no_experiments_rerun": True,
    "no_existing_files_deleted": True,
}
RECEIPT.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

print("\nRESTORE COMPLETE")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 8 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

WORK = Path("/kaggle/working")
INJ = WORK / "E4_COMPACT_INJECTIONS_v2"
PACE = WORK / "E4_COMPACT_PACING_v1"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"EXPERIMENT_RESUMPTION_LEDGER_{STAMP}"
OUT.mkdir(exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

injection_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job = INJ / scenario / attack
        receipt_path = job / "receipt.json"
        output_path = job / "primary_outputs.npz"
        features_path = job / "attacked_selected_features.csv.gz"

        receipt = read_json(receipt_path) if receipt_path.is_file() else {}
        complete = bool(
            receipt.get("status") == "INJECTION_JOB_COMPLETE"
            and output_path.is_file()
            and features_path.is_file()
        )

        injection_rows.append({
            "scenario": scenario,
            "attack": attack,
            "complete": complete,
            "receipt_status": receipt.get("status"),
            "primary_outputs_present": output_path.is_file(),
            "features_present": features_path.is_file(),
        })

pacing_rows = []
for scenario in TARGETS:
    job = PACE / scenario
    receipt_path = job / "receipt.json"
    result_path = job / "detector_results.csv"
    receipt = read_json(receipt_path) if receipt_path.is_file() else {}

    complete = bool(
        receipt.get("status") == "PACING_JOB_COMPLETE"
        and result_path.is_file()
    )

    pacing_rows.append({
        "scenario": scenario,
        "complete": complete,
        "receipt_status": receipt.get("status"),
        "detector_results_present": result_path.is_file(),
        "eligible_flows": receipt.get("eligible_flows"),
        "delayed_packets": receipt.get("delayed_packets"),
        "mapping_fraction": receipt.get("mapping_fraction"),
        "seconds": receipt.get("seconds"),
    })

injection = pd.DataFrame(injection_rows)
pacing = pd.DataFrame(pacing_rows)

if injection.complete.sum() != 16:
    raise RuntimeError(
        f"Expected 16 complete injection jobs; found "
        f"{int(injection.complete.sum())}."
    )

if pacing.complete.sum() != 7:
    raise RuntimeError(
        f"Expected exactly 7 restored complete PACE jobs; found "
        f"{int(pacing.complete.sum())}."
    )

missing_pace = pacing.loc[~pacing.complete, "scenario"].tolist()
if missing_pace != ["CTU-IoT-Malware-Capture-49-1"]:
    raise RuntimeError(
        "Unexpected pending pacing set: " + repr(missing_pace)
    )

injection.to_csv(OUT / "injection_completion.csv", index=False)
pacing.to_csv(OUT / "pacing_completion.csv", index=False)

ledger = pd.DataFrame([
    {
        "item": "E4 compact injection jobs",
        "required": 16,
        "complete": int(injection.complete.sum()),
        "status": "COMPLETE" if injection.complete.all() else "INCOMPLETE",
    },
    {
        "item": "E4 PACE_1s jobs",
        "required": 8,
        "complete": int(pacing.complete.sum()),
        "status": "ONE_TARGET_REMAINS",
    },
    {
        "item": "Remaining PACE_1s target",
        "required": 1,
        "complete": 0,
        "status": missing_pace[0],
    },
    {
        "item": "E5 adaptive real-PCAP experiment",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "Faithful MD3 baseline",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "E6 full monitor overhead",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "E6 actual edge-device measurement",
        "required": 1,
        "complete": 0,
        "status": "REQUIRES_NON_KAGGLE_EDGE_HARDWARE",
    },
    {
        "item": "Original-protocol final statistics",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
], columns=["item", "required", "complete", "status"])

ledger.to_csv(OUT / "remaining_work_ledger.csv", index=False)

print("INJECTION JOBS")
print(injection.to_string(index=False))

print("\nPACE_1s JOBS")
print(pacing.to_string(index=False))

print("\nRESUMPTION LEDGER")
print(ledger.to_string(index=False))

print(f"\nSaved: {OUT}")

# ===== CELL INPUT 9 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

WORK = Path("/kaggle/working")
INJ = WORK / "E4_COMPACT_INJECTIONS_v2"
PACE = WORK / "E4_COMPACT_PACING_v1"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"EXPERIMENT_RESUMPTION_LEDGER_{STAMP}"
OUT.mkdir(exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

injection_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job = INJ / scenario / attack
        receipt_path = job / "receipt.json"
        output_path = job / "primary_outputs.npz"
        features_path = job / "attacked_selected_features.csv.gz"

        receipt = read_json(receipt_path) if receipt_path.is_file() else {}
        complete = bool(
            receipt.get("status") == "INJECTION_JOB_COMPLETE"
            and output_path.is_file()
            and features_path.is_file()
        )

        injection_rows.append({
            "scenario": scenario,
            "attack": attack,
            "complete": complete,
            "receipt_status": receipt.get("status"),
            "primary_outputs_present": output_path.is_file(),
            "features_present": features_path.is_file(),
        })

pacing_rows = []
for scenario in TARGETS:
    job = PACE / scenario
    receipt_path = job / "receipt.json"
    result_path = job / "detector_results.csv"
    receipt = read_json(receipt_path) if receipt_path.is_file() else {}

    complete = bool(
        receipt.get("status") == "PACING_JOB_COMPLETE"
        and result_path.is_file()
    )

    pacing_rows.append({
        "scenario": scenario,
        "complete": complete,
        "receipt_status": receipt.get("status"),
        "detector_results_present": result_path.is_file(),
        "eligible_flows": receipt.get("eligible_flows"),
        "delayed_packets": receipt.get("delayed_packets"),
        "mapping_fraction": receipt.get("mapping_fraction"),
        "seconds": receipt.get("seconds"),
    })

injection = pd.DataFrame(injection_rows)
pacing = pd.DataFrame(pacing_rows)

if injection.complete.sum() != 16:
    raise RuntimeError(
        f"Expected 16 complete injection jobs; found "
        f"{int(injection.complete.sum())}."
    )

if pacing.complete.sum() != 7:
    raise RuntimeError(
        f"Expected exactly 7 restored complete PACE jobs; found "
        f"{int(pacing.complete.sum())}."
    )

missing_pace = pacing.loc[~pacing.complete, "scenario"].tolist()
if missing_pace != ["CTU-IoT-Malware-Capture-49-1"]:
    raise RuntimeError(
        "Unexpected pending pacing set: " + repr(missing_pace)
    )

injection.to_csv(OUT / "injection_completion.csv", index=False)
pacing.to_csv(OUT / "pacing_completion.csv", index=False)

ledger = pd.DataFrame([
    {
        "item": "E4 compact injection jobs",
        "required": 16,
        "complete": int(injection.complete.sum()),
        "status": "COMPLETE" if injection.complete.all() else "INCOMPLETE",
    },
    {
        "item": "E4 PACE_1s jobs",
        "required": 8,
        "complete": int(pacing.complete.sum()),
        "status": "ONE_TARGET_REMAINS",
    },
    {
        "item": "Remaining PACE_1s target",
        "required": 1,
        "complete": 0,
        "status": missing_pace[0],
    },
    {
        "item": "E5 adaptive real-PCAP experiment",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "Faithful MD3 baseline",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "E6 full monitor overhead",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
    {
        "item": "E6 actual edge-device measurement",
        "required": 1,
        "complete": 0,
        "status": "REQUIRES_NON_KAGGLE_EDGE_HARDWARE",
    },
    {
        "item": "Original-protocol final statistics",
        "required": 1,
        "complete": 0,
        "status": "NOT_YET_VERIFIED_OR_RUN",
    },
], columns=["item", "required", "complete", "status"])

ledger.to_csv(OUT / "remaining_work_ledger.csv", index=False)

print("INJECTION JOBS")
print(injection.to_string(index=False))

print("\nPACE_1s JOBS")
print(pacing.to_string(index=False))

print("\nRESUMPTION LEDGER")
print(ledger.to_string(index=False))

print(f"\nSaved: {OUT}")

# ===== CELL INPUT 10 =====
from pathlib import Path
import json
import os
import shutil

WORK = Path("/kaggle/working").resolve()

ROOTS = {
    "working": WORK,
    "full_backup": Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup"
    ),
    "one_last": Path(
        "/kaggle/input/datasets/mdhamidborkottulla/one-last"
    ),
    "all_kaggle_work": Path(
        "/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"
    ),
    "complete_backup": Path(
        "/kaggle/input/datasets/mdhamidborkottulla/complete-backup"
    ),
    "last_day_backup": Path(
        "/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"
    ),
}

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

def find_named_directories(root, name):
    found = []
    if not root.is_dir():
        return found

    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)
        if current.name == name:
            found.append(current)

    return sorted(found, key=lambda path: str(path))

def tree_size(path):
    total = 0
    files = 0

    if path.is_file():
        return path.stat().st_size, 1

    for current, dirs, names in os.walk(path, followlinks=False):
        current = Path(current)
        for name in names:
            item = current / name
            try:
                total += item.lstat().st_size
                files += 1
            except FileNotFoundError:
                pass

    return total, files

def valid_injection_jobs(injection_root):
    rows = []

    for scenario in TARGETS:
        for attack in ["INJ_k1", "INJ_k3"]:
            job = injection_root / scenario / attack
            receipt_path = job / "receipt.json"
            outputs = job / "primary_outputs.npz"
            features = job / "attacked_selected_features.csv.gz"

            receipt = (
                read_json(receipt_path)
                if receipt_path.is_file() else {}
            )
            valid = bool(
                receipt.get("status") == "INJECTION_JOB_COMPLETE"
                and outputs.is_file()
                and features.is_file()
            )

            rows.append({
                "scenario": scenario,
                "attack": attack,
                "valid": valid,
                "receipt_status": receipt.get("status"),
                "receipt_path": str(receipt_path),
                "outputs_present": outputs.is_file(),
                "features_present": features.is_file(),
            })

    return rows

def valid_pacing_jobs(pacing_root):
    rows = []

    for scenario in TARGETS:
        job = pacing_root / scenario
        receipt_path = job / "receipt.json"
        result_path = job / "detector_results.csv"

        receipt = (
            read_json(receipt_path)
            if receipt_path.is_file() else {}
        )
        valid = bool(
            receipt.get("status") == "PACING_JOB_COMPLETE"
            and result_path.is_file()
        )

        rows.append({
            "scenario": scenario,
            "valid": valid,
            "receipt_status": receipt.get("status"),
            "receipt_path": str(receipt_path),
            "results_present": result_path.is_file(),
        })

    return rows

print("=" * 88)
print("DISK STATE — NO FILES ARE CHANGED")
print("=" * 88)
disk = shutil.disk_usage(WORK)
print(f"Working free space:  {disk.free / 1024**3:.4f} GiB")
print(f"Working used space:  {disk.used / 1024**3:.4f} GiB")
print(f"Working total space: {disk.total / 1024**3:.4f} GiB")

print("\n" + "=" * 88)
print("LARGEST TOP-LEVEL WORKING-DIRECTORY ITEMS")
print("=" * 88)

top_items = []
for path in WORK.iterdir():
    try:
        size, files = tree_size(path)
        top_items.append((size, files, path))
    except Exception as error:
        print(f"Could not size {path}: {type(error).__name__}: {error}")

for size, files, path in sorted(top_items, reverse=True)[:30]:
    print(
        f"{size / 1024**3:8.4f} GiB | "
        f"{files:6,} files | {path.name}"
    )

print("\n" + "=" * 88)
print("EXACT INJECTION AND PACING ROOTS FOUND")
print("=" * 88)

all_valid_injection_sources = []
all_valid_pacing_sources = []

for label, root in ROOTS.items():
    print(f"\n[{label}] {root}")

    if not root.is_dir():
        print("  ROOT MISSING")
        continue

    injection_roots = find_named_directories(
        root, "E4_COMPACT_INJECTIONS_v2"
    )
    pacing_roots = find_named_directories(
        root, "E4_COMPACT_PACING_v1"
    )
    model_roots = find_named_directories(
        root, "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    )
    clean_roots = find_named_directories(
        root,
        "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_"
        "20261012T181242007570Z"
    )

    print(f"  Injection roots: {len(injection_roots)}")
    print(f"  Pacing roots:    {len(pacing_roots)}")
    print(f"  Model roots:     {len(model_roots)}")
    print(f"  Clean roots:     {len(clean_roots)}")

    for root_path in injection_roots:
        rows = valid_injection_jobs(root_path)
        valid_count = sum(row["valid"] for row in rows)

        print(
            f"\n  INJECTION ROOT: {root_path}\n"
            f"  Valid jobs: {valid_count}/16"
        )

        for row in rows:
            if row["valid"]:
                print(
                    f"    VALID  {row['scenario']} / {row['attack']}"
                )
            elif row["receipt_status"] is not None:
                print(
                    f"    INVALID {row['scenario']} / {row['attack']} | "
                    f"status={row['receipt_status']} | "
                    f"outputs={row['outputs_present']} | "
                    f"features={row['features_present']}"
                )

        if valid_count == 16:
            all_valid_injection_sources.append(str(root_path))

    for root_path in pacing_roots:
        rows = valid_pacing_jobs(root_path)
        valid_count = sum(row["valid"] for row in rows)

        print(
            f"\n  PACING ROOT: {root_path}\n"
            f"  Valid jobs: {valid_count}/8"
        )

        for row in rows:
            state = "VALID" if row["valid"] else "PENDING/INVALID"
            print(
                f"    {state:15s} {row['scenario']} | "
                f"status={row['receipt_status']} | "
                f"results={row['results_present']}"
            )

        if valid_count > 0:
            all_valid_pacing_sources.append(str(root_path))

print("\n" + "=" * 88)
print("RESTORE RECEIPTS ALREADY PRESENT IN WORKING")
print("=" * 88)

restore_receipts = sorted(
    WORK.glob("FULL_BACKUP_RESTORE_RECEIPT_*.json"),
    key=lambda path: path.stat().st_mtime_ns,
    reverse=True
)

if not restore_receipts:
    print("No Cell-1 restore receipt found.")
else:
    for receipt_path in restore_receipts[:5]:
        receipt = read_json(receipt_path)
        print(f"\n{receipt_path.name}")
        print(
            json.dumps({
                key: receipt.get(key)
                for key in [
                    "status",
                    "source_workspace_root",
                    "source_files",
                    "source_bytes",
                    "copied_files",
                    "identical_existing_files_skipped",
                    "all_required_markers_present",
                    "required_marker_status",
                ]
            },
            indent=2)
        )

print("\n" + "=" * 88)
print("DIAGNOSIS SUMMARY")
print("=" * 88)
print("Locations with all 16 valid injection jobs:")
for path in all_valid_injection_sources:
    print("  -", path)

print("\nLocations with one or more valid PACE jobs:")
for path in all_valid_pacing_sources:
    print("  -", path)

print(
    "\nNo copying, deletion, overwrite, replay, model training, "
    "or experiment execution occurred in this diagnostic."
)

# ===== CELL INPUT 11 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

WORK = Path("/kaggle/working")
INJ = WORK / "E4_COMPACT_INJECTIONS_v2"
PACE = WORK / "E4_COMPACT_PACING_v1"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"CORRECTED_E4_COMPLETION_LEDGER_{STAMP}"
OUT.mkdir(exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

injection_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job = INJ / scenario / attack
        receipt_path = job / "receipt.json"
        outputs_path = job / "primary_outputs.npz"
        features_path = job / "attacked_selected_features.csv.gz"

        receipt = (
            read_json(receipt_path)
            if receipt_path.is_file() else {}
        )

        # Correct criterion:
        # receipt + primary prediction outputs constitute the completed
        # compact injection job. The selected feature artifact is optional.
        complete = bool(
            receipt.get("status") == "INJECTION_JOB_COMPLETE"
            and outputs_path.is_file()
        )

        injection_rows.append({
            "scenario": scenario,
            "attack": attack,
            "complete": complete,
            "receipt_status": receipt.get("status"),
            "primary_outputs_present": outputs_path.is_file(),
            "optional_features_present": features_path.is_file(),
            "receipt_path": str(receipt_path),
        })

pacing_rows = []
for scenario in TARGETS:
    job = PACE / scenario
    receipt_path = job / "receipt.json"
    results_path = job / "detector_results.csv"

    receipt = (
        read_json(receipt_path)
        if receipt_path.is_file() else {}
    )
    complete = bool(
        receipt.get("status") == "PACING_JOB_COMPLETE"
        and results_path.is_file()
    )

    pacing_rows.append({
        "scenario": scenario,
        "complete": complete,
        "receipt_status": receipt.get("status"),
        "detector_results_present": results_path.is_file(),
        "eligible_flows": receipt.get("eligible_flows"),
        "delayed_packets": receipt.get("delayed_packets"),
        "mapping_fraction": receipt.get("mapping_fraction"),
    })

injection = pd.DataFrame(injection_rows)
pacing = pd.DataFrame(pacing_rows)

if injection.complete.sum() != 16:
    raise RuntimeError(
        "Unexpected injection state. Expected 16 valid receipt/output "
        f"pairs but found {int(injection.complete.sum())}."
    )

if pacing.complete.sum() != 7:
    raise RuntimeError(
        "Unexpected pacing state. Expected 7 completed jobs but found "
        f"{int(pacing.complete.sum())}."
    )

pending = pacing.loc[~pacing.complete, "scenario"].tolist()
if pending != ["CTU-IoT-Malware-Capture-49-1"]:
    raise RuntimeError(f"Unexpected pending pacing scenarios: {pending}")

injection.to_csv(OUT / "injection_jobs.csv", index=False)
pacing.to_csv(OUT / "pacing_jobs.csv", index=False)

ledger = pd.DataFrame([
    {
        "experiment": "E4 compact injections",
        "required_jobs": 16,
        "completed_jobs": int(injection.complete.sum()),
        "status": "COMPLETE — DO NOT RERUN",
        "completion_rule": (
            "INJECTION_JOB_COMPLETE receipt plus primary_outputs.npz"
        ),
    },
    {
        "experiment": "E4 PACE_1s",
        "required_jobs": 8,
        "completed_jobs": int(pacing.complete.sum()),
        "status": "ONE JOB REMAINS",
        "completion_rule": (
            "PACING_JOB_COMPLETE receipt plus detector_results.csv"
        ),
    },
    {
        "experiment": "Missing pacing target",
        "required_jobs": 1,
        "completed_jobs": 0,
        "status": "CTU-IoT-Malware-Capture-49-1",
        "completion_rule": "Run once after disk-space preflight passes",
    },
], columns=[
    "experiment", "required_jobs", "completed_jobs",
    "status", "completion_rule"
])

ledger.to_csv(OUT / "corrected_ledger.csv", index=False)

receipt = {
    "status": "CORRECTED_E4_AUDIT_COMPLETE",
    "injections_complete": int(injection.complete.sum()),
    "pacing_complete": int(pacing.complete.sum()),
    "pending_pacing": pending,
    "important_correction": (
        "Missing attacked_selected_features.csv.gz does not invalidate "
        "a completed injection job when receipt and primary outputs exist."
    ),
    "injections_rerun": 0,
    "files_deleted": 0,
}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2))

print("CORRECTED E4 LEDGER")
print(ledger.to_string(index=False))

print("\nINJECTION COMPLETION CHECK")
print(
    injection.groupby(
        ["complete", "optional_features_present"],
        dropna=False
    ).size().rename("jobs").reset_index().to_string(index=False)
)

print("\nPACE STATUS")
print(pacing.to_string(index=False))

print("\nRECEIPT")
print(json.dumps(receipt, indent=2))
print(f"\nSaved: {OUT}")

# ===== CELL INPUT 12 =====
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import pandas as pd
import joblib

WORK = Path("/kaggle/working")
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
CLEAN_SAMPLE = (
    WORK
    / "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z"
    / SCENARIO
    / "frozen_clean_target_sample.csv.gz"
)
ASSET_CSV = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
HELPER = WORK / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
PACE_JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO

ZEEK_CANDIDATES = [
    Path("/opt/zeek/bin/zeek"),
    Path("/usr/local/bin/zeek"),
    Path("/usr/bin/zeek"),
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

for path in [MODEL, CLEAN_SAMPLE, ASSET_CSV, HELPER]:
    if not path.is_file():
        raise FileNotFoundError(f"Required restored file missing: {path}")

zeek = next((path for path in ZEEK_CANDIDATES if path.is_file()), None)
if zeek is None:
    raise FileNotFoundError("Zeek executable not found.")

existing_receipt = PACE_JOB / "receipt.json"
if existing_receipt.is_file():
    receipt = json.loads(existing_receipt.read_text())
    if receipt.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 already has a completed PACE receipt; refusing rerun."
        )

sample = pd.read_csv(CLEAN_SAMPLE, dtype={"ks": str})
if len(sample) != 1024 or sample.ks.duplicated().any():
    raise ValueError("Frozen Capture 49 sample is invalid.")

assets = pd.read_csv(ASSET_CSV)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise ValueError(
        f"Expected exactly one resolved asset row; got {len(asset)}."
    )

asset = asset.iloc[0]
pcap = Path(asset.pcap_path)
conn_log = Path(asset.conn_log_path)

if not pcap.is_file():
    raise FileNotFoundError(f"Capture 49 PCAP unavailable: {pcap}")
if not conn_log.is_file():
    raise FileNotFoundError(f"Capture 49 conn.log unavailable: {conn_log}")

pcap_sha_ok = sha256_file(pcap) == asset.pcap_sha256
if not pcap_sha_ok:
    raise ValueError("Capture 49 PCAP checksum does not match frozen asset CSV.")

bundle = joblib.load(MODEL)
seeds = sorted(str(seed) for seed in bundle["models"])
if seeds != ["8101", "8102", "8103"]:
    raise ValueError(f"Unexpected frozen seed set: {seeds}")

disk = shutil.disk_usage(WORK)
pcap_bytes = pcap.stat().st_size

# Conservative requirement:
# one transformed PCAP + SQLite ordering index + Zeek temporary logs +
# 1 GiB safety margin. This does not include any additional backup copies.
required_bytes = (
    2 * pcap_bytes
    + int(0.15 * pcap_bytes)
    + 1024**3
)

preflight = {
    "scenario": SCENARIO,
    "status": (
        "PREFLIGHT_PASS"
        if disk.free >= required_bytes else "INSUFFICIENT_DISK_SPACE"
    ),
    "frozen_sample_rows": len(sample),
    "frozen_positive_rows": int(sample.y.sum()),
    "pcap": str(pcap),
    "pcap_GiB": round(pcap_bytes / 1024**3, 4),
    "pcap_sha256_verified": True,
    "conn_log": str(conn_log),
    "zeek": str(zeek),
    "frozen_seeds": seeds,
    "free_working_GiB": round(disk.free / 1024**3, 4),
    "conservative_required_GiB": round(required_bytes / 1024**3, 4),
    "space_margin_GiB": round(
        (disk.free - required_bytes) / 1024**3, 4
    ),
    "existing_capture49_receipt": existing_receipt.exists(),
    "files_deleted": 0,
    "copies_created": 0,
    "experiments_rerun": 0,
}

PACE_JOB.mkdir(parents=True, exist_ok=True)
(PACE_JOB / "capture49_preflight.json").write_text(
    json.dumps(preflight, indent=2),
    encoding="utf-8"
)

print(json.dumps(preflight, indent=2))

if preflight["status"] != "PREFLIGHT_PASS":
    raise RuntimeError(
        "Capture 49 pacing has NOT started because the conservative "
        "temporary-space requirement does not fit in working storage."
    )

# ===== CELL INPUT 13 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from decimal import Decimal
import ast
import bisect
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"
PACE_ROOT = WORK / "E4_COMPACT_PACING_v1"
JOB = PACE_ROOT / SCENARIO

SEARCH_ROOTS = [
    WORK,
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
]

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

PCAP_MAGICS = {
    b"\xd4\xc3\xb2\xa1": ("<", 1000),
    b"\xa1\xb2\xc3\xd4": (">", 1000),
    b"\x4d\x3c\xb2\xa1": ("<", 1),
    b"\xa1\xb2\x3c\x4d": (">", 1),
}

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    frame["proto"] = frame["proto"].astype(str).str.lower()
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    return frame

def locate_all(filename):
    found = []

    for root in SEARCH_ROOTS:
        if not root.is_dir():
            continue

        for candidate in root.rglob(filename):
            if candidate.is_file():
                found.append(candidate)

    return sorted(
        set(found),
        key=lambda path: (
            0 if str(path).startswith(str(WORK)) else 1,
            len(path.parts),
            str(path),
        )
    )

def locate_model():
    candidates = locate_all("frozen_source_models.joblib")
    candidates = [
        path for path in candidates
        if path.parent.name == "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    ]

    if not candidates:
        raise FileNotFoundError(
            "Could not locate frozen_source_models.joblib in any mounted "
            "backup or restored working tree."
        )

    return candidates[0]

def locate_clean_sample():
    candidates = locate_all("frozen_clean_target_sample.csv.gz")
    candidates = [
        path for path in candidates
        if path.parent.name == SCENARIO
        and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1"
        in str(path)
    ]

    valid = []
    for path in candidates:
        try:
            frame = pd.read_csv(path, dtype={"ks": str}, nrows=1030)
            if (
                len(frame) == 1024
                and "ks" in frame.columns
                and "y" in frame.columns
                and not frame.ks.astype(str).duplicated().any()
            ):
                valid.append(path)
        except Exception:
            pass

    if not valid:
        searched = "\n".join(str(root) for root in SEARCH_ROOTS)
        raise FileNotFoundError(
            "No valid frozen Capture 49 sample was found. Searched:\n"
            + searched
        )

    return valid[0]

def locate_helper():
    candidates = locate_all("run_streaming_confirmatory_batch_A_v1_2_fixed.py")
    if not candidates:
        raise FileNotFoundError(
            "Could not locate run_streaming_confirmatory_batch_A_v1_2_fixed.py."
        )
    return candidates[0]

def locate_asset_csv():
    candidates = locate_all("target_asset_resolution.csv")
    valid = []

    for path in candidates:
        try:
            table = pd.read_csv(path)
            row = table[
                (table.scenario == SCENARIO)
                & (table.status == "RESOLVED")
            ]
            if len(row) == 1:
                valid.append(path)
        except Exception:
            pass

    if not valid:
        raise FileNotFoundError(
            "No target_asset_resolution.csv contains one resolved Capture 49 row."
        )

    return valid[0]

def choose_zeek():
    candidates = [
        Path("/opt/zeek/bin/zeek"),
        Path("/usr/local/bin/zeek"),
        Path("/usr/bin/zeek"),
    ]
    zeek = next((path for path in candidates if path.is_file()), None)

    if zeek is None:
        raise FileNotFoundError("Zeek executable was not found.")

    return zeek

def extract_packet_helpers(helper_path):
    required = {
        "key", "skey", "mat",
        "pcap_iter", "pcap_header",
        "tcp", "log_iter"
    }

    tree = ast.parse(helper_path.read_text(encoding="utf-8"))
    definitions = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name in required
    ]

    found = {node.name for node in definitions}
    missing = required - found

    if missing:
        raise RuntimeError(
            "Required packet helper definitions missing from runner: "
            + ", ".join(sorted(missing))
        )

    namespace = dict(globals())
    module = ast.Module(body=definitions, type_ignores=[])
    exec(
        compile(
            ast.fix_missing_locations(module),
            "capture49_verified_helpers",
            "exec"
        ),
        namespace
    )

    return namespace

def zeek_memory_limit():
    limit = 6 * 1024**3
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

def validate_existing_job():
    receipt_path = JOB / "receipt.json"

    if receipt_path.is_file():
        receipt = read_json(receipt_path)

        if receipt.get("status") == "PACING_JOB_COMPLETE":
            raise RuntimeError(
                "Capture 49 already has a completed pacing receipt. "
                "Refusing to rerun it."
            )

def build_preflight(
    model_path, clean_path, asset_path, helper_path,
    pcap_path, conn_path, pcap_bytes, free_bytes,
    minimum_required_bytes, zeek_path
):
    return {
        "status": (
            "PREFLIGHT_PASS"
            if free_bytes >= minimum_required_bytes
            else "INSUFFICIENT_DISK_SPACE"
        ),
        "scenario": SCENARIO,
        "model": str(model_path),
        "clean_sample": str(clean_path),
        "target_assets": str(asset_path),
        "helper": str(helper_path),
        "source_pcap": str(pcap_path),
        "source_conn_log": str(conn_path),
        "source_pcap_GiB": round(pcap_bytes / 1024**3, 4),
        "zeek": str(zeek_path),
        "free_working_GiB": round(free_bytes / 1024**3, 4),
        "minimum_required_GiB": round(
            minimum_required_bytes / 1024**3, 4
        ),
        "space_margin_GiB": round(
            (free_bytes - minimum_required_bytes) / 1024**3, 4
        ),
        "temporary_files": (
            "One transformed PCAP, disk-backed packet-order SQLite index, "
            "Zeek logs, and a fixed 1.25 GiB safety reserve."
        ),
        "no_backup_copying": True,
        "completed_jobs_rerun": 0,
    }

validate_existing_job()
JOB.mkdir(parents=True, exist_ok=True)

model_path = locate_model()
clean_path = locate_clean_sample()
asset_path = locate_asset_csv()
helper_path = locate_helper()
zeek_path = choose_zeek()

sample = normalize(pd.read_csv(clean_path, dtype={"ks": str}))

if len(sample) != 1024:
    raise ValueError(
        f"Capture 49 frozen sample must contain 1,024 rows; found {len(sample)}."
    )

if sample.ks.duplicated().any():
    raise ValueError("Capture 49 frozen sample has duplicate keys.")

if set(sample.y.unique()) != {0, 1}:
    raise ValueError("Capture 49 frozen sample labels are not binary.")

assets = pd.read_csv(asset_path)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise ValueError(
        f"Expected exactly one resolved Capture 49 asset row; got {len(asset)}."
    )

asset = asset.iloc[0]
pcap_path = Path(asset.pcap_path)
conn_path = Path(asset.conn_log_path)

if not pcap_path.is_file():
    raise FileNotFoundError(f"Capture 49 PCAP not available: {pcap_path}")

if not conn_path.is_file():
    raise FileNotFoundError(f"Capture 49 conn.log not available: {conn_path}")

if sha256_file(pcap_path) != asset.pcap_sha256:
    raise ValueError("Capture 49 PCAP checksum differs from frozen asset CSV.")

bundle = joblib.load(model_path)
model_seeds = sorted(str(seed) for seed in bundle["models"])

if model_seeds != ["8101", "8102", "8103"]:
    raise ValueError(
        f"Expected frozen seeds 8101/8102/8103; got {model_seeds}."
    )

pcap_bytes = pcap_path.stat().st_size
free_before = shutil.disk_usage(WORK).free

# The source PCAP stays read-only in /kaggle/input. Only one transformed PCAP
# is written under /kaggle/working. The SQLite offset index is bounded at
# 80 bytes per packet after the first pass, plus a 1.25 GiB safety reserve.
# The actual count is added after the first pass, before temp output begins.
initial_required = pcap_bytes + int(1.25 * 1024**3)

preflight = build_preflight(
    model_path=model_path,
    clean_path=clean_path,
    asset_path=asset_path,
    helper_path=helper_path,
    pcap_path=pcap_path,
    conn_path=conn_path,
    pcap_bytes=pcap_bytes,
    free_bytes=free_before,
    minimum_required_bytes=initial_required,
    zeek_path=zeek_path,
)

write_json(JOB / "capture49_preflight.json", preflight)
print("RESOLVED CAPTURE 49 INPUTS")
print(json.dumps(preflight, indent=2))

if preflight["status"] != "PREFLIGHT_PASS":
    raise RuntimeError(
        "PACE did not start: transformed-PCAP reserve does not fit in "
        "remaining working storage. No packet files were created."
    )

helpers = extract_packet_helpers(helper_path)
key = helpers["key"]
skey = helpers["skey"]
mat = helpers["mat"]
pcap_iter = helpers["pcap_iter"]
pcap_header = helpers["pcap_header"]
tcp = helpers["tcp"]
log_iter = helpers["log_iter"]

wanted_keys = set(sample.ks)
labels = dict(zip(sample.ks, sample.y.astype(int)))
flows = {}

for row in log_iter(conn_path):
    flow_key = skey(key(
        row["ts"],
        row["id.orig_h"],
        row["id.orig_p"],
        row["id.resp_h"],
        row["id.resp_p"],
        row["proto"],
    ))

    if flow_key in wanted_keys:
        if flow_key in flows:
            raise ValueError(
                f"Ambiguous clean conn.log flow key: {flow_key}"
            )
        flows[flow_key] = row

if set(flows) != wanted_keys:
    missing = sorted(wanted_keys - set(flows))
    raise ValueError(
        "Frozen Capture 49 sample does not resolve uniquely in conn.log. "
        f"Missing keys: {len(missing)}."
    )

descriptions = defaultdict(list)

for flow_key, row in flows.items():
    if labels[flow_key] != 1 or str(row["proto"]).lower() != "tcp":
        continue

    start_ns = int(Decimal(str(row["ts"])) * 10**9)
    duration_ns = (
        0
        if row["duration"] == "-"
        else int(Decimal(str(row["duration"])) * 10**9)
    )

    endpoints = tuple(sorted([
        (row["id.orig_h"], int(row["id.orig_p"])),
        (row["id.resp_h"], int(row["id.resp_p"])),
    ]))

    descriptions[endpoints].append(
        (start_ns, start_ns + duration_ns + 1_000_000, flow_key)
    )

for values in descriptions.values():
    values.sort()

starts = {
    endpoint: [item[0] for item in values]
    for endpoint, values in descriptions.items()
}

pcap_file_header, endian, unit, network = pcap_header(pcap_path)

def selected_flow_for_packet(timestamp_ns, payload):
    packet_info = tcp(payload, network)

    if packet_info is None:
        return None

    source_host, source_port, dest_host, dest_port, _, _ = packet_info
    endpoints = tuple(sorted([
        (source_host, source_port),
        (dest_host, dest_port),

# ===== CELL INPUT 14 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from decimal import Decimal
import ast
import bisect
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"
PACE_ROOT = WORK / "E4_COMPACT_PACING_v1"
JOB = PACE_ROOT / SCENARIO

SEARCH_ROOTS = [
    WORK,
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
]

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

PCAP_MAGICS = {
    b"\xd4\xc3\xb2\xa1": ("<", 1000),
    b"\xa1\xb2\xc3\xd4": (">", 1000),
    b"\x4d\x3c\xb2\xa1": ("<", 1),
    b"\xa1\xb2\x3c\x4d": (">", 1),
}

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    frame["proto"] = frame["proto"].astype(str).str.lower()
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    return frame

def locate_all(filename):
    found = []

    for root in SEARCH_ROOTS:
        if not root.is_dir():
            continue

        for candidate in root.rglob(filename):
            if candidate.is_file():
                found.append(candidate)

    return sorted(
        set(found),
        key=lambda path: (
            0 if str(path).startswith(str(WORK)) else 1,
            len(path.parts),
            str(path),
        )
    )

def locate_model():
    candidates = locate_all("frozen_source_models.joblib")
    candidates = [
        path for path in candidates
        if path.parent.name == "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    ]

    if not candidates:
        raise FileNotFoundError(
            "Could not locate frozen_source_models.joblib in any mounted "
            "backup or restored working tree."
        )

    return candidates[0]

def locate_clean_sample():
    candidates = locate_all("frozen_clean_target_sample.csv.gz")
    candidates = [
        path for path in candidates
        if path.parent.name == SCENARIO
        and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1"
        in str(path)
    ]

    valid = []
    for path in candidates:
        try:
            frame = pd.read_csv(path, dtype={"ks": str}, nrows=1030)
            if (
                len(frame) == 1024
                and "ks" in frame.columns
                and "y" in frame.columns
                and not frame.ks.astype(str).duplicated().any()
            ):
                valid.append(path)
        except Exception:
            pass

    if not valid:
        searched = "\n".join(str(root) for root in SEARCH_ROOTS)
        raise FileNotFoundError(
            "No valid frozen Capture 49 sample was found. Searched:\n"
            + searched
        )

    return valid[0]

def locate_helper():
    candidates = locate_all("run_streaming_confirmatory_batch_A_v1_2_fixed.py")
    if not candidates:
        raise FileNotFoundError(
            "Could not locate run_streaming_confirmatory_batch_A_v1_2_fixed.py."
        )
    return candidates[0]

def locate_asset_csv():
    candidates = locate_all("target_asset_resolution.csv")
    valid = []

    for path in candidates:
        try:
            table = pd.read_csv(path)
            row = table[
                (table.scenario == SCENARIO)
                & (table.status == "RESOLVED")
            ]
            if len(row) == 1:
                valid.append(path)
        except Exception:
            pass

    if not valid:
        raise FileNotFoundError(
            "No target_asset_resolution.csv contains one resolved Capture 49 row."
        )

    return valid[0]

def choose_zeek():
    candidates = [
        Path("/opt/zeek/bin/zeek"),
        Path("/usr/local/bin/zeek"),
        Path("/usr/bin/zeek"),
    ]
    zeek = next((path for path in candidates if path.is_file()), None)

    if zeek is None:
        raise FileNotFoundError("Zeek executable was not found.")

    return zeek

def extract_packet_helpers(helper_path):
    required = {
        "key", "skey", "mat",
        "pcap_iter", "pcap_header",
        "tcp", "log_iter"
    }

    tree = ast.parse(helper_path.read_text(encoding="utf-8"))
    definitions = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name in required
    ]

    found = {node.name for node in definitions}
    missing = required - found

    if missing:
        raise RuntimeError(
            "Required packet helper definitions missing from runner: "
            + ", ".join(sorted(missing))
        )

    namespace = dict(globals())
    module = ast.Module(body=definitions, type_ignores=[])
    exec(
        compile(
            ast.fix_missing_locations(module),
            "capture49_verified_helpers",
            "exec"
        ),
        namespace
    )

    return namespace

def zeek_memory_limit():
    limit = 6 * 1024**3
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

def validate_existing_job():
    receipt_path = JOB / "receipt.json"

    if receipt_path.is_file():
        receipt = read_json(receipt_path)

        if receipt.get("status") == "PACING_JOB_COMPLETE":
            raise RuntimeError(
                "Capture 49 already has a completed pacing receipt. "
                "Refusing to rerun it."
            )

def build_preflight(
    model_path, clean_path, asset_path, helper_path,
    pcap_path, conn_path, pcap_bytes, free_bytes,
    minimum_required_bytes, zeek_path
):
    return {
        "status": (
            "PREFLIGHT_PASS"
            if free_bytes >= minimum_required_bytes
            else "INSUFFICIENT_DISK_SPACE"
        ),
        "scenario": SCENARIO,
        "model": str(model_path),
        "clean_sample": str(clean_path),
        "target_assets": str(asset_path),
        "helper": str(helper_path),
        "source_pcap": str(pcap_path),
        "source_conn_log": str(conn_path),
        "source_pcap_GiB": round(pcap_bytes / 1024**3, 4),
        "zeek": str(zeek_path),
        "free_working_GiB": round(free_bytes / 1024**3, 4),
        "minimum_required_GiB": round(
            minimum_required_bytes / 1024**3, 4
        ),
        "space_margin_GiB": round(
            (free_bytes - minimum_required_bytes) / 1024**3, 4
        ),
        "temporary_files": (
            "One transformed PCAP, disk-backed packet-order SQLite index, "
            "Zeek logs, and a fixed 1.25 GiB safety reserve."
        ),
        "no_backup_copying": True,
        "completed_jobs_rerun": 0,
    }

validate_existing_job()
JOB.mkdir(parents=True, exist_ok=True)

model_path = locate_model()
clean_path = locate_clean_sample()
asset_path = locate_asset_csv()
helper_path = locate_helper()
zeek_path = choose_zeek()

sample = normalize(pd.read_csv(clean_path, dtype={"ks": str}))

if len(sample) != 1024:
    raise ValueError(
        f"Capture 49 frozen sample must contain 1,024 rows; found {len(sample)}."
    )

if sample.ks.duplicated().any():
    raise ValueError("Capture 49 frozen sample has duplicate keys.")

if set(sample.y.unique()) != {0, 1}:
    raise ValueError("Capture 49 frozen sample labels are not binary.")

assets = pd.read_csv(asset_path)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise ValueError(
        f"Expected exactly one resolved Capture 49 asset row; got {len(asset)}."
    )

asset = asset.iloc[0]
pcap_path = Path(asset.pcap_path)
conn_path = Path(asset.conn_log_path)

if not pcap_path.is_file():
    raise FileNotFoundError(f"Capture 49 PCAP not available: {pcap_path}")

if not conn_path.is_file():
    raise FileNotFoundError(f"Capture 49 conn.log not available: {conn_path}")

if sha256_file(pcap_path) != asset.pcap_sha256:
    raise ValueError("Capture 49 PCAP checksum differs from frozen asset CSV.")

bundle = joblib.load(model_path)
model_seeds = sorted(str(seed) for seed in bundle["models"])

if model_seeds != ["8101", "8102", "8103"]:
    raise ValueError(
        f"Expected frozen seeds 8101/8102/8103; got {model_seeds}."
    )

pcap_bytes = pcap_path.stat().st_size
free_before = shutil.disk_usage(WORK).free

# The source PCAP stays read-only in /kaggle/input. Only one transformed PCAP
# is written under /kaggle/working. The SQLite offset index is bounded at
# 80 bytes per packet after the first pass, plus a 1.25 GiB safety reserve.
# The actual count is added after the first pass, before temp output begins.
initial_required = pcap_bytes + int(1.25 * 1024**3)

preflight = build_preflight(
    model_path=model_path,
    clean_path=clean_path,
    asset_path=asset_path,
    helper_path=helper_path,
    pcap_path=pcap_path,
    conn_path=conn_path,
    pcap_bytes=pcap_bytes,
    free_bytes=free_before,
    minimum_required_bytes=initial_required,
    zeek_path=zeek_path,
)

write_json(JOB / "capture49_preflight.json", preflight)
print("RESOLVED CAPTURE 49 INPUTS")
print(json.dumps(preflight, indent=2))

if preflight["status"] != "PREFLIGHT_PASS":
    raise RuntimeError(
        "PACE did not start: transformed-PCAP reserve does not fit in "
        "remaining working storage. No packet files were created."
    )

helpers = extract_packet_helpers(helper_path)
key = helpers["key"]
skey = helpers["skey"]
mat = helpers["mat"]
pcap_iter = helpers["pcap_iter"]
pcap_header = helpers["pcap_header"]
tcp = helpers["tcp"]
log_iter = helpers["log_iter"]

wanted_keys = set(sample.ks)
labels = dict(zip(sample.ks, sample.y.astype(int)))
flows = {}

for row in log_iter(conn_path):
    flow_key = skey(key(
        row["ts"],
        row["id.orig_h"],
        row["id.orig_p"],
        row["id.resp_h"],
        row["id.resp_p"],
        row["proto"],
    ))

    if flow_key in wanted_keys:
        if flow_key in flows:
            raise ValueError(
                f"Ambiguous clean conn.log flow key: {flow_key}"
            )
        flows[flow_key] = row

if set(flows) != wanted_keys:
    missing = sorted(wanted_keys - set(flows))
    raise ValueError(
        "Frozen Capture 49 sample does not resolve uniquely in conn.log. "
        f"Missing keys: {len(missing)}."
    )

descriptions = defaultdict(list)

for flow_key, row in flows.items():
    if labels[flow_key] != 1 or str(row["proto"]).lower() != "tcp":
        continue

    start_ns = int(Decimal(str(row["ts"])) * 10**9)
    duration_ns = (
        0
        if row["duration"] == "-"
        else int(Decimal(str(row["duration"])) * 10**9)
    )

    endpoints = tuple(sorted([
        (row["id.orig_h"], int(row["id.orig_p"])),
        (row["id.resp_h"], int(row["id.resp_p"])),
    ]))

    descriptions[endpoints].append(
        (start_ns, start_ns + duration_ns + 1_000_000, flow_key)
    )

for values in descriptions.values():
    values.sort()

starts = {
    endpoint: [item[0] for item in values]
    for endpoint, values in descriptions.items()
}

pcap_file_header, endian, unit, network = pcap_header(pcap_path)

def selected_flow_for_packet(timestamp_ns, payload):
    packet_info = tcp(payload, network)

    if packet_info is None:
        return None

    source_host, source_port, dest_host, dest_port, _, _ = packet_info
    endpoints = tuple(sorted([
        (source_host, source_port),
        (dest_host, dest_port),
    ]))

    if endpoints not in descriptions:
        return None

    position = bisect.bisect_right(
        starts[endpoints], timestamp_ns
    ) - 1

    if position < 0:
        return None

    begin, end, flow_key = descriptions[endpoints][position]
    return flow_key if timestamp_ns <= end else None

print(
    f"\nFIRST PASS: packet counting and Capture 49 eligibility "
    f"({SCENARIO})...",
    flush=True
)

packet_count = 0
packet_counts_by_flow = defaultdict(int)
first_packet_index = {}
previous_timestamp = None
original_digest = hashlib.sha256()

for packet_index, timestamp_ns, wire_length, payload in pcap_iter(pcap_path):
    if previous_timestamp is not None and timestamp_ns < previous_timestamp:
        raise ValueError("Source PCAP timestamps are not nondecreasing.")

    previous_timestamp = timestamp_ns
    packet_count += 1
    original_digest.update(struct.pack("!II", len(payload), wire_length))
    original_digest.update(payload)

    flow_key = selected_flow_for_packet(timestamp_ns, payload)

    if flow_key is not None:
        packet_counts_by_flow[flow_key] += 1
        first_packet_index.setdefault(flow_key, packet_index)

eligible_flows = {
    flow_key
    for flow_key, count in packet_counts_by_flow.items()
    if count >= 2
}

# Exact disk calculation before any temporary replay material is created.
# SQLite holds scalar metadata only, never packet payloads.
required_after_count = (
    pcap_bytes
    + packet_count * 80
    + int(1.25 * 1024**3)
)

free_after_count = shutil.disk_usage(WORK).free

preflight.update({
    "source_packet_count": packet_count,
    "selected_tcp_positive_flows_seen": len(packet_counts_by_flow),
    "eligible_flows": len(eligible_flows),
    "required_after_packet_count_GiB": round(
        required_after_count / 1024**3, 4
    ),
    "free_after_packet_count_GiB": round(
        free_after_count / 1024**3, 4
    ),
    "space_margin_after_packet_count_GiB": round(
        (free_after_count - required_after_count) / 1024**3, 4
    ),
})

if free_after_count < required_after_count:
    preflight["status"] = "INSUFFICIENT_DISK_SPACE_AFTER_PACKET_COUNT"
    write_json(JOB / "capture49_preflight.json", preflight)
    raise RuntimeError(
        "PACE did not start: measured packet-count temporary-space "
        "requirement exceeds remaining disk. No transformed PCAP was written."
    )

if not eligible_flows:
    preflight["status"] = "ZERO_ELIGIBLE_FLOWS"
    write_json(JOB / "capture49_preflight.json", preflight)
    raise RuntimeError(
        "PACE did not start: Capture 49 has zero eligible selected flows "
        "with at least two packets. This is a valid null-transformability "
        "result, not a reason to fabricate a replay."
    )

write_json(JOB / "capture49_preflight.json", preflight)

temporary = Path(tempfile.mkdtemp(prefix="capture49_pace_", dir=JOB))
database = None
started = time.time()

try:
    database = sqlite3.connect(temporary / "packet_order.sqlite")
    database.execute("PRAGMA journal_mode=OFF")
    database.execute("PRAGMA synchronous=OFF")
    database.execute("PRAGMA temp_store=FILE")
    database.execute("PRAGMA cache_size=-32768")
    database.execute(
        "CREATE TABLE records ("
        "ts INTEGER, idx INTEGER, offset INTEGER, cap INTEGER, wire INTEGER)"
    )

    print(
        f"BUILDING DISK-BACKED ORDER INDEX: "
        f"{len(eligible_flows)} eligible flows.",
        flush=True
    )

    offset = 24
    batch = []
    delayed_by_flow = defaultdict(int)

    for packet_index, timestamp_ns, wire_length, payload in pcap_iter(pcap_path):
        flow_key = selected_flow_for_packet(timestamp_ns, payload)
        delay_ns = (
            1_000_000_000
            if flow_key in eligible_flows
            and packet_index != first_packet_index[flow_key]
            else 0
        )

        if delay_ns:
            delayed_by_flow[flow_key] += 1

        batch.append((
            timestamp_ns + delay_ns,
            packet_index,
            offset + 16,
            len(payload),
            wire_length,
        ))

        offset += 16 + len(payload)

        if len(batch) >= 20_000:
            database.executemany(
                "INSERT INTO records VALUES (?,?,?,?,?)",
                batch
            )
            batch.clear()

    if batch:
        database.executemany(
            "INSERT INTO records VALUES (?,?,?,?,?)",
            batch
        )

    database.commit()
    database.execute("CREATE INDEX time_order ON records(ts, idx)")
    database.commit()

    transformed_pcap = temporary / "capture49_paced_1s.pcap"
    copied_digest = hashlib.sha256()

    print("VERIFYING ORIGINAL PACKET BYTES...", flush=True)

    with open(pcap_path, "rb") as source:
        for offset_payload, captured, wire in database.execute(
            "SELECT offset, cap, wire FROM records ORDER BY idx"
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise ValueError("Truncated original packet during validation.")

            copied_digest.update(struct.pack("!II", captured, wire))
            copied_digest.update(payload)

    if copied_digest.digest() != original_digest.digest():
        raise ValueError(
            "Original packet byte/order validation failed before replay."
        )

    print("WRITING PACED PCAP...", flush=True)

    output_packets = 0
    prior_output_time = None
    last_selected_packet_index = {}
    selected_flow_order_ok = True

    with open(pcap_path, "rb") as source, open(transformed_pcap, "wb") as target:
        target.write(pcap_file_header)

        for timestamp_ns, packet_index, offset_payload, captured, wire in (
            database.execute(
                "SELECT ts, idx, offset, cap, wire "
                "FROM records ORDER BY ts, idx"
            )
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise ValueError("Truncated packet while writing paced PCAP.")

            if (
                prior_output_time is not None
                and timestamp_ns < prior_output_time
            ):
                raise ValueError("Paced output timestamps are unordered.")

            prior_output_time = timestamp_ns

            source.seek(offset_payload - 16)
            packet_header = source.read(16)
            seconds, fraction, _, _ = struct.unpack(
                endian + "IIII",
                packet_header
            )
            original_timestamp_ns = seconds * 10**9 + fraction * unit

            flow_key = selected_flow_for_packet(
                original_timestamp_ns,
                payload
            )

            if flow_key is not None:
                previous = last_selected_packet_index.get(flow_key)

                if previous is not None and packet_index <= previous:
                    selected_flow_order_ok = False

                last_selected_packet_index[flow_key] = packet_index

            applied_delay = timestamp_ns - original_timestamp_ns
            if applied_delay not in {0, 1_000_000_000}:
                raise ValueError("Invalid packet delay encountered.")

            if timestamp_ns < original_timestamp_ns:
                raise ValueError("A packet was advanced rather than delayed.")

            target.write(struct.pack(
                endian + "IIII",
                timestamp_ns // 10**9,
                (timestamp_ns % 10**9) // unit,
                captured,
                wire,
            ))
            target.write(payload)
            output_packets += 1

    if output_packets != packet_count:
        raise ValueError("Paced PCAP packet count differs from source PCAP.")

    if not selected_flow_order_ok:
        raise ValueError("Selected-flow packet order changed during pacing.")

    transformed_sha256 = sha256_file(transformed_pcap)

    if database is not None:
        database.close()
        database = None

    print("RUNNING ZEEK ON CAPTURE 49 PACED PCAP...", flush=True)

    with open(temporary / "zeek_stdout.txt", "w") as stdout, \
         open(temporary / "zeek_stderr.txt", "w") as stderr:
        completed = subprocess.run(
            [str(zeek_path), "-C", "-r", str(transformed_pcap)],
            cwd=temporary,
            stdout=stdout,
            stderr=stderr,
            timeout=1800,
            preexec_fn=zeek_memory_limit,
        )

    paced_conn = temporary / "conn.log"

    if completed.returncode != 0 or not paced_conn.is_file():
        raise RuntimeError(
            "Zeek failed. Temporary stderr is preserved only until this "
            "cell exits; failure.json records the return code."
        )

    paced_flows = {}
    duplicates = set()

    for row in log_iter(paced_conn):
        flow_key = skey(key(
            row["ts"],
            row["id.orig_h"],
            row["id.orig_p"],
            row["id.resp_h"],
            row["id.resp_p"],
            row["proto"],
        ))

        if flow_key in wanted_keys:
            if flow_key in paced_flows:
                duplicates.add(flow_key)

            paced_flows[flow_key] = row

    missing = sorted(wanted_keys - set(paced_flows))

    mapping = {
        "scenario": SCENARIO,
        "sample_rows": len(sample),
        "mapped_rows": len(paced_flows),
        "mapping_fraction": len(paced_flows) / len(sample),
        "missing_keys": missing,
        "ambiguous_keys": sorted(duplicates),
    }
    write_json(JOB / "mapping_diagnostic.json", mapping)

    if missing or duplicates:
        raise RuntimeError(
            "Exact Capture 49 selected-flow mapping failed. "
            "No rows were silently dropped; inspect mapping_diagnostic.json."
        )

    attacked = normalize(pd.DataFrame([
        {
            **{column: paced_flows[flow_key][column] for column in FEATURES},
            "ks": flow_key,
            "y": labels[flow_key],
        }
        for flow_key in sample.ks
    ]))

    attacked.to_csv(
        JOB / "attacked_selected_features.csv.gz",
        index=False,
        compression="gzip",
    )

    arrays = {
        "ks": sample.ks.to_numpy(dtype=str),
        "y": sample.y.to_numpy(dtype=int),
    }
    result_rows = []

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            clean_probability = bank["PRIMARY"].predict_proba(
                mat(sample, FEATURES)
            )[:, 1]

            paced_probability = bank["PRIMARY"].predict_proba(
                mat(attacked, FEATURES)
            )[:, 1]

            clean_accuracy = float(
                ((clean_probability >= 0.5) == sample.y.to_numpy()).mean()
            )
            paced_accuracy = float(
                ((paced_probability >= 0.5) == sample.y.to_numpy()).mean()
            )

            result_rows.append({
                "scenario": SCENARIO,
                "attack": "PACE_1s",
                "seed": int(seed),
                "clean_accuracy": clean_accuracy,
                "attack_accuracy": paced_accuracy,
                "true_damage": clean_accuracy - paced_accuracy,
                "eligible_flows": len(eligible_flows),
                "delayed_packets": int(sum(delayed_by_flow.values())),
                "mapped_fraction": 1.0,
            })

            arrays[f"seed_{seed}_clean_probability"] = clean_probability
            arrays[f"seed_{seed}_attack_probability"] = paced_probability

    results = pd.DataFrame(result_rows)
    results.to_csv(JOB / "detector_results.csv", index=False)
    np.savez_compressed(JOB / "primary_outputs.npz", **arrays)

    receipt = {
        "status": "PACING_JOB_COMPLETE",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "sample_path": str(clean_path),
        "sample_sha256": sha256_file(clean_path),
        "source_pcap_sha256": asset.pcap_sha256,
        "transformed_pcap_sha256": transformed_sha256,
        "original_packet_count": packet_count,
        "eligible_flows": len(eligible_flows),
        "delayed_packets": int(sum(delayed_by_flow.values())),
        "mapping_fraction": 1.0,
        "original_bytes_verified": True,
        "per_selected_flow_order_verified": True,
        "no_packet_advanced": True,
        "output_timestamps_nondecreasing": True,
        "models_retrained": False,
        "seconds": round(time.time() - started, 2),
        "temporary_replays_retained": False,
        "source_resolution": {
            "model": str(model_path),
            "sample": str(clean_path),
            "assets": str(asset_path),
            "helper": str(helper_path),
        },
    }

    write_json(JOB / "receipt.json", receipt)

    print("\nCAPTURE 49 PACE RESULT")
    print(results.to_string(index=False))
    print("\nCAPTURE 49 RECEIPT")
    print(json.dumps(receipt, indent=2))

except Exception as error:
    failure = {
        "status": "INCOMPLETE_NOT_A_RESULT",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "error": f"{type(error).__name__}: {error}",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "temporary_replays_retained": False,
    }
    write_json(JOB / "failure.json", failure)
    raise

finally:
    if database is not None:
        database.close()

    shutil.rmtree(temporary, ignore_errors=True)

# ===== CELL INPUT 15 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from decimal import Decimal
import ast
import bisect
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"
PACE_ROOT = WORK / "E4_COMPACT_PACING_v1"
JOB = PACE_ROOT / SCENARIO

SEARCH_ROOTS = [
    WORK,
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
]

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

PCAP_MAGICS = {
    b"\xd4\xc3\xb2\xa1": ("<", 1000),
    b"\xa1\xb2\xc3\xd4": (">", 1000),
    b"\x4d\x3c\xb2\xa1": ("<", 1),
    b"\xa1\xb2\x3c\x4d": (">", 1),
}

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    frame["proto"] = frame["proto"].astype(str).str.lower()
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    return frame

def locate_all(filename):
    found = []

    for root in SEARCH_ROOTS:
        if not root.is_dir():
            continue

        for candidate in root.rglob(filename):
            if candidate.is_file():
                found.append(candidate)

    return sorted(
        set(found),
        key=lambda path: (
            0 if str(path).startswith(str(WORK)) else 1,
            len(path.parts),
            str(path),
        )
    )

def locate_model():
    candidates = locate_all("frozen_source_models.joblib")
    candidates = [
        path for path in candidates
        if path.parent.name == "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    ]

    if not candidates:
        raise FileNotFoundError(
            "Could not locate frozen_source_models.joblib in any mounted "
            "backup or restored working tree."
        )

    return candidates[0]

def locate_clean_sample():
    candidates = locate_all("frozen_clean_target_sample.csv.gz")
    candidates = [
        path for path in candidates
        if path.parent.name == SCENARIO
        and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1"
        in str(path)
    ]

    valid = []
    for path in candidates:
        try:
            frame = pd.read_csv(path, dtype={"ks": str}, nrows=1030)
            if (
                len(frame) == 1024
                and "ks" in frame.columns
                and "y" in frame.columns
                and not frame.ks.astype(str).duplicated().any()
            ):
                valid.append(path)
        except Exception:
            pass

    if not valid:
        searched = "\n".join(str(root) for root in SEARCH_ROOTS)
        raise FileNotFoundError(
            "No valid frozen Capture 49 sample was found. Searched:\n"
            + searched
        )

    return valid[0]

def locate_helper():
    candidates = locate_all("run_streaming_confirmatory_batch_A_v1_2_fixed.py")
    if not candidates:
        raise FileNotFoundError(
            "Could not locate run_streaming_confirmatory_batch_A_v1_2_fixed.py."
        )
    return candidates[0]

def locate_asset_csv():
    candidates = locate_all("target_asset_resolution.csv")
    valid = []

    for path in candidates:
        try:
            table = pd.read_csv(path)
            row = table[
                (table.scenario == SCENARIO)
                & (table.status == "RESOLVED")
            ]
            if len(row) == 1:
                valid.append(path)
        except Exception:
            pass

    if not valid:
        raise FileNotFoundError(
            "No target_asset_resolution.csv contains one resolved Capture 49 row."
        )

    return valid[0]

def choose_zeek():
    candidates = [
        Path("/opt/zeek/bin/zeek"),
        Path("/usr/local/bin/zeek"),
        Path("/usr/bin/zeek"),
    ]
    zeek = next((path for path in candidates if path.is_file()), None)

    if zeek is None:
        raise FileNotFoundError("Zeek executable was not found.")

    return zeek

def extract_packet_helpers(helper_path):
    required = {
        "key", "skey", "mat",
        "pcap_iter", "pcap_header",
        "tcp", "log_iter"
    }

    tree = ast.parse(helper_path.read_text(encoding="utf-8"))
    definitions = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name in required
    ]

    found = {node.name for node in definitions}
    missing = required - found

    if missing:
        raise RuntimeError(
            "Required packet helper definitions missing from runner: "
            + ", ".join(sorted(missing))
        )

    namespace = dict(globals())
    module = ast.Module(body=definitions, type_ignores=[])
    exec(
        compile(
            ast.fix_missing_locations(module),
            "capture49_verified_helpers",
            "exec"
        ),
        namespace
    )

    return namespace

def zeek_memory_limit():
    limit = 6 * 1024**3
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

def validate_existing_job():
    receipt_path = JOB / "receipt.json"

    if receipt_path.is_file():
        receipt = read_json(receipt_path)

        if receipt.get("status") == "PACING_JOB_COMPLETE":
            raise RuntimeError(
                "Capture 49 already has a completed pacing receipt. "
                "Refusing to rerun it."
            )

def build_preflight(
    model_path, clean_path, asset_path, helper_path,
    pcap_path, conn_path, pcap_bytes, free_bytes,
    minimum_required_bytes, zeek_path
):
    return {
        "status": (
            "PREFLIGHT_PASS"
            if free_bytes >= minimum_required_bytes
            else "INSUFFICIENT_DISK_SPACE"
        ),
        "scenario": SCENARIO,
        "model": str(model_path),
        "clean_sample": str(clean_path),
        "target_assets": str(asset_path),
        "helper": str(helper_path),
        "source_pcap": str(pcap_path),
        "source_conn_log": str(conn_path),
        "source_pcap_GiB": round(pcap_bytes / 1024**3, 4),
        "zeek": str(zeek_path),
        "free_working_GiB": round(free_bytes / 1024**3, 4),
        "minimum_required_GiB": round(
            minimum_required_bytes / 1024**3, 4
        ),
        "space_margin_GiB": round(
            (free_bytes - minimum_required_bytes) / 1024**3, 4
        ),
        "temporary_files": (
            "One transformed PCAP, disk-backed packet-order SQLite index, "
            "Zeek logs, and a fixed 1.25 GiB safety reserve."
        ),
        "no_backup_copying": True,
        "completed_jobs_rerun": 0,
    }

validate_existing_job()
JOB.mkdir(parents=True, exist_ok=True)

model_path = locate_model()
clean_path = locate_clean_sample()
asset_path = locate_asset_csv()
helper_path = locate_helper()
zeek_path = choose_zeek()

sample = normalize(pd.read_csv(clean_path, dtype={"ks": str}))

if len(sample) != 1024:
    raise ValueError(
        f"Capture 49 frozen sample must contain 1,024 rows; found {len(sample)}."
    )

if sample.ks.duplicated().any():
    raise ValueError("Capture 49 frozen sample has duplicate keys.")

if set(sample.y.unique()) != {0, 1}:
    raise ValueError("Capture 49 frozen sample labels are not binary.")

assets = pd.read_csv(asset_path)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise ValueError(
        f"Expected exactly one resolved Capture 49 asset row; got {len(asset)}."
    )

asset = asset.iloc[0]
pcap_path = Path(asset.pcap_path)
conn_path = Path(asset.conn_log_path)

if not pcap_path.is_file():
    raise FileNotFoundError(f"Capture 49 PCAP not available: {pcap_path}")

if not conn_path.is_file():
    raise FileNotFoundError(f"Capture 49 conn.log not available: {conn_path}")

if sha256_file(pcap_path) != asset.pcap_sha256:
    raise ValueError("Capture 49 PCAP checksum differs from frozen asset CSV.")

bundle = joblib.load(model_path)
model_seeds = sorted(str(seed) for seed in bundle["models"])

if model_seeds != ["8101", "8102", "8103"]:
    raise ValueError(
        f"Expected frozen seeds 8101/8102/8103; got {model_seeds}."
    )

pcap_bytes = pcap_path.stat().st_size
free_before = shutil.disk_usage(WORK).free

# The source PCAP stays read-only in /kaggle/input. Only one transformed PCAP
# is written under /kaggle/working. The SQLite offset index is bounded at
# 80 bytes per packet after the first pass, plus a 1.25 GiB safety reserve.
# The actual count is added after the first pass, before temp output begins.
initial_required = pcap_bytes + int(1.25 * 1024**3)

preflight = build_preflight(
    model_path=model_path,
    clean_path=clean_path,
    asset_path=asset_path,
    helper_path=helper_path,
    pcap_path=pcap_path,
    conn_path=conn_path,
    pcap_bytes=pcap_bytes,
    free_bytes=free_before,
    minimum_required_bytes=initial_required,
    zeek_path=zeek_path,
)

write_json(JOB / "capture49_preflight.json", preflight)
print("RESOLVED CAPTURE 49 INPUTS")
print(json.dumps(preflight, indent=2))

if preflight["status"] != "PREFLIGHT_PASS":
    raise RuntimeError(
        "PACE did not start: transformed-PCAP reserve does not fit in "
        "remaining working storage. No packet files were created."
    )

helpers = extract_packet_helpers(helper_path)
key = helpers["key"]
skey = helpers["skey"]
mat = helpers["mat"]
pcap_iter = helpers["pcap_iter"]
pcap_header = helpers["pcap_header"]
tcp = helpers["tcp"]
log_iter = helpers["log_iter"]

wanted_keys = set(sample.ks)
labels = dict(zip(sample.ks, sample.y.astype(int)))
flows = {}

for row in log_iter(conn_path):
    flow_key = skey(key(
        row["ts"],
        row["id.orig_h"],
        row["id.orig_p"],
        row["id.resp_h"],
        row["id.resp_p"],
        row["proto"],
    ))

    if flow_key in wanted_keys:
        if flow_key in flows:
            raise ValueError(
                f"Ambiguous clean conn.log flow key: {flow_key}"
            )
        flows[flow_key] = row

if set(flows) != wanted_keys:
    missing = sorted(wanted_keys - set(flows))
    raise ValueError(
        "Frozen Capture 49 sample does not resolve uniquely in conn.log. "
        f"Missing keys: {len(missing)}."
    )

descriptions = defaultdict(list)

for flow_key, row in flows.items():
    if labels[flow_key] != 1 or str(row["proto"]).lower() != "tcp":
        continue

    start_ns = int(Decimal(str(row["ts"])) * 10**9)
    duration_ns = (
        0
        if row["duration"] == "-"
        else int(Decimal(str(row["duration"])) * 10**9)
    )

    endpoints = tuple(sorted([
        (row["id.orig_h"], int(row["id.orig_p"])),
        (row["id.resp_h"], int(row["id.resp_p"])),
    ]))

    descriptions[endpoints].append(
        (start_ns, start_ns + duration_ns + 1_000_000, flow_key)
    )

for values in descriptions.values():
    values.sort()

starts = {
    endpoint: [item[0] for item in values]
    for endpoint, values in descriptions.items()
}

pcap_file_header, endian, unit, network = pcap_header(pcap_path)

def selected_flow_for_packet(timestamp_ns, payload):
    packet_info = tcp(payload, network)

    if packet_info is None:
        return None

    source_host, source_port, dest_host, dest_port, _, _ = packet_info
    endpoints = tuple(sorted([
        (source_host, source_port),
        (dest_host, dest_port),
    ]))

    if endpoints not in descriptions:
        return None

    position = bisect.bisect_right(
        starts[endpoints], timestamp_ns
    ) - 1

    if position < 0:
        return None

    begin, end, flow_key = descriptions[endpoints][position]
    return flow_key if timestamp_ns <= end else None

print(
    f"\nFIRST PASS: packet counting and Capture 49 eligibility "
    f"({SCENARIO})...",
    flush=True
)

packet_count = 0
packet_counts_by_flow = defaultdict(int)
first_packet_index = {}
previous_timestamp = None
original_digest = hashlib.sha256()

for packet_index, timestamp_ns, wire_length, payload in pcap_iter(pcap_path):
    if previous_timestamp is not None and timestamp_ns < previous_timestamp:
        raise ValueError("Source PCAP timestamps are not nondecreasing.")

    previous_timestamp = timestamp_ns
    packet_count += 1
    original_digest.update(struct.pack("!II", len(payload), wire_length))
    original_digest.update(payload)

    flow_key = selected_flow_for_packet(timestamp_ns, payload)

    if flow_key is not None:
        packet_counts_by_flow[flow_key] += 1
        first_packet_index.setdefault(flow_key, packet_index)

eligible_flows = {
    flow_key
    for flow_key, count in packet_counts_by_flow.items()
    if count >= 2
}

# Exact disk calculation before any temporary replay material is created.
# SQLite holds scalar metadata only, never packet payloads.
required_after_count = (
    pcap_bytes
    + packet_count * 80
    + int(1.25 * 1024**3)
)

free_after_count = shutil.disk_usage(WORK).free

preflight.update({
    "source_packet_count": packet_count,
    "selected_tcp_positive_flows_seen": len(packet_counts_by_flow),
    "eligible_flows": len(eligible_flows),
    "required_after_packet_count_GiB": round(
        required_after_count / 1024**3, 4
    ),
    "free_after_packet_count_GiB": round(
        free_after_count / 1024**3, 4
    ),
    "space_margin_after_packet_count_GiB": round(
        (free_after_count - required_after_count) / 1024**3, 4
    ),
})

if free_after_count < required_after_count:
    preflight["status"] = "INSUFFICIENT_DISK_SPACE_AFTER_PACKET_COUNT"
    write_json(JOB / "capture49_preflight.json", preflight)
    raise RuntimeError(
        "PACE did not start: measured packet-count temporary-space "
        "requirement exceeds remaining disk. No transformed PCAP was written."
    )

if not eligible_flows:
    preflight["status"] = "ZERO_ELIGIBLE_FLOWS"
    write_json(JOB / "capture49_preflight.json", preflight)
    raise RuntimeError(
        "PACE did not start: Capture 49 has zero eligible selected flows "
        "with at least two packets. This is a valid null-transformability "
        "result, not a reason to fabricate a replay."
    )

write_json(JOB / "capture49_preflight.json", preflight)

temporary = Path(tempfile.mkdtemp(prefix="capture49_pace_", dir=JOB))
database = None
started = time.time()

try:
    database = sqlite3.connect(temporary / "packet_order.sqlite")
    database.execute("PRAGMA journal_mode=OFF")
    database.execute("PRAGMA synchronous=OFF")
    database.execute("PRAGMA temp_store=FILE")
    database.execute("PRAGMA cache_size=-32768")
    database.execute(
        "CREATE TABLE records ("
        "ts INTEGER, idx INTEGER, offset INTEGER, cap INTEGER, wire INTEGER)"
    )

    print(
        f"BUILDING DISK-BACKED ORDER INDEX: "
        f"{len(eligible_flows)} eligible flows.",
        flush=True
    )

    offset = 24
    batch = []
    delayed_by_flow = defaultdict(int)

    for packet_index, timestamp_ns, wire_length, payload in pcap_iter(pcap_path):
        flow_key = selected_flow_for_packet(timestamp_ns, payload)
        delay_ns = (
            1_000_000_000
            if flow_key in eligible_flows
            and packet_index != first_packet_index[flow_key]
            else 0
        )

        if delay_ns:
            delayed_by_flow[flow_key] += 1

        batch.append((
            timestamp_ns + delay_ns,
            packet_index,
            offset + 16,
            len(payload),
            wire_length,
        ))

        offset += 16 + len(payload)

        if len(batch) >= 20_000:
            database.executemany(
                "INSERT INTO records VALUES (?,?,?,?,?)",
                batch
            )
            batch.clear()

    if batch:
        database.executemany(
            "INSERT INTO records VALUES (?,?,?,?,?)",
            batch
        )

    database.commit()
    database.execute("CREATE INDEX time_order ON records(ts, idx)")
    database.commit()

    transformed_pcap = temporary / "capture49_paced_1s.pcap"
    copied_digest = hashlib.sha256()

    print("VERIFYING ORIGINAL PACKET BYTES...", flush=True)

    with open(pcap_path, "rb") as source:
        for offset_payload, captured, wire in database.execute(
            "SELECT offset, cap, wire FROM records ORDER BY idx"
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise ValueError("Truncated original packet during validation.")

            copied_digest.update(struct.pack("!II", captured, wire))
            copied_digest.update(payload)

    if copied_digest.digest() != original_digest.digest():
        raise ValueError(
            "Original packet byte/order validation failed before replay."
        )

    print("WRITING PACED PCAP...", flush=True)

    output_packets = 0
    prior_output_time = None
    last_selected_packet_index = {}
    selected_flow_order_ok = True

    with open(pcap_path, "rb") as source, open(transformed_pcap, "wb") as target:
        target.write(pcap_file_header)

        for timestamp_ns, packet_index, offset_payload, captured, wire in (
            database.execute(
                "SELECT ts, idx, offset, cap, wire "
                "FROM records ORDER BY ts, idx"
            )
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise ValueError("Truncated packet while writing paced PCAP.")

            if (
                prior_output_time is not None
                and timestamp_ns < prior_output_time
            ):
                raise ValueError("Paced output timestamps are unordered.")

            prior_output_time = timestamp_ns

            source.seek(offset_payload - 16)
            packet_header = source.read(16)
            seconds, fraction, _, _ = struct.unpack(
                endian + "IIII",
                packet_header
            )
            original_timestamp_ns = seconds * 10**9 + fraction * unit

            flow_key = selected_flow_for_packet(
                original_timestamp_ns,
                payload
            )

            if flow_key is not None:
                previous = last_selected_packet_index.get(flow_key)

                if previous is not None and packet_index <= previous:
                    selected_flow_order_ok = False

                last_selected_packet_index[flow_key] = packet_index

            applied_delay = timestamp_ns - original_timestamp_ns
            if applied_delay not in {0, 1_000_000_000}:
                raise ValueError("Invalid packet delay encountered.")

            if timestamp_ns < original_timestamp_ns:
                raise ValueError("A packet was advanced rather than delayed.")

            target.write(struct.pack(
                endian + "IIII",
                timestamp_ns // 10**9,
                (timestamp_ns % 10**9) // unit,
                captured,
                wire,
            ))
            target.write(payload)
            output_packets += 1

    if output_packets != packet_count:
        raise ValueError("Paced PCAP packet count differs from source PCAP.")

    if not selected_flow_order_ok:
        raise ValueError("Selected-flow packet order changed during pacing.")

    transformed_sha256 = sha256_file(transformed_pcap)

    if database is not None:
        database.close()
        database = None

    print("RUNNING ZEEK ON CAPTURE 49 PACED PCAP...", flush=True)

    with open(temporary / "zeek_stdout.txt", "w") as stdout, \
         open(temporary / "zeek_stderr.txt", "w") as stderr:
        completed = subprocess.run(
            [str(zeek_path), "-C", "-r", str(transformed_pcap)],
            cwd=temporary,
            stdout=stdout,
            stderr=stderr,
            timeout=1800,
            preexec_fn=zeek_memory_limit,
        )

    paced_conn = temporary / "conn.log"

    if completed.returncode != 0 or not paced_conn.is_file():
        raise RuntimeError(
            "Zeek failed. Temporary stderr is preserved only until this "
            "cell exits; failure.json records the return code."
        )

    paced_flows = {}
    duplicates = set()

    for row in log_iter(paced_conn):
        flow_key = skey(key(
            row["ts"],
            row["id.orig_h"],
            row["id.orig_p"],
            row["id.resp_h"],
            row["id.resp_p"],
            row["proto"],
        ))

        if flow_key in wanted_keys:
            if flow_key in paced_flows:
                duplicates.add(flow_key)

            paced_flows[flow_key] = row

    missing = sorted(wanted_keys - set(paced_flows))

    mapping = {
        "scenario": SCENARIO,
        "sample_rows": len(sample),
        "mapped_rows": len(paced_flows),
        "mapping_fraction": len(paced_flows) / len(sample),
        "missing_keys": missing,
        "ambiguous_keys": sorted(duplicates),
    }
    write_json(JOB / "mapping_diagnostic.json", mapping)

    if missing or duplicates:
        raise RuntimeError(
            "Exact Capture 49 selected-flow mapping failed. "
            "No rows were silently dropped; inspect mapping_diagnostic.json."
        )

    attacked = normalize(pd.DataFrame([
        {
            **{column: paced_flows[flow_key][column] for column in FEATURES},
            "ks": flow_key,
            "y": labels[flow_key],
        }
        for flow_key in sample.ks
    ]))

    attacked.to_csv(
        JOB / "attacked_selected_features.csv.gz",
        index=False,
        compression="gzip",
    )

    arrays = {
        "ks": sample.ks.to_numpy(dtype=str),
        "y": sample.y.to_numpy(dtype=int),
    }
    result_rows = []

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            clean_probability = bank["PRIMARY"].predict_proba(
                mat(sample, FEATURES)
            )[:, 1]

            paced_probability = bank["PRIMARY"].predict_proba(
                mat(attacked, FEATURES)
            )[:, 1]

            clean_accuracy = float(
                ((clean_probability >= 0.5) == sample.y.to_numpy()).mean()
            )
            paced_accuracy = float(
                ((paced_probability >= 0.5) == sample.y.to_numpy()).mean()
            )

            result_rows.append({
                "scenario": SCENARIO,
                "attack": "PACE_1s",
                "seed": int(seed),
                "clean_accuracy": clean_accuracy,
                "attack_accuracy": paced_accuracy,
                "true_damage": clean_accuracy - paced_accuracy,
                "eligible_flows": len(eligible_flows),
                "delayed_packets": int(sum(delayed_by_flow.values())),
                "mapped_fraction": 1.0,
            })

            arrays[f"seed_{seed}_clean_probability"] = clean_probability
            arrays[f"seed_{seed}_attack_probability"] = paced_probability

    results = pd.DataFrame(result_rows)
    results.to_csv(JOB / "detector_results.csv", index=False)
    np.savez_compressed(JOB / "primary_outputs.npz", **arrays)

    receipt = {
        "status": "PACING_JOB_COMPLETE",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "sample_path": str(clean_path),
        "sample_sha256": sha256_file(clean_path),
        "source_pcap_sha256": asset.pcap_sha256,
        "transformed_pcap_sha256": transformed_sha256,
        "original_packet_count": packet_count,
        "eligible_flows": len(eligible_flows),
        "delayed_packets": int(sum(delayed_by_flow.values())),
        "mapping_fraction": 1.0,
        "original_bytes_verified": True,
        "per_selected_flow_order_verified": True,
        "no_packet_advanced": True,
        "output_timestamps_nondecreasing": True,
        "models_retrained": False,
        "seconds": round(time.time() - started, 2),
        "temporary_replays_retained": False,
        "source_resolution": {
            "model": str(model_path),
            "sample": str(clean_path),
            "assets": str(asset_path),
            "helper": str(helper_path),
        },
    }

    write_json(JOB / "receipt.json", receipt)

    print("\nCAPTURE 49 PACE RESULT")
    print(results.to_string(index=False))
    print("\nCAPTURE 49 RECEIPT")
    print(json.dumps(receipt, indent=2))

except Exception as error:
    failure = {
        "status": "INCOMPLETE_NOT_A_RESULT",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "error": f"{type(error).__name__}: {error}",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "temporary_replays_retained": False,
    }
    write_json(JOB / "failure.json", failure)
    raise

finally:
    if database is not None:
        database.close()

    shutil.rmtree(temporary, ignore_errors=True)

# ===== CELL INPUT 16 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working")
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
INJ_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
PACE_JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
PACE_JOB.mkdir(parents=True, exist_ok=True)

SAMPLE = PACE_JOB / "capture49_frozen_sample_verified.csv.gz"
RECEIPT = PACE_JOB / "capture49_sample_verification.json"

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def matrix(frame, columns):
    numeric = [column for column in columns if column != "proto"]
    parts = [np.log1p(frame[numeric].to_numpy(dtype=float))]

    if "proto" in columns:
        parts.append(np.column_stack([
            frame.proto.eq(protocol).to_numpy(dtype=float)
            for protocol in ["tcp", "udp", "icmp"]
        ]))

    return np.hstack(parts)

for path in [ASSETS, MODEL, INJ_OUTPUTS]:
    if not path.is_file():
        raise FileNotFoundError(f"Required frozen artifact missing: {path}")

existing_pace_receipt = PACE_JOB / "receipt.json"
if existing_pace_receipt.is_file():
    previous = json.loads(existing_pace_receipt.read_text())
    if previous.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 pacing is already complete. Refusing to overwrite it."
        )

assets = pd.read_csv(ASSETS)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise RuntimeError(
        f"Expected exactly one resolved Capture 49 asset row; found {len(asset)}."
    )

asset = asset.iloc[0]
features_path = Path(asset.features_path)

if not features_path.is_file():
    raise FileNotFoundError(
        f"Capture 49 E1 features table is missing: {features_path}"
    )

# This trusted frozen output has object-type ks keys. Pickle is enabled only
# to read this already-created local artifact; no external object is executed.
with np.load(INJ_OUTPUTS, allow_pickle=True) as saved:
    frozen_keys = saved["ks"].astype(str)
    frozen_y = saved["y"].astype(int)
    saved_clean_probability = {
        str(seed): saved[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(frozen_keys) != 1024:
    raise ValueError(
        f"Expected 1,024 frozen Capture 49 keys; found {len(frozen_keys)}."
    )

if len(set(frozen_keys)) != 1024:
    raise ValueError("Frozen Capture 49 keys are not unique.")

if int((frozen_y == 0).sum()) != 512 or int((frozen_y == 1).sum()) != 512:
    raise ValueError(
        "Frozen Capture 49 output is not the required 512/512 class balance."
    )

wanted = set(frozen_keys)
retrieved = []
seen = set()

for chunk in pd.read_csv(
    features_path,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise ValueError(
            "Capture 49 E1 features file lacks required ks/y columns."
        )

    selected = chunk[chunk.ks.astype(str).isin(wanted)].copy()

    if not selected.empty:
        selected["ks"] = selected.ks.astype(str)

        duplicate = set(selected.ks) & seen
        if duplicate:
            raise ValueError(
                "A frozen Capture 49 key occurs more than once in E1 features."
            )

        seen.update(selected.ks)
        retrieved.append(selected)

if seen != wanted:
    missing = sorted(wanted - seen)
    raise RuntimeError(
        "The E1 feature table does not contain every frozen Capture 49 key. "
        f"Missing keys: {len(missing)}."
    )

sample = pd.concat(retrieved, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

if not np.array_equal(sample.ks.to_numpy(str), frozen_keys):
    raise AssertionError("Key order differs from frozen injection output.")

if not np.array_equal(sample.y.to_numpy(int), frozen_y):
    raise AssertionError("Labels differ from frozen injection output.")

bundle = joblib.load(MODEL)
seeds = sorted(str(seed) for seed in bundle["models"])

if seeds != ["8101", "8102", "8103"]:
    raise ValueError(f"Unexpected model seeds: {seeds}")

verification_rows = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)

        recomputed = bank["PRIMARY"].predict_proba(
            matrix(sample, FEATURES)
        )[:, 1]

        saved_probability = saved_clean_probability[seed]

        verification_rows.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved_probability))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved_probability >= 0.5)).sum()
            ),
            "clean_accuracy": float(
                ((recomputed >= 0.5) == sample.y.to_numpy()).mean()
            ),
        })

verification = pd.DataFrame(verification_rows)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "E1 Capture 49 rows do not exactly reproduce the stored frozen "
        "clean predictions. Pacing will not start."
    )

sample.to_csv(SAMPLE, index=False, compression="gzip")
verification.to_csv(
    PACE_JOB / "capture49_sample_prediction_verification.csv",
    index=False
)

receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "sample_path": str(SAMPLE),
    "sample_sha256": sha256_file(SAMPLE),
    "membership_source": str(INJ_OUTPUTS),
    "membership_source_sha256": sha256_file(INJ_OUTPUTS),
    "feature_source": str(features_path),
    "feature_source_sha256": sha256_file(features_path),
    "model_source": str(MODEL),
    "model_source_sha256": sha256_file(MODEL),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
    "files_deleted": 0,
}

atomic_json(RECEIPT, receipt)

print("CAPTURE 49 FROZEN-SAMPLE VERIFICATION")
print(verification.to_string(index=False))
print("\nRECEIPT")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 17 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working")
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
INJ_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
PACE_JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
PACE_JOB.mkdir(parents=True, exist_ok=True)

SAMPLE = PACE_JOB / "capture49_frozen_sample_verified.csv.gz"
RECEIPT = PACE_JOB / "capture49_sample_verification.json"

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def matrix(frame, columns):
    numeric = [column for column in columns if column != "proto"]
    parts = [np.log1p(frame[numeric].to_numpy(dtype=float))]

    if "proto" in columns:
        parts.append(np.column_stack([
            frame.proto.eq(protocol).to_numpy(dtype=float)
            for protocol in ["tcp", "udp", "icmp"]
        ]))

    return np.hstack(parts)

for path in [ASSETS, MODEL, INJ_OUTPUTS]:
    if not path.is_file():
        raise FileNotFoundError(f"Required frozen artifact missing: {path}")

existing_pace_receipt = PACE_JOB / "receipt.json"
if existing_pace_receipt.is_file():
    previous = json.loads(existing_pace_receipt.read_text())
    if previous.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 pacing is already complete. Refusing to overwrite it."
        )

assets = pd.read_csv(ASSETS)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise RuntimeError(
        f"Expected exactly one resolved Capture 49 asset row; found {len(asset)}."
    )

asset = asset.iloc[0]
features_path = Path(asset.features_path)

if not features_path.is_file():
    raise FileNotFoundError(
        f"Capture 49 E1 features table is missing: {features_path}"
    )

# This trusted frozen output has object-type ks keys. Pickle is enabled only
# to read this already-created local artifact; no external object is executed.
with np.load(INJ_OUTPUTS, allow_pickle=True) as saved:
    frozen_keys = saved["ks"].astype(str)
    frozen_y = saved["y"].astype(int)
    saved_clean_probability = {
        str(seed): saved[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(frozen_keys) != 1024:
    raise ValueError(
        f"Expected 1,024 frozen Capture 49 keys; found {len(frozen_keys)}."
    )

if len(set(frozen_keys)) != 1024:
    raise ValueError("Frozen Capture 49 keys are not unique.")

if int((frozen_y == 0).sum()) != 512 or int((frozen_y == 1).sum()) != 512:
    raise ValueError(
        "Frozen Capture 49 output is not the required 512/512 class balance."
    )

wanted = set(frozen_keys)
retrieved = []
seen = set()

for chunk in pd.read_csv(
    features_path,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise ValueError(
            "Capture 49 E1 features file lacks required ks/y columns."
        )

    selected = chunk[chunk.ks.astype(str).isin(wanted)].copy()

    if not selected.empty:
        selected["ks"] = selected.ks.astype(str)

        duplicate = set(selected.ks) & seen
        if duplicate:
            raise ValueError(
                "A frozen Capture 49 key occurs more than once in E1 features."
            )

        seen.update(selected.ks)
        retrieved.append(selected)

if seen != wanted:
    missing = sorted(wanted - seen)
    raise RuntimeError(
        "The E1 feature table does not contain every frozen Capture 49 key. "
        f"Missing keys: {len(missing)}."
    )

sample = pd.concat(retrieved, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

if not np.array_equal(sample.ks.to_numpy(str), frozen_keys):
    raise AssertionError("Key order differs from frozen injection output.")

if not np.array_equal(sample.y.to_numpy(int), frozen_y):
    raise AssertionError("Labels differ from frozen injection output.")

bundle = joblib.load(MODEL)
seeds = sorted(str(seed) for seed in bundle["models"])

if seeds != ["8101", "8102", "8103"]:
    raise ValueError(f"Unexpected model seeds: {seeds}")

verification_rows = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)

        recomputed = bank["PRIMARY"].predict_proba(
            matrix(sample, FEATURES)
        )[:, 1]

        saved_probability = saved_clean_probability[seed]

        verification_rows.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved_probability))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved_probability >= 0.5)).sum()
            ),
            "clean_accuracy": float(
                ((recomputed >= 0.5) == sample.y.to_numpy()).mean()
            ),
        })

verification = pd.DataFrame(verification_rows)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "E1 Capture 49 rows do not exactly reproduce the stored frozen "
        "clean predictions. Pacing will not start."
    )

sample.to_csv(SAMPLE, index=False, compression="gzip")
verification.to_csv(
    PACE_JOB / "capture49_sample_prediction_verification.csv",
    index=False
)

receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "sample_path": str(SAMPLE),
    "sample_sha256": sha256_file(SAMPLE),
    "membership_source": str(INJ_OUTPUTS),
    "membership_source_sha256": sha256_file(INJ_OUTPUTS),
    "feature_source": str(features_path),
    "feature_source_sha256": sha256_file(features_path),
    "model_source": str(MODEL),
    "model_source_sha256": sha256_file(MODEL),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
    "files_deleted": 0,
}

atomic_json(RECEIPT, receipt)

print("CAPTURE 49 FROZEN-SAMPLE VERIFICATION")
print(verification.to_string(index=False))
print("\nRECEIPT")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 18 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

E1_ROOT = WORK / "E1_BLIND_TARGETS_20261012T125026604016Z"
ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
INJ_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
JOB.mkdir(parents=True, exist_ok=True)

SAMPLE = JOB / "capture49_frozen_sample_verified.csv.gz"
PATH_RECEIPT = JOB / "capture49_resolved_e1_assets.json"
VERIFY_RECEIPT = JOB / "capture49_sample_verification.json"

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def model_matrix(frame):
    numeric = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes"
    ]
    return np.hstack([
        np.log1p(frame[numeric].to_numpy(dtype=float)),
        np.column_stack([
            frame.proto.eq(protocol).to_numpy(dtype=float)
            for protocol in ["tcp", "udp", "icmp"]
        ]),
    ])

def asset_value(row, name):
    if name not in row.index:
        raise KeyError(
            f"Frozen target asset CSV has no required column: {name}"
        )
    value = row[name]
    if pd.isna(value) or str(value).strip() == "":
        raise ValueError(
            f"Frozen target asset CSV has an empty required value: {name}"
        )
    return str(value)

def e1_files():
    if not E1_ROOT.is_dir():
        raise FileNotFoundError(f"Restored E1 root missing: {E1_ROOT}")

    files = []
    for current, dirs, names in os.walk(E1_ROOT, followlinks=False):
        current = Path(current)
        for name in names:
            candidate = current / name
            if candidate.is_file():
                files.append(candidate)
    return files

def resolve_asset(files, old_path_text, expected_sha256, kind):
    old_path = Path(old_path_text)

    # First preference: original manifest path if it remains valid.
    if old_path.is_file():
        actual = sha256_file(old_path)
        if actual == expected_sha256:
            return old_path

    # Second preference: same basename under the restored E1 root.
    exact_name = [path for path in files if path.name == old_path.name]

    # Third preference: scenario-bearing files of the expected artifact kind.
    # This handles flattened restored layouts such as:
    # CTU-IoT-Malware-Capture-49-1features.csv.gz
    if kind == "features":
        keyword_matches = [
            path for path in files
            if SCENARIO in path.name
            and "feature" in path.name.lower()
        ]
    elif kind == "conn_log":
        keyword_matches = [
            path for path in files
            if SCENARIO in path.name
            and "conn" in path.name.lower()
            and path.name.lower().endswith((".log", ".log.gz"))
        ]
    elif kind == "pcap":
        keyword_matches = [
            path for path in files
            if SCENARIO in path.name
            and path.name.lower().endswith((".pcap", ".cap"))
        ]
    else:
        raise ValueError(f"Unknown asset kind: {kind}")

    candidates = []
    seen = set()

    for path in exact_name + keyword_matches:
        if path not in seen:
            candidates.append(path)
            seen.add(path)

    verified = []
    checked = []

    for path in candidates:
        actual_sha256 = sha256_file(path)
        checked.append({
            "path": str(path),
            "sha256": actual_sha256,
            "bytes": path.stat().st_size,
        })
        if actual_sha256 == expected_sha256:
            verified.append(path)

    if len(verified) != 1:
        raise RuntimeError(
            f"Could not uniquely resolve Capture 49 {kind} by frozen SHA-256. "
            f"Candidates checked: {json.dumps(checked, indent=2)}"
        )

    return verified[0]

for required in [ASSETS, MODEL, INJ_OUTPUTS]:
    if not required.is_file():
        raise FileNotFoundError(f"Required frozen artifact missing: {required}")

if (JOB / "receipt.json").is_file():
    old = json.loads((JOB / "receipt.json").read_text())
    if old.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 PACE_1s is already complete; refusing overwrite."
        )

assets = pd.read_csv(ASSETS)
selected = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(selected) != 1:
    raise RuntimeError(
        f"Expected exactly one resolved Capture 49 asset row; found {len(selected)}."
    )

asset = selected.iloc[0]
files = e1_files()

resolved_features = resolve_asset(
    files=files,
    old_path_text=asset_value(asset, "features_path"),
    expected_sha256=asset_value(asset, "features_sha256"),
    kind="features",
)
resolved_conn_log = resolve_asset(
    files=files,
    old_path_text=asset_value(asset, "conn_log_path"),
    expected_sha256=asset_value(asset, "conn_log_sha256"),
    kind="conn_log",
)
resolved_pcap = resolve_asset(
    files=files,
    old_path_text=asset_value(asset, "pcap_path"),
    expected_sha256=asset_value(asset, "pcap_sha256"),
    kind="pcap",
)

path_receipt = {
    "status": "CAPTURE49_E1_ASSETS_RESOLVED_BY_FROZEN_SHA256",
    "scenario": SCENARIO,
    "e1_root": str(E1_ROOT),
    "features_path": str(resolved_features),
    "features_sha256": sha256_file(resolved_features),
    "conn_log_path": str(resolved_conn_log),
    "conn_log_sha256": sha256_file(resolved_conn_log),
    "pcap_path": str(resolved_pcap),
    "pcap_sha256": sha256_file(resolved_pcap),
    "pcap_GiB": round(resolved_pcap.stat().st_size / 1024**3, 4),
    "old_manifest_paths_used_directly": False,
    "asset_identity_verified_by_hash": True,
    "files_deleted": 0,
    "backup_copied": False,
}
atomic_json(PATH_RECEIPT, path_receipt)

# The completed injection artifact is the authoritative frozen membership:
# exact 1,024 ks keys, labels, and saved clean probabilities.
with np.load(INJ_OUTPUTS, allow_pickle=True) as saved:
    frozen_keys = saved["ks"].astype(str)
    frozen_y = saved["y"].astype(int)
    saved_clean = {
        str(seed): saved[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(frozen_keys) != 1024 or len(set(frozen_keys)) != 1024:
    raise ValueError("Frozen Capture 49 membership must be 1,024 unique keys.")

if int((frozen_y == 0).sum()) != 512 or int((frozen_y == 1).sum()) != 512:
    raise ValueError("Frozen Capture 49 membership must be 512 benign + 512 malicious.")

wanted = set(frozen_keys)
selected_chunks = []
found = set()

for chunk in pd.read_csv(
    resolved_features,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise ValueError("Resolved E1 feature table lacks ks/y columns.")

    hit = chunk[chunk.ks.astype(str).isin(wanted)].copy()

    if not hit.empty:
        hit["ks"] = hit.ks.astype(str)

        duplicate = set(hit.ks) & found
        if duplicate:
            raise RuntimeError(
                "A frozen Capture 49 key occurs more than once in E1 features."
            )

        found.update(hit.ks)
        selected_chunks.append(hit)

if found != wanted:
    raise RuntimeError(
        "Resolved Capture 49 E1 feature table does not contain every "
        f"frozen key. Missing: {len(wanted - found)}."
    )

sample = pd.concat(selected_chunks, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

bundle = joblib.load(MODEL)
verification_rows = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)
        recomputed = bank["PRIMARY"].predict_proba(
            model_matrix(sample)
        )[:, 1]

        verification_rows.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved_clean[seed]))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved_clean[seed] >= 0.5)).sum()
            ),
            "clean_accuracy": float(
                ((recomputed >= 0.5) == sample.y.to_numpy()).mean()
            ),
        })

verification = pd.DataFrame(verification_rows)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "The recovered E1 rows do not exactly reproduce frozen Capture 49 "
        "predictions. No PACE replay was started."
    )

sample.to_csv(SAMPLE, index=False, compression="gzip")
verification.to_csv(
    JOB / "capture49_sample_prediction_verification.csv",
    index=False
)

verify_receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "sample_path": str(SAMPLE),
    "sample_sha256": sha256_file(SAMPLE),
    "frozen_membership_source": str(INJ_OUTPUTS),
    "frozen_membership_source_sha256": sha256_file(INJ_OUTPUTS),
    "resolved_assets_receipt": str(PATH_RECEIPT),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
    "files_deleted": 0,
}

atomic_json(VERIFY_RECEIPT, verify_receipt)

print("RESOLVED CAPTURE 49 E1 ASSETS")
print(json.dumps(path_receipt, indent=2))

print("\nFROZEN SAMPLE VERIFICATION")
print(verification.to_string(index=False))

print("\nVERIFICATION RECEIPT")
print(json.dumps(verify_receipt, indent=2))

# ===== CELL INPUT 19 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working")
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
INJ_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
PACE_JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
PACE_JOB.mkdir(parents=True, exist_ok=True)

SAMPLE = PACE_JOB / "capture49_frozen_sample_verified.csv.gz"
RECEIPT = PACE_JOB / "capture49_sample_verification.json"

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def matrix(frame, columns):
    numeric = [column for column in columns if column != "proto"]
    parts = [np.log1p(frame[numeric].to_numpy(dtype=float))]

    if "proto" in columns:
        parts.append(np.column_stack([
            frame.proto.eq(protocol).to_numpy(dtype=float)
            for protocol in ["tcp", "udp", "icmp"]
        ]))

    return np.hstack(parts)

for path in [ASSETS, MODEL, INJ_OUTPUTS]:
    if not path.is_file():
        raise FileNotFoundError(f"Required frozen artifact missing: {path}")

existing_pace_receipt = PACE_JOB / "receipt.json"
if existing_pace_receipt.is_file():
    previous = json.loads(existing_pace_receipt.read_text())
    if previous.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 pacing is already complete. Refusing to overwrite it."
        )

assets = pd.read_csv(ASSETS)
asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(asset) != 1:
    raise RuntimeError(
        f"Expected exactly one resolved Capture 49 asset row; found {len(asset)}."
    )

asset = asset.iloc[0]
features_path = Path(asset.features_path)

if not features_path.is_file():
    raise FileNotFoundError(
        f"Capture 49 E1 features table is missing: {features_path}"
    )

# This trusted frozen output has object-type ks keys. Pickle is enabled only
# to read this already-created local artifact; no external object is executed.
with np.load(INJ_OUTPUTS, allow_pickle=True) as saved:
    frozen_keys = saved["ks"].astype(str)
    frozen_y = saved["y"].astype(int)
    saved_clean_probability = {
        str(seed): saved[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(frozen_keys) != 1024:
    raise ValueError(
        f"Expected 1,024 frozen Capture 49 keys; found {len(frozen_keys)}."
    )

if len(set(frozen_keys)) != 1024:
    raise ValueError("Frozen Capture 49 keys are not unique.")

if int((frozen_y == 0).sum()) != 512 or int((frozen_y == 1).sum()) != 512:
    raise ValueError(
        "Frozen Capture 49 output is not the required 512/512 class balance."
    )

wanted = set(frozen_keys)
retrieved = []
seen = set()

for chunk in pd.read_csv(
    features_path,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise ValueError(
            "Capture 49 E1 features file lacks required ks/y columns."
        )

    selected = chunk[chunk.ks.astype(str).isin(wanted)].copy()

    if not selected.empty:
        selected["ks"] = selected.ks.astype(str)

        duplicate = set(selected.ks) & seen
        if duplicate:
            raise ValueError(
                "A frozen Capture 49 key occurs more than once in E1 features."
            )

        seen.update(selected.ks)
        retrieved.append(selected)

if seen != wanted:
    missing = sorted(wanted - seen)
    raise RuntimeError(
        "The E1 feature table does not contain every frozen Capture 49 key. "
        f"Missing keys: {len(missing)}."
    )

sample = pd.concat(retrieved, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

if not np.array_equal(sample.ks.to_numpy(str), frozen_keys):
    raise AssertionError("Key order differs from frozen injection output.")

if not np.array_equal(sample.y.to_numpy(int), frozen_y):
    raise AssertionError("Labels differ from frozen injection output.")

bundle = joblib.load(MODEL)
seeds = sorted(str(seed) for seed in bundle["models"])

if seeds != ["8101", "8102", "8103"]:
    raise ValueError(f"Unexpected model seeds: {seeds}")

verification_rows = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)

        recomputed = bank["PRIMARY"].predict_proba(
            matrix(sample, FEATURES)
        )[:, 1]

        saved_probability = saved_clean_probability[seed]

        verification_rows.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved_probability))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved_probability >= 0.5)).sum()
            ),
            "clean_accuracy": float(
                ((recomputed >= 0.5) == sample.y.to_numpy()).mean()
            ),
        })

verification = pd.DataFrame(verification_rows)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "E1 Capture 49 rows do not exactly reproduce the stored frozen "
        "clean predictions. Pacing will not start."
    )

sample.to_csv(SAMPLE, index=False, compression="gzip")
verification.to_csv(
    PACE_JOB / "capture49_sample_prediction_verification.csv",
    index=False
)

receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "sample_path": str(SAMPLE),
    "sample_sha256": sha256_file(SAMPLE),
    "membership_source": str(INJ_OUTPUTS),
    "membership_source_sha256": sha256_file(INJ_OUTPUTS),
    "feature_source": str(features_path),
    "feature_source_sha256": sha256_file(features_path),
    "model_source": str(MODEL),
    "model_source_sha256": sha256_file(MODEL),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
    "files_deleted": 0,
}

atomic_json(RECEIPT, receipt)

print("CAPTURE 49 FROZEN-SAMPLE VERIFICATION")
print(verification.to_string(index=False))
print("\nRECEIPT")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 20 =====
print("NEW CAPTURE 49 SAMPLE BUILD — NO OLD MANIFEST PATHS USED", flush=True)

from pathlib import Path
import hashlib
import json
import os

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

E1_ROOT = WORK / "E1_BLIND_TARGETS_20261012T125026604016Z"
ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
FROZEN_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
JOB.mkdir(parents=True, exist_ok=True)

SAMPLE = JOB / "capture49_frozen_sample_verified.csv.gz"
RECEIPT = JOB / "capture49_sample_verification.json"
RESOLVED = JOB / "capture49_resolved_e1_assets.json"

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def matrix(frame):
    numerical = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes"
    ]

    return np.hstack([
        np.log1p(frame[numerical].to_numpy(dtype=float)),
        np.column_stack([
            frame.proto.eq(protocol).to_numpy(dtype=float)
            for protocol in ["tcp", "udp", "icmp"]
        ]),
    ])

def manifest_value(row, column):
    if column not in row.index:
        raise RuntimeError(
            f"Target asset manifest has no column named {column}."
        )

    value = row[column]

    if pd.isna(value) or not str(value).strip():
        raise RuntimeError(
            f"Target asset manifest has no usable value for {column}."
        )

    return str(value)

for path in [E1_ROOT, ASSETS, MODEL, FROZEN_OUTPUTS]:
    if not path.exists():
        raise FileNotFoundError(f"Required existing artifact missing: {path}")

assets = pd.read_csv(ASSETS)
selected = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(selected) != 1:
    raise RuntimeError(
        f"Expected exactly one resolved Capture 49 row; found {len(selected)}."
    )

asset = selected.iloc[0]

expected_features_hash = manifest_value(asset, "features_sha256")
expected_conn_hash = manifest_value(asset, "conn_log_sha256")
expected_pcap_hash = manifest_value(asset, "pcap_sha256")

# Enumerate only the already restored E1 directory. This creates no copy.
e1_files = []

for current, dirs, names in os.walk(E1_ROOT, followlinks=False):
    current = Path(current)

    for name in names:
        path = current / name
        if path.is_file():
            e1_files.append(path)

if not e1_files:
    raise RuntimeError("The restored E1 directory contains no regular files.")

print(f"E1 files available: {len(e1_files)}", flush=True)

def resolve_by_hash(expected_hash, artifact_name):
    # First use filenames that visibly name Capture 49 or the expected artifact.
    preferred = [
        path for path in e1_files
        if (
            SCENARIO.lower() in path.name.lower()
            or artifact_name.lower() in path.name.lower()
        )
    ]

    # If backup flattening renamed files, SHA-256 across the existing E1 files
    # remains the authoritative identity check.
    candidates = preferred + [
        path for path in e1_files if path not in preferred
    ]

    matches = []

    for index, path in enumerate(candidates, start=1):
        actual_hash = sha256_file(path)

        if actual_hash == expected_hash:
            matches.append(path)

        if index % 5 == 0 or index == len(candidates):
            print(
                f"Hash-checked {index}/{len(candidates)} E1 files "
                f"while resolving {artifact_name}",
                flush=True
            )

    if len(matches) != 1:
        raise RuntimeError(
            f"Expected exactly one SHA-256 match for Capture 49 "
            f"{artifact_name}; found {len(matches)}."
        )

    return matches[0]

# These paths are resolved solely by frozen content hashes.
# No stale absolute path from the earlier Kaggle session is trusted.
features_file = resolve_by_hash(expected_features_hash, "features")
conn_log_file = resolve_by_hash(expected_conn_hash, "conn_log")
pcap_file = resolve_by_hash(expected_pcap_hash, "pcap")

resolved_assets = {
    "status": "CAPTURE49_E1_ASSETS_RESOLVED_BY_SHA256",
    "scenario": SCENARIO,
    "features_file": str(features_file),
    "features_sha256": sha256_file(features_file),
    "conn_log_file": str(conn_log_file),
    "conn_log_sha256": sha256_file(conn_log_file),
    "pcap_file": str(pcap_file),
    "pcap_sha256": sha256_file(pcap_file),
    "pcap_GiB": round(pcap_file.stat().st_size / 1024**3, 4),
    "old_absolute_manifest_paths_used": False,
    "backup_copied": False,
    "files_deleted": 0,
}
atomic_json(RESOLVED, resolved_assets)

print("\nRESOLVED CAPTURE 49 ASSETS")
print(json.dumps(resolved_assets, indent=2))

# The completed injection output is the authoritative frozen membership.
# It contains exactly the ks flow keys and labels used in the completed
# Capture 49 compact experiment.
with np.load(FROZEN_OUTPUTS, allow_pickle=True) as frozen:
    frozen_keys = frozen["ks"].astype(str)
    frozen_y = frozen["y"].astype(int)
    frozen_clean_probabilities = {
        str(seed): frozen[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(frozen_keys) != 1024 or len(set(frozen_keys)) != 1024:
    raise RuntimeError("Frozen Capture 49 output does not contain 1,024 unique keys.")

if int((frozen_y == 0).sum()) != 512 or int((frozen_y == 1).sum()) != 512:
    raise RuntimeError("Frozen Capture 49 output is not exactly 512 benign / 512 malicious.")

wanted = set(frozen_keys)
rows = []
found = set()

for chunk in pd.read_csv(
    features_file,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise RuntimeError(
            "Resolved Capture 49 feature file does not contain ks/y."
        )

    hit = chunk[chunk.ks.astype(str).isin(wanted)].copy()

    if not hit.empty:
        hit["ks"] = hit.ks.astype(str)
        duplicate = set(hit.ks) & found

        if duplicate:
            raise RuntimeError(
                "A frozen Capture 49 ks value occurs more than once "
                "in the resolved E1 feature file."
            )

        rows.append(hit)
        found.update(hit.ks)

if found != wanted:
    raise RuntimeError(
        "Resolved Capture 49 feature table does not contain every frozen "
        f"membership key. Missing keys: {len(wanted - found)}."
    )

sample = pd.concat(rows, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

if not np.array_equal(sample.ks.to_numpy(dtype=str), frozen_keys):
    raise RuntimeError("Frozen key ordering changed during reconstruction.")

if not np.array_equal(sample.y.to_numpy(dtype=int), frozen_y):
    raise RuntimeError("Frozen labels changed during reconstruction.")

bundle = joblib.load(MODEL)
verification_rows = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)

        recomputed = bank["PRIMARY"].predict_proba(
            matrix(sample)
        )[:, 1]

        saved = frozen_clean_probabilities[seed]

        verification_rows.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved >= 0.5)).sum()
            ),
            "clean_accuracy": float(
                ((recomputed >= 0.5) == sample.y.to_numpy()).mean()
            ),
        })

verification = pd.DataFrame(verification_rows)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "The exact E1 rows do not reproduce frozen Capture 49 predictions. "
        "No pacing job has started."
    )

sample.to_csv(SAMPLE, index=False, compression="gzip")
verification.to_csv(
    JOB / "capture49_sample_prediction_verification.csv",
    index=False
)

receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_path": str(SAMPLE),
    "sample_sha256": sha256_file(SAMPLE),
    "rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "frozen_membership_source": str(FROZEN_OUTPUTS),
    "resolved_e1_assets": str(RESOLVED),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
    "backup_copied": False,
    "files_deleted": 0,
}

atomic_json(RECEIPT, receipt)

print("\nCAPTURE 49 FROZEN SAMPLE VERIFIED")
print(verification.to_string(index=False))
print("\nFINAL RECEIPT")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 21 =====
"""Resume after runtime disconnection: inspect the four mounted backups and restore verified trees.
No model loading/training, attacks, raw dataset reads, or new outcome generation.
"""
import contextlib,csv,hashlib,json,os,shutil,zipfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath

ROOTS=[Path('/kaggle/input/datasets/mdhamidborkottulla')/name
 for name in ['the-last-update','complete-backup','whole-in-one','ran-files']]
OUT=Path('/kaggle/working')/('resume_verified_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(parents=True,exist_ok=False)
EXPECTED={
 'CICIoT2023_bundle.joblib':'29953ea07802a058999db2e66a84ee11cafe00ca5498b8a2d27bb41f80ad6e88',
 'CICIoMT2024_bundle.joblib':'7fb9923184800d7cbbc8b5a90ac4a339344d5e2ca91ca378647d3c2466b38473',
 'CSE_bundle.joblib':'df7b8d69c59e75be107c3f524bed0c6cf0293b8c3a1cd7c8add65b5afcd4dae3',
 'NSL_bundle.joblib':'cd29b0ac4a421aa7ba0d75c7da2e8238ca601c80e13ebfef8fb01691d03fda29',
 'TONIoT_bundle.joblib':'bb65ffc65efcd62a93c7f9b33aa4d000ecde3970370f2fa05f5786753d53b1bf',
 'NF_source_bundle.joblib':'d7dd5a584fa41419d088ac7c80c08742330677159ca35d6fd3fb3884cc5fe307',
 'NF_calibrated_source_bundle.joblib':'888e9783643a06792283f128403eda2e88309c6f162f0037e61dc6c907a39268',
 'NF_target_panels.joblib':'c9ad50e812246b29251587b0f85ba1aaa9b09749685f774e67580994ee609b5c'}
CORE_DIRS={'CICIoT2023_bundle.joblib':'CICIoT2023','CICIoMT2024_bundle.joblib':'CICIoMT2024',
 'CSE_bundle.joblib':'CSE','NSL_bundle.joblib':'NSL','TONIoT_bundle.joblib':'TONIoT'}
NF_DIRS={'nf_boundary_spec_v1','nf_step2_source_training_v1','nf_step3_calibration_v1',
 'nf_source_discrimination_diagnosis','nf_step4_target_contract_v1','nf_step4_target_contract_v2','nf_step5_locked_evaluation_v1'}
records=[];discovery_errors=[];root_rows=[]

def save(name,rows,columns):
 with (OUT/name).open('w',newline='',encoding='utf-8') as f:
  writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(rows)
@contextlib.contextmanager
def reader(record):
 if record['member']:
  with zipfile.ZipFile(record['container']) as archive:
   with archive.open(record['member']) as handle:yield handle
 else:
  with Path(record['container']).open('rb') as handle:yield handle

def stream_hash(record):
 h=hashlib.sha256()
 with reader(record) as handle:
  for block in iter(lambda:handle.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def disk_hash(path):
 h=hashlib.sha256()
 with path.open('rb') as handle:
  for block in iter(lambda:handle.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def record_id(record):return record['container']+'::'+record['member']
def namespace(record):
 return ('zip',record['container']) if record['member'] else ('directory',record['root'])
def safe_name(name):
 p=PurePosixPath(name)
 return not p.is_absolute() and '..' not in p.parts

def read_json(record):
 with reader(record) as handle:
  payload=handle.read(20*1024*1024+1)
 if len(payload)>20*1024*1024:raise ValueError('JSON metadata exceeds safe limit.')
 return json.loads(payload)

for priority,root in enumerate(ROOTS):
 count=0
 if root.is_dir():
  for directory,dirs,filenames in os.walk(root,followlinks=False):
   current=Path(directory)
   dirs[:]=[name for name in dirs if not (current/name).is_symlink()]
   for name in sorted(filenames):
    path=current/name
    if path.is_symlink() or not path.is_file():continue
    count+=1;logical=str(path.relative_to(root))
    if name.lower().endswith('.zip'):
     try:
      with zipfile.ZipFile(path) as archive:
       for info in archive.infolist():
        if info.is_dir():continue
        if not safe_name(info.filename):raise ValueError('Unsafe archive member: '+info.filename)
        records.append({'priority':priority,'root':str(root),'container':str(path),
         'member':info.filename,'logical':info.filename,'bytes':info.file_size})
     except Exception as error:
      discovery_errors.append({'path':str(path),'error':f'{type(error).__name__}: {error}'})
    else:
     records.append({'priority':priority,'root':str(root),'container':str(path),
      'member':'','logical':logical,'bytes':path.stat().st_size})
 root_rows.append({'root':str(root),'exists':root.is_dir(),'regular_files_discovered':count})
save('roots.csv',root_rows,['root','exists','regular_files_discovered'])
save('discovery_errors.csv',discovery_errors,['path','error'])

anchors={};hash_checks=[]
for basename,expected in EXPECTED.items():
 candidates=[r for r in records if PurePosixPath(r['logical']).name==basename]
 candidates.sort(key=lambda r:(r['priority'],'PRIVATE_development_snapshot' in r['logical'],len(r['logical']),record_id(r)))
 for record in candidates:
  try:
   actual=stream_hash(record);match=actual==expected
   hash_checks.append({'file':basename,'source':record_id(record),'sha256':actual,'matches_expected':match,'error':''})
   if match:
    anchors[basename]=record;break
  except Exception as error:
   hash_checks.append({'file':basename,'source':record_id(record),'sha256':'','matches_expected':False,
    'error':f'{type(error).__name__}: {error}'})
save('anchor_hash_checks.csv',hash_checks,['file','source','sha256','matches_expected','error'])

# Select a complete core tree using its five known bundle anchors.
core_candidates=[]
for record in records:
 suffix='CICIoT2023/CICIoT2023_bundle.joblib'
 if not record['logical'].endswith(suffix):continue
 prefix=record['logical'][:-len(suffix)]
 available={r['logical']:r for r in records if namespace(r)==namespace(record)}
 members=[]
 for basename,directory in CORE_DIRS.items():
  candidate=available.get(prefix+directory+'/'+basename)
  if candidate is None:break
  members.append((basename,candidate))
 if len(members)==5:core_candidates.append((record,prefix,members))
core_candidates.sort(key=lambda item:(item[0]['priority'],'PRIVATE_development_snapshot' in item[1],len(item[1])))
selected_core=None
for record,prefix,members in core_candidates:
 try:
  if all(stream_hash(r)==EXPECTED[name] for name,r in members):
   selected_core=(namespace(record),prefix);break
 except Exception as error:
  discovery_errors.append({'path':record_id(record),'error':str(error)})

selected=[]
if selected_core:
 space,prefix=selected_core
 for r in records:
  if namespace(r)!=space or not r['logical'].startswith(prefix):continue
  relative=r['logical'][len(prefix):]
  if not relative or not safe_name(relative):continue
  if any(p.startswith('PRIVATE_development_snapshot') or p in {'.git','__pycache__'} for p in PurePosixPath(relative).parts):continue
  if relative.lower().endswith(('.zip','.pcap','.pcapng','.cap','.pcap.gz')):continue
  selected.append((r,OUT/'development'/relative))

# Recover NF stage trees from the verified NF anchor namespaces.
nf_sources=[]
for name in ['NF_source_bundle.joblib','NF_calibrated_source_bundle.joblib','NF_target_panels.joblib']:
 record=anchors.get(name)
 if record:
  parts=PurePosixPath(record['logical']).parts
  stage_index=next((i for i,p in enumerate(parts) if p in NF_DIRS),None)
  if stage_index is not None:
   prefix='/'.join(parts[:stage_index]);prefix=(prefix+'/') if prefix else ''
   nf_sources.append((record['priority'],namespace(record),prefix))
nf_sources.sort(key=lambda item:item[0])
selected_destinations={str(destination) for _,destination in selected}
for _,space,prefix in nf_sources:
 for r in records:
  if namespace(r)!=space or not r['logical'].startswith(prefix):continue
  relative=r['logical'][len(prefix):]
  if not relative or not safe_name(relative) or PurePosixPath(relative).parts[0] not in NF_DIRS:continue
  destination=OUT/relative
  if str(destination) not in selected_destinations:
   selected.append((r,destination));selected_destinations.add(str(destination))

# Recover a verified terminal NF receipt even if models are absent from a results-only ZIP.
result_candidates=[r for r in records if r['logical'].endswith('nf_step5_locked_evaluation_v1/evaluation_receipt.json')]
result_candidates.sort(key=lambda r:r['priority'])
selected_nf_result=None
for r in result_candidates:
 try:
  candidate=read_json(r)
  if candidate.get('settings_sha256')!='b18bf4cdbf33675e6e4350617b16ddf3ce554d7c25d8d51be530ec1436ab2019':continue
  prefix=r['logical'][:-len('evaluation_receipt.json')]
  index={item['logical']:item for item in records if namespace(item)==namespace(r)}
  if all(prefix+filename in index and stream_hash(index[prefix+filename])==digest for filename,digest in candidate['output_sha256'].items()):
   selected_nf_result=candidate
   result_records=[item for item in records if namespace(item)==namespace(r) and item['logical'].startswith(prefix)]
   for item in result_records:
    destination=OUT/'nf_step5_locked_evaluation_v1'/item['logical'][len(prefix):]
    # Prefer this checksum-verified result namespace to an unverified duplicate.
    selected=[pair for pair in selected if pair[1]!=destination]
    selected.append((item,destination))
   break
 except Exception as error:discovery_errors.append({'path':record_id(r),'error':str(error)})

# Ensure matched model objects are restored under canonical paths.
for name,record in anchors.items():
 if name in CORE_DIRS:destination=OUT/'development'/CORE_DIRS[name]/name
 elif name=='NF_source_bundle.joblib':destination=OUT/'nf_step2_source_training_v1'/name
 elif name=='NF_calibrated_source_bundle.joblib':destination=OUT/'nf_step3_calibration_v1'/name
 else:destination=OUT/'nf_step4_target_contract_v2'/name
 selected=[pair for pair in selected if pair[1]!=destination];selected.append((record,destination))

size=sum(r['bytes'] for r,_ in selected)
if size+1024**3>shutil.disk_usage('/kaggle/working').free:raise RuntimeError('Insufficient space for selected restoration plus 1 GiB reserve.')
copy_rows=[]
for index,(record,destination) in enumerate(selected,start=1):
 destination.parent.mkdir(parents=True,exist_ok=True)
 expected=stream_hash(record)
 if destination.exists():
  if disk_hash(destination)!=expected:raise RuntimeError('Restoration destination conflict: '+str(destination))
  continue
 temp=destination.with_suffix(destination.suffix+'.restoring')
 with reader(record) as source,temp.open('wb') as target:shutil.copyfileobj(source,target,8*1024*1024)
 if disk_hash(temp)!=expected:raise RuntimeError('Copy verification failed: '+str(destination))
 temp.replace(destination)
 copy_rows.append({'source':record_id(record),'destination':str(destination),'bytes':record['bytes'],'sha256':expected})
 if index%200==0:print('VERIFIED RESTORED FILES:',index,'/',len(selected),flush=True)
save('verified_restoration.csv',copy_rows,['source','destination','bytes','sha256'])
save('discovery_errors.csv',discovery_errors,['path','error'])

verified=[]
for name in CORE_DIRS:
 p=OUT/'development'/CORE_DIRS[name]/name
 if p.is_file() and disk_hash(p)==EXPECTED[name]:verified.append(name)
nf_results_verified=False
if selected_nf_result:
 nf_results_verified=all(disk_hash(OUT/'nf_step5_locked_evaluation_v1'/filename)==digest
  for filename,digest in selected_nf_result['output_sha256'].items())
receipt={'recovery_root':str(OUT),'restored_development_base':str(OUT/'development'),
 'verified_core_bundles':verified,'all_five_core_bundles_verified':len(verified)==5,
 'complete_core_tree_selected':selected_core is not None,
 'NF_verified_anchor_names':[name for name in anchors if name.startswith('NF_')],
 'NF_terminal_result_outputs_verified':nf_results_verified,
 'restored_files':len(copy_rows),'restored_bytes':sum(row['bytes'] for row in copy_rows),
 'backup_discovery_errors':len(discovery_errors),'models_loaded_or_retrained':False,
 'experiments_rerun':False,'legacy_ran_files_overlaid':False,
 'independent_corpus_boundary_created_by_restoration':False,
 'prospective_confirmation_created_by_restoration':False,
 'NF_boundary_result':selected_nf_result.get('boundary_result') if selected_nf_result else None}
(OUT/'resume_receipt.json').write_text(json.dumps(receipt,indent=2))
Path('/kaggle/working/research_resume_latest.json').write_text(json.dumps({'recovery_root':str(OUT),'development_base':str(OUT/'development')},indent=2))
print(json.dumps(receipt,indent=2));print('\nROOT AVAILABILITY');print(json.dumps(root_rows,indent=2))
print('\nNEXT: reuse verified completed artifacts; no blanket model/experiment rerun.')

# ===== CELL INPUT 22 =====
"""Main Step 1: build a source-quotation workbench for the two primary datasets.
Reads verified bundle metadata and existing cached non-statistical source excerpts.
No classifier fitting, predictions, attacks, corpus loading, or automatic provenance approval.
"""
import hashlib,json,re
from datetime import datetime,timezone
from pathlib import Path
import joblib
import pandas as pd
ROOT=Path('/kaggle/working/resume_verified_20261011T144807877506Z')
BASE=ROOT/'development'
OUT=ROOT/('main_source_contract_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(parents=True,exist_ok=False)
BUNDLES={
 'CICIoT2023':('CICIoT2023/CICIoT2023_bundle.joblib','29953ea07802a058999db2e66a84ee11cafe00ca5498b8a2d27bb41f80ad6e88'),
 'CICIoMT2024':('CICIoMT2024/CICIoMT2024_bundle.joblib','7fb9923184800d7cbbc8b5a90ac4a339344d5e2ca91ca378647d3c2466b38473')}
SEARCH_ROOTS=[ROOT,Path('/kaggle/input/datasets/mdhamidborkottulla/the-last-update'),
 Path('/kaggle/input/datasets/mdhamidborkottulla/complete-backup'),
 Path('/kaggle/input/datasets/mdhamidborkottulla/whole-in-one')]
EVIDENCE_NAMES={'nonstatistical_definition_excerpts.csv','definition_excerpts_with_explicit_reconciliation.csv','actual_source_quotations.csv'}

def norm(value):return re.sub(r'[^a-z0-9]','',str(value).lower())
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def value(row,names):
 for name in names:
  if name in row and str(row[name]).strip():return str(row[name])
 return ''

features={};metadata_rows=[]
for dataset,(relative,expected) in BUNDLES.items():
 path=BASE/relative
 if not path.is_file() or sha(path)!=expected:raise RuntimeError('Verified bundle mismatch: '+dataset)
 bundle=joblib.load(path)
 columns=list(bundle['primary_features'])
 features[dataset]=columns
 membership={feature:view for view,fields in bundle['semantic_views'].items() for feature in fields}
 for position,feature in enumerate(columns,start=1):
  metadata_rows.append({'dataset':dataset,'feature':feature,'position':position,
   'current_saved_view':membership.get(feature,'primary_only'),
   'historically_mutable':feature in bundle['mutable_columns'],'bundle_sha256':expected})
 del bundle
pd.DataFrame(metadata_rows).to_csv(OUT/'exact_primary_feature_inputs.csv',index=False)

paths=set()
for root in SEARCH_ROOTS:
 if root.is_dir():
  paths.update(path for path in root.rglob('*.csv') if path.name in EVIDENCE_NAMES and path.is_file() and not path.is_symlink())
seen_files=set();evidence=[];errors=[]
for path in sorted(paths,key=str):
 try:
  digest=sha(path)
  if digest in seen_files:continue
  seen_files.add(digest)
  table=pd.read_csv(path,keep_default_na=False)
  if 'dataset' not in table.columns:
   errors.append({'path':str(path),'error':'No dataset column; rows not inferred from filename.'});continue
  for index,row in table.iterrows():
   dataset_match=[d for d in BUNDLES if norm(d)==norm(row['dataset'])]
   if len(dataset_match)!=1:continue
   dataset=dataset_match[0]
   documented=value(row,['raw_feature','document_feature','feature','model_feature'])
   matches=[f for f in features[dataset] if norm(f)==norm(documented)]
   if len(matches)!=1:continue
   quote=value(row,['exact_quote','verbatim_quote','verbatim_table_row','quote','definition_text'])
   definition=value(row,['definition_text','description'])
   if not quote:continue
   if re.search(r'recaptcha|checking your browser|access denied',quote,re.I):continue
   evidence.append({'dataset':dataset,'feature':matches[0],'source_url':value(row,['source_url','requested_url']),
    'source_document_sha256':value(row,['source_sha256','document_sha256','sourcesha256']),
    'locator':value(row,['locator','table_context']),'exact_quote':quote,'definition_text':definition,
    'cache_file':str(path),'cache_file_sha256':digest,'cache_row':int(index)+2,
    'source_verified_by_this_code':False})
 except Exception as error:errors.append({'path':str(path),'error':f'{type(error).__name__}: {error}'})
evidence_table=pd.DataFrame(evidence,columns=['dataset','feature','source_url','source_document_sha256','locator',
 'exact_quote','definition_text','cache_file','cache_file_sha256','cache_row','source_verified_by_this_code'])
if not evidence_table.empty:
 evidence_table=evidence_table.drop_duplicates(['dataset','feature','source_url','source_document_sha256','exact_quote'])
evidence_table.to_csv(OUT/'exact_source_quotations.csv',index=False)

ledger=[];summary=[]
for row in metadata_rows:
 subset=evidence_table[(evidence_table.dataset==row['dataset'])&(evidence_table.feature==row['feature'])]
 ttl=bool(subset.exact_quote.str.contains(r'\bttl\b|time\s*[- ]?to\s*[- ]?live',case=False,regex=True).any()) if len(subset) else False
 ledger.append({**row,'source_excerpt_count':len(subset),'source_quote_status':'EXCERPTS_FOR_REVIEW' if len(subset) else 'NO_CACHED_EXACT_EXCERPT',
  'TTL_word_present_in_quote':ttl,'semantic_view_final':'','units':'','primitive_source':'','derived_from':'',
  'permitted_report_corruption_action':'','executable_dependency_rule':'','review_decision':'PENDING',
  'source_verified':False,'traffic_or_packet_transform_approved':False})
ledger=pd.DataFrame(ledger);ledger.to_csv(OUT/'primary_feature_contract_REVIEW.csv',index=False)
for dataset in BUNDLES:
 rows=ledger[ledger.dataset==dataset]
 summary.append({'dataset':dataset,'predictors':len(rows),'with_exact_cached_excerpt':int((rows.source_excerpt_count>0).sum()),
  'without_exact_cached_excerpt':int((rows.source_excerpt_count==0).sum()),
  'historically_mutable_without_excerpt':int((rows.historically_mutable&(rows.source_excerpt_count==0)).sum()),
  'final_source_contract_approved':False})
pd.DataFrame(summary).to_csv(OUT/'source_contract_coverage.csv',index=False)
pd.DataFrame(errors,columns=['path','error']).to_csv(OUT/'evidence_read_errors.csv',index=False)

review='# Primary-dataset exact source quotations\n\nCached excerpts are evidence to review, not automatic approval. No cross-dataset transfer or invented definitions.\n'
for row in evidence_table.to_dict('records'):
 review+=f"\n## {row['dataset']} / {row['feature']}\nURL: {row['source_url']}\nDocument SHA256: {row['source_document_sha256']}\nLocator: {row['locator']}\nCache: {row['cache_file']} / row {row['cache_row']}\n\n{row['exact_quote']}\n"
(OUT/'PRIMARY_SOURCE_QUOTATIONS.md').write_text(review,encoding='utf-8')
receipt={'output_directory':str(OUT),'active_development_base':str(BASE),'cached_evidence_files_considered':len(paths),
 'deduplicated_evidence_files_read':len(seen_files),'exact_source_excerpt_rows':len(evidence_table),
 'bundles_loaded_for_schema_metadata_only':True,'predictions_computed':False,'models_trained':False,
 'NF_experiments_repeated':False,'source_contract_approved':False,'prospective_protocol_frozen':False,
 'no_definition_invented':True,'read_errors':len(errors)}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
print('\nPRIMARY SOURCE-CONTRACT COVERAGE');print(pd.DataFrame(summary).to_string(index=False))
print('\nHISTORICAL MUTABLE FIELDS — ACTUAL QUOTES')
mutable=set(zip(ledger.loc[ledger.historically_mutable,'dataset'],ledger.loc[ledger.historically_mutable,'feature']))
for row in evidence_table.to_dict('records'):
 if (row['dataset'],row['feature']) in mutable:
  print('\n',row['dataset'],row['feature']);print(row['source_url']);print(row['exact_quote'])
print('\nUPLOAD DOCUMENT:',OUT/'PRIMARY_SOURCE_QUOTATIONS.md')

# ===== CELL INPUT 23 =====
"""Read-only A–G evidence audit. Run in Kaggle after stopping other jobs.
No joblib loading, training, predictions, attack optimization, or automatic approval.
"""
import csv,gzip,hashlib,io,json,os,re,shutil,zipfile
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd

ACTIVE=Path('/kaggle/working/resume_verified_20261011T144807877506Z')
WORK=Path('/kaggle/working');INPUT=Path('/kaggle/input')
if not (ACTIVE/'development').is_dir():raise FileNotFoundError(ACTIVE/'development')
OUT=WORK/('PLAN_CLOSURE_AUDIT_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(exist_ok=False)
COPY=OUT/'evidence';COPY.mkdir()
MAX_ENTRY=24*1024**2
MAX_TOTAL=384*1024**2
MAX_NESTED_ZIP=64*1024**2
MAX_DEPTH=3
MAX_CSV_ROWS=200000

# The reference is the supplied original A–G plan, not a newly invented plan.
REFERENCE_PLAN='# Research Plan: Unlabeled Integrity Monitoring for Frozen Edge IoT IDS Under Evasion\n\n**Status:** Development roadmap — not a submission-ready manuscript  \n**Target venue:** IEEE Internet of Things Journal, regular submission  \n**Special issue decision:** Do **not** target the current AI-Driven Network Forensics special issue unless a genuine evidence-acquisition, provenance, and post-incident reconstruction component is added.  \n**Primary framing:** Edge-IoT integrity monitoring under adversarial telemetry manipulation.  \n**Not the framing:** Generic drift detection, generic IDS classification, universal accuracy certification, or end-to-end digital forensics.\n\n---\n\n## 1. Executive decision\n\nThe rejected KARAT manuscript should **not** be revised into this paper. Its CKA-triggered teacher--student blend, synthetic cloud-disaster-recovery task, semantic IDS-to-cloud label mappings, and teacher-cost narrative are retired as central contributions.\n\nThe new work keeps only the motivating observation:\n\n> A deployed model may be wrong while multiple monitoring models appear mutually consistent; unlabeled output agreement alone does not establish that the detector remains trustworthy.\n\nThe new paper must be written as a **new manuscript**. It will study the conditions under which an edge IoT IDS can or cannot monitor the trustworthiness of its own labels without ground truth during an attack.\n\n### Proposed final title\n\n**Unlabeled Integrity Monitoring of Frozen Edge IoT Intrusion Detectors Under Evasion**\n\nAlternative after semantic provenance work is complete:\n\n**Can an Unlabeled Edge Monitor Detect Evasion? Identifiability Limits and Provenance-Aware Multi-View Integrity Monitoring for IoT IDS**\n\nThe second title is stronger, but use it only if the semantic-view/provenance component is actually implemented and evaluated.\n\n---\n\n## 2. Problem statement\n\nAn IoT intrusion detector is deployed at an edge node. During operation, labels are delayed, unavailable, or costly to obtain. The detector can therefore receive manipulated telemetry while the operator has no direct way to know whether the detector\'s labels remain reliable.\n\nLet a frozen detector be decomposed into \\(G\\) view models. At time or window \\(t\\), view \\(g\\) produces probabilities \\(p_g(x)\\) for records in the current telemetry window. The monitor observes the view-output matrix but not the true labels.\n\nThe task is **not** to retrain the IDS and **not** to detect every malicious flow. The task is to decide whether the current detector outputs remain sufficiently trustworthy for an operator or downstream response policy to use.\n\nThe monitor must output an integrity record:\n\n\\[\n\\mathcal{I}_t = (\\widehat A_t,\\,\\mathbf{w}_t,\\,\\mathbf{d}_t,\\,\\mathcal{V}_{\\mathrm{suspect}},\\,\\rho_t,\\,h_t),\n\\]\n\nwhere:\n\n- \\(\\widehat A_t\\) is a conditional estimate of detector accuracy;\n- \\(\\mathbf{w}_t\\) are view weights;\n- \\(\\mathbf{d}_t\\) are view-level drift statistics;\n- \\(\\mathcal{V}_{\\mathrm{suspect}}\\) identifies suspect telemetry/evidence channels;\n- \\(\\rho_t\\) is an integrity or abstention score;\n- \\(h_t\\) hashes the reference-window configuration, view schema, and monitor version.\n\nThe monitor does **not** claim universal or certified recovery of true accuracy. It either reports a conditional estimate under explicit assumptions or abstains when those assumptions are not met.\n\n---\n\n## 3. Research gap and position\n\n### 3.1 What existing work already covers\n\n1. **Unlabeled concept-drift detection.** MD3 tracks the density of samples near a classifier\'s decision margin. It detects drift without labels, but it does not estimate IDS accuracy under adversarially induced correlated errors.\n2. **Adversarial concept drift.** Predict-Detect and later adversarial-drift studies examine attackers who evade or poison drift detectors. They do not directly solve the narrow problem of determining whether a frozen IoT IDS\'s labels remain trustworthy without labels.\n3. **Adversarial IDS robustness.** Realistic black-box traffic attacks and constrained evasion studies show that feature-space attacks can overstate practical risk; attack constraints must be explicit.\n4. **IoT feature grouping and multi-view IDS.** Feature grouping is used for lightweight/high-accuracy IoT intrusion detection. It is not normally tied to telemetry provenance, attacker control, unlabeled label-trust estimation, or monitor abstention.\n5. **IoT forensics.** IoT forensic work addresses evidence acquisition, source identification, provenance, storage, chain-of-custody, and reconstruction. The present work does not yet implement those functions.\n\n### 3.2 Narrow novelty claim\n\nThe novelty claim is **not** that drift detection, adversarial IDS defense, feature grouping, or weighted voting is new.\n\nThe claim to test is:\n\n> The intersection of (i) unlabeled post-deployment label-trust estimation, (ii) test-time evasive manipulation of IoT telemetry, and (iii) telemetry-provenance-aware multi-view integrity monitoring is underexplored.\n\nThe paper contributes an identifiability limit, a provenance-aware monitor, a realistic attack/evaluation protocol, and a failure map.\n\n### 3.3 Scope language\n\nUse **integrity monitoring** or **forensic-ready integrity evidence**, not full "network forensics."\n\n"Forensics-ready" is permitted only for the monitor evidence record: view schema, provenance mapping, drift evidence, timestamps, hashes, and suspect channels. Do not claim post-incident reconstruction, chain-of-custody, evidence acquisition, or causal attribution unless those are implemented.\n\n---\n\n## 4. Core contributions to prove\n\n### C1. Output-only non-identifiability theorem\n\nFormalize an unlabeled multi-view monitor observing only prediction outputs \\(P\\). Construct two worlds with the same observable output matrix but different true labels and therefore different detector accuracies.\n\nTarget conclusion:\n\n\\[\n\\nexists\\,\\widehat{A}(P)\\quad\\text{that uniformly recovers true accuracy from unlabeled outputs alone.}\n\\]\n\nThis theorem must be written precisely. It should state what is observed, what attacker control is allowed, which labels differ, and why the two worlds are indistinguishable to every output-only monitor.\n\n**Purpose:** This distinguishes the paper from ordinary drift detection. It explains why output agreement, confidence, entropy, correlation, and similar unlabeled quantities can fail under coordinated evasion.\n\n### C2. Provenance-aware semantic views\n\nReplace correlation-balanced/random feature partitions with semantic telemetry views.\n\nEach feature must be mapped to a primitive source channel, for example:\n\n| Semantic view | Example primitive telemetry | Example derived flow features | Attacker-control status |\n|---|---|---|---|\n| Size/volume | packet sizes, packet count | bytes, packets, mean packet length | partly mutable |\n| Timing | packet timestamps, pacing | duration, IAT, packet/s, byte/s | partly mutable |\n| Directionality | forward/reverse traffic | Fwd/Bwd packets, Fwd/Bwd bytes | partly mutable |\n| TCP state | SYN/ACK/FIN/RST events | flag counts and state measures | constrained |\n| Protocol/service | protocol number, destination service | protocol, port class | normally immutable for a fixed flow |\n| Derived statistics | rates, averages, ratios | flow rates, average size | recompute; do not directly perturb |\n\nThe feature schema, mapping, units, mutability and constraints must be released as a machine-readable CSV.\n\n### C3. Drift-gated integrity monitor\n\nThe method begins with the current drift-gated voting evidence but becomes semantic:\n\n1. Train one lightweight model bank for each provenance view.\n2. Calibrate each view using a clean, trusted reference window.\n3. Measure the drift of each view\'s predicted positive rate and output behavior from that reference.\n4. Downweight suspect views.\n5. Estimate conditional accuracy or return **abstain** if monitor integrity is insufficient.\n6. Emit the integrity evidence record.\n\nA sufficient weighted-integrity condition is:\n\n\\[\n\\sum_{g\\in\\mathcal{C}} w_g(1-2e_g)\n>\n\\sum_{g\\in\\mathcal{A}}w_g,\n\\]\n\nwhere \\(\\mathcal{C}\\) denotes clean views, \\(\\mathcal{A}\\) attacked views, \\(w_g\\) the inferred weights, and \\(e_g\\) the conditional clean-view error.\n\nThis is a sufficient condition for the weighted decision to remain dominated by clean evidence. It is **not** an unconditional accuracy guarantee.\n\n### C4. Stealth--damage frontier\n\nA detector-aware adversary optimizes two conflicting objectives:\n\n\\[\n\\max_{\\delta}\\;\n\\mathcal{L}_{\\mathrm{evasion}}(x+\\delta)\n-\n\\lambda\\mathcal{L}_{\\mathrm{monitor}}(x+\\delta).\n\\]\n\nIt must be shown that preserving monitor statistics reduces attainable attack damage, or else that the monitor fails and abstains.\n\n### C5. Boundary condition and abstention\n\nThe final study must explain when the method works and when it does not. The development result suggests view-level accuracy under natural shift is a candidate boundary variable. Test the preregistered prediction:\n\n> When mean semantic-view accuracy under natural shift is at least 0.80, the monitor will improve differential estimation error over the fixed primary baseline; otherwise, it may abstain or provide no advantage.\n\nThe fifth dataset must test this prediction without changing it after results are known.\n\n---\n\n## 5. Current development evidence\n\n### 5.1 What has been completed\n\nThe development experiments include:\n\n- CICIoMT2024, CICIoT2023, CSE-CIC-IDS2018 and NSL-KDD;\n- three seeds for the primary monitor experiments;\n- random/correlation-balanced disjoint view construction;\n- white-box feature-space PGD;\n- surrogate transfer PGD;\n- rate-matched monitor-aware attacks;\n- soft-surrogate estimator-aware PGD;\n- sparse feature attacks;\n- range clipping, low-cardinality freezing, and integer rounding;\n- output-only estimator baselines: AC, DoC, ATC, GDE, ALine, majority and reweighted majority;\n- domain-AUC proxy, KS-max proxy, and margin-density proxy;\n- drift-gate ablation (`ANCH`, `W_ACC`, `DRIFT_ONLY`);\n- differential accuracy-estimation error;\n- decision-level damage detection;\n- attack frontier;\n- view memory/latency measurements.\n\n### 5.2 Development findings that can be retained as exploratory evidence\n\n- Output-only estimators over-report accuracy under successful evasion.\n- A soft estimator-aware attack still leaves positive gains on CICIoMT2024 and CICIoT2023.\n- The drift term explains most of the gain on the positive datasets; competence-only weighting does not.\n- Transfer attacks remain effective against the monitor but do not erase the monitor gain on the positive IoT datasets.\n- Sparse attacks can touch most views, yet the monitor still improves differential error on the two positive IoT datasets.\n- The monitor has explicit negative/failure cases on CSE-CIC-IDS2018 and weak/inconclusive outcomes on NSL-KDD.\n\n### 5.3 Development results that must not be final claims\n\n- Current partitions are not semantic/provenance-based.\n- Current D3 and MD3 implementations are proxies, not reproductions.\n- The gradient score is a proxy, not a verified reproduction of GdScore.\n- Integer rounding/range clipping is not packet-semantic validity.\n- The present Holm-corrected primary family was chosen after development results were visible.\n- The present estimator-aware attack uses a differentiable soft surrogate, not a full hard-objective and gradient-free adaptive attack.\n\n---\n\n## 6. Experiments needed for the complete study\n\n### Experiment group A: protocol freeze and confirmatory replication\n\n**Goal:** Separate exploratory results from confirmatory evidence.\n\n1. Freeze source code under a Git tag: `v1-development-freeze`.\n2. Create `protocol-confirmatory.yaml` containing:\n   - datasets;\n   - sample seed;\n   - model settings;\n   - semantic view schema version;\n   - attacks;\n   - attack strengths;\n   - metrics;\n   - primary hypotheses;\n   - correction family;\n   - seeds.\n3. Use fresh settings:\n   - `RUN = "confirm"`\n   - `SEEDS = [10, 11, 12]`\n   - `BLIND_SEEDS = [10]`\n   - `POOL_SEED = 1`\n4. Do not tune any parameter after the first confirmatory result.\n\n**Primary confirmatory family:**\n\n| Dataset | Attack |\n|---|---|\n| CICIoMT2024 | constrained semantic white-box |\n| CICIoMT2024 | constrained transfer |\n| CICIoMT2024 | constrained sparse/provenance attack |\n| CICIoT2023 | constrained semantic white-box |\n| CICIoT2023 | constrained transfer |\n| CICIoT2023 | constrained sparse/provenance attack |\n\n**Primary metric:** differential absolute accuracy-estimation error.\n\n**Statistical test:** paired, seed/pair clustered bootstrap, one-sided gain test, Holm correction over exactly six primary tests.\n\n### Experiment group B: semantic provenance views\n\n**Goal:** Replace artificial feature partitions.\n\nFor each target IoT dataset:\n\n1. Read official feature definitions.\n2. Mark every predictor as:\n   - primitive telemetry feature,\n   - derived feature,\n   - immutable field,\n   - categorical/protocol field,\n   - integer count,\n   - mutable under a valid attacker action.\n3. Build views from semantic channels, not correlation alone.\n4. Compare:\n   - random/correlation partitions,\n   - semantic provenance partitions,\n   - one monolithic model.\n5. Measure:\n   - view accuracy;\n   - feature overlap;\n   - attacker exposure per primitive channel;\n   - monitor estimation error;\n   - suspect-channel attribution precision/recall.\n\n**Required table:** `feature_provenance_schema.csv`.\n\nColumns:\n\n```text\nfeature,dataset,semantic_view,primitive_source,derived_from,mutable,integer,categorical,immutable_reason,validity_rule\n```\n\n### Experiment group C: realistic attack validity\n\n**Goal:** Ensure the attack remains plausible after constraints.\n\nFor each semantic view, define allowed transformations.\n\n| Attack primitive | Allowed operations | Recompute afterward |\n|---|---|---|\n| Packet padding | add bytes within MTU/payload bounds | total bytes, packet-size statistics, rates |\n| Timing/pacing | nonnegative delay with bounded jitter | duration, IAT, rates |\n| Packet injection | add valid dummy packets subject to protocol constraints | counts, bytes, timing, averages |\n| TCP flags | no direct arbitrary flipping | derive from valid state transitions |\n| Protocol/service | immutable per flow | none |\n\nReport:\n\n\\[\n\\text{ValidityRate} = \\frac{\\text{valid adversarial records}}{\\text{all generated adversarial records}}.\n\\]\n\nAlso report damage before and after projection/recomputation. If constrained damage vanishes, state that directly.\n\n### Experiment group D: baseline correctness\n\n**Goal:** Prevent a reviewer from rejecting the work for incorrect comparisons.\n\nImplement the actual published procedures or explicitly exclude them.\n\n| Current proxy | Action |\n|---|---|\n| `d3_auc` | Rename `Domain-AUC proxy`; do not call it D3 |\n| `md3` | Rename `Margin-density proxy`; implement actual MD3 or exclude citation |\n| `gd_score` | Rename `LastLayer-Gradient-Norm proxy`; reproduce exact GdScore only after method/code verification |\n\nRequired final baselines:\n\n1. Frozen detector confidence: AC.\n2. Difference of confidence: DoC.\n3. Accuracy-threshold confidence: ATC.\n4. Agreement/generalization estimator: GDE/ALine.\n5. Actual MD3.\n6. Actual D3 or explicitly named domain-classifier monitor.\n7. Exact gradient-based estimator, if reproducible.\n8. Drift-gated majority monitor.\n9. Drift-only ablation.\n10. Competence-only ablation.\n\n### Experiment group E: adaptive attacks\n\n**Goal:** Test the actual defense mechanism, as required by adaptive-evaluation practice.\n\nRequired attacks:\n\n1. White-box constrained semantic attack.\n2. Surrogate-transfer constrained attack.\n3. Sparse primitive-channel attack.\n4. Rate-matched attack.\n5. Estimator-aware attack using a differentiable surrogate.\n6. Gradient-free estimator-aware verification (SPSA or NES).\n\nFor the adaptive attack, optimize both detector damage and monitor deception:\n\n\\[\n\\max_{\\delta} \\;\n\\mathrm{Damage}(\\delta)\n- \\lambda_1\\mathrm{MonitorDeviation}(\\delta)\n- \\lambda_2\\mathrm{ConstraintViolation}(\\delta).\n\\]\n\nThe gradient-free verification is mandatory because the hard gate, discrete feature constraints, and feature recomputation may invalidate a purely differentiable attack result.\n\n### Experiment group F: fifth dataset boundary test\n\n**Goal:** Test generalization rather than add another table.\n\nCandidate: TON_IoT or NF-ToN-IoT-V2.\n\nBefore loading the data, commit the prediction:\n\n> If mean semantic-view accuracy under natural shift is at least 0.80, the monitor will obtain a positive, clustered confidence interval for its differential estimation-error gain under the primary constrained attack; otherwise, it will not claim a gain.\n\nThe fifth dataset must not choose parameters. It is a held-out boundary test.\n\n### Experiment group G: model-family and resource checks\n\n1. Re-run the primary attack family using gradient-boosted view models.\n2. Report semantic-view MLP and GBDT results separately.\n3. Report:\n   - parameter count;\n   - float32/INT8 size estimate;\n   - per-1,000-record inference time;\n   - monitor overhead;\n   - energy is not claimed without hardware measurement.\n4. If GBDT views fail, report the result as a model-family boundary.\n\n---\n\n## 7. Metrics\n\n### Primary metric\n\nFor estimator \\(m\\), attack state \\(a\\), and clean reference state \\(0\\):\n\n\\[\nE_m(a) = \\left|[\\widehat A_m(a) - A(a)] - [\\widehat A_m(0) - A(0)]\\right|.\n\\]\n\nThis differential error separates attack-induced monitoring error from natural-shift calibration bias.\n\n### Secondary metrics\n\n- True accuracy damage: \\(A(0)-A(a)\\).\n- Relative differential-error reduction against a fixed baseline.\n- AUROC for detecting accuracy damage greater than 5 percentage points.\n- TPR at 5% FPR.\n- False alarms on clean and natural-shift windows.\n- Attack frontier: largest damage hidden while monitor-estimated accuracy drop remains below \\(\\tau\\).\n- View/channel attribution precision, recall and F1.\n- Validity rate and damage retention after constraint projection.\n- Memory and latency.\n- Abstention rate and abstention precision.\n\n### Do not use as primary claims\n\n- Raw detector classification accuracy.\n- Attack success without a validity audit.\n- Mean results without pair/seed clustering.\n- “Best baseline” selected separately after observing each result unless described as an oracle comparison.\n\n---\n\n## 8. Statistical plan\n\n1. The independent unit is a **pair × seed** combination, not an attack strength, view count, or estimator row.\n2. Bootstrap confidence intervals resample pair × seed units.\n3. Holm correction is applied to the frozen six-test confirmatory primary family.\n4. Development results remain exploratory.\n5. Negative results remain visible in the main text.\n6. Report effect sizes and complete result files, not only selected significant rows.\n\n---\n\n## 9. Manuscript structure\n\n1. **Introduction**\n   - Frozen edge detectors, delayed labels, adversarial telemetry.\n   - Why confidence and agreement alone do not establish trust.\n   - Contributions and scope.\n\n2. **Related Work**\n   - IDS evasion and realistic traffic attacks.\n   - Unlabeled drift and performance monitoring.\n   - Agreement-based accuracy estimation.\n   - Multi-view and lightweight IoT IDS.\n   - IoT forensic evidence integrity, clearly differentiated.\n\n3. **Problem and Threat Model**\n   - Detector, views, trusted reference window.\n   - Telemetry provenance and attacker control.\n   - White-box, transfer, sparse and adaptive attacker capabilities.\n\n4. **Identifiability Limit**\n   - Theorem 1 and proof.\n\n5. **Provenance-Aware Integrity Monitor**\n   - Semantic views.\n   - Drift evidence.\n   - Weighted vote.\n   - Integrity record.\n   - Abstain condition.\n   - Proposition/weighted integrity condition.\n\n6. **Experimental Protocol**\n   - Data, schema, feature provenance, natural shifts.\n   - Validity-constrained attacks.\n   - Baselines, primary metric, confirmation protocol.\n\n7. **Results**\n   - Output-only blindness.\n   - Main primary-family comparison.\n   - Adaptive and transfer attacks.\n   - Stealth--damage frontier.\n   - Semantic partition ablation.\n   - Decision-level detection.\n   - Attribution and edge footprint.\n   - Negative controls and boundary map.\n\n8. **Limitations and Ethics**\n   - Feature/flow-level rather than packet-level semantics.\n   - Trusted reference window assumption.\n   - Dataset-specific results.\n   - No full digital-forensics chain-of-custody claim.\n\n9. **Conclusion**\n\n---\n\n## 10. Initial reference inventory\n\n### Verified or strongly relevant\n\n- Sethi and Kantardzic, *On the Reliable Detection of Concept Drift from Streaming Unlabeled Data*, Expert Systems with Applications, 2017. DOI: 10.1016/j.eswa.2017.04.008.\n- Sethi and Kantardzic, *Handling Adversarial Concept Drift in Streaming Data*, Expert Systems with Applications, 2018.\n- Korycki and Krawczyk, *Adversarial Concept Drift Detection Under Poisoning Attacks for Robust Data Stream Mining*, Machine Learning, 2022. DOI: 10.1007/s10994-022-06177-w.\n- Debicha et al., *Adv-Bot: Realistic Adversarial Botnet Attacks Against Network Intrusion Detection Systems*, Computers & Security 128, 2023. DOI: 10.1016/j.cose.2023.103176.\n- Yan et al., *Automatic Evasion of Machine-Learning-Based Network Intrusion Detection Systems*, IEEE Transactions on Dependable and Secure Computing 21, 2024. DOI: 10.1109/TDSC.2023.3247585.\n- He et al., *A Lightweight and Efficient IoT Intrusion Detection Method Based on Feature Grouping*, IEEE Internet of Things Journal 11(2), 2024. DOI: 10.1109/JIOT.2023.3294259.\n- Zoppi et al., *Which Algorithm Can Detect Unknown Attacks?*, Computers & Security 127, 2023.\n- Stoyanova et al., *A Survey on the Internet of Things Forensics*, IEEE Communications Surveys & Tutorials 22, 2020. DOI: 10.1109/COMST.2019.2962586.\n- Ruiz-Villafranca et al., *A Forensic Tool for the Identification, Acquisition and Analysis of Sources of Evidence in IoT Investigations*, Internet of Things 27, 2024.\n\n### Candidate references supplied by the user; verify bibliographic details before citation\n\n- Alatawi (2026), adversarial evasion review.\n- Maseno et al. (2026), explainable adversarial-evasion detection.\n- Apruzzese et al. (2024), adversarial perturbations and concept drift.\n- Nie et al. (2024), multi-task multi-view IoT IDS.\n- Yuan et al. (2026), adaptive drift-aware IDS.\n\n### Citation rule\n\nDo not cite arXiv versions where a journal or proceedings version exists. Verify every DOI, publication year, venue, page range, and author list in Crossref, IEEE Xplore, the publisher page, or the final PDF before submission.\n\n---\n\n## 11. Decision gates\n\n### Continue toward regular IoT-J only if all are satisfied\n\n- Confirmatory primary-family gains remain positive after Holm correction.\n- Fifth-dataset boundary prediction is correctly evaluated and reported.\n- Semantic provenance views replace random/correlation partitions.\n- Validity-constrained attacks retain nontrivial damage.\n- Actual MD3 and at least one additional published unlabeled monitor are included.\n- The adaptive attack cannot trivially invalidate the monitor without a documented damage cost or abstention.\n- The final paper reports the IDS2018 and NSL-KDD failures openly.\n\n### Submit to the special issue only if all are additionally satisfied\n\n- Integrity records are implemented with timestamps, configuration hashes and provenance metadata.\n- View-level evidence channels are attributable to telemetry sources.\n- An explicit evidence acquisition/storage/provenance component exists.\n- The manuscript includes post-incident evidence correlation or reconstruction, not merely monitoring.\n\nOtherwise, use **regular IEEE Internet of Things Journal**.\n\n---\n\n## 12. Immediate next task\n\n1. Attach TON_IoT or NF-ToN-IoT-V2.\n2. Print and archive its schema.\n3. Build `feature_provenance_schema.csv`.\n4. Replace correlation-balanced views with semantic provenance views.\n5. Freeze the confirmatory protocol.\n6. Only then run the final confirmatory experiment.\n\nThis ordering is deliberate. More random attack variants will not make the paper more novel. Semantic provenance, realistic constraints, a formal limit, and an independent confirmation are what convert the current promising development evidence into a serious IoT-J submission.\n'
(OUT/'REFERENCE_ORIGINAL_PLAN.md').write_text(REFERENCE_PLAN,encoding='utf-8')

FILES=[];ASSETS=[];ARCHIVES=[];ERRORS=[];EVIDENCE=[];FLAGS=[];TABLES=[];DOCS=[]
content={};seen=set();bytes_retained=0;budget_exhausted=False
PLAN_RE=re.compile(r'plan|protocol|prereg|claim|theorem|lemma|proof|provenance|source.*review|source.*quot|integrity.*record|README_RESTORE',re.I)
CSV_RE=re.compile(r'coverage|evidence|ledger|schema|manifest|summary|interval|bank_units|remaining|resource|quantization|risk.coverage|frontier|replay|constraint|validity|retention|definition|provenance|attribution|md3_results|comparison|calibration|paired_rule|comparison_rule',re.I)
RAW_RE=re.compile(r'(^|[_ -])(train|test_df|validation_df|attack_records|source_test|target_windows|target_estimator_windows|pool)([_ .-]|$)',re.I)
ASSET_RE=re.compile(r'\.(pcap|pcapng)(\.gz)?$|(^|/)(conn\.log\.labeled|zeek-conn\.log\.labeled|labels?\.config)$',re.I)


def digest(b):return hashlib.sha256(b).hexdigest()
def norm(v):return re.sub(r'[^a-z0-9]','',str(v).lower())
def truth(v):return str(v).strip().lower() in {'true','1','yes'}
def eligible(name):
 base=Path(name).name;suffix=Path(base).suffix.lower()
 if suffix=='.json':return not re.search(r'credential|secret|token|cookie',base,re.I)
 if suffix=='.csv':return bool(CSV_RE.search(base)) and not RAW_RE.search(base)
 if suffix in {'.yaml','.yml','.md','.txt'}:return bool(PLAN_RE.search(base))
 return False

def flag_walk(obj,source,path='',depth=0):
 if depth>10:return
 if isinstance(obj,dict):
  for k,v in obj.items():
   p=(path+'.' if path else '')+str(k)
   if isinstance(v,(dict,list)):flag_walk(v,source,p,depth+1)
   elif isinstance(v,(bool,int,float,str)) and re.search(r'confirm|prospect|valid|approved|independ|packet|trace|source|freeze|threshold|seed|scope|retrain|attack|labels|zeek|status|complete|sha256',str(k),re.I):
    FLAGS.append({'evidence_sha256':source,'key':p,'value':str(v)[:2500]})
 elif isinstance(obj,list) and len(obj)<=100:
  for i,v in enumerate(obj):flag_walk(v,source,f'{path}[{i}]',depth+1)

def retain(locator,name,blob):
 global bytes_retained,budget_exhausted
 h=digest(blob)
 EVIDENCE.append({'locator':locator,'name':Path(name).name,'bytes':len(blob),'sha256':h})
 if h in seen:return
 if bytes_retained+len(blob)>MAX_TOTAL:
  budget_exhausted=True;ERRORS.append({'locator':locator,'issue':'METADATA_BUDGET_EXHAUSTED'});return
 seen.add(h);bytes_retained+=len(blob);content[h]=blob
 suffix=Path(name).suffix.lower();(COPY/(h+suffix)).write_bytes(blob)
 if suffix=='.json':
  try:obj=json.loads(blob.decode('utf-8-sig'));flag_walk(obj,h)
  except Exception as e:ERRORS.append({'locator':locator,'issue':'JSON_PARSE: '+str(e)})
 elif suffix=='.csv':
  try:
   table=pd.read_csv(io.BytesIO(blob),keep_default_na=False,nrows=MAX_CSV_ROWS+1)
   partial=len(table)>MAX_CSV_ROWS
   if partial:table=table.iloc[:MAX_CSV_ROWS]
   TABLES.append((h,Path(name).name,table,partial))
   if partial:ERRORS.append({'locator':locator,'issue':'CSV_ROW_CAP; table not fully inspected'})
  except Exception as e:ERRORS.append({'locator':locator,'issue':'CSV_PARSE: '+str(e)})
 else:
  try:DOCS.append((h,Path(name).name,blob.decode('utf-8-sig')))
  except Exception as e:ERRORS.append({'locator':locator,'issue':'TEXT_DECODE: '+str(e)})

def scan_zip(source,locator,depth=0):
 if depth>MAX_DEPTH:
  ERRORS.append({'locator':locator,'issue':'NESTED_ARCHIVE_DEPTH_LIMIT'});return
 try:
  with zipfile.ZipFile(source) as z:
   infos=z.infolist()
   ARCHIVES.append({'locator':locator,'kind':'ZIP','members':len(infos),'inspection':'CENTRAL_DIRECTORY_AND_SELECTED_METADATA_ONLY'})
   for info in infos:
    if info.is_dir():continue
    member=f'{locator}!{info.filename}'
    if ASSET_RE.search(info.filename):ASSETS.append({'locator':member,'bytes':info.file_size,'kind':'ARCHIVED_ASSET_NOT_REPLAYED','header_hex':''})
    if eligible(info.filename):
     if info.file_size>MAX_ENTRY:
      ERRORS.append({'locator':member,'issue':'SELECTED_METADATA_ENTRY_TOO_LARGE'});continue
     if budget_exhausted:continue
     try:retain(member,info.filename,z.read(info))
     except Exception as e:ERRORS.append({'locator':member,'issue':'ZIP_ENTRY_READ: '+str(e)})
    elif info.filename.lower().endswith('.zip'):
     if info.file_size<=MAX_NESTED_ZIP and depth<MAX_DEPTH and not budget_exhausted:
      try:scan_zip(io.BytesIO(z.read(info)),member,depth+1)
      except Exception as e:ERRORS.append({'locator':member,'issue':'NESTED_ZIP_READ: '+str(e)})
     else:ERRORS.append({'locator':member,'issue':'NESTED_ZIP_NOT_OPENED_SIZE_OR_DEPTH_LIMIT'})
    elif re.search(r'\.(tar|tgz|tar\.gz|7z|rar)$',info.filename,re.I):
     ERRORS.append({'locator':member,'issue':'NON_ZIP_CONTAINER_INVENTORIED_NOT_CONTENT_INSPECTED'})
 except Exception as e:ERRORS.append({'locator':locator,'issue':'ZIP_OPEN: '+str(e)})

for root in [WORK,INPUT]:
 if not root.is_dir():continue
 for directory,dirs,names in os.walk(root,followlinks=False):
  d=Path(directory)
  dirs[:]=sorted(x for x in dirs if not (d/x).is_symlink() and (d/x)!=OUT and not x.startswith('PLAN_CLOSURE_AUDIT_'))
  for name in sorted(names):
   p=d/name
   if p.is_symlink():continue
   try:
    size=p.stat().st_size
    FILES.append({'locator':str(p),'bytes':size,'suffix':p.suffix.lower()})
    if ASSET_RE.search(str(p)):
     header=''
     if re.search(r'\.pcap(ng)?(\.gz)?$',name,re.I):
      try:
       opener=gzip.open if name.lower().endswith('.gz') else open
       with opener(p,'rb') as f:header=f.read(16).hex()
      except Exception as e:ERRORS.append({'locator':str(p),'issue':'CAPTURE_HEADER_READ: '+str(e)})
     ASSETS.append({'locator':str(p),'bytes':size,'kind':'FILESYSTEM_ASSET_NOT_REPLAYED','header_hex':header})
    if eligible(name):
     if size<=MAX_ENTRY and not budget_exhausted:retain(str(p),name,p.read_bytes())
     elif size>MAX_ENTRY:ERRORS.append({'locator':str(p),'issue':'SELECTED_METADATA_FILE_TOO_LARGE'})
    elif name.lower().endswith('.zip'):scan_zip(p,str(p))
    elif re.search(r'\.(tar|tgz|tar\.gz|7z|rar)$',name,re.I):
     ARCHIVES.append({'locator':str(p),'kind':'OTHER_ARCHIVE','members':'','inspection':'NOT_CONTENT_INSPECTED'})
     ERRORS.append({'locator':str(p),'issue':'NON_ZIP_CONTAINER_INVENTORIED_NOT_CONTENT_INSPECTED'})
   except Exception as e:ERRORS.append({'locator':str(p),'issue':'FILESYSTEM_READ: '+str(e)})

# Content diagnostics: do not approve methods merely because files exist.
DIAGNOSTICS=[]
for h,name,t,partial in TABLES:
 row={'sha256':h,'name':name,'rows_inspected':len(t),'full_table_inspected':not partial,'columns':'|'.join(map(str,t.columns))}
 for col in ['dataset','status','review_decision','source_verified','confirmatory_test','independent_whole_bank_runs','interval_scope','oracle_labels_consumed','packet_validity_established','NetFlow_cross_field_validity_established','models_trained']:
  if col in t:
   counts=t[col].astype(str).value_counts(dropna=False)
   row[col+'_counts']=json.dumps({str(k):int(v) for k,v in counts.head(25).items()})
 DIAGNOSTICS.append(row)

TASKS=[
 ('A','A1','Development freeze/reproduction','ALREADY_DONE_IF_EVIDENCE_CONFIRMS','final_development_receipt.json|clean_primary_reproduction.csv|reproduction_status.csv','Preserve frozen development; no blanket retraining.'),
 ('A','A2','Final prospective six-test protocol and results','REQUIRED_FINAL','protocol-confirmatory.yaml|protocol_confirmatory.yaml|confirmatory_protocol.json|primary_hypothesis_tests.csv|holm_primary_results.csv','Choose original CIC primary family versus IoT-23 amendment explicitly; prove outcome chronology and sampling units.'),
 ('B','B1','Reviewed source/dependency contract','REQUIRED_FINAL','primary_feature_contract_REVIEW.csv|feature_provenance_schema.csv|quality_corrected_feature_ledger.csv|definition_excerpts_with_explicit_reconciliation.csv|CICIoT_documentary_provenance_review.csv','Review source identity, units, primitive/derived fields and executable constraints; coverage alone is not approval.'),
 ('B','B2','Capture/extractor/label/model-row linkage','REQUIRED_TRACE_TRACK','A0_protocol_reset_and_next_step.json|A0_scenario_asset_provenance_manifest.csv|A2_clean_replay_receipt.json|trace_to_model_row_mapping.csv|record_mapping_review.csv','Resolve label rules, capture/log mapping, clean replay and row identity.'),
 ('C','C1','Existing feature-space consistency/retention','DEVELOPMENT_REUSE','damage_retention_overview.csv|report_constraint_checks.csv','Reuse candidate algebraic/type/range checks; not packet validity.'),
 ('C','C2','Valid primitive transformations and re-extraction','REQUIRED_TRACE_TRACK','trace_attack_validity.csv|packet_transformation_receipt.json|trace_damage_retention.csv|transformed_capture_replay.csv','Actual transformations, extraction, protocol checks and label-preservation review; file presence is insufficient.'),
 ('D','D1','Published baseline/label-use fidelity','DEVELOPMENT_REUSE_AND_FINAL_ADAPTERS','all_datasets_md3_results.csv|all_datasets_corrected_direct_target_summary.csv|baseline_fidelity_ledger.csv','Separate MD3 warning from label-assisted confirmation; bind each estimate to its actual target; name proxies honestly.'),
 ('E','E1','Existing hard-gate/adaptive/neural replay','DEVELOPMENT_REUSE','configuration_summary.csv|all_datasets_corrected_direct_target_summary.csv|neural_replay_status.csv','Reuse inspected feature-space development attacks and failures.'),
 ('E','E2','Adaptive final constrained monitor evaluation','REQUIRED_FINAL','final_adaptive_frontier.csv|final_hard_gate_query_results.csv|trace_adaptive_evaluation.csv','Evaluate the final approved action space and hard gate with fixed query budgets.'),
 ('F','F1','Locked NF same-parent boundary result','REUSE_SEALED_NEGATIVE','boundary_result.json|evaluation_receipt.json|primary_paired_family_errors.csv','Retain negative NF result; do not retune; it does not establish independent-corpus confirmation.'),
 ('F','F2','Independent boundary requirement','REQUIRED_OR_EXPLICIT_PLAN_AMENDMENT','independent_boundary_protocol.json|independent_boundary_results.csv','Audit exposure and physical/data dependencies; do not claim independent corpora from family panels.'),
 ('G','G1','Existing model-family/resource development','DEVELOPMENT_REUSE','resource_summary.csv|resource_audit.csv|resource_precision_summary.csv|model_family_summary.csv','Reuse existing banks/resources; deterministic duplicate predictions are not fresh independent units.'),
 ('G','G2','Final pipeline attribution/resource check','REQUIRED_IF_FINAL_IMPLEMENTATION_CHANGES','final_resource_audit.csv|final_channel_attribution.csv','Measure changed final pipeline only; source attribution requires verified channel truth; no unsupported energy claims.'),
 ('THEORY','T1','Generic output-only lemma','EXISTS_AWAITING_FINAL_PROOF_REVIEW','output_only_nonidentifiability_lemma.md|generic_nonidentifiability_lemma.md','Distinguish generic abstract worlds from IDS-specific attack attainability.'),
 ('THEORY','T2','IDS assumptions and weighted-integrity proposition','REQUIRED_FINAL','weighted_integrity_proposition.md|IDS_admissible_worlds_proof.md','Give precise observation/threat assumptions and probabilistic guarantee; no uniform accuracy certificate.'),
 ('STATS','S1','Final independent-unit inference','REQUIRED_FINAL','paired_conditional_bank_intervals.csv|primary_hypothesis_tests.csv|holm_primary_results.csv','Conditional bank intervals are not final source-domain confirmation; report clustered effect sizes and frozen correction family.'),
 ('PACKAGE','P1','Claim/version/reproduction closure','REQUIRED_FINAL','manuscript_claim_and_limitation_matrix.csv|protocol-confirmatory.yaml|baseline_fidelity_ledger.csv','Bind schemas, banks, threshold operators, profiles, code and each claim to a reproducible version.')]

index_by_name={}
for item in EVIDENCE:index_by_name.setdefault(item['name'].lower(),[]).append(item)
ledger=[];matches=[]
for group,task,requirement,category,candidates,rule in TASKS:
 hits=[]
 for name in candidates.split('|'):hits.extend(index_by_name.get(name.lower(),[]))
 unique={r['sha256']:r for r in hits}
 state='CANDIDATE_EVIDENCE_FOUND_REVIEW_CONTENT'
 if not hits:state='NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT'
 for r in unique.values():matches.append({'task':task,**r})
 ledger.append({'group':group,'task':task,'requirement':requirement,'plan_category':category,'audit_state':state,
  'distinct_candidate_contents':len(unique),'completion_gate':rule,'scientific_completion_auto_approved':False})

# Source contract: report exact values, never transfer definitions between datasets.
source_rows=[]
for h,name,t,partial in TABLES:
 if name=='source_contract_coverage.csv':
  for row in t.to_dict('records'):source_rows.append({'sha256':h,'table':name,**row})

# Find conflicting approvals/statuses for human review, preserving provenance.
contradictions=[]
for h,name,t,partial in TABLES:
 if 'view_membership_approved' in t and 'dataset' in t:
  for row in t.to_dict('records'):
   if truth(row.get('view_membership_approved')):contradictions.append({'sha256':h,'item':str(row.get('dataset')),'issue':'Structural view approval found; does not establish source semantics or that saved banks were trained with this schema.'})
 if 'confirmatory_test' in t:
  contradictions.append({'sha256':h,'item':name,'issue':'Confirmatory labels must be checked against protocol chronology and actual independent units; no automatic acceptance.'})

write_csv=lambda filename,rows,columns:pd.DataFrame(rows,columns=columns).to_csv(OUT/filename,index=False)
write_csv('filesystem_inventory.csv',FILES,['locator','bytes','suffix'])
write_csv('raw_asset_inventory.csv',ASSETS,['locator','bytes','kind','header_hex'])
write_csv('archive_scope.csv',ARCHIVES,['locator','kind','members','inspection'])
write_csv('evidence_index.csv',EVIDENCE,['locator','name','bytes','sha256'])
write_csv('decision_flags.csv',FLAGS,['evidence_sha256','key','value'])
pd.DataFrame(DIAGNOSTICS).to_csv(OUT/'table_content_diagnostics.csv',index=False)
pd.DataFrame(ledger).to_csv(OUT/'PLAN_TASK_LEDGER.csv',index=False)
write_csv('task_evidence_matches.csv',matches,['task','locator','name','bytes','sha256'])
pd.DataFrame(source_rows).to_csv(OUT/'recovered_source_contract_coverage.csv',index=False)
write_csv('interpretation_warnings.csv',contradictions,['sha256','item','issue'])
write_csv('audit_limits_and_errors.csv',ERRORS,['locator','issue'])

report='# Kaggle A–G plan closure: evidence audit\n\n'
report+='This is an evidence-content workbench, not scientific approval. Completed development must not be rerun blindly. Missing filename matches may indicate naming differences or uninspected containers.\n\n'
report+='## Relevant remaining gates\n\n'
for row in ledger:
 report+=f"- {row['task']} — {row['requirement']}: {row['audit_state']}. Gate: {row['completion_gate']}\n"
report+='\n## Content evidence\n\n'
for h,name,t,partial in TABLES:
 if any(re.search(p,name,re.I) for p in ['source_contract','coverage','A_to_G','remaining','reproduction_status','semantic_definition','validity','damage_retention','baseline_fidelity','holm','primary_hypothesis','primary_paired_family','resource_summary','resource_audit']):
  report+=f'\n### {name} / SHA256 {h}\n\n'+t.head(35).to_csv(index=False)+'\n'
for item in FLAGS:
 if re.search(r'confirm|valid|approved|independent|prospect|zeek|labels_config|packet|original_A_to_G|high_competence|mean_semantic|equal_family_mean_gain|precommitted',item['key'],re.I):
  report+=f"\n- {item['evidence_sha256']} / {item['key']}: {item['value']}"
report+='\n\n## Audit limits\n\n'+json.dumps(ERRORS,indent=2)
(OUT/'KAGGLE_PLAN_AUDIT.md').write_text(report,encoding='utf-8')

receipt={'output_directory':str(OUT),'active_development_base':str(ACTIVE/'development'),
 'reference_plan_sha256':digest(REFERENCE_PLAN.encode()),'filesystem_files_inventoried':len(FILES),
 'archive_indexes_inspected':len(ARCHIVES),'raw_assets_inventoried':len(ASSETS),
 'evidence_locators':len(EVIDENCE),'unique_evidence_contents_retained':len(seen),
 'metadata_bytes_retained':bytes_retained,'tables_content_inspected':len(TABLES),'decision_flags_extracted':len(FLAGS),
 'budget_exhausted':budget_exhausted,'audit_limit_or_error_records':len(ERRORS),
 'model_bundles_loaded':False,'models_trained':False,'predictions_computed':False,
 'attacks_rerun':False,'NF_settings_changed':False,'source_or_packet_validity_auto_approved':False,
 'scientific_completion_determined':False,'requires_review_of_actual_evidence':True,
 'note':'Do not rerun completed experiments. Review evidence and limits to select only the next missing plan-linked task.'}
(OUT/'AUDIT_RECEIPT.json').write_text(json.dumps(receipt,indent=2))

# Create one private review ZIP with actual retained evidence, not datasets/models.
package=WORK/(OUT.name+'_PRIVATE_REVIEW.zip')
if shutil.disk_usage(WORK).free < bytes_retained+128*1024**2:raise RuntimeError('Insufficient space for review ZIP; audit outputs remain saved.')
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(OUT)))
with zipfile.ZipFile(package) as z:
 bad=z.testzip()
 if bad:raise RuntimeError('Review ZIP integrity failure: '+bad)
h=hashlib.sha256()
with package.open('rb') as f:
 for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
package.with_suffix('.zip.sha256').write_text(h.hexdigest()+'  '+package.name+'\n')
receipt.update({'private_review_zip':str(package),'review_zip_bytes':package.stat().st_size,'review_zip_CRC_verified':True,'review_zip_sha256':h.hexdigest()})
(OUT/'PACKAGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
print('\nPLAN TASK LEDGER — CANDIDATE ARTIFACTS ARE NOT AUTOMATIC APPROVAL')
print(pd.DataFrame(ledger)[['group','task','plan_category','distinct_candidate_contents','audit_state']].to_string(index=False))
print('\nCURRENT SOURCE-CONTRACT TABLES')
print(pd.DataFrame(source_rows).to_string(index=False) if source_rows else 'No matching coverage table; review the evidence index.')
print('\nRAW ASSETS BY KIND')
print(pd.DataFrame(ASSETS).groupby('kind').size().to_string() if ASSETS else 'No assets discovered in this audit scope; inspect unexamined archive limits before declaring absent.')
print('\nUPLOAD THE PRIVATE REVIEW ZIP FOR CONTENT-BASED TASK SIGN-OFF.')

# ===== CELL INPUT 24 =====
# NEXT STEP: verify and expose the acquired label rules + exact extractor environment.
# No downloads, model fitting, attack optimization, or broad filesystem re-audit.
import hashlib,json,os,re,shutil,subprocess,zipfile
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd

WORK=Path('/kaggle/working')
ROOT=WORK/'TRACE_LABEL_RECOVERY_20261011T153846517131Z'
if not (ROOT/'publisher_retrieval_receipts.csv').is_file():
 candidates=[p for p in WORK.glob('TRACE_LABEL_RECOVERY_*') if p.is_dir() and (p/'publisher_retrieval_receipts.csv').is_file()]
 if len(candidates)!=1:raise RuntimeError('Set ROOT to the completed TRACE_LABEL_RECOVERY folder; no arbitrary version selected.')
 ROOT=candidates[0]
OUT=WORK/('TRACE_RULE_FORMAT_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(exist_ok=False)

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def write_json(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')

table=pd.read_csv(ROOT/'publisher_retrieval_receipts.csv',keep_default_na=False)
required={'kind','path','sha256','scenario','url_final'}
if not required.issubset(table):raise ValueError('Unexpected publisher receipt columns.')
rules=table[table.kind.eq('publisher_rules')].copy()
if rules.empty:raise RuntimeError('No previously downloaded publisher rules; do not fabricate replacements.')
verified=[];errors=[];unique={}
for _,row in rules.iterrows():
 p=Path(row['path'])
 if not p.is_file():errors.append({'path':str(p),'issue':'FILE_MISSING'});continue
 actual=sha(p)
 if actual!=row['sha256']:errors.append({'path':str(p),'issue':'HASH_MISMATCH'});continue
 if p.stat().st_size>1024**2:errors.append({'path':str(p),'issue':'UNEXPECTED_RULE_SIZE'});continue
 text=p.read_text(encoding='utf-8-sig')
 verified.append({'scenario':row['scenario'],'path':str(p),'sha256':actual,'source_url':row['url_final']})
 unique.setdefault(actual,{'text':text,'scenarios':[],'path':str(p)})['scenarios'].append(row['scenario'])
pd.DataFrame(verified).to_csv(OUT/'verified_rule_sources.csv',index=False)
pd.DataFrame(errors,columns=['path','issue']).to_csv(OUT/'verification_errors.csv',index=False)
if errors:raise RuntimeError('Downloaded rule verification failed; inspect verification_errors.csv. Nothing approved.')

# Preserve actual syntax. Interpretation waits for the real contents; no guessed labeler.
report='# Exact publisher rule contents\n\n'
for h,value in unique.items():
 report+='\n## SHA256 '+h+'\nScenarios: '+', '.join(sorted(value['scenarios']))+'\n\n```text\n'+value['text']+'\n```\n'
(OUT/'ACTUAL_RULE_CONTENTS.md').write_text(report,encoding='utf-8')

binary=shutil.which('zeek') or shutil.which('bro')
if not binary:
 for p in [Path('/opt/zeek/bin/zeek'),Path('/usr/local/zeek/bin/zeek'),Path('/usr/local/bin/zeek')]:
  if p.is_file() and os.access(p,os.X_OK):binary=str(p);break
env={'os_release':Path('/etc/os-release').read_text() if Path('/etc/os-release').exists() else '',
 'architecture':__import__('platform').machine(),'effective_uid':os.geteuid() if hasattr(os,'geteuid') else None,
 'zeek_binary':binary or '', 'zeek_runnable':False,'version_stdout':'','version_stderr':'',
 'apt_get':shutil.which('apt-get') or '', 'dpkg_deb':shutil.which('dpkg-deb') or '',
 'free_working_bytes':shutil.disk_usage(WORK).free}
if binary:
 try:
  version=subprocess.run([binary,'--version'],text=True,capture_output=True,timeout=30)
  env.update({'zeek_runnable':version.returncode==0,'returncode':version.returncode,
   'version_stdout':version.stdout,'version_stderr':version.stderr})
 except Exception as error:env['binary_error']=str(error)
write_json(OUT/'extractor_environment.json',env)

# Only validate the paths already recorded by the completed trace-recovery step.
scenarios=pd.read_csv(ROOT/'scenario_label_evidence.csv',keep_default_na=False)
links=[]
for _,row in scenarios.iterrows():
 for role,col in [('capture','local_capture_paths'),('labeled_log','local_log_paths')]:
  for value in json.loads(row[col]):
   p=Path(value)
   item={'scenario':row['official_scenario'],'role':role,'path':str(p),'exists':p.is_file(),
    'bytes':p.stat().st_size if p.is_file() else None,'header_preview':''}
   if role=='labeled_log' and p.is_file():
    lines=[]
    with p.open('r',encoding='utf-8',errors='replace') as f:
     for i,line in enumerate(f):
      if i>40:break
      if line.startswith(('#separator','#fields','#types')):lines.append(line.rstrip())
      elif not line.startswith('#'):
       lines.append(line.rstrip());break
    item['header_preview']='\n'.join(lines)
   links.append(item)
pd.DataFrame(links).to_csv(OUT/'recorded_trace_paths_and_log_headers.csv',index=False)
receipt={'output_directory':str(OUT),'reused_rule_recovery_directory':str(ROOT),
 'publisher_rule_files_verified':len(verified),'distinct_rule_contents':len(unique),
 'missing_recorded_trace_paths':sum(not r['exists'] for r in links),'zeek_runnable':env['zeek_runnable'],
 'label_semantics_approved':False,'v1_v2_equivalence_approved':False,'clean_replay_completed':False,
 'models_trained':False,'attacks_executed':False,'NF_changed':False,
 'next_step':'Install/validate extractor if needed, interpret actual rules, then clean capture/log mapping.'}
write_json(OUT/'receipt.json',receipt)
package=WORK/(OUT.name+'_PRIVATE_REVIEW.zip')
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(OUT)))
with zipfile.ZipFile(package) as z:
 if z.testzip() is not None:raise RuntimeError('Review archive integrity failure.')
print(json.dumps({**receipt,'private_review_zip':str(package),'review_zip_sha256':sha(package)},indent=2))
print('\nEXTRACTOR ENVIRONMENT\n'+json.dumps(env,indent=2))
print('\nEXACT UNIQUE LABEL RULES')
for h,value in unique.items():
 print('\nSHA256:',h,'SCENARIOS:',', '.join(value['scenarios']));print(value['text'])
print('\nFIRST TWO EXISTING LABELED-LOG HEADERS')
for row in [r for r in links if r['role']=='labeled_log' and r['exists']][:2]:
 print(row['path']);print(row['header_preview'])
print('\nPaste the receipt, environment and rule output. Existing experiments were not rerun.')

# ===== CELL INPUT 25 =====
"""Zeek bootstrap + one clean replay linkage test. No training or attacks.
Official signed APT package; simulation blocks installed-package upgrades/removals.
Smoke capture is selected by file size only, not labels/model outcomes.
Published labels are joined only on unique exact connection keys; never inferred.
"""
import hashlib,json,os,re,shutil,subprocess,time,zipfile
from collections import Counter,defaultdict
from datetime import datetime,timezone
from decimal import Decimal,ROUND_HALF_EVEN
from pathlib import Path
import pandas as pd
import requests

WORK=Path('/kaggle/working')
RECOVERY=WORK/'TRACE_LABEL_RECOVERY_20261011T153846517131Z'
if not (RECOVERY/'scenario_label_evidence.csv').is_file():raise FileNotFoundError(RECOVERY)
OUT=WORK/('TRACE_CLEAN_REPLAY_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(exist_ok=False)
TOOLS=WORK/'trace_tools';TOOLS.mkdir(exist_ok=True)
MAX_REPLAY_SECONDS=900
MAX_REFERENCE_ROWS=1000000
MAX_GENERATED_ROWS=1000000
MIN_FREE_BYTES=2*1024**3
COMMANDS=[]

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def save_json(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def run(cmd,name,cwd=None,timeout=600):
 logfile=OUT/(name+'.log');started=time.monotonic()
 env=os.environ.copy();env['DEBIAN_FRONTEND']='noninteractive'
 try:
  with logfile.open('w') as f:
   result=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,text=True,timeout=timeout,env=env)
  COMMANDS.append({'name':name,'command':cmd,'returncode':result.returncode,'seconds':time.monotonic()-started,'log':str(logfile)})
  if result.returncode:raise RuntimeError(f'{name} failed ({result.returncode}): '+logfile.read_text(errors='replace')[-5000:])
  return logfile.read_text(errors='replace')
 except subprocess.TimeoutExpired:
  COMMANDS.append({'name':name,'command':cmd,'returncode':'TIMEOUT','seconds':time.monotonic()-started,'log':str(logfile)})
  raise RuntimeError(f'{name} timeout; partial logs preserved in {logfile}')

def zeek_path():
 for p in [shutil.which('zeek'),'/opt/zeek/bin/zeek','/usr/local/zeek/bin/zeek']:
  if p and Path(p).is_file() and os.access(p,os.X_OK):return p
 return None

def get_logs(path,cap):
 rows=[];fields=None;total=0;complete=True;bad=0
 with path.open('r',encoding='utf-8',errors='strict') as f:
  for line_number,line in enumerate(f,1):
   if line.startswith('#fields'):
    fields=line.strip().split()[1:];continue
   if line.startswith('#') or not line.strip():continue
   if fields is None:raise ValueError('Missing #fields in '+str(path))
   if total>=cap:complete=False;break
   total+=1
   parts=line.rstrip().split()
   if len(parts)!=len(fields):bad+=1;continue
   row=dict(zip(fields,parts));row['_line']=line_number;rows.append(row)
 return rows,{'records_scanned':total,'complete_file_scanned':complete,'malformed_rows':bad,'fields':fields}

def connection_key(row):
 required=['ts','id.orig_h','id.orig_p','id.resp_h','id.resp_p','proto']
 if any(k not in row for k in required):raise ValueError('Required connection-key field absent.')
 micros=int((Decimal(row['ts'])*Decimal(1000000)).to_integral_value(rounding=ROUND_HALF_EVEN))
 return (micros,row['id.orig_h'],row['id.orig_p'],row['id.resp_h'],row['id.resp_p'],row['proto'].lower())

receipt={'output_directory':str(OUT),'models_trained':False,'attacks_executed':False,'NF_changed':False,
 'confirmatory_scenario_selected':False,'label_rules_applied':False,'packet_validity_approved':False,
 'full_trace_mapping_approved':False,'purpose':'CLEAN_EXTRACTION_SMOKE_AND_EXACT_KEY_MAPPING_ONLY'}
try:
 # Explicitly mark placeholder rule files as unsuitable, without deleting/replacing them.
 sources=pd.read_csv(RECOVERY/'publisher_retrieval_receipts.csv',keep_default_na=False)
 rule_rows=[]
 for _,r in sources[sources.kind.eq('publisher_rules')].iterrows():
  p=Path(r['path'])
  if not p.is_file() or sha(p)!=r['sha256']:raise RuntimeError('Rule source hash mismatch: '+str(p))
  active=[line.split('#',1)[0].strip() for line in p.read_text().splitlines()]
  active=[line for line in active if line]
  placeholders=[line for line in active if re.search(r'xxx\.xxx\.xxx\.xxx|(?:srcPort|dstPort)\s*=\s*xx\b',line,re.I)]
  rule_rows.append({'scenario':r['scenario'],'source_sha256':r['sha256'],'active_placeholder_lines':len(placeholders),
   'status':'PLACEHOLDER_TEMPLATE_NOT_APPLICABLE' if placeholders else 'CONCRETE_RULES_REQUIRE_FIDELITY_REVIEW',
   'rules_verified_against_local_labels':False})
 pd.DataFrame(rule_rows).to_csv(OUT/'rule_applicability.csv',index=False)

 binary=zeek_path()
 if binary is None:
  release={}
  for line in Path('/etc/os-release').read_text().splitlines():
   if '=' in line:
    k,v=line.split('=',1);release[k]=v.strip('"')
  if release.get('ID')!='ubuntu' or release.get('VERSION_ID')!='24.04':raise RuntimeError('This verified installer is for the reported Ubuntu 24.04 environment only.')
  if os.geteuid()!=0:raise RuntimeError('Root privileges required for official package installation.')
  if not shutil.which('gpg'):raise RuntimeError('gpg missing; signed-repository bootstrap cannot proceed safely.')
  if shutil.disk_usage(WORK).free<MIN_FREE_BYTES:raise RuntimeError('Less than 2 GiB free before installation.')
  base='https://download.opensuse.org/repositories/security:/zeek/xUbuntu_24.04/'
  response=requests.get(base+'Release.key',timeout=(20,90));response.raise_for_status()
  keyfile=TOOLS/'zeek_OBS_Release.key';keyfile.write_bytes(response.content)
  keyring=TOOLS/'zeek_OBS_keyring.gpg'
  run(['gpg','--batch','--yes','--dearmor','--output',str(keyring),str(keyfile)],'repository_key')
  key_info=run(['gpg','--show-keys','--with-colons',str(keyring)],'repository_fingerprints')
  # Repo trust is scoped to this source list, not installed as a global trust key.
  sourcelist=TOOLS/'zeek_sources.list'
  existing=Path('/etc/apt/sources.list').read_text() if Path('/etc/apt/sources.list').is_file() else ''
  sourcelist.write_text(existing+'\n'+f'deb [signed-by={keyring}] {base} /\n')
  opts=['-o',f'Dir::Etc::sourcelist={sourcelist}','-o','Dir::Etc::sourceparts=/etc/apt/sources.list.d']
  run(['apt-get',*opts,'update'],'apt_update',timeout=900)
  policy=run(['apt-cache',*opts,'policy','zeek-8.0'],'zeek_package_candidate')
  match=re.search(r'Candidate:\s*(\S+)',policy)
  if not match or match.group(1)=='(none)':raise RuntimeError('Official zeek-8.0 package candidate unavailable; no unpinned fallback used.')
  version=match.group(1);package='zeek-8.0='+version
  simulated=run(['apt-get',*opts,'--simulate','--no-install-recommends','install',package],'apt_simulation')
  if re.search(r'^Remv\s|^Inst\s+\S+\s+\[',simulated,re.M):raise RuntimeError('Installation would remove/upgrade an existing package; stopped to preserve environment.')
  save_json(OUT/'installation_lock.json',{'repository':base,'key_sha256':sha(keyfile),'key_fingerprints':key_info,
   'package':package,'existing_package_upgrades_allowed':False})
  run(['apt-get',*opts,'-y','--no-install-recommends','--no-upgrade','install',package],'apt_install',timeout=1800)
  binary=zeek_path()
  if not binary:raise RuntimeError('Package installed but Zeek executable not located.')
 version=run([binary,'--version'],'zeek_version',timeout=30).strip()
 receipt.update({'zeek_binary':binary,'zeek_version':version,'zeek_runnable':True})

 # Pick smallest one-PCAP / one-labelled-log entry: a mapping pilot, never a primary selection.
 scenarios=pd.read_csv(RECOVERY/'scenario_label_evidence.csv',keep_default_na=False)
 eligible=[]
 for _,r in scenarios.iterrows():
  caps=[Path(p) for p in json.loads(r['local_capture_paths'])]
  logs=[Path(p) for p in json.loads(r['local_log_paths'])]
  if len(caps)==1 and len(logs)==1 and caps[0].is_file() and logs[0].is_file():
   eligible.append((caps[0].stat().st_size,r['official_scenario'],caps[0],logs[0]))
 if not eligible:raise RuntimeError('No unambiguous local one-capture/one-log mapping pilot; no arbitrary merge performed.')
 _,name,capture,reference=min(eligible,key=lambda x:(x[0],x[1],str(x[2])))
 replay_dir=OUT/'clean_replay';replay_dir.mkdir()
 save_json(OUT/'smoke_selection.json',{'scenario':name,'capture':str(capture),'reference':str(reference),
  'selection_rule':'SMALLEST_CAPTURE_BYTES_AMONG_ONE_CAPTURE_ONE_LOG; NO LABEL_OR_MODEL_OUTCOME_SELECTION',
  'confirmatory_selection':False,'pcap_sha256':sha(capture),'reference_log_sha256':sha(reference),
  'checksum_policy':'-C: ignore checksum errors for capture/offload compatibility; NOT a packet-validity approval'})
 print('REPLAYING:',name,'CAPTURE BYTES:',capture.stat().st_size,flush=True)
 run([binary,'-C','-r',str(capture)],'zeek_clean_replay',cwd=replay_dir,timeout=MAX_REPLAY_SECONDS)
 generated=replay_dir/'conn.log'
 if not generated.is_file():raise RuntimeError('Zeek finished without conn.log; see replay log.')
 target,ref_info=get_logs(reference,MAX_REFERENCE_ROWS)
 reproduced,gen_info=get_logs(generated,MAX_GENERATED_ROWS)
 if ref_info['malformed_rows'] or gen_info['malformed_rows']:raise RuntimeError('Malformed log rows; parser must be repaired before mapping.')
 lookup=defaultdict(list);invalid_ref=0
 for row in target:
  try:lookup[connection_key(row)].append(row)
  except Exception:invalid_ref+=1
 gen_counts=Counter();invalid_generated=0
 for row in reproduced:
  try:gen_counts[connection_key(row)]+=1
  except Exception:invalid_generated+=1
 mapped=[];unmatched=0;ambiguous=0;field_diff=Counter()
 for row in reproduced:
  try:k=connection_key(row)
  except Exception:continue
  found=lookup.get(k,[])
  if not found:unmatched+=1;continue
  if len(found)!=1 or gen_counts[k]!=1:ambiguous+=1;continue
  supplied=found[0];label=supplied.get('label','')
  if not label:raise RuntimeError('Supplied label column absent; detailed-label is not used as a replacement.')
  item={'timestamp_microseconds':k[0],'orig_h':k[1],'orig_p':k[2],'resp_h':k[3],'resp_p':k[4],'proto':k[5],
   'generated_line':row['_line'],'reference_line':supplied['_line'],'published_label':label,
   'published_detailed_label':supplied.get('detailed-label',''),'generated_uid':row.get('uid',''),
   'reference_uid':supplied.get('uid','')}
  for f in ['duration','orig_bytes','resp_bytes','orig_pkts','resp_pkts','conn_state','service','missed_bytes']:
   if f in row and f in supplied:
    item[f+'_generated']=row[f];item[f+'_reference']=supplied[f]
    if row[f]!=supplied[f]:field_diff[f]+=1
  mapped.append(item)
 pd.DataFrame(mapped).to_csv(OUT/'unique_exact_key_mapping.csv',index=False)
 receipt.update({'status':'CLEAN_REPLAY_AND_MAPPING_SMOKE_COMPUTED','scenario':name,
  'reference_scan':ref_info,'generated_scan':gen_info,'unique_exact_key_matches':len(mapped),
  'unmatched_generated_rows':unmatched,'ambiguous_generated_rows':ambiguous,
  'invalid_reference_keys':invalid_ref,'invalid_generated_keys':invalid_generated,
  'match_fraction_of_parsed_generated_rows':len(mapped)/len(reproduced) if reproduced else None,
  'mapped_field_string_differences':dict(field_diff),
  'placeholder_rule_scenarios':sum(r['active_placeholder_lines']>0 for r in rule_rows),
  'concrete_rule_scenarios_pending_review':sum(r['active_placeholder_lines']==0 for r in rule_rows),
  'label_semantics_approved':False,'full_trace_mapping_approved':False,
  'next_step':'Review mapping completeness, version differences and actual labels. Then resolve eligible scenarios; no training yet.'})
except Exception as error:
 receipt.update({'status':'BLOCKED_WITH_EXPLICIT_CAUSE','error':f'{type(error).__name__}: {error}',
  'next_step':'Resolve this exact recorded error; do not repeat completed development experiments.'})
finally:
 save_json(OUT/'command_receipts.json',COMMANDS);save_json(OUT/'receipt.json',receipt)
 print('\nSTEP RECEIPT\n'+json.dumps(receipt,indent=2))
 if (OUT/'rule_applicability.csv').is_file():
  print('\nLABEL-RULE APPLICABILITY');print(pd.read_csv(OUT/'rule_applicability.csv').to_string(index=False))
 # Small review package excludes PCAPs and full generated connection logs.
 package=WORK/(OUT.name+'_PRIVATE_REVIEW.zip')
 with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
  for p in OUT.iterdir():
   if p.is_file() and p.stat().st_size<=32*1024**2:z.write(p,p.name)
 with zipfile.ZipFile(package) as z:
  if z.testzip() is not None:raise RuntimeError('Review ZIP integrity failure.')
 print('\nPRIVATE REVIEW ZIP:',package,'SHA256:',sha(package))
 print('Paste STEP RECEIPT; if blocked, also paste the failed-command log tail.')

# ===== CELL INPUT 26 =====
"""Reuse completed clean replay: full-field fidelity + concrete rule applicability.
No Zeek rerun, model fitting, label replacement, attack, or outcome-driven selection.
Rule evaluation is a documented equality-only diagnostic, not certified publisher-tool reproduction.
"""
import hashlib,json,re,zipfile
from collections import Counter,defaultdict
from datetime import datetime,timezone
from decimal import Decimal,InvalidOperation,ROUND_HALF_EVEN
from pathlib import Path
import pandas as pd

ROOT=Path('/kaggle/working/TRACE_CLEAN_REPLAY_20261011T161846072286Z')
RECOVERY=Path('/kaggle/working/TRACE_LABEL_RECOVERY_20261011T153846517131Z')
WORK=Path('/kaggle/working')
OUT=WORK/('TRACE_LABEL_FIDELITY_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(exist_ok=False)

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def save_json(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
def read_log(p):
 fields=None;rows=[]
 with p.open('r',encoding='utf-8') as f:
  for lineno,line in enumerate(f,1):
   if line.startswith('#fields'):
    fields=line.strip().split()[1:];continue
   if line.startswith('#') or not line.strip():continue
   if fields is None:raise ValueError('Missing #fields: '+str(p))
   values=line.rstrip().split()
   if len(values)!=len(fields):raise ValueError(f'Field count mismatch: {p}:{lineno}')
   row=dict(zip(fields,values));row['_line']=lineno;rows.append(row)
 return fields,rows

def key(row):
 ts=int((Decimal(row['ts'])*Decimal(1000000)).to_integral_value(rounding=ROUND_HALF_EVEN))
 return (ts,row['id.orig_h'],row['id.orig_p'],row['id.resp_h'],row['id.resp_p'],row['proto'].lower())
def typed_equal(name,a,b):
 numeric={'ts','duration','orig_bytes','resp_bytes','orig_pkts','resp_pkts','orig_ip_bytes','resp_ip_bytes','missed_bytes','id.orig_p','id.resp_p'}
 if name in numeric and a!='-' and b!='-':
  try:return Decimal(a)==Decimal(b)
  except InvalidOperation:return False
 return a==b

selection=json.loads((ROOT/'smoke_selection.json').read_text())
receipt0=json.loads((ROOT/'receipt.json').read_text())
if receipt0.get('status')!='CLEAN_REPLAY_AND_MAPPING_SMOKE_COMPUTED':raise RuntimeError('Previous clean replay is not complete.')
reference=Path(selection['reference']);capture=Path(selection['capture']);generated=ROOT/'clean_replay/conn.log'
if not reference.is_file() or sha(reference)!=selection['reference_log_sha256']:raise RuntimeError('Reference log changed.')
if not generated.is_file():raise FileNotFoundError(generated)
ref_fields,ref=read_log(reference);gen_fields,gen=read_log(generated)
ref_map=defaultdict(list);gen_counts=Counter(key(r) for r in gen)
for r in ref:ref_map[key(r)].append(r)
if len(ref)!=receipt0['reference_scan']['records_scanned'] or len(gen)!=receipt0['generated_scan']['records_scanned']:raise RuntimeError('Log record counts changed.')

common=[f for f in ref_fields if f in gen_fields and f not in {'uid','label','detailed-label'}]
counts={f:{'string_differences':0,'typed_differences':0} for f in common}
examples=[];pairs=[]
for g in gen:
 found=ref_map.get(key(g),[])
 if len(found)!=1 or gen_counts[key(g)]!=1:raise RuntimeError('Exact key is unmatched or ambiguous; do not transfer labels.')
 r=found[0];pairs.append((r,g))
 for field in common:
  if r[field]!=g[field]:counts[field]['string_differences']+=1
  if not typed_equal(field,r[field],g[field]):
   counts[field]['typed_differences']+=1
   if len([x for x in examples if x['field']==field])<5:
    examples.append({'field':field,'reference_line':r['_line'],'generated_line':g['_line'],'published_value':r[field],'replayed_value':g[field]})
pd.DataFrame([{'field':f,'records':len(pairs),**v} for f,v in counts.items()]).to_csv(OUT/'all_shared_field_fidelity.csv',index=False)
pd.DataFrame(examples).to_csv(OUT/'field_difference_examples.csv',index=False)

sources=pd.read_csv(RECOVERY/'publisher_retrieval_receipts.csv',keep_default_na=False)
rows=sources[(sources.kind=='publisher_rules')&(sources.scenario==selection['scenario'])]
if len(rows)!=1:raise RuntimeError('Exactly one publisher rule file required for this replayed scenario.')
source=rows.iloc[0];rule_path=Path(source['path'])
if not rule_path.is_file() or sha(rule_path)!=source['sha256']:raise RuntimeError('Publisher rule checksum mismatch.')
rule_text=rule_path.read_text()
active=[s.split('#',1)[0].strip() for s in rule_text.splitlines()]
active=[s for s in active if s]
if any(re.search(r'xxx\.xxx\.xxx\.xxx|(?:srcPort|dstPort)\s*=\s*xx\b',s,re.I) for s in active):raise RuntimeError('Placeholder template cannot be applied.')
field_map={'srcIP':'id.orig_h','dstIP':'id.resp_h','srcPort':'id.orig_p','dstPort':'id.resp_p','Proto':'proto'}
rules=[];current=None
for line in active:
 if not line.startswith('-'):
  if not line.endswith(':') or line.endswith('::'):raise RuntimeError('Unsupported heading syntax; no silent rule repair: '+line)
  heading=line[:-1].strip();parts=heading.split(',',1);binary=parts[0].strip()
  if binary not in {'Background','Benign','Malicious'}:raise RuntimeError('Unsupported label: '+heading)
  current={'generic':binary,'detail':parts[1].strip() if len(parts)>1 else ''};continue
 if current is None:raise RuntimeError('Rule has no label heading.')
 terms=[]
 for atom in line[1:].strip().split('&'):
  match=re.fullmatch(r'\s*([A-Za-z]+)\s*=\s*([^\s&]+)\s*',atom)
  if not match or match.group(1) not in field_map:raise RuntimeError('Unsupported rule term; no guessed semantics: '+atom)
  terms.append((match.group(1),match.group(2)))
 rules.append({**current,'conditions':terms})
save_json(OUT/'parsed_concrete_rules.json',{'source_sha256':source['sha256'],'source_url':source['url_final'],
 'semantics':'AND terms; OR lines; sequential last-match overwrites, as stated in downloaded file; equality only; protocol case-insensitive',
 'published_tool_fidelity_verified':False,'rules':rules})

def evaluate(row):
 assigned='UNMATCHED';detail='';winner=None;hits=0
 for number,rule in enumerate(rules):
  ok=True
  for field,value in rule['conditions']:
   actual=row[field_map[field]]
   if value.lower()=='all':continue
   if field=='Proto':equal=actual.lower()==value.lower()
   elif field in {'srcPort','dstPort'}:
    try:equal=int(actual)==int(value)
    except ValueError:equal=False
   else:equal=actual==value
   if not equal:ok=False;break
  if ok:assigned=rule['generic'];detail=rule['detail'];winner=number;hits+=1
 return assigned,detail,winner,hits

comparison=[];confusion=Counter();prediction_invariance=0;published_counts=Counter();unrecognized=0
linked=[]
for r,g in pairs:
 published=r.get('label','').strip().lower()
 if published not in {'benign','malicious'}:unrecognized+=1
 published_counts[published]+=1
 rp,rd,rule_number,hit_count=evaluate(r);gp,gd,grule,ghits=evaluate(g)
 agree=rp.lower()==published;confusion[(published,rp.lower())]+=1
 if (rp,rd)!=(gp,gd):prediction_invariance+=1
 comparison.append({'reference_line':r['_line'],'generated_line':g['_line'],'published_label':r.get('label',''),
  'published_detailed_label':r.get('detailed-label',''),'rule_predicted_generic':rp,'rule_predicted_detail':rd,
  'binary_agrees':agree,'winning_rule':rule_number,'matched_rule_count':hit_count,
  'same_rule_result_on_reextracted_fields':(rp,rd)==(gp,gd)})
 # Keep supplied labels, never replace them with rule predictions.
 linked.append({**{f:g[f] for f in gen_fields},'published_label':r.get('label',''),
  'published_detailed_label':r.get('detailed-label',''),'reference_line':r['_line'],'generated_line':g['_line'],
  'source_scenario':selection['scenario'],'source_pcap_sha256':selection['pcap_sha256'],
  'reference_log_sha256':selection['reference_log_sha256'],'replayed_log_sha256':sha(generated) if not linked else linked[0]['replayed_log_sha256']})
pd.DataFrame(comparison).to_csv(OUT/'rule_vs_published_labels.csv',index=False)
pd.DataFrame([{'published_label':k[0],'rule_predicted_generic':k[1],'records':v} for k,v in sorted(confusion.items())]).to_csv(OUT/'rule_binary_confusion.csv',index=False)
pd.DataFrame(linked).to_csv(OUT/'trace_linked_published_label_records.csv',index=False)
agreements=sum(x['binary_agrees'] for x in comparison)
receipt={'output_directory':str(OUT),'scenario':selection['scenario'],'rows':len(pairs),
 'all_unique_exact_keys_verified':True,'shared_fields_checked':len(common),
 'typed_field_difference_counts':{f:v['typed_differences'] for f,v in counts.items() if v['typed_differences']},
 'published_binary_label_counts':dict(published_counts),'unsupported_published_label_rows':unrecognized,
 'concrete_rules_evaluated':len(rules),'binary_rule_agreements':agreements,'binary_rule_disagreements':len(pairs)-agreements,
 'binary_rule_agreement_fraction':agreements/len(pairs) if pairs else None,
 'rule_result_changes_on_reextracted_fields':prediction_invariance,'published_labels_replaced':False,
 'publisher_tool_fidelity_verified':False,'label_semantics_final_approved':False,
 'packet_validity_approved':False,'confirmatory_scenario_selected':False,'models_trained':False,'attacks_executed':False,
 'clean_replay_repeated':False,'NF_changed':False,
 'next_step':'Review binary-rule disagreements and service/version differences; then expand linkage to remaining predetermined concrete-rule scenarios, with no target performance selection.'}
save_json(OUT/'receipt.json',receipt)
package=WORK/(OUT.name+'_PRIVATE_REVIEW.zip')
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.iterdir()):
  if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(package) as z:
 if z.testzip() is not None:raise RuntimeError('Review ZIP integrity failure.')
print(json.dumps({**receipt,'private_review_zip':str(package),'review_zip_sha256':sha(package)},indent=2))
print('\nALL SHARED FIELD FIDELITY');print(pd.read_csv(OUT/'all_shared_field_fidelity.csv').to_string(index=False))
print('\nBINARY RULE / PUBLISHED LABEL CONFUSION');print(pd.read_csv(OUT/'rule_binary_confusion.csv').to_string(index=False))
print('\nFIRST LABEL DISAGREEMENTS');print(pd.DataFrame([r for r in comparison if not r['binary_agrees']]).head(15).to_string(index=False))
print('\nSERVICE DIFFERENCE EXAMPLES');print(pd.DataFrame([e for e in examples if e['field']=='service']).to_string(index=False))

# ===== CELL INPUT 27 =====
"""Resumable full-log linkage expansion for all five concrete-rule scenarios.
Streaming SQLite joins avoid loading giant connection logs into RAM.
No models, attacks, label replacement, or outcome-driven scenario selection.
Capture 8 replay is reused. Every listed candidate for other scenarios is assessed separately.
"""
import csv,hashlib,json,os,re,shutil,sqlite3,subprocess
from collections import Counter
from datetime import datetime,timezone
from decimal import Decimal,ROUND_HALF_EVEN,InvalidOperation
from pathlib import Path
import pandas as pd

WORK=Path('/kaggle/working')
SRC=WORK/'TRACE_LABEL_RECOVERY_20261011T153846517131Z'
PILOT=WORK/'TRACE_CLEAN_REPLAY_20261011T161846072286Z'
OUT=WORK/'TRACE_LINKAGE_BATCH_v1';OUT.mkdir(exist_ok=True)
ZEEK='/opt/zeek/bin/zeek'
SCENARIOS=['CTU-IoT-Malware-Capture-1-1','CTU-IoT-Malware-Capture-3-1','CTU-IoT-Malware-Capture-7-1','CTU-IoT-Malware-Capture-8-1','CTU-IoT-Malware-Capture-9-1']
PREDICTORS=['duration','orig_bytes','resp_bytes','orig_pkts','resp_pkts','orig_ip_bytes','resp_ip_bytes','missed_bytes','proto','conn_state','history']
NUMERIC=set(PREDICTORS[:8])
EXCLUDED=['uid','service','local_orig','local_resp','tunnel_parents','ip_proto','id.orig_h','id.resp_h','id.orig_p','id.resp_p','ts']
MAX_REPLAY_SECONDS=1800
BATCH=5000

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def key(row):
 micros=int((Decimal(row['ts'])*1000000).to_integral_value(rounding=ROUND_HALF_EVEN))
 return json.dumps([micros,row['id.orig_h'],row['id.orig_p'],row['id.resp_h'],row['id.resp_p'],row['proto'].lower()],separators=(',',':'))
def stream(p):
 fields=None
 with p.open('r',encoding='utf-8') as f:
  for number,line in enumerate(f,1):
   if line.startswith('#fields'):
    fields=line.strip().split()[1:];continue
   if line.startswith('#') or not line.strip():continue
   if fields is None:raise ValueError('Missing Zeek schema: '+str(p))
   values=line.strip().split()
   if len(values)!=len(fields):raise ValueError(f'Malformed log row: {p}:{number}')
   row=dict(zip(fields,values));row['_line']=number;yield row

def equal(field,a,b):
 if field in NUMERIC and a!='-' and b!='-':
  try:return Decimal(a)==Decimal(b)
  except InvalidOperation:return False
 return a==b

def parse_rules(text):
 rules=[];head=None;warnings=[]
 mapping={'srcIP':'id.orig_h','dstIP':'id.resp_h','srcPort':'id.orig_p','dstPort':'id.resp_p','Proto':'proto'}
 for number,line in enumerate(text.splitlines(),1):
  line=line.split('#',1)[0].strip()
  if not line:continue
  if re.search(r'xxx\.xxx\.xxx\.xxx|(?:srcPort|dstPort)\s*=\s*xx\b',line,re.I):raise ValueError('Placeholder rule refused.')
  if not line.startswith('-'):
   match=re.fullmatch(r'(Background|Benign|Malicious)(?:,\s*([^:]+?))?\s*:*',line)
   if not match:raise ValueError('Unsupported label heading: '+line)
   if not line.endswith(':') or line.endswith('::'):
    warnings.append({'line':number,'source_text':line,'issue':'NONCANONICAL_HEADING_INTERPRETED_DIAGNOSTICALLY; publisher-parser fidelity not approved'})
   head=(match.group(1),(match.group(2)or'').strip());continue
  if head is None:raise ValueError('Rule without heading.')
  terms=[]
  for atom in line[1:].split('&'):
   m=re.fullmatch(r'\s*([A-Za-z]+)\s*=\s*([^\s&]+)\s*',atom)
   if not m or m.group(1)not in mapping:raise ValueError('Unsupported rule expression: '+atom)
   terms.append((m.group(1),m.group(2)))
  rules.append((head,terms))
 return rules,warnings,mapping

def infer(row,rules,mapping):
 label='UNMATCHED'
 for head,terms in rules:
  good=True
  for field,value in terms:
   actual=row[mapping[field]]
   if value.lower()=='all':continue
   if field=='Proto':ok=actual.lower()==value.lower()
   elif field in {'srcPort','dstPort'}:
    try:ok=int(actual)==int(value)
    except ValueError:ok=False
   else:ok=actual==value
   if not ok:good=False;break
  if good:label=head[0].lower()
 return label

version=subprocess.run([ZEEK,'--version'],capture_output=True,text=True,timeout=30)
if version.returncode:raise RuntimeError('Previously installed Zeek is not runnable.')
policy={'scenarios':SCENARIOS,'candidate_predictors':PREDICTORS,'excluded_or_metadata_only':EXCLUDED,
 'selection':'All five prelisted concrete-rule scenarios; every recorded PCAP candidate assessed separately, no merging and no target performance selection.',
 'checksum_policy':'Ignore capture checksums (-C), not packet-validity certification',
 'zeek_version':version.stdout.strip() or version.stderr.strip(),
 'label_source':'Supplied expert labels attached only to unique exact-key matches. Rule results remain a separate diagnostic.',
 'publisher_tool_fidelity_verified':False}
lock=OUT/'batch_policy.json'
if lock.exists() and json.loads(lock.read_text())!=policy:raise RuntimeError('Existing batch policy differs; do not mix versions.')
if not lock.exists():dump(lock,policy)
scenarios=pd.read_csv(SRC/'scenario_label_evidence.csv',keep_default_na=False)
source=pd.read_csv(SRC/'publisher_retrieval_receipts.csv',keep_default_na=False)
results=[];failures=[];rule_results=[]

for name in SCENARIOS:
 try:
  matches=scenarios[scenarios.official_scenario.eq(name)]
  if len(matches)!=1:raise ValueError('Ambiguous/missing recorded scenario.')
  row=matches.iloc[0];refs=[Path(x)for x in json.loads(row['local_log_paths'])]
  caps=[Path(x)for x in json.loads(row['local_capture_paths'])]
  if len(refs)!=1 or not refs[0].is_file():raise ValueError('Exactly one supplied labelled log required.')
  reference=refs[0];rp=source[(source.scenario==name)&(source.kind=='publisher_rules')]
  if len(rp)!=1:raise ValueError('Exactly one publisher rule source required.')
  rp=rp.iloc[0];rulefile=Path(rp['path'])
  if sha(rulefile)!=rp['sha256']:raise ValueError('Rule source changed.')
  rules,warnings,mapping=parse_rules(rulefile.read_text())
  scenario_dir=OUT/name;scenario_dir.mkdir(exist_ok=True)
  dump(scenario_dir/'rule_interpretation.json',{'source_sha256':rp['sha256'],'heading_warnings':warnings,
    'rule_count':len(rules),'publisher_tool_fidelity_verified':False,'diagnostic_only':True})
  ref_sha=sha(reference);dbfile=scenario_dir/'reference_keys.sqlite'
  db_receipt=scenario_dir/'reference_index_receipt.json'
  cached=None
  if dbfile.exists() and db_receipt.exists():
   cached=json.loads(db_receipt.read_text())
   if cached.get('reference_sha256')!=ref_sha or not cached.get('complete'):raise ValueError('Reference index invalid; do not reuse.')
  elif dbfile.exists():raise ValueError('Incomplete reference index present; preserve it and report this blocker.')
  conn=sqlite3.connect(dbfile);conn.execute('PRAGMA temp_store=FILE');conn.execute('PRAGMA synchronous=NORMAL')
  if cached is None:
   conn.execute('CREATE TABLE ref(k TEXT PRIMARY KEY,n INTEGER,payload TEXT)')
   pending=[];counts=Counter();confusion=Counter();total=0
   for r in stream(reference):
    if 'label'not in r:raise ValueError('Primary label field missing; do not substitute detailed-label.')
    observed=r['label'].lower();pred=infer(r,rules,mapping)
    counts[observed]+=1;confusion[(observed,pred)]+=1;total+=1
    pending.append((key(r),1,json.dumps(r,separators=(',',':'))))
    if len(pending)>=BATCH:
     conn.executemany('INSERT INTO ref VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=n+1',pending);conn.commit();pending=[]
     if total%250000==0:print(name,'REFERENCE ROWS',total,flush=True)
     if shutil.disk_usage(WORK).free<1024**3:raise RuntimeError('Free disk below 1 GiB; stopped before exhausting storage.')
   if pending:conn.executemany('INSERT INTO ref VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=n+1',pending);conn.commit()
   cached={'reference_sha256':ref_sha,'complete':True,'rows':total,'published_labels':dict(counts),
    'rule_agreement':sum(v for (a,b),v in confusion.items()if a==b),'confusion':[{'published':a,'rule':b,'records':v}for (a,b),v in confusion.items()]}
   dump(db_receipt,cached)
  rule_results.append({'scenario':name,'reference_rows':cached['rows'],'rule_agreements':cached['rule_agreement'],
   'rule_agreement_fraction':cached['rule_agreement']/cached['rows'] if cached['rows'] else None,
   'noncanonical_rule_headers':len(warnings),'published_label_counts':json.dumps(cached['published_labels'])})
  pd.DataFrame(cached['confusion']).to_csv(scenario_dir/'rule_binary_confusion.csv',index=False)

  for capture in sorted(caps,key=lambda p:(p.stat().st_size if p.exists()else float('inf'),str(p))):
   try:
    if not capture.is_file():raise FileNotFoundError(capture)
    cap_sha=sha(capture);job=scenario_dir/cap_sha[:20];job.mkdir(exist_ok=True)
    completed=job/'candidate_receipt.json'
    if completed.exists():
     previous=json.loads(completed.read_text())
     if previous.get('reference_sha256')!=ref_sha or previous.get('pcap_sha256')!=cap_sha:raise ValueError('Cached job input mismatch.')
     if previous.get('status')=='FULL_LOG_LINKAGE_COMPUTED':results.append(previous);print(name,capture.name,'REUSED',flush=True);continue
    pilot=json.loads((PILOT/'smoke_selection.json').read_text())
    if cap_sha==pilot['pcap_sha256'] and ref_sha==pilot['reference_log_sha256']:
     generated=PILOT/'clean_replay/conn.log';reused=True
    else:
     existing_done=job/'extraction_complete.json';replaydir=job/'replay';replaydir.mkdir(exist_ok=True)
     generated=replaydir/'conn.log';reused=existing_done.exists()
     if reused:
      info=json.loads(existing_done.read_text())
      if not generated.is_file() or sha(generated)!=info['conn_log_sha256']:raise ValueError('Saved extracted log changed.')
     else:
      print('EXTRACTING',name,capture.name,capture.stat().st_size,'bytes',flush=True)
      with (job/'zeek.log').open('w')as log:
       try:r=subprocess.run([ZEEK,'-C','-r',str(capture)],cwd=replaydir,stdout=log,stderr=subprocess.STDOUT,timeout=MAX_REPLAY_SECONDS)
       except subprocess.TimeoutExpired:raise RuntimeError('Zeek timeout; partial logs preserved, no completion claimed.')
      if r.returncode or not generated.is_file():raise RuntimeError('Zeek failed; inspect '+str(job/'zeek.log'))
      dump(existing_done,{'pcap_sha256':cap_sha,'conn_log_sha256':sha(generated),'zeek_version':policy['zeek_version']})
    # Per-candidate generated-key table is disk-backed; references are never merged or relabelled.
    conn.execute('DROP TABLE IF EXISTS gen');conn.execute('CREATE TABLE gen(k TEXT PRIMARY KEY,n INTEGER,payload TEXT)')
    pending=[];genrows=0
    for g in stream(generated):
     pending.append((key(g),1,json.dumps(g,separators=(',',':'))));genrows+=1
     if len(pending)>=BATCH:
      conn.executemany('INSERT INTO gen VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=n+1',pending);conn.commit();pending=[]
    if pending:conn.executemany('INSERT INTO gen VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=n+1',pending);conn.commit()
    matched=0;diff=Counter();new_labels=Counter();rule_invariance=0
    fields=PREDICTORS+['published_label','published_detailed_label','reference_line','generated_line','source_scenario','pcap_sha256','reference_log_sha256']
    with (job/'linked_records.csv').open('w',newline='')as f:
     writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
     for rp0,gp0 in conn.execute('SELECT ref.payload,gen.payload FROM ref JOIN gen USING(k) WHERE ref.n=1 AND gen.n=1'):
      ref=json.loads(rp0);g=json.loads(gp0);matched+=1
      for feature in PREDICTORS:
       if feature not in ref or feature not in g:raise ValueError('Candidate predictor absent: '+feature)
       if not equal(feature,ref[feature],g[feature]):diff[feature]+=1
      if infer(ref,rules,mapping)!=infer(g,rules,mapping):rule_invariance+=1
      label=ref['label'];new_labels[label.lower()]+=1
      writer.writerow({**{feature:g[feature]for feature in PREDICTORS},'published_label':label,
       'published_detailed_label':ref.get('detailed-label',''),'reference_line':ref['_line'],'generated_line':g['_line'],
       'source_scenario':name,'pcap_sha256':cap_sha,'reference_log_sha256':ref_sha})
    ambiguous=conn.execute('SELECT COALESCE(SUM(gen.n),0) FROM gen JOIN ref USING(k) WHERE gen.n>1 OR ref.n>1').fetchone()[0]
    unmatched=conn.execute('SELECT COALESCE(SUM(gen.n),0) FROM gen LEFT JOIN ref USING(k) WHERE ref.k IS NULL').fetchone()[0]
    detail={'status':'FULL_LOG_LINKAGE_COMPUTED','scenario':name,'capture':str(capture),'pcap_sha256':cap_sha,
     'reference_sha256':ref_sha,'generated_log_sha256':sha(generated),'reference_rows':cached['rows'],'generated_rows':genrows,
     'unique_exact_key_matches':matched,'unmatched_generated_rows':unmatched,'ambiguous_generated_rows':ambiguous,
     'full_reference_coverage':matched==cached['rows'],'full_generated_coverage':matched==genrows,
     'predictor_difference_counts':dict(diff),'mapped_published_label_counts':dict(new_labels),
     'rule_result_changes_on_reextracted_fields':rule_invariance,'extraction_reused':reused,
     'linked_records_path':str(job/'linked_records.csv'),'linked_records_sha256':sha(job/'linked_records.csv'),
     'source_rule_sha256':rp['sha256'],'publisher_tool_fidelity_verified':False,
     'confirmatory_scenario_selected':False,'packet_validity_approved':False}
    dump(completed,detail);results.append(detail)
    print(name,capture.name,'MATCHES',matched,'/',genrows,'REFERENCE',cached['rows'],'DIFFERENCES',dict(diff),flush=True)
   except Exception as error:failures.append({'scenario':name,'capture':str(capture),'error':f'{type(error).__name__}: {error}'})
  conn.execute('DROP TABLE IF EXISTS gen');conn.commit();conn.close()
 except Exception as error:failures.append({'scenario':name,'capture':'REFERENCE_OR_RULES','error':f'{type(error).__name__}: {error}'})
 pd.DataFrame(results).to_csv(OUT/'candidate_linkage_summary.csv',index=False)
 pd.DataFrame(rule_results).to_csv(OUT/'scenario_rule_agreement.csv',index=False)
 pd.DataFrame(failures,columns=['scenario','capture','error']).to_csv(OUT/'explicit_failures.csv',index=False)

summary=[]
for name in SCENARIOS:
 candidates=[r for r in results if r['scenario']==name]
 complete=[r for r in candidates if r['full_reference_coverage'] and r['full_generated_coverage'] and not r['predictor_difference_counts']]
 rr=[r for r in rule_results if r['scenario']==name]
 summary.append({'scenario':name,'candidate_captures_assessed':len(candidates),'full_bijection_predictor_fidelity_candidates':len(complete),
  'rule_agreement_fraction':rr[0]['rule_agreement_fraction'] if rr else None,
  'status':'ONE_FULL_LINKAGE_CANDIDATE_FOR_REVIEW' if len(complete)==1 else ('MULTIPLE_FULL_CANDIDATES_REVIEW_DUPLICATION' if len(complete)>1 else 'NO_FULL_FIDELITY_CANDIDATE_YET'),
  'scientific_approval_automatic':False})
pd.DataFrame(summary).to_csv(OUT/'scenario_gate_summary.csv',index=False)
receipt={'output_directory':str(OUT),'planned_concrete_rule_scenarios':len(SCENARIOS),'candidate_linkages_computed_or_reused':len(results),
 'explicit_failures':len(failures),'source_labels_replaced':False,'models_trained':False,'attacks_executed':False,
 'NF_changed':False,'confirmatory_scenarios_selected':False,'new_packet_validity_claim':False,
 'next_step':'Review the complete linkage candidates and rule agreement; resolve only actual blockers, then freeze trace-study allocation and feature/action contract before outcomes.'}
dump(OUT/'receipt.json',receipt)
print('\nBATCH RECEIPT\n'+json.dumps(receipt,indent=2))
print('\nSCENARIO GATES\n'+pd.DataFrame(summary).to_string(index=False))
print('\nRULE AGREEMENT\n'+pd.DataFrame(rule_results).to_string(index=False))
print('\nEXPLICIT FAILURES\n'+(pd.DataFrame(failures).to_string(index=False)if failures else 'None'))
print('\nRetain this directory. Rerunning resumes completed candidates; no blanket replay.')

# ===== CELL INPUT 28 =====
# RUN AFTER THE FAILED CELL HAS STOPPED. Keep this kernel; do not restart.
# Removes ONLY rebuildable caches and incomplete replay output under this batch.
# Preserves models, input datasets, completed receipts, linked CSVs and completed replays.
import gc,hashlib,json,os,shutil,sqlite3
from datetime import datetime,timezone
from pathlib import Path

WORK=Path('/kaggle/working')
BASE=WORK/'TRACE_LINKAGE_BATCH_v1'
if not BASE.is_dir() or BASE.is_symlink():raise RuntimeError('Expected nonsymlink batch directory missing.')
BASE=BASE.resolve()

# Do not delete anything while a Zeek extraction in this batch is still running.
active=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  name=(proc/'comm').read_text().strip()
  cwd=(proc/'cwd').resolve()
  if name in {'zeek','bro'} and cwd.is_relative_to(BASE):active.append(proc.name)
 except (OSError,RuntimeError):pass
if active:raise RuntimeError('Stop the running extraction before cleanup; active process IDs: '+','.join(active))

# Close only live SQLite connections belonging to this batch.
closed=0
for obj in gc.get_objects():
 if not isinstance(obj,sqlite3.Connection):continue
 try:
  dbs=obj.execute('PRAGMA database_list').fetchall()
  if any(row[2] and Path(row[2]).resolve().is_relative_to(BASE) for row in dbs):
   obj.close();closed+=1
 except sqlite3.ProgrammingError:pass
 except sqlite3.Error as error:raise RuntimeError('Could not safely close batch database: '+str(error))
gc.collect()

# Keep small completed candidate receipts in memory before freeing space.
completed=[];metadata_hashes={}
for p in BASE.rglob('*.json'):
 if p.is_symlink() or not p.is_file():continue
 if p.stat().st_size>2*1024**2:continue
 try:
  data=p.read_bytes();metadata_hashes[str(p)]=hashlib.sha256(data).hexdigest()
  if p.name=='candidate_receipt.json':
   obj=json.loads(data)
   if obj.get('status')=='FULL_LOG_LINKAGE_COMPUTED':completed.append(obj)
 except (OSError,ValueError):pass

before=shutil.disk_usage(WORK).free
removed=[]
# These files contain derived indexes, NOT original observations or labels.
for p in sorted(BASE.rglob('reference_keys.sqlite*')):
 if p.is_symlink() or not p.is_file():continue
 if p.name not in {'reference_keys.sqlite','reference_keys.sqlite-wal','reference_keys.sqlite-shm','reference_keys.sqlite-journal'}:continue
 if not p.resolve().is_relative_to(BASE):raise RuntimeError('Cache path escaped batch root.')
 size=p.stat().st_size;p.unlink()
 removed.append({'path':str(p),'bytes':size,'reason':'REBUILDABLE_SQLITE_CACHE'})

# Delete replay folders only when neither extraction nor candidate completion exists.
# Preserve the separate zeek.log and record the partial folder's file inventory.
for replay in sorted(BASE.rglob('replay')):
 if not replay.is_dir() or replay.is_symlink():continue
 job=replay.parent
 if (job/'extraction_complete.json').exists() or (job/'candidate_receipt.json').exists():continue
 files=[p for p in replay.rglob('*') if p.is_file() and not p.is_symlink()]
 if any(p.is_symlink() for p in replay.rglob('*')):raise RuntimeError('Unexpected symlink in partial replay; not deleting it.')
 if not replay.resolve().is_relative_to(BASE):raise RuntimeError('Partial replay path escaped batch root.')
 details=[{'path':str(p),'bytes':p.stat().st_size}for p in files]
 size=sum(r['bytes']for r in details)
 shutil.rmtree(replay)
 removed.append({'path':str(replay),'bytes':size,'reason':'INCOMPLETE_EXTRACTION_ONLY','partial_files':details})

after=shutil.disk_usage(WORK).free
if after<64*1024**2:raise RuntimeError('Cleanup freed too little space to save receipt; do not delete other outputs blindly.')
changed=[]
for value,expected in metadata_hashes.items():
 p=Path(value)
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:changed.append(value)
if changed:raise RuntimeError('Protected metadata changed: '+str(changed))

receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'batch_root':str(BASE),
 'closed_batch_database_connections':closed,'removed_derivative_entries':removed,
 'free_bytes_before':before,'free_bytes_after':after,'free_GiB_after':round(after/1024**3,3),
 'protected_small_metadata_unchanged':True,'completed_candidate_receipts_preserved':len(completed),
 'original_input_datasets_deleted':False,'models_deleted':False,'completed_linked_CSVs_deleted':False,
 'completed_replay_logs_deleted':False,'NF_changed':False,
 'old_SQLite_batch_must_not_be_rerun':True,
 'continuation_design':'Compressed hash-partition joins; all records, bounded cache budget, one scenario at a time.'}
(WORK/'TRACE_STORAGE_RECOVERY_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
(WORK/'TRACE_PRESERVED_CANDIDATE_RECEIPTS.json').write_text(json.dumps(completed,indent=2))
print(json.dumps({k:v for k,v in receipt.items()if k!='removed_derivative_entries'},indent=2))
print('\nREMOVED REBUILDABLE STORAGE')
for r in removed:print(round(r['bytes']/1024**3,3),'GiB',r['reason'],r['path'])
print('\nPRESERVED COMPUTED CANDIDATES')
for r in completed:
 print(r['scenario'],Path(r['capture']).name,'matches=',r['unique_exact_key_matches'],
       'generated=',r['generated_rows'],'reference=',r['reference_rows'],
       'predictor_differences=',r['predictor_difference_counts'])
print('\nPaste this recovery output. DO NOT rerun expand_trace_linkage_batch_v1.py.')

# ===== CELL INPUT 29 =====
"""Bounded-storage linkage continuation. Full records, no SQLite indexes or sampling.
Completed 1/3 candidate receipts and Capture-8 replay are reused.
One scenario's compressed shards at a time; successful joins delete only temporary shards.
Existing scientific outputs/model bundles/source inputs are never removed.
"""
import csv,gzip,hashlib,json,os,re,resource,shutil,subprocess,time
from collections import Counter
from datetime import datetime,timezone
from decimal import Decimal,ROUND_HALF_EVEN,InvalidOperation
from pathlib import Path
import pandas as pd

WORK=Path('/kaggle/working')
OLD=WORK/'TRACE_LINKAGE_BATCH_v1'
SRC=WORK/'TRACE_LABEL_RECOVERY_20261011T153846517131Z'
PILOT=WORK/'TRACE_CLEAN_REPLAY_20261011T161846072286Z'
OUT=WORK/'TRACE_LINKAGE_STREAM_v2';OUT.mkdir(exist_ok=True)
CACHE=OUT/'temporary_shards';CACHE.mkdir(exist_ok=True)
ZEEK='/opt/zeek/bin/zeek'
SCENARIOS=['CTU-IoT-Malware-Capture-1-1','CTU-IoT-Malware-Capture-3-1','CTU-IoT-Malware-Capture-7-1','CTU-IoT-Malware-Capture-8-1','CTU-IoT-Malware-Capture-9-1']
PREDICTORS=['duration','orig_bytes','resp_bytes','orig_pkts','resp_pkts','orig_ip_bytes','resp_ip_bytes','missed_bytes','proto','conn_state','history']
NUMERIC=set(PREDICTORS[:8])
PARTITIONS=256
MAX_BUCKET_ROWS=300000
CACHE_BUDGET=3*1024**3
REPLAY_BUDGET=5*1024**3
MIN_FREE=4*1024**3
TIMEOUT=3600
RESULTS=[];RULE_SUMMARY=[];ERRORS=[]

def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def key(row):
 micros=int((Decimal(row['ts'])*1000000).to_integral_value(rounding=ROUND_HALF_EVEN))
 return json.dumps([micros,row['id.orig_h'],row['id.orig_p'],row['id.resp_h'],row['id.resp_p'],row['proto'].lower()],separators=(',',':'))
def stream(p):
 fields=None
 opener=gzip.open(p,'rt',encoding='utf-8')if p.name.endswith('.gz')else p.open('r',encoding='utf-8')
 with opener as f:
  for number,line in enumerate(f,1):
   if line.startswith('#fields'):
    fields=line.strip().split()[1:];continue
   if line.startswith('#')or not line.strip():continue
   if fields is None:raise ValueError('Missing Zeek schema: '+str(p))
   values=line.strip().split()
   if len(values)!=len(fields):raise ValueError(f'Malformed log row: {p}:{number}')
   row=dict(zip(fields,values));row['_line']=number;yield row

def equal(field,a,b):
 if field in NUMERIC and a!='-'and b!='-':
  try:return Decimal(a)==Decimal(b)
  except InvalidOperation:return False
 return a==b

def parse_rules(text):
 rules=[];head=None;warnings=[]
 mapping={'srcIP':'id.orig_h','dstIP':'id.resp_h','srcPort':'id.orig_p','dstPort':'id.resp_p','Proto':'proto'}
 for number,line in enumerate(text.splitlines(),1):
  line=line.split('#',1)[0].strip()
  if not line:continue
  if re.search(r'xxx\.xxx\.xxx\.xxx|(?:srcPort|dstPort)\s*=\s*xx\b',line,re.I):raise ValueError('Placeholder rule refused.')
  if not line.startswith('-'):
   m=re.fullmatch(r'(Background|Benign|Malicious)(?:,\s*([^:]+?))?\s*:*',line)
   if not m:raise ValueError('Unsupported heading: '+line)
   if not line.endswith(':')or line.endswith('::'):warnings.append({'line':number,'text':line,'diagnostic_normalization_only':True})
   head=(m.group(1),(m.group(2)or'').strip());continue
  if head is None:raise ValueError('Rule without heading.')
  terms=[]
  for atom in line[1:].split('&'):
   m=re.fullmatch(r'\s*([A-Za-z]+)\s*=\s*([^\s&]+)\s*',atom)
   if not m or m.group(1)not in mapping:raise ValueError('Unsupported term: '+atom)
   terms.append((m.group(1),m.group(2)))
  rules.append((head,terms))
 return rules,warnings,mapping

def infer(row,rules,mapping):
 label='UNMATCHED'
 for head,terms in rules:
  ok=True
  for field,value in terms:
   actual=row[mapping[field]]
   if value.lower()=='all':continue
   if field=='Proto':equal0=actual.lower()==value.lower()
   elif field in {'srcPort','dstPort'}:
    try:equal0=int(actual)==int(value)
    except ValueError:equal0=False
   else:equal0=actual==value
   if not equal0:ok=False;break
  if ok:label=head[0].lower()
 return label


def atomic(p,obj):
 temp=p.with_suffix(p.suffix+'.partial');temp.write_text(json.dumps(obj,indent=2,ensure_ascii=False));temp.replace(p)
def folder_bytes(p):return sum(q.stat().st_size for q in p.rglob('*')if q.is_file() and not q.is_symlink())
def guard():
 free=shutil.disk_usage(WORK).free
 if free<MIN_FREE:raise RuntimeError(f'Free space safety stop: {free/1024**3:.2f} GiB; partial outputs preserved.')
 size=folder_bytes(CACHE)
 if size>CACHE_BUDGET:raise RuntimeError('Compressed temporary-shard budget exceeded; no sampling or silently incomplete result.')
def bucket(k):return hashlib.blake2b(k.encode(),digest_size=2).digest()[0]
def cache_remove(p):
 if not p.exists():return
 if p.is_symlink()or not p.resolve().is_relative_to(CACHE.resolve()):raise RuntimeError('Unsafe temporary-cache deletion refused.')
 shutil.rmtree(p)
def hasher_stream(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()

def partition(log,out,kind,rules,mapping):
 receipt=out/'partition_receipt.json'
 source_sha=sha(log)
 if receipt.exists():
  previous=json.loads(receipt.read_text())
  if previous['source_sha256']==source_sha and previous['complete']:
   for r in previous['shards']:
    q=out/r['file']
    if not q.is_file()or hasher_stream(q)!=r['sha256']:raise RuntimeError('Saved shard changed.')
   return previous
  raise RuntimeError('Existing shard receipt has incompatible source.')
 if out.exists():cache_remove(out)
 out.mkdir(parents=True)
 writers=[];rows=0;labels=Counter();confusion=Counter()
 try:
  soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
  if soft<1024 and hard>=1024:resource.setrlimit(resource.RLIMIT_NOFILE,(1024,hard))
  for n in range(PARTITIONS):writers.append(gzip.open(out/f'{n:03d}.jsonl.gz','wt',encoding='utf-8',compresslevel=1))
  for row in stream(log):
   k=key(row);features=[row[f]for f in PREDICTORS]
   label=row.get('label','');detail=row.get('detailed-label','')
   record=[k,features,row['_line'],label,detail]
   writers[bucket(k)].write(json.dumps(record,separators=(',',':'),ensure_ascii=False)+'\n');rows+=1
   if kind=='reference':
    if not label:raise RuntimeError('Primary supplied label absent.')
    labels[label.lower()]+=1;confusion[(label.lower(),infer(row,rules,mapping))]+=1
   if rows%250000==0:
    print(kind,log.parent.name,'PARTITIONED ROWS',rows,flush=True)
    for w in writers:w.flush()
    guard()
 finally:
  for w in writers:w.close()
 guard()
 shards=[{'file':q.name,'bytes':q.stat().st_size,'sha256':sha(q)}for q in sorted(out.glob('*.jsonl.gz'))]
 result={'source_sha256':source_sha,'complete':True,'rows':rows,'kind':kind,'shards':shards,
 'compressed_bytes':sum(r['bytes']for r in shards),'published_labels':dict(labels),
 'confusion':[{'published':a,'rule':b,'records':v}for(a,b),v in confusion.items()],
 'rule_agreements':sum(v for(a,b),v in confusion.items()if a==b)}
 atomic(receipt,result);return result

def load_bucket(path):
 lookup={};rows=0
 with gzip.open(path,'rt',encoding='utf-8')as f:
  for line in f:
   row=json.loads(line);rows+=1
   if rows>MAX_BUCKET_ROWS:raise RuntimeError('Bucket memory safety limit reached; no rows discarded.')
   k=row[0]
   if k in lookup:lookup[k][1]+=1
   else:lookup[k]=[row,1]
 return lookup

def extract(capture,job,cap_sha):
 pilot=json.loads((PILOT/'smoke_selection.json').read_text())
 if cap_sha==pilot['pcap_sha256']:return PILOT/'clean_replay/conn.log',True
 old_job=OLD/job.parent.name/cap_sha[:20]
 for base in [old_job,job]:
  marker=base/'extraction_complete.json';log=base/'replay/conn.log'
  if marker.exists()and log.is_file():
   saved=json.loads(marker.read_text())
   if saved.get('pcap_sha256')==cap_sha and saved.get('conn_log_sha256')==sha(log):return log,True
 replay=job/'replay';replay.mkdir(exist_ok=True)
 if list(replay.iterdir()):raise RuntimeError('Incomplete replay remains; do not mix attempts. Report this path: '+str(replay))
 guard();stdout=job/'zeek.log'
 print('EXTRACTING',job.parent.name,capture.name,'bytes',capture.stat().st_size,flush=True)
 with stdout.open('w')as f:
  process=subprocess.Popen([ZEEK,'-C','-r',str(capture)],cwd=replay,stdout=f,stderr=subprocess.STDOUT)
  start=time.monotonic()
  try:
   while process.poll() is None:
    time.sleep(5)
    if time.monotonic()-start>TIMEOUT:raise RuntimeError('Zeek timeout; partial extraction retained.')
    if shutil.disk_usage(WORK).free<MIN_FREE or folder_bytes(replay)>REPLAY_BUDGET:raise RuntimeError('Zeek storage safety stop before disk exhaustion.')
  except Exception:
   process.terminate()
   try:process.wait(timeout=30)
   except subprocess.TimeoutExpired:process.kill();process.wait()
   raise
 if process.returncode or not (replay/'conn.log').is_file():raise RuntimeError('Zeek failed; inspect '+str(stdout))
 log=replay/'conn.log';atomic(job/'extraction_complete.json',{'pcap_sha256':cap_sha,'conn_log_sha256':sha(log),'zeek_version':VERSION})
 return log,False

def lossless_archive_new_log(log,job):
 # Only this v2 job's own extracted conn.log is compacted; old completed logs are untouched.
 if log.parent!=job/'replay' or not log.is_file():return
 dest=job/'replay/conn.log.gz';partial=dest.with_suffix('.gz.partial')
 original=sha(log);guard()
 try:
  with log.open('rb')as source,gzip.open(partial,'wb',compresslevel=1)as target:
   total=0
   for block in iter(lambda:source.read(8*1024**2),b''):
    target.write(block);total+=len(block)
    if total%(128*1024**2)==0:guard()
  check=hashlib.sha256()
  with gzip.open(partial,'rb')as f:
   for b in iter(lambda:f.read(8*1024**2),b''):check.update(b)
  if check.hexdigest()!=original:raise RuntimeError('Lossless compressed replay verification failed.')
  partial.replace(dest)
  atomic(job/'compressed_replay_receipt.json',{'uncompressed_sha256':original,'compressed_sha256':sha(dest),'path':str(dest),'lossless_verified':True})
  log.unlink()
 except Exception:
  if partial.exists():partial.unlink()
  raise

v=subprocess.run([ZEEK,'--version'],capture_output=True,text=True,timeout=30)
if v.returncode:raise RuntimeError('Installed Zeek is not runnable.')
VERSION=v.stdout.strip()or v.stderr.strip()
policy={'scenarios':SCENARIOS,'candidate_predictors':PREDICTORS,'zeek_version':VERSION,
 'all_records':True,'sampling':False,'partitions':PARTITIONS,'temporary_cache_budget_bytes':CACHE_BUDGET,
 'minimum_free_bytes':MIN_FREE,'maximum_uncompressed_replay_bytes':REPLAY_BUDGET,
 'selection':'Reuse completed candidates; assess every remaining recorded PCAP separately; no merging or target-performance selection.'}
lock=OUT/'policy.json'
if lock.exists()and json.loads(lock.read_text())!=policy:raise RuntimeError('V2 policy changed; cannot mix results.')
if not lock.exists():atomic(lock,policy)
scenario_table=pd.read_csv(SRC/'scenario_label_evidence.csv',keep_default_na=False)
sources=pd.read_csv(SRC/'publisher_retrieval_receipts.csv',keep_default_na=False)

for name in SCENARIOS:
 refcache=CACHE/name/'reference'
 try:
  selected=scenario_table[scenario_table.official_scenario.eq(name)]
  if len(selected)!=1:raise RuntimeError('Recorded scenario ambiguous.')
  spec=selected.iloc[0];refs=[Path(p)for p in json.loads(spec['local_log_paths'])]
  captures=[Path(p)for p in json.loads(spec['local_capture_paths'])]
  if len(refs)!=1:raise RuntimeError('Exactly one reference log required.')
  reference=refs[0];ref_sha=sha(reference)
  source=sources[(sources.kind=='publisher_rules')&(sources.scenario==name)]
  if len(source)!=1:raise RuntimeError('Rule source ambiguous.')
  source=source.iloc[0];p=Path(source['path'])
  if sha(p)!=source['sha256']:raise RuntimeError('Rule source changed.')
  rules,warnings,mapping=parse_rules(p.read_text())
  scdir=OUT/name;scdir.mkdir(exist_ok=True)
  atomic(scdir/'rule_interpretation.json',{'source_sha256':source['sha256'],'heading_warnings':warnings,'publisher_parser_fidelity_verified':False})
  refinfo=None
  for capture in sorted(captures,key=lambda p:(p.stat().st_size,str(p))):
   try:
    cap_sha=sha(capture);job=scdir/cap_sha[:20];job.mkdir(exist_ok=True)
    # Reuse previously computed scientific results, not the deleted database caches.
    previous_paths=[job/'candidate_receipt.json',OLD/name/cap_sha[:20]/'candidate_receipt.json']
    previous=None
    for pp in previous_paths:
     if not pp.is_file():continue
     obj=json.loads(pp.read_text())
     if obj.get('status')=='FULL_LOG_LINKAGE_COMPUTED'and obj.get('pcap_sha256')==cap_sha and obj.get('reference_sha256')==ref_sha:
      linked=Path(obj['linked_records_path'])
      if not linked.is_file()or sha(linked)!=obj['linked_records_sha256']:raise RuntimeError('Saved linked-record output missing/changed.')
      previous={**obj,'computed_result_reused':True,'receipt_source':str(pp)};break
    if previous:
     RESULTS.append(previous);print(name,capture.name,'COMPLETED RESULT REUSED',flush=True);continue
    log,extraction_reused=extract(capture,job,cap_sha)
    if refinfo is None:
     refinfo=partition(reference,refcache,'reference',rules,mapping)
     atomic(scdir/'reference_summary.json',{**{k:v for k,v in refinfo.items()if k!='shards'},'source_rule_sha256':source['sha256'],'noncanonical_headers':len(warnings)})
    gencache=CACHE/name/cap_sha[:20]
    geninfo=partition(log,gencache,'generated',rules,mapping)
    final=job/'linked_records.csv.gz';partial=job/'linked_records.csv.gz.partial'
    fields=PREDICTORS+['published_label','published_detailed_label','reference_line','generated_line','source_scenario','pcap_sha256','reference_log_sha256']
    matches=0;unmatched=0;ambiguous=0;diff=Counter();labels=Counter()
    with gzip.open(partial,'wt',encoding='utf-8',newline='',compresslevel=1)as f:
     writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
     for n in range(PARTITIONS):
      refbucket=load_bucket(refcache/f'{n:03d}.jsonl.gz');genbucket=load_bucket(gencache/f'{n:03d}.jsonl.gz')
      for k,(g,ng)in genbucket.items():
       found=refbucket.get(k)
       if found is None:unmatched+=ng;continue
       r,nr=found
       if nr!=1 or ng!=1:ambiguous+=ng;continue
       matches+=1;labels[r[3].lower()]+=1
       for i,feature in enumerate(PREDICTORS):
        if not equal(feature,r[1][i],g[1][i]):diff[feature]+=1
       writer.writerow({**dict(zip(PREDICTORS,g[1])),'published_label':r[3],'published_detailed_label':r[4],
        'reference_line':r[2],'generated_line':g[2],'source_scenario':name,'pcap_sha256':cap_sha,'reference_log_sha256':ref_sha})
      del refbucket,genbucket
      if (n+1)%32==0:guard();print(name,capture.name,'JOINED PARTITIONS',n+1,'/',PARTITIONS,flush=True)
    partial.replace(final)
    result={'status':'FULL_LOG_LINKAGE_COMPUTED','scenario':name,'capture':str(capture),'pcap_sha256':cap_sha,'reference_sha256':ref_sha,
     'generated_log_sha256':geninfo['source_sha256'],'reference_rows':refinfo['rows'],'generated_rows':geninfo['rows'],
     'unique_exact_key_matches':matches,'unmatched_generated_rows':unmatched,'ambiguous_generated_rows':ambiguous,
     'full_reference_coverage':matches==refinfo['rows'],'full_generated_coverage':matches==geninfo['rows'],
     'predictor_difference_counts':dict(diff),'mapped_published_label_counts':dict(labels),
     'linked_records_path':str(final),'linked_records_sha256':sha(final),'linked_record_format':'gzip CSV',
     'extraction_reused':extraction_reused,'computed_result_reused':False,'source_rule_sha256':source['sha256'],
     'publisher_tool_fidelity_verified':False,'confirmatory_scenario_selected':False,'packet_validity_approved':False,
     'all_records_processed':True,'sampling':False,'join_method':'compressed hash-partition, exact original connection keys'}
    atomic(job/'candidate_receipt.json',result);RESULTS.append(result)
    cache_remove(gencache)
    # Compact the newly produced replay only after successful exact linkage.
    lossless_archive_new_log(log,job)
    print(name,capture.name,'MATCHES',matches,'/',geninfo['rows'],'DIFFERENCES',dict(diff),flush=True)
   except Exception as error:
    ERRORS.append({'scenario':name,'capture':str(capture),'error':f'{type(error).__name__}: {error}'})
    if shutil.disk_usage(WORK).free<MIN_FREE:raise RuntimeError('Storage safety stop; resolve explicitly, not by rerunning SQLite.')
  summaryfile=scdir/'reference_summary.json';oldref=OLD/name/'reference_index_receipt.json'
  if summaryfile.is_file():rs=json.loads(summaryfile.read_text());n=rs['rows'];agree=rs['rule_agreements'];pub=rs['published_labels']
  elif oldref.is_file():rs=json.loads(oldref.read_text());n=rs['rows'];agree=rs['rule_agreement'];pub=rs['published_labels']
  else:n=agree=None;pub={}
  RULE_SUMMARY.append({'scenario':name,'reference_rows':n,'rule_agreements':agree,'rule_agreement_fraction':agree/n if n else None,
   'published_label_counts':json.dumps(pub),'noncanonical_rule_headers':len(warnings)})
  cache_remove(CACHE/name)
 except Exception as error:ERRORS.append({'scenario':name,'capture':'SCENARIO_STAGE','error':f'{type(error).__name__}: {error}'})
 pd.DataFrame(RESULTS).to_csv(OUT/'candidate_linkage_summary.csv',index=False)
 pd.DataFrame(RULE_SUMMARY).to_csv(OUT/'scenario_rule_agreement.csv',index=False)
 pd.DataFrame(ERRORS,columns=['scenario','capture','error']).to_csv(OUT/'explicit_failures.csv',index=False)
 if shutil.disk_usage(WORK).free<MIN_FREE:break

summary=[]
for name in SCENARIOS:
 rows=[r for r in RESULTS if r['scenario']==name]
 faithful=[r for r in rows if r['full_reference_coverage']and r['full_generated_coverage']and not r['predictor_difference_counts']]
 summary.append({'scenario':name,'computed_candidates':len(rows),'full_bijection_predictor_fidelity_candidates':len(faithful),
 'status':'FULL_FIDELITY_CANDIDATE_FOR_REVIEW'if len(faithful)==1 else ('MULTIPLE_FULL_CANDIDATES_REVIEW'if faithful else 'LINKAGE_OR_FEATURE_DIFFERENCES_REMAIN'),
 'scientific_approval_automatic':False})
pd.DataFrame(summary).to_csv(OUT/'scenario_gate_summary.csv',index=False)
receipt={'output_directory':str(OUT),'computed_candidates':len(RESULTS),'completed_results_reused':sum(r.get('computed_result_reused',False)for r in RESULTS),
 'explicit_failure_records':len(ERRORS),'SQLite_used':False,'sampling_used':False,'free_GiB':round(shutil.disk_usage(WORK).free/1024**3,3),
 'remaining_temporary_cache_GiB':round(folder_bytes(CACHE)/1024**3,3),'models_trained':False,'attacks_executed':False,'NF_changed':False,
 'packet_validity_approved':False,'confirmatory_scenarios_selected':False}
atomic(OUT/'receipt.json',receipt)
print('\nSTREAMING BATCH RECEIPT\n'+json.dumps(receipt,indent=2))
print('\nSCENARIO GATES\n'+pd.DataFrame(summary).to_string(index=False))
print('\nRULE AGREEMENT\n'+pd.DataFrame(RULE_SUMMARY).to_string(index=False))
print('\nEXPLICIT FAILURES\n'+(pd.DataFrame(ERRORS).to_string(index=False)if ERRORS else 'None'))

# ===== CELL INPUT 30 =====
"""Two closing analyses: class-balanced rule discrepancies + stable-field compatibility.
Reads already computed full-log summaries/receipts; no Zeek reruns or large indexes.
No labels replaced, no models, no attack, no automatic confirmatory approval.
"""
import csv,gzip,hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd

WORK=Path('/kaggle/working');STREAM=WORK/'TRACE_LINKAGE_STREAM_v2';OLD=WORK/'TRACE_LINKAGE_BATCH_v1'
SRC=WORK/'TRACE_LABEL_RECOVERY_20261011T153846517131Z'
OUT=WORK/('TRACE_CLOSING_PAIR_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(exist_ok=False)
SCENARIOS=['CTU-IoT-Malware-Capture-1-1','CTU-IoT-Malware-Capture-3-1','CTU-IoT-Malware-Capture-7-1','CTU-IoT-Malware-Capture-8-1','CTU-IoT-Malware-Capture-9-1']
CORE=['duration','orig_bytes','resp_bytes','orig_pkts','resp_pkts','orig_ip_bytes','resp_ip_bytes','missed_bytes','proto']
EXCLUDE=['conn_state','history','service','local_orig','local_resp','tunnel_parents','ip_proto']

def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def save_json(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')

# A: inspect the full-population confusion already computed, not just overall agreement.
metrics=[];confusions=[];errors=[];sources=[]
for scenario in SCENARIOS:
 paths=[STREAM/scenario/'reference_summary.json',OLD/scenario/'reference_index_receipt.json']
 path=next((p for p in paths if p.is_file()),None)
 if path is None:errors.append({'task':'A','scenario':scenario,'error':'Completed full reference confusion not found'});continue
 obj=json.loads(path.read_text());sources.append({'role':'full_reference_confusion','scenario':scenario,'path':str(path),'sha256':sha(path)})
 rows=int(obj['rows']);matrix={}
 for row in obj['confusion']:
  a=str(row['published']).lower();b=str(row['rule']).lower();n=int(row['records'])
  matrix[(a,b)]=matrix.get((a,b),0)+n
  confusions.append({'scenario':scenario,'published_label':a,'rule_label':b,'records':n})
 if sum(matrix.values())!=rows:raise RuntimeError('Confusion total does not equal full reference count: '+scenario)
 benign=sum(n for(a,b),n in matrix.items()if a=='benign')
 malicious=sum(n for(a,b),n in matrix.items()if a=='malicious')
 correct_b=matrix.get(('benign','benign'),0);correct_m=matrix.get(('malicious','malicious'),0)
 correct=sum(n for(a,b),n in matrix.items()if a==b)
 b_recall=correct_b/benign if benign else None;m_recall=correct_m/malicious if malicious else None
 unsupported=sum(n for(a,b),n in matrix.items()if a not in {'benign','malicious'})
 background=sum(n for(a,b),n in matrix.items()if b=='background')
 unmatched=sum(n for(a,b),n in matrix.items()if b=='unmatched')
 metrics.append({'scenario':scenario,'full_reference_rows':rows,'benign_records':benign,'malicious_records':malicious,
  'overall_agreement':correct/rows if rows else None,'benign_class_agreement':b_recall,'malicious_class_agreement':m_recall,
  'balanced_class_agreement':(b_recall+m_recall)/2 if b_recall is not None and m_recall is not None else None,
  'disagreements':rows-correct,'rule_background_predictions':background,'rule_unmatched_predictions':unmatched,
  'unsupported_published_labels':unsupported,'binary_rule_identity_on_all_reference_records':correct==rows and unsupported==0,
  'published_labels_replaced':False,'publisher_tool_fidelity_approved':False})
pd.DataFrame(metrics).to_csv(OUT/'A_class_balanced_rule_fidelity.csv',index=False)
pd.DataFrame(confusions).to_csv(OUT/'A_full_binary_confusions.csv',index=False)

# B: test a proposed extractor-version-stable core on ALL uniquely linked rows,
# using saved full-comparison counts. No new training/outcome selection.
# This is a disclosed schema amendment proposal, not a claim that dropped fields reproduce.
summary=pd.read_csv(STREAM/'candidate_linkage_summary.csv',keep_default_na=False)
if not {'linked_records_path','scenario','capture'}.issubset(summary.columns):raise RuntimeError('Unexpected completed summary schema.')
receipts=[];seen=set()
for root in [STREAM,OLD]:
 for path in root.rglob('candidate_receipt.json'):
  obj=json.loads(path.read_text())
  if obj.get('status')!='FULL_LOG_LINKAGE_COMPUTED':continue
  ident=(obj['scenario'],obj['pcap_sha256'],obj['reference_sha256'])
  if ident in seen:continue
  seen.add(ident);receipts.append((path,obj))
expected=set(zip(summary.scenario,summary.pcap_sha256,summary.reference_sha256))
if seen!=expected:raise RuntimeError('Saved candidate receipts disagree with completed batch summary.')
compatibility=[];manifest=[]
for path,obj in receipts:
 linked=Path(obj['linked_records_path'])
 if not linked.is_file()or sha(linked)!=obj['linked_records_sha256']:raise RuntimeError('Saved linked output missing/changed: '+str(linked))
 differences=obj['predictor_difference_counts'];unstable={k:v for k,v in differences.items()if k in EXCLUDE};core_diff={k:v for k,v in differences.items()if k in CORE}
 if any(k not in CORE+EXCLUDE for k in differences):raise RuntimeError('Unknown compared predictor in receipt.')
 # Check recorded CSV schema without rebuilding/copying data.
 opener=gzip.open(linked,'rt',encoding='utf-8',newline='')if linked.name.endswith('.gz')else linked.open('r',encoding='utf-8',newline='')
 with opener as f:columns=next(csv.reader(f))
 if not set(CORE+['published_label','reference_line','generated_line']).issubset(columns):raise RuntimeError('Core/schema/label lineage fields absent: '+str(linked))
 row={'scenario':obj['scenario'],'capture':Path(obj['capture']).name,'reference_rows':obj['reference_rows'],
  'generated_rows':obj['generated_rows'],'unique_exact_key_matches':obj['unique_exact_key_matches'],
  'unlinked_reference_rows':obj['reference_rows']-obj['unique_exact_key_matches'],
  'unlinked_generated_rows':obj['generated_rows']-obj['unique_exact_key_matches'],
  'ambiguous_generated_rows':obj['ambiguous_generated_rows'],
  'mapped_reference_fraction':obj['unique_exact_key_matches']/obj['reference_rows'],
  'mapped_generated_fraction':obj['unique_exact_key_matches']/obj['generated_rows'],
  'unstable_field_difference_counts':json.dumps(unstable),'stable_core_difference_counts':json.dumps(core_diff),
  'stable_core_identical_on_all_uniquely_linked_rows':not core_diff,
  'full_population_bijection':obj['unique_exact_key_matches']==obj['reference_rows']==obj['generated_rows'],
  'dropped_rows_are_reported_not_hidden':True,'automatic_label_or_protocol_approval':False}
 compatibility.append(row)
 manifest.append({'scenario':obj['scenario'],'pcap_path':obj['capture'],'pcap_sha256':obj['pcap_sha256'],
  'reference_log_sha256':obj['reference_sha256'],'linked_records_path':str(linked),'linked_records_sha256':obj['linked_records_sha256'],
  'candidate_receipt':str(path),'candidate_receipt_sha256':sha(path),'stable_core_columns':CORE,
  'label_column':'published_label','identity_columns_metadata_only':['reference_line','generated_line','source_scenario','pcap_sha256','reference_log_sha256'],
  'eligible_for_training_by_this_code':False,'reason':'Stable-core compatibility does not itself approve label provenance, capture allocation, or independence.'})
 sources.append({'role':'candidate_receipt','scenario':obj['scenario'],'path':str(path),'sha256':sha(path)})
pd.DataFrame(compatibility).to_csv(OUT/'B_stable_core_compatibility.csv',index=False)
save_json(OUT/'B_noncopying_dataset_manifest.json',manifest)

schema=[]
for feature in CORE:
 if feature=='duration':view='timing';kind='connection interval';unit='seconds';action='Re-extract after permitted timestamp transformation; never directly edit CSV.'
 elif feature=='proto':view='protocol';kind='protocol category';unit='categorical';action='Immutable under padding/pacing action.'
 elif feature=='missed_bytes':view='capture_quality';kind='extraction quality indicator';unit='bytes';action='Quality constraint; not an attacker-optimizable numeric coordinate.'
 else:view='directional_volume';kind='extracted directional counter';unit='packets'if 'pkts'in feature else'bytes';action='Re-extract after permitted packet transformation; never independently edit counter.'
 schema.append({'feature':feature,'candidate_view':view,'role':kind,'candidate_unit':unit,'candidate_action_policy':action,
  'semantics_status':'REQUIRES_VERSIONED_ZEEK_SOURCE_CONFIRMATION_BEFORE_FINAL_SCHEMA',
  'source_verified':False,'candidate_only':True})
for feature in EXCLUDE:
 schema.append({'feature':feature,'candidate_view':'EXCLUDED_FROM_STABLE_CORE','role':'version-dependent or unverified field',
  'candidate_unit':'','candidate_action_policy':'Preserve in extraction evidence, omit from proposed cross-version core.',
  'semantics_status':'EXCLUSION_BASED_ON_EXTRACTION_FIDELITY; NOT TARGET_MODEL_PERFORMANCE','source_verified':False,'candidate_only':True})
pd.DataFrame(schema).to_csv(OUT/'B_proposed_stable_feature_contract.csv',index=False)
pd.DataFrame(sources).to_csv(OUT/'evidence_sources.csv',index=False)
pd.DataFrame(errors,columns=['task','scenario','error']).to_csv(OUT/'explicit_errors.csv',index=False)
receipt={'output_directory':str(OUT),'closing_analyses_completed':['A_CLASS_BALANCED_RULE_FIDELITY','B_STABLE_CORE_COMPATIBILITY'],
 'scenarios_rule_analyzed':len(metrics),'candidate_linkages_checked':len(compatibility),
 'stable_core_fields':CORE,'new_predictor_fidelity_claim_scope':'uniquely linked rows only; unmatched/ambiguous rows remain counted',
 'schema_amendment_final_approved':False,'publisher_label_rules_auto_approved':False,
 'published_labels_replaced':False,'data_copied':False,'Zeek_rerun':False,'models_trained':False,'attacks_executed':False,
 'NF_changed':False,'explicit_errors':len(errors),'next_step':'Use class-balanced disagreements and stable-core evidence to resolve label/version policy; then approve a source-backed allocation/action contract before any confirmatory outcomes.'}
save_json(OUT/'receipt.json',receipt)
package=WORK/(OUT.name+'_PRIVATE_REVIEW.zip')
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(OUT.iterdir()):
  if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(package)as z:
 if z.testzip()is not None:raise RuntimeError('Private review ZIP integrity failure.')
print(json.dumps({**receipt,'private_review_zip':str(package),'review_zip_sha256':sha(package)},indent=2))
print('\nA — CLASS-BALANCED RULE FIDELITY');print(pd.DataFrame(metrics).to_string(index=False))
print('\nA — FULL BINARY CONFUSIONS');print(pd.DataFrame(confusions).to_string(index=False))
print('\nB — STABLE-CORE LINKAGE COMPATIBILITY');print(pd.DataFrame(compatibility).to_string(index=False))
print('\nEXPLICIT ERRORS');print(pd.DataFrame(errors).to_string(index=False)if errors else'None')

# ===== CELL INPUT 31 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

WORK = Path("/kaggle/working")
INJ = WORK / "E4_COMPACT_INJECTIONS_v2"
PACE = WORK / "E4_COMPACT_PACING_v1"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
OUT = WORK / f"CORRECTED_E4_COMPLETION_LEDGER_{STAMP}"
OUT.mkdir(exist_ok=False)

TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return {"_read_error": f"{type(error).__name__}: {error}"}

injection_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job = INJ / scenario / attack
        receipt_path = job / "receipt.json"
        outputs_path = job / "primary_outputs.npz"
        features_path = job / "attacked_selected_features.csv.gz"

        receipt = (
            read_json(receipt_path)
            if receipt_path.is_file() else {}
        )

        # Correct criterion:
        # receipt + primary prediction outputs constitute the completed
        # compact injection job. The selected feature artifact is optional.
        complete = bool(
            receipt.get("status") == "INJECTION_JOB_COMPLETE"
            and outputs_path.is_file()
        )

        injection_rows.append({
            "scenario": scenario,
            "attack": attack,
            "complete": complete,
            "receipt_status": receipt.get("status"),
            "primary_outputs_present": outputs_path.is_file(),
            "optional_features_present": features_path.is_file(),
            "receipt_path": str(receipt_path),
        })

pacing_rows = []
for scenario in TARGETS:
    job = PACE / scenario
    receipt_path = job / "receipt.json"
    results_path = job / "detector_results.csv"

    receipt = (
        read_json(receipt_path)
        if receipt_path.is_file() else {}
    )
    complete = bool(
        receipt.get("status") == "PACING_JOB_COMPLETE"
        and results_path.is_file()
    )

    pacing_rows.append({
        "scenario": scenario,
        "complete": complete,
        "receipt_status": receipt.get("status"),
        "detector_results_present": results_path.is_file(),
        "eligible_flows": receipt.get("eligible_flows"),
        "delayed_packets": receipt.get("delayed_packets"),
        "mapping_fraction": receipt.get("mapping_fraction"),
    })

injection = pd.DataFrame(injection_rows)
pacing = pd.DataFrame(pacing_rows)

if injection.complete.sum() != 16:
    raise RuntimeError(
        "Unexpected injection state. Expected 16 valid receipt/output "
        f"pairs but found {int(injection.complete.sum())}."
    )

if pacing.complete.sum() != 7:
    raise RuntimeError(
        "Unexpected pacing state. Expected 7 completed jobs but found "
        f"{int(pacing.complete.sum())}."
    )

pending = pacing.loc[~pacing.complete, "scenario"].tolist()
if pending != ["CTU-IoT-Malware-Capture-49-1"]:
    raise RuntimeError(f"Unexpected pending pacing scenarios: {pending}")

injection.to_csv(OUT / "injection_jobs.csv", index=False)
pacing.to_csv(OUT / "pacing_jobs.csv", index=False)

ledger = pd.DataFrame([
    {
        "experiment": "E4 compact injections",
        "required_jobs": 16,
        "completed_jobs": int(injection.complete.sum()),
        "status": "COMPLETE — DO NOT RERUN",
        "completion_rule": (
            "INJECTION_JOB_COMPLETE receipt plus primary_outputs.npz"
        ),
    },
    {
        "experiment": "E4 PACE_1s",
        "required_jobs": 8,
        "completed_jobs": int(pacing.complete.sum()),
        "status": "ONE JOB REMAINS",
        "completion_rule": (
            "PACING_JOB_COMPLETE receipt plus detector_results.csv"
        ),
    },
    {
        "experiment": "Missing pacing target",
        "required_jobs": 1,
        "completed_jobs": 0,
        "status": "CTU-IoT-Malware-Capture-49-1",
        "completion_rule": "Run once after disk-space preflight passes",
    },
], columns=[
    "experiment", "required_jobs", "completed_jobs",
    "status", "completion_rule"
])

ledger.to_csv(OUT / "corrected_ledger.csv", index=False)

receipt = {
    "status": "CORRECTED_E4_AUDIT_COMPLETE",
    "injections_complete": int(injection.complete.sum()),
    "pacing_complete": int(pacing.complete.sum()),
    "pending_pacing": pending,
    "important_correction": (
        "Missing attacked_selected_features.csv.gz does not invalidate "
        "a completed injection job when receipt and primary outputs exist."
    ),
    "injections_rerun": 0,
    "files_deleted": 0,
}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2))

print("CORRECTED E4 LEDGER")
print(ledger.to_string(index=False))

print("\nINJECTION COMPLETION CHECK")
print(
    injection.groupby(
        ["complete", "optional_features_present"],
        dropna=False
    ).size().rename("jobs").reset_index().to_string(index=False)
)

print("\nPACE STATUS")
print(pacing.to_string(index=False))

print("\nRECEIPT")
print(json.dumps(receipt, indent=2))
print(f"\nSaved: {OUT}")

# ===== CELL INPUT 32 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil

WORK = Path("/kaggle/working").resolve()

FULL_BACKUP = Path(
    "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
    "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
).resolve()

ONE_LAST = Path(
    "/kaggle/input/datasets/mdhamidborkottulla/one-last/"
    "PRIVATE_TRACE_CONFIRMATORY_TODAY_20261012T191221683578Z/"
    "trace_confirmatory_today"
).resolve()

STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
RECEIPT = WORK / f"VERIFIED_DUPLICATE_SPACE_CLEANUP_{STAMP}.json"

# Only these explicitly listed working copies may be deleted, and only after
# every source/destination file is size- and SHA-256-identical.
CANDIDATES = [
    {
        "working": WORK / "PRIVATE_TRACE_CONFIRMATORY_TODAY_20261012T191221683578Z",
        "backup": ONE_LAST,
        "label": "private_trace_backup_copy",
    },
    {
        "working": WORK / "TRACE_CONFIRMATORY_RESULTS_v1_1",
        "backup": FULL_BACKUP / "TRACE_CONFIRMATORY_RESULTS_v1_1",
        "label": "confirmatory_results_duplicate",
    },
    {
        "working": WORK / "resume_verified_20261011T144807877506Z",
        "backup": FULL_BACKUP / "resume_verified_20261011T144807877506Z",
        "label": "resume_verified_duplicate",
    },
    {
        "working": WORK / "TRACE_PACKET_INJECTION_1_1_20261012T115115809570Z",
        "backup": FULL_BACKUP / "TRACE_PACKET_INJECTION_1_1_20261012T115115809570Z",
        "label": "packet_injection_duplicate",
    },
    {
        "working": WORK / "PLAN_CLOSURE_AUDIT_20261011T152520447854Z",
        "backup": FULL_BACKUP / "PLAN_CLOSURE_AUDIT_20261011T152520447854Z",
        "label": "plan_closure_audit_1_duplicate",
    },
    {
        "working": WORK / "PLAN_CLOSURE_AUDIT_20261011T153510820175Z",
        "backup": FULL_BACKUP / "PLAN_CLOSURE_AUDIT_20261011T153510820175Z",
        "label": "plan_closure_audit_2_duplicate",
    },
]

PROTECTED = {
    "E1_BLIND_TARGETS_20261012T125026604016Z",
    "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2",
    "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z",
    "E4_COMPACT_INJECTIONS_v2",
    "E4_COMPACT_PACING_v1",
}

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def directory_manifest(root):
    if not root.is_dir():
        raise FileNotFoundError(f"Directory missing: {root}")

    manifest = {}

    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)

        for name in names:
            path = current / name
            relative = path.relative_to(root).as_posix()

            if path.is_symlink():
                manifest[relative] = {
                    "type": "symlink",
                    "target": os.readlink(path),
                    "bytes": path.lstat().st_size,
                }
            else:
                manifest[relative] = {
                    "type": "file",
                    "bytes": path.stat().st_size,
                    "path": path,
                }

    return manifest

def directory_size(path):
    total = 0
    files = 0

    for current, dirs, names in os.walk(path, followlinks=False):
        current = Path(current)

        for name in names:
            item = current / name
            total += item.lstat().st_size
            files += 1

    return total, files

def exact_directory_match(working_dir, backup_dir):
    working_manifest = directory_manifest(working_dir)
    backup_manifest = directory_manifest(backup_dir)

    if set(working_manifest) != set(backup_manifest):
        missing_from_backup = sorted(
            set(working_manifest) - set(backup_manifest)
        )
        missing_from_working = sorted(
            set(backup_manifest) - set(working_manifest)
        )
        return False, {
            "reason": "different_relative_file_sets",
            "missing_from_backup": missing_from_backup[:20],
            "missing_from_working": missing_from_working[:20],
        }

    checked = 0

    for relative in sorted(working_manifest):
        left = working_manifest[relative]
        right = backup_manifest[relative]

        if left["type"] != right["type"]:
            return False, {
                "reason": "different_file_types",
                "relative_path": relative,
            }

        if left["type"] == "symlink":
            if left["target"] != right["target"]:
                return False, {
                    "reason": "different_symlink_targets",
                    "relative_path": relative,
                }
            continue

        if left["bytes"] != right["bytes"]:
            return False, {
                "reason": "different_file_sizes",
                "relative_path": relative,
                "working_bytes": left["bytes"],
                "backup_bytes": right["bytes"],
            }

        if sha256_file(left["path"]) != sha256_file(right["path"]):
            return False, {
                "reason": "different_sha256",
                "relative_path": relative,
            }

        checked += 1

    return True, {
        "reason": "all_files_byte_identical",
        "files_verified": checked,
    }

if not FULL_BACKUP.is_dir():
    raise FileNotFoundError(f"Full backup root missing: {FULL_BACKUP}")

if not ONE_LAST.is_dir():
    raise FileNotFoundError(f"One-last backup root missing: {ONE_LAST}")

before = shutil.disk_usage(WORK).free
results = []

for item in CANDIDATES:
    working_dir = item["working"]
    backup_dir = item["backup"]

    record = {
        "label": item["label"],
        "working": str(working_dir),
        "backup": str(backup_dir),
        "deleted": False,
        "freed_bytes": 0,
        "verification": None,
    }

    if working_dir.name in PROTECTED:
        record["verification"] = {
            "reason": "protected_directory_not_eligible_for_deletion"
        }
        results.append(record)
        continue

    if not working_dir.is_dir():
        record["verification"] = {
            "reason": "working_directory_absent_nothing_deleted"
        }
        results.append(record)
        continue

    if not backup_dir.is_dir():
        record["verification"] = {
            "reason": "backup_directory_absent_nothing_deleted"
        }
        results.append(record)
        continue

    print(f"\nVERIFYING DUPLICATE: {item['label']}", flush=True)

    identical, evidence = exact_directory_match(
        working_dir=working_dir,
        backup_dir=backup_dir,
    )
    record["verification"] = evidence

    if not identical:
        print(
            f"KEPT: {working_dir.name} — verification failed: "
            f"{evidence['reason']}",
            flush=True
        )
        results.append(record)
        continue

    bytes_to_free, files_to_free = directory_size(working_dir)

    # Final source verification immediately before deletion.
    identical_again, final_evidence = exact_directory_match(
        working_dir=working_dir,
        backup_dir=backup_dir,
    )

    if not identical_again:
        record["verification"] = {
            "reason": "changed_between_verification_and_deletion",
            "detail": final_evidence,
        }
        results.append(record)
        continue

    shutil.rmtree(working_dir)

    if working_dir.exists():
        raise RuntimeError(
            f"Deletion did not complete for {working_dir}; stopping."
        )

    record["deleted"] = True
    record["freed_bytes"] = bytes_to_free
    record["files_deleted_from_working"] = files_to_free

    print(
        f"DELETED VERIFIED DUPLICATE: {working_dir.name} | "
        f"{bytes_to_free / 1024**3:.4f} GiB | "
        f"{files_to_free:,} files",
        flush=True
    )

    results.append(record)

after = shutil.disk_usage(WORK).free

receipt = {
    "status": "VERIFIED_DUPLICATE_CLEANUP_COMPLETE",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "free_before_GiB": round(before / 1024**3, 4),
    "free_after_GiB": round(after / 1024**3, 4),
    "freed_GiB": round((after - before) / 1024**3, 4),
    "protected_directories_not_deleted": sorted(PROTECTED),
    "candidate_results": results,
    "important": (
        "A working directory was deleted only after every relative file "
        "matched the specified uploaded backup by type, size, and SHA-256."
    ),
}
RECEIPT.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

print("\nCLEANUP RECEIPT")
print(json.dumps(receipt, indent=2))

# ===== CELL INPUT 33 =====
from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import ast
import bisect
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

print("STARTING ONLY THE MISSING CAPTURE 49 PACE_1s JOB", flush=True)

WORK = Path("/kaggle/working").resolve()
SCENARIO = "CTU-IoT-Malware-Capture-49-1"

E1_ROOT = WORK / "E1_BLIND_TARGETS_20261012T125026604016Z"
ASSETS = (
    WORK
    / "TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2"
    / "target_asset_resolution.csv"
)
MODEL = (
    WORK
    / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    / "frozen_source_models.joblib"
)
HELPER = WORK / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
FROZEN_OUTPUTS = (
    WORK
    / "E4_COMPACT_INJECTIONS_v2"
    / SCENARIO
    / "INJ_k1"
    / "primary_outputs.npz"
)
JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
JOB.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

ZEEK_CANDIDATES = [
    Path("/opt/zeek/bin/zeek"),
    Path("/usr/local/bin/zeek"),
    Path("/usr/bin/zeek"),
]

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)

def normalize(frame):
    frame = frame.copy()
    frame["ks"] = frame["ks"].astype(str)
    frame["y"] = pd.to_numeric(frame["y"], errors="raise").astype(int)
    frame["proto"] = frame["proto"].astype(str).str.lower()

    for column in FEATURES:
        if column != "proto":
            frame[column] = pd.to_numeric(
                frame[column].replace("-", np.nan),
                errors="coerce"
            ).fillna(0).clip(lower=0)

    return frame

def asset_value(row, column):
    if column not in row.index:
        raise RuntimeError(f"Asset manifest has no {column} column.")

    value = row[column]

    if pd.isna(value) or not str(value).strip():
        raise RuntimeError(f"Asset manifest has empty {column} value.")

    return str(value)

def all_e1_files():
    if not E1_ROOT.is_dir():
        raise FileNotFoundError(f"E1 root missing: {E1_ROOT}")

    found = []

    for current, dirs, names in os.walk(E1_ROOT, followlinks=False):
        current = Path(current)

        for name in names:
            candidate = current / name
            if candidate.is_file():
                found.append(candidate)

    if not found:
        raise RuntimeError("E1 root contains no files.")

    return found

def resolve_e1_file(files, expected_sha256, kind):
    if kind == "features":
        preferred = [
            path for path in files
            if SCENARIO.lower() in path.name.lower()
            and "feature" in path.name.lower()
        ]
    elif kind == "conn":
        preferred = [
            path for path in files
            if SCENARIO.lower() in path.name.lower()
            and "conn" in path.name.lower()
        ]
    elif kind == "pcap":
        preferred = [
            path for path in files
            if SCENARIO.lower() in path.name.lower()
            and path.name.lower().endswith((".pcap", ".cap"))
        ]
    else:
        raise ValueError(f"Unknown E1 artifact kind: {kind}")

    ordered = preferred + [
        path for path in files if path not in preferred
    ]

    matches = []

    for index, candidate in enumerate(ordered, start=1):
        if sha256_file(candidate) == expected_sha256:
            matches.append(candidate)

        if index % 5 == 0 or index == len(ordered):
            print(
                f"Resolved {kind}: hash-checked "
                f"{index}/{len(ordered)} E1 files",
                flush=True
            )

    if len(matches) != 1:
        raise RuntimeError(
            f"Could not uniquely resolve Capture 49 {kind} from "
            f"the frozen SHA-256 manifest. Matches={len(matches)}."
        )

    return matches[0]

def get_helpers(helper_path):
    required = {
        "key", "skey", "mat",
        "pcap_iter", "pcap_header",
        "tcp", "log_iter",
    }

    tree = ast.parse(helper_path.read_text(encoding="utf-8"))
    definitions = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name in required
    ]

    found = {node.name for node in definitions}

    if found != required:
        raise RuntimeError(
            "Missing helper definitions: "
            + ", ".join(sorted(required - found))
        )

    namespace = dict(globals())
    exec(
        compile(
            ast.fix_missing_locations(
                ast.Module(body=definitions, type_ignores=[])
            ),
            "capture49_pace_helpers",
            "exec",
        ),
        namespace,
    )

    return namespace

def zeek_memory_limit():
    resource.setrlimit(
        resource.RLIMIT_AS,
        (6 * 1024**3, 6 * 1024**3),
    )

for required_path in [
    E1_ROOT, ASSETS, MODEL, HELPER, FROZEN_OUTPUTS
]:
    if not required_path.exists():
        raise FileNotFoundError(
            f"Required existing artifact missing: {required_path}"
        )

existing_receipt = JOB / "receipt.json"

if existing_receipt.is_file():
    previous = json.loads(existing_receipt.read_text())

    if previous.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError(
            "Capture 49 PACE_1s is already complete; no rerun is allowed."
        )

zeek = next(
    (candidate for candidate in ZEEK_CANDIDATES if candidate.is_file()),
    None
)

if zeek is None:
    raise FileNotFoundError("Zeek executable is unavailable.")

assets = pd.read_csv(ASSETS)
selected_asset = assets[
    (assets.scenario == SCENARIO)
    & (assets.status == "RESOLVED")
]

if len(selected_asset) != 1:
    raise RuntimeError(
        f"Expected one resolved Capture 49 asset row; got {len(selected_asset)}."
    )

asset = selected_asset.iloc[0]
e1_files = all_e1_files()

features_file = resolve_e1_file(
    e1_files,
    asset_value(asset, "features_sha256"),
    "features",
)
conn_log = resolve_e1_file(
    e1_files,
    asset_value(asset, "conn_log_sha256"),
    "conn",
)
pcap = resolve_e1_file(
    e1_files,
    asset_value(asset, "pcap_sha256"),
    "pcap",
)

resolved = {
    "status": "CAPTURE49_E1_ASSETS_RESOLVED_BY_SHA256",
    "scenario": SCENARIO,
    "features_file": str(features_file),
    "conn_log": str(conn_log),
    "pcap": str(pcap),
    "features_sha256": sha256_file(features_file),
    "conn_log_sha256": sha256_file(conn_log),
    "pcap_sha256": sha256_file(pcap),
    "pcap_GiB": round(pcap.stat().st_size / 1024**3, 4),
    "old_absolute_paths_used": False,
    "files_deleted": 0,
    "backup_copied": False,
}
atomic_json(JOB / "capture49_resolved_assets.json", resolved)

with np.load(FROZEN_OUTPUTS, allow_pickle=True) as frozen:
    frozen_keys = frozen["ks"].astype(str)
    frozen_y = frozen["y"].astype(int)
    frozen_clean_probabilities = {
        str(seed): frozen[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if (
    len(frozen_keys) != 1024
    or len(set(frozen_keys)) != 1024
    or int((frozen_y == 0).sum()) != 512
    or int((frozen_y == 1).sum()) != 512
):
    raise RuntimeError(
        "Completed Capture 49 injection output does not preserve "
        "the expected frozen 512/512 evaluation membership."
    )

wanted_keys = set(frozen_keys)
chunks = []
found_keys = set()

print("BUILDING EXACT FROZEN CAPTURE 49 SAMPLE FROM E1 FEATURES...", flush=True)

for chunk in pd.read_csv(
    features_file,
    compression="gzip",
    dtype={"ks": str},
    chunksize=250_000,
):
    if "ks" not in chunk.columns or "y" not in chunk.columns:
        raise RuntimeError("E1 features table lacks ks/y columns.")

    selected = chunk[chunk.ks.astype(str).isin(wanted_keys)].copy()

    if not selected.empty:
        selected["ks"] = selected.ks.astype(str)

        duplicate = set(selected.ks) & found_keys
        if duplicate:
            raise RuntimeError(
                "A frozen Capture 49 key appears multiple times in E1 features."
            )

        chunks.append(selected)
        found_keys.update(selected.ks)

if found_keys != wanted_keys:
    raise RuntimeError(
        "E1 Capture 49 features do not contain all frozen membership keys. "
        f"Missing={len(wanted_keys - found_keys)}."
    )

sample = pd.concat(chunks, ignore_index=True)
sample = sample.set_index("ks").loc[frozen_keys].reset_index()
sample["y"] = frozen_y
sample = normalize(sample)

helpers = get_helpers(HELPER)
key = helpers["key"]
skey = helpers["skey"]
mat = helpers["mat"]
pcap_iter = helpers["pcap_iter"]
pcap_header = helpers["pcap_header"]
tcp = helpers["tcp"]
log_iter = helpers["log_iter"]

bundle = joblib.load(MODEL)
verification = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)
        recomputed = bank["PRIMARY"].predict_proba(
            mat(sample, FEATURES)
        )[:, 1]

        saved = frozen_clean_probabilities[seed]

        verification.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(recomputed - saved))
            ),
            "clean_decision_mismatches": int(
                ((recomputed >= 0.5) != (saved >= 0.5)).sum()
            ),
        })

verification = pd.DataFrame(verification)

if not (
    (verification.max_clean_probability_difference <= 1e-12).all()
    and (verification.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "Freshly rebuilt Capture 49 E1 sample does not exactly reproduce "
        "frozen primary predictions. Pacing is blocked."
    )

sample_path = JOB / "capture49_frozen_sample_verified.csv.gz"
sample.to_csv(sample_path, index=False, compression="gzip")
verification.to_csv(
    JOB / "capture49_clean_prediction_verification.csv",
    index=False,
)

sample_receipt = {
    "status": "CAPTURE49_FROZEN_SAMPLE_VERIFIED",
    "scenario": SCENARIO,
    "sample_path": str(sample_path),
    "sample_sha256": sha256_file(sample_path),
    "rows": len(sample),
    "benign_rows": int((sample.y == 0).sum()),
    "malicious_rows": int((sample.y == 1).sum()),
    "exact_clean_prediction_reproduction": True,
    "new_sample_selected": False,
    "models_retrained": False,
    "pcap_replay_started": False,
}
atomic_json(JOB / "capture49_sample_receipt.json", sample_receipt)

clean_flows = {}

for row in log_iter(conn_log):
    flow_key = skey(key(
        row["ts"],
        row["id.orig_h"],
        row["id.orig_p"],
        row["id.resp_h"],
        row["id.resp_p"],
        row["proto"],
    ))

    if flow_key in wanted_keys:
        if flow_key in clean_flows:
            raise RuntimeError(
                f"Ambiguous selected clean-flow key: {flow_key}"
            )
        clean_flows[flow_key] = row

if set(clean_flows) != wanted_keys:
    raise RuntimeError(
        "Selected frozen keys do not uniquely resolve in Capture 49 conn.log."
    )

labels = dict(zip(sample.ks, sample.y.astype(int)))
descriptions = defaultdict(list)

for flow_key, row in clean_flows.items():
    if labels[flow_key] != 1 or str(row["proto"]).lower() != "tcp":
        continue

    start_ns = int(Decimal(str(row["ts"])) * 10**9)
    duration_ns = (
        0
        if row["duration"] == "-"
        else int(Decimal(str(row["duration"])) * 10**9)
    )

    endpoints = tuple(sorted([
        (row["id.orig_h"], int(row["id.orig_p"])),
        (row["id.resp_h"], int(row["id.resp_p"])),
    ]))

    descriptions[endpoints].append(
        (start_ns, start_ns + duration_ns + 1_000_000, flow_key)
    )

for values in descriptions.values():
    values.sort()

starts = {
    endpoint: [entry[0] for entry in entries]
    for endpoint, entries in descriptions.items()
}

pcap_header_bytes, endian, time_unit, link_type = pcap_header(pcap)

def packet_flow(timestamp_ns, payload):
    parsed = tcp(payload, link_type)

    if parsed is None:
        return None

    source_host, source_port, dest_host, dest_port, _, _ = parsed
    endpoints = tuple(sorted([
        (source_host, source_port),
        (dest_host, dest_port),
    ]))

    if endpoints not in descriptions:
        return None

    position = bisect.bisect_right(
        starts[endpoints],
        timestamp_ns,
    ) - 1

    if position < 0:
        return None

    begin, end, flow_key = descriptions[endpoints][position]
    return flow_key if timestamp_ns <= end else None

counts = defaultdict(int)
first_packet = {}
packet_count = 0
previous_timestamp = None
original_digest = hashlib.sha256()

print("FIRST PACKET PASS: COUNTING CAPTURE 49 ELIGIBLE FLOWS...", flush=True)

for packet_index, timestamp_ns, wire_bytes, payload in pcap_iter(pcap):
    if previous_timestamp is not None and timestamp_ns < previous_timestamp:
        raise RuntimeError("Source PCAP timestamps are not nondecreasing.")

    previous_timestamp = timestamp_ns
    packet_count += 1

    original_digest.update(struct.pack("!II", len(payload), wire_bytes))
    original_digest.update(payload)

    flow_key = packet_flow(timestamp_ns, payload)

    if flow_key is not None:
        counts[flow_key] += 1
        first_packet.setdefault(flow_key, packet_index)

eligible_flows = {
    flow_key for flow_key, count in counts.items()
    if count >= 2
}

free_space = shutil.disk_usage(WORK).free

# One temporary transformed PCAP + on-disk offset index + 1.25 GiB reserve.
required_space = (
    pcap.stat().st_size
    + packet_count * 80
    + int(1.25 * 1024**3)
)

preflight = {
    "status": (
        "PREFLIGHT_PASS"
        if free_space >= required_space and eligible_flows
        else "PREFLIGHT_BLOCKED"
    ),
    "scenario": SCENARIO,
    "source_pcap_GiB": round(pcap.stat().st_size / 1024**3, 4),
    "packet_count": packet_count,
    "eligible_flows": len(eligible_flows),
    "free_working_GiB": round(free_space / 1024**3, 4),
    "required_working_GiB": round(required_space / 1024**3, 4),
    "space_margin_GiB": round(
        (free_space - required_space) / 1024**3,
        4,
    ),
    "completed_jobs_rerun": 0,
    "temporary_replay_retained": False,
}
atomic_json(JOB / "capture49_pacing_preflight.json", preflight)

print("\nPRE-FLIGHT")
print(json.dumps(preflight, indent=2))

if free_space < required_space:
    raise RuntimeError(
        "PACE did not start: insufficient safe working space."
    )

if not eligible_flows:
    raise RuntimeError(
        "PACE did not start: Capture 49 has zero eligible selected "
        "malicious TCP flows with at least two packets."
    )

temporary = Path(tempfile.mkdtemp(prefix="capture49_pace_", dir=JOB))
database = None
started = time.time()

try:
    database = sqlite3.connect(temporary / "packet_order.sqlite")
    database.execute("PRAGMA journal_mode=OFF")
    database.execute("PRAGMA synchronous=OFF")
    database.execute("PRAGMA temp_store=FILE")
    database.execute(
        "CREATE TABLE records ("
        "ts INTEGER, idx INTEGER, offset INTEGER, cap INTEGER, wire INTEGER)"
    )

    offset = 24
    batch = []
    delayed = defaultdict(int)

    print("BUILDING DISK-BACKED PACING ORDER...", flush=True)

    for packet_index, timestamp_ns, wire_bytes, payload in pcap_iter(pcap):
        flow_key = packet_flow(timestamp_ns, payload)

        delay_ns = (
            1_000_000_000
            if flow_key in eligible_flows
            and packet_index != first_packet[flow_key]
            else 0
        )

        if delay_ns:
            delayed[flow_key] += 1

        batch.append((
            timestamp_ns + delay_ns,
            packet_index,
            offset + 16,
            len(payload),
            wire_bytes,
        ))

        offset += 16 + len(payload)

        if len(batch) >= 20_000:
            database.executemany(
                "INSERT INTO records VALUES (?,?,?,?,?)",
                batch,
            )
            batch.clear()

    if batch:
        database.executemany(
            "INSERT INTO records VALUES (?,?,?,?,?)",
            batch,
        )

    database.commit()
    database.execute("CREATE INDEX time_order ON records(ts, idx)")
    database.commit()

    transformed = temporary / "capture49_pace_1s.pcap"
    copied_digest = hashlib.sha256()
    output_count = 0
    last_output_timestamp = None
    last_packet_index = {}
    per_flow_order_ok = True

    print("VERIFYING ORIGINAL PACKET BYTES...", flush=True)

    with open(pcap, "rb") as source:
        for offset_payload, captured, wire in database.execute(
            "SELECT offset, cap, wire FROM records ORDER BY idx"
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise RuntimeError("Truncated source packet during validation.")

            copied_digest.update(struct.pack("!II", captured, wire))
            copied_digest.update(payload)

    if copied_digest.digest() != original_digest.digest():
        raise RuntimeError("Original source packet bytes do not match.")

    print("WRITING PACED CAPTURE 49 PCAP...", flush=True)

    with open(pcap, "rb") as source, open(transformed, "wb") as target:
        target.write(pcap_header_bytes)

        query = (
            "SELECT ts, idx, offset, cap, wire "
            "FROM records ORDER BY ts, idx"
        )

        for timestamp_ns, packet_index, offset_payload, captured, wire in (
            database.execute(query)
        ):
            source.seek(offset_payload)
            payload = source.read(captured)

            if len(payload) != captured:
                raise RuntimeError("Truncated packet during paced output.")

            if (
                last_output_timestamp is not None
                and timestamp_ns < last_output_timestamp
            ):
                raise RuntimeError("Output PCAP timestamps are unordered.")

            last_output_timestamp = timestamp_ns

            source.seek(offset_payload - 16)
            seconds, fraction, _, _ = struct.unpack(
                endian + "IIII",
                source.read(16),
            )
            original_timestamp_ns = seconds * 10**9 + fraction * time_unit

            flow_key = packet_flow(original_timestamp_ns, payload)

            if flow_key is not None:
                previous_index = last_packet_index.get(flow_key)

                if (
                    previous_index is not None
                    and packet_index <= previous_index
                ):
                    per_flow_order_ok = False

                last_packet_index[flow_key] = packet_index

            actual_delay = timestamp_ns - original_timestamp_ns

            if actual_delay not in {0, 1_000_000_000}:
                raise RuntimeError("Invalid pacing delay detected.")

            if timestamp_ns < original_timestamp_ns:
                raise RuntimeError("A packet was advanced.")

            target.write(struct.pack(
                endian + "IIII",
                timestamp_ns // 10**9,
                (timestamp_ns % 10**9) // time_unit,
                captured,
                wire,
            ))
            target.write(payload)
            output_count += 1

    if output_count != packet_count:
        raise RuntimeError("Paced output packet count differs from source.")

    if not per_flow_order_ok:
        raise RuntimeError("Selected-flow packet order changed.")

    transformed_sha256 = sha256_file(transformed)

    database.close()
    database = None

    print("RUNNING ZEEK ON PACED CAPTURE 49...", flush=True)

    with open(temporary / "zeek_stdout.txt", "w") as stdout, \
         open(temporary / "zeek_stderr.txt", "w") as stderr:

        process = subprocess.run(
            [str(zeek), "-C", "-r", str(transformed)],
            cwd=temporary,
            stdout=stdout,
            stderr=stderr,
            timeout=1800,
            preexec_fn=zeek_memory_limit,
        )

    paced_conn = temporary / "conn.log"

    if process.returncode != 0 or not paced_conn.is_file():
        raise RuntimeError(
            f"Zeek failed with exit code {process.returncode}."
        )

    mapped = {}
    duplicates = set()

    for row in log_iter(paced_conn):
        flow_key = skey(key(
            row["ts"],
            row["id.orig_h"],
            row["id.orig_p"],
            row["id.resp_h"],
            row["id.resp_p"],
            row["proto"],
        ))

        if flow_key in wanted_keys:
            if flow_key in mapped:
                duplicates.add(flow_key)

            mapped[flow_key] = row

    missing = sorted(wanted_keys - set(mapped))

    mapping = {
        "scenario": SCENARIO,
        "sample_rows": len(sample),
        "mapped_rows": len(mapped),
        "mapping_fraction": len(mapped) / len(sample),
        "missing_keys": missing,
        "ambiguous_keys": sorted(duplicates),
    }
    atomic_json(JOB / "mapping_diagnostic.json", mapping)

    if missing or duplicates:
        raise RuntimeError(
            "Exact selected-flow mapping failed. No flow was dropped "
            "or relabeled."
        )

    attacked = normalize(pd.DataFrame([
        {
            **{column: mapped[flow_key][column] for column in FEATURES},
            "ks": flow_key,
            "y": labels[flow_key],
        }
        for flow_key in sample.ks
    ]))

    attacked.to_csv(
        JOB / "attacked_selected_features.csv.gz",
        index=False,
        compression="gzip",
    )

    results = []
    outputs = {
        "ks": sample.ks.to_numpy(dtype=str),
        "y": sample.y.to_numpy(dtype=int),
    }

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            clean_probability = bank["PRIMARY"].predict_proba(
                mat(sample, FEATURES)
            )[:, 1]

            paced_probability = bank["PRIMARY"].predict_proba(
                mat(attacked, FEATURES)
            )[:, 1]

            clean_accuracy = float(
                ((clean_probability >= 0.5) == sample.y.to_numpy()).mean()
            )
            paced_accuracy = float(
                ((paced_probability >= 0.5) == sample.y.to_numpy()).mean()
            )

            results.append({
                "scenario": SCENARIO,
                "attack": "PACE_1s",
                "seed": int(seed),
                "clean_accuracy": clean_accuracy,
                "attack_accuracy": paced_accuracy,
                "true_damage": clean_accuracy - paced_accuracy,
                "eligible_flows": len(eligible_flows),
                "delayed_packets": int(sum(delayed.values())),
                "mapped_fraction": 1.0,
            })

            outputs[f"seed_{seed}_clean_probability"] = clean_probability
            outputs[f"seed_{seed}_attack_probability"] = paced_probability

    results = pd.DataFrame(results)
    results.to_csv(JOB / "detector_results.csv", index=False)
    np.savez_compressed(JOB / "primary_outputs.npz", **outputs)

    receipt = {
        "status": "PACING_JOB_COMPLETE",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "sample_path": str(sample_path),
        "sample_sha256": sha256_file(sample_path),
        "source_pcap": str(pcap),
        "source_pcap_sha256": sha256_file(pcap),
        "transformed_pcap_sha256": transformed_sha256,
        "original_packet_count": packet_count,
        "eligible_flows": len(eligible_flows),
        "delayed_packets": int(sum(delayed.values())),
        "mapping_fraction": 1.0,
        "original_bytes_verified": True,
        "per_selected_flow_order_verified": True,
        "no_packet_advanced": True,
        "output_timestamps_nondecreasing": True,
        "models_retrained": False,
        "temporary_replays_retained": False,
        "seconds": round(time.time() - started, 2),
    }
    atomic_json(JOB / "receipt.json", receipt)

    print("\nCAPTURE 49 PACE_1s RESULTS")
    print(results.to_string(index=False))
    print("\nCOMPLETION RECEIPT")
    print(json.dumps(receipt, indent=2))

except Exception as error:
    atomic_json(JOB / "failure.json", {
        "status": "INCOMPLETE_NOT_A_RESULT",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "error": f"{type(error).__name__}: {error}",
        "temporary_replays_retained": False,
    })
    raise

finally:
    if database is not None:
        database.close()

    shutil.rmtree(temporary, ignore_errors=True)

# ===== CELL INPUT 34 =====
from pathlib import Path
from collections import defaultdict
from decimal import Decimal
import ast, bisect, hashlib, json, os, resource, shutil
import sqlite3, struct, subprocess, tempfile, time
import gzip, ipaddress
import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

print("SELF-CONTAINED CAPTURE 49 PACE_1s RUNNER", flush=True)

WORK = Path("/kaggle/working").resolve()
E1 = WORK / "E1_BLIND_TARGETS_20261012T125026604016Z"
SCENARIO = "CTU-IoT-Malware-Capture-49-1"
JOB = WORK / "E4_COMPACT_PACING_v1" / SCENARIO
MODEL = WORK / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
HELPER = WORK / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
FROZEN = WORK / f"E4_COMPACT_INJECTIONS_v2/{SCENARIO}/INJ_k1/primary_outputs.npz"
ZEEK = Path("/opt/zeek/bin/zeek")

F = [
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
    "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
]

def hfile(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()

def dump(path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temp.replace(path)

def norm(df):
    df = df.copy()
    df["ks"] = df["ks"].astype(str)
    df["y"] = pd.to_numeric(df["y"], errors="raise").astype(int)
    df["proto"] = df["proto"].astype(str).str.lower()
    for c in F:
        if c != "proto":
            df[c] = pd.to_numeric(
                df[c].replace("-", np.nan), errors="coerce"
            ).fillna(0).clip(lower=0)
    return df

for p in [E1, MODEL, HELPER, FROZEN, ZEEK]:
    if not p.exists():
        raise FileNotFoundError(f"Required artifact missing: {p}")

JOB.mkdir(parents=True, exist_ok=True)

if (JOB / "receipt.json").is_file():
    old = json.loads((JOB / "receipt.json").read_text())
    if old.get("status") == "PACING_JOB_COMPLETE":
        raise RuntimeError("Capture 49 pacing is already complete.")

# Extract exactly the helper functions used by the original notebook runner.
needed = {"key", "skey", "mat", "pcap_iter", "pcap_header", "tcp", "log_iter"}
tree = ast.parse(HELPER.read_text(encoding="utf-8"))
defs = [
    n for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name in needed
]
if {n.name for n in defs} != needed:
    raise RuntimeError("Original runner helper definitions are incomplete.")

ns = dict(globals())
ns.update({"gzip": gzip, "ipaddress": ipaddress})
exec(
    compile(
        ast.fix_missing_locations(ast.Module(body=defs, type_ignores=[])),
        "capture49_original_helpers",
        "exec"
    ),
    ns
)

key = ns["key"]
skey = ns["skey"]
mat = ns["mat"]
pcap_iter = ns["pcap_iter"]
pcap_header = ns["pcap_header"]
tcp = ns["tcp"]
log_iter = ns["log_iter"]

# Use the already completed injection output as the frozen membership record.
with np.load(FROZEN, allow_pickle=True) as z:
    ks = z["ks"].astype(str)
    y = z["y"].astype(int)
    clean_saved = {
        str(seed): z[f"seed_{seed}_clean_probability"].astype(float)
        for seed in [8101, 8102, 8103]
    }

if len(ks) != 1024 or len(set(ks)) != 1024:
    raise RuntimeError("Frozen Capture 49 membership is not 1,024 unique keys.")

if int((y == 0).sum()) != 512 or int((y == 1).sum()) != 512:
    raise RuntimeError("Frozen Capture 49 membership is not 512 benign / 512 malicious.")

wanted = set(ks)
labels = dict(zip(ks, y))

# Find the one actual Capture 49 PCAP in the restored E1 assets.
pcaps = sorted([
    p for p in E1.rglob("*")
    if p.is_file()
    and SCENARIO in p.name
    and p.suffix.lower() in {".pcap", ".cap"}
])

if len(pcaps) != 1:
    raise RuntimeError(
        f"Expected exactly one Capture 49 PCAP under E1; found {len(pcaps)}: "
        + "\n".join(map(str, pcaps))
    )

pcap = pcaps[0]

# Find the correct conn log by testing actual frozen key recovery.
conn_candidates = sorted([
    p for p in E1.rglob("*")
    if p.is_file()
    and SCENARIO in p.name
    and "conn" in p.name.lower()
    and p.name.lower().endswith((".log", ".log.gz"))
])

if not conn_candidates:
    raise RuntimeError("No Capture 49 conn-log candidate exists under E1.")

separators = [",", "|", "_", ""]

def score_conn(path):
    best = (-1, None)
    for sep in separators:
        score = 0
        try:
            for row in log_iter(path):
                flow_key = skey(key(
                    row["ts"], row["id.orig_h"], row["id.orig_p"],
                    row["id.resp_h"], row["id.resp_p"], row["proto"]
                ), sep)
                if flow_key in wanted:
                    score += 1
        except Exception:
            continue
        if score > best[0]:
            best = (score, sep)
    return best

scores = []
for candidate in conn_candidates:
    score, separator = score_conn(candidate)
    scores.append({
        "path": candidate,
        "score": score,
        "separator": separator,
    })
    print(
        f"Conn candidate: {candidate.name} | "
        f"matched frozen keys: {score}",
        flush=True
    )

best = max(scores, key=lambda r: r["score"])
if best["score"] != 1024:
    raise RuntimeError(
        "No Capture 49 conn log resolves all 1,024 frozen keys. "
        f"Best score={best['score']}."
    )

conn = best["path"]
sep = best["separator"]

clean_rows = {}
for row in log_iter(conn):
    flow_key = skey(key(
        row["ts"], row["id.orig_h"], row["id.orig_p"],
        row["id.resp_h"], row["id.resp_p"], row["proto"]
    ), sep)

    if flow_key in wanted:
        if flow_key in clean_rows:
            raise RuntimeError(f"Duplicate frozen flow key in conn log: {flow_key}")
        clean_rows[flow_key] = row

if set(clean_rows) != wanted:
    raise RuntimeError("Frozen keys did not resolve uniquely in selected conn log.")

sample = norm(pd.DataFrame([
    {**{c: clean_rows[k][c] for c in F}, "ks": k, "y": labels[k]}
    for k in ks
]))

bundle = joblib.load(MODEL)
checks = []

with threadpool_limits(limits=2):
    for seed, bank in bundle["models"].items():
        seed = str(seed)
        p = bank["PRIMARY"].predict_proba(mat(sample, F))[:, 1]
        checks.append({
            "seed": int(seed),
            "max_clean_probability_difference": float(
                np.max(np.abs(p - clean_saved[seed]))
            ),
            "clean_decision_mismatches": int(
                ((p >= .5) != (clean_saved[seed] >= .5)).sum()
            ),
        })

checks = pd.DataFrame(checks)

if not (
    (checks.max_clean_probability_difference <= 1e-12).all()
    and (checks.clean_decision_mismatches == 0).all()
):
    raise RuntimeError(
        "Rebuilt Capture 49 sample does not exactly reproduce frozen "
        "clean predictions; pacing is blocked."
    )

sample_path = JOB / "capture49_frozen_sample_verified.csv.gz"
sample.to_csv(sample_path, index=False, compression="gzip")
checks.to_csv(JOB / "capture49_clean_prediction_check.csv", index=False)

header, endian, unit, linktype = pcap_header(pcap)

descriptions = defaultdict(list)
for flow_key, row in clean_rows.items():
    if labels[flow_key] != 1 or row["proto"].lower() != "tcp":
        continue
    start = int(Decimal(str(row["ts"])) * 10**9)
    duration = (
        0 if row["duration"] == "-"
        else int(Decimal(str(row["duration"])) * 10**9)
    )
    endpoints = tuple(sorted([
        (row["id.orig_h"], int(row["id.orig_p"])),
        (row["id.resp_h"], int(row["id.resp_p"])),
    ]))
    descriptions[endpoints].append(
        (start, start + duration + 1_000_000, flow_key)
    )

for values in descriptions.values():
    values.sort()

starts = {
    endpoint: [value[0] for value in values]
    for endpoint, values in descriptions.items()
}

def packet_flow(timestamp, payload):
    info = tcp(payload, linktype)
    if info is None:
        return None
    src, sp, dst, dp, _, _ = info
    endpoint = tuple(sorted([(src, sp), (dst, dp)]))
    if endpoint not in descriptions:
        return None
    j = bisect.bisect_right(starts[endpoint], timestamp) - 1
    if j < 0:
        return None
    begin, end, flow_key = descriptions[endpoint][j]
    return flow_key if timestamp <= end else None

packet_count = 0
counts = defaultdict(int)
first_packet = {}
original_digest = hashlib.sha256()
previous_ts = None

print("First PCAP pass: identifying eligible Capture 49 flows...", flush=True)

for index, timestamp, wire, payload in pcap_iter(pcap):
    if previous_ts is not None and timestamp < previous_ts:
        raise RuntimeError("Source PCAP timestamps are unordered.")
    previous_ts = timestamp
    packet_count += 1
    original_digest.update(struct.pack("!II", len(payload), wire))
    original_digest.update(payload)

    flow_key = packet_flow(timestamp, payload)
    if flow_key is not None:
        counts[flow_key] += 1
        first_packet.setdefault(flow_key, index)

eligible = {k for k, n in counts.items() if n >= 2}

# One paced PCAP + SQLite scalar index + 1 GiB reserve.
needed_space = pcap.stat().st_size + packet_count * 80 + 1024**3
free_space = shutil.disk_usage(WORK).free

preflight = {
    "scenario": SCENARIO,
    "pcap": str(pcap),
    "conn_log": str(conn),
    "key_separator": sep,
    "pcap_GiB": round(pcap.stat().st_size / 1024**3, 4),
    "source_packet_count": packet_count,
    "eligible_flows": len(eligible),
    "free_GiB": round(free_space / 1024**3, 4),
    "required_GiB": round(needed_space / 1024**3, 4),
    "status": (
        "PREFLIGHT_PASS"
        if free_space >= needed_space and eligible
        else "PREFLIGHT_BLOCKED"
    ),
}
dump(JOB / "capture49_pacing_preflight.json", preflight)
print(json.dumps(preflight, indent=2))

if free_space < needed_space:
    raise RuntimeError("Insufficient safe disk space; pacing did not start.")
if not eligible:
    raise RuntimeError("Zero eligible flows; pacing did not start.")

tmp = Path(tempfile.mkdtemp(prefix="capture49_pace_", dir=JOB))
db = None
started = time.time()

try:
    db = sqlite3.connect(tmp / "packet_order.sqlite")
    db.execute("PRAGMA journal_mode=OFF")
    db.execute("PRAGMA synchronous=OFF")
    db.execute("CREATE TABLE r(ts INTEGER, idx INTEGER, off INTEGER, cap INTEGER, wire INTEGER)")

    offset = 24
    batch = []
    delayed = defaultdict(int)

    for index, timestamp, wire, payload in pcap_iter(pcap):
        flow_key = packet_flow(timestamp, payload)
        delay = (
            1_000_000_000
            if flow_key in eligible and index != first_packet[flow_key]
            else 0
        )
        if delay:
            delayed[flow_key] += 1

        batch.append((timestamp + delay, index, offset + 16, len(payload), wire))
        offset += 16 + len(payload)

        if len(batch) >= 20_000:
            db.executemany("INSERT INTO r VALUES (?,?,?,?,?)", batch)
            batch.clear()

    if batch:
        db.executemany("INSERT INTO r VALUES (?,?,?,?,?)", batch)

    db.commit()
    db.execute("CREATE INDEX order_idx ON r(ts, idx)")
    db.commit()

    transformed = tmp / "capture49_pace_1s.pcap"
    copied_digest = hashlib.sha256()
    last_out = None
    out_count = 0

    with open(pcap, "rb") as source:
        for off, cap, wire in db.execute(
            "SELECT off, cap, wire FROM r ORDER BY idx"
        ):
            source.seek(off)
            payload = source.read(cap)
            copied_digest.update(struct.pack("!II", cap, wire))
            copied_digest.update(payload)

    if copied_digest.digest() != original_digest.digest():
        raise RuntimeError("Source packet-byte validation failed.")

    print("Writing paced PCAP...", flush=True)

    with open(pcap, "rb") as source, open(transformed, "wb") as target:
        target.write(header)

        for timestamp, index, off, cap, wire in db.execute(
            "SELECT ts, idx, off, cap, wire FROM r ORDER BY ts, idx"
        ):
            if last_out is not None and timestamp < last_out:
                raise RuntimeError("Paced timestamps are unordered.")
            last_out = timestamp

            source.seek(off)
            payload = source.read(cap)

            source.seek(off - 16)
            sec, frac, _, _ = struct.unpack(endian + "IIII", source.read(16))
            original_timestamp = sec * 10**9 + frac * unit

            if timestamp < original_timestamp:
                raise RuntimeError("A packet was advanced.")

            if timestamp - original_timestamp not in {0, 1_000_000_000}:
                raise RuntimeError("Invalid pacing delay.")

            target.write(struct.pack(
                endian + "IIII",
                timestamp // 10**9,
                (timestamp % 10**9) // unit,
                cap,
                wire,
            ))
            target.write(payload)
            out_count += 1

    if out_count != packet_count:
        raise RuntimeError("Output packet count differs from source.")

    transformed_sha = hfile(transformed)

    db.close()
    db = None

    print("Running Zeek...", flush=True)

    def zeek_limit():
        resource.setrlimit(resource.RLIMIT_AS, (6 * 1024**3, 6 * 1024**3))

    with open(tmp / "zeek_stdout.txt", "w") as stdout, \
         open(tmp / "zeek_stderr.txt", "w") as stderr:
        run = subprocess.run(
            [str(ZEEK), "-C", "-r", str(transformed)],
            cwd=tmp,
            stdout=stdout,
            stderr=stderr,
            timeout=1800,
            preexec_fn=zeek_limit,
        )

    if run.returncode != 0 or not (tmp / "conn.log").is_file():
        raise RuntimeError(f"Zeek failed with exit code {run.returncode}.")

    mapped = {}
    duplicates = set()

    for row in log_iter(tmp / "conn.log"):
        flow_key = skey(key(
            row["ts"], row["id.orig_h"], row["id.orig_p"],
            row["id.resp_h"], row["id.resp_p"], row["proto"]
        ), sep)

        if flow_key in wanted:
            if flow_key in mapped:
                duplicates.add(flow_key)
            mapped[flow_key] = row

    missing = sorted(wanted - set(mapped))
    dump(JOB / "mapping_diagnostic.json", {
        "sample_rows": 1024,
        "mapped_rows": len(mapped),
        "missing_keys": missing,
        "ambiguous_keys": sorted(duplicates),
    })

    if missing or duplicates:
        raise RuntimeError("Exact paced-flow mapping failed.")

    attacked = norm(pd.DataFrame([
        {**{c: mapped[k][c] for c in F}, "ks": k, "y": labels[k]}
        for k in ks
    ]))
    attacked.to_csv(
        JOB / "attacked_selected_features.csv.gz",
        index=False,
        compression="gzip",
    )

    output = {"ks": ks, "y": y}
    results = []

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            p0 = bank["PRIMARY"].predict_proba(mat(sample, F))[:, 1]
            p1 = bank["PRIMARY"].predict_proba(mat(attacked, F))[:, 1]

            a0 = float(((p0 >= .5) == y).mean())
            a1 = float(((p1 >= .5) == y).mean())

            results.append({
                "scenario": SCENARIO,
                "attack": "PACE_1s",
                "seed": int(seed),
                "clean_accuracy": a0,
                "attack_accuracy": a1,
                "true_damage": a0 - a1,
                "eligible_flows": len(eligible),
                "delayed_packets": int(sum(delayed.values())),
                "mapped_fraction": 1.0,
            })

            output[f"seed_{seed}_clean_probability"] = p0
            output[f"seed_{seed}_attack_probability"] = p1

    pd.DataFrame(results).to_csv(JOB / "detector_results.csv", index=False)
    np.savez_compressed(JOB / "primary_outputs.npz", **output)

    receipt = {
        "status": "PACING_JOB_COMPLETE",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "sample_path": str(sample_path),
        "sample_sha256": hfile(sample_path),
        "source_pcap": str(pcap),
        "source_pcap_sha256": hfile(pcap),
        "transformed_pcap_sha256": transformed_sha,
        "original_packet_count": packet_count,
        "eligible_flows": len(eligible),
        "delayed_packets": int(sum(delayed.values())),
        "mapping_fraction": 1.0,
        "original_bytes_verified": True,
        "no_packet_advanced": True,
        "output_timestamps_nondecreasing": True,
        "models_retrained": False,
        "temporary_replays_retained": False,
        "seconds": round(time.time() - started, 2),
    }
    dump(JOB / "receipt.json", receipt)

    print("\nCAPTURE 49 COMPLETE")
    print(pd.DataFrame(results).to_string(index=False))
    print(json.dumps(receipt, indent=2))

except Exception as error:
    dump(JOB / "failure.json", {
        "status": "INCOMPLETE_NOT_A_RESULT",
        "scenario": SCENARIO,
        "attack": "PACE_1s",
        "error": f"{type(error).__name__}: {error}",
    })
    raise

finally:
    if db is not None:
        db.close()
    shutil.rmtree(tmp, ignore_errors=True)

# ===== CELL INPUT 35 =====
from pathlib import Path
import os
import zipfile

ROOTS = [
    Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/ran-files"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/the-last-update"),
    Path("/kaggle/input/datasets/mdhamidborkottulla/whole-in-one"),
    Path("/kaggle/working/E1_BLIND_TARGETS_20261012T125026604016Z"),
]

PCAP_MAGIC = {
    b"\xd4\xc3\xb2\xa1",
    b"\xa1\xb2\xc3\xd4",
    b"\x4d\x3c\xb2\xa1",
    b"\xa1\xb2\x3c\x4d",
}
PCAPNG_MAGIC = b"\x0a\x0d\x0d\x0a"

captures = []
capture49_files = []
archives = []
errors = []
counts = {}

for root in ROOTS:
    if not root.is_dir():
        counts[str(root)] = "NOT MOUNTED"
        continue

    count = 0
    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)

        for name in names:
            path = current / name
            if path.is_symlink():
                continue

            count += 1
            try:
                size = path.stat().st_size
                with path.open("rb") as handle:
                    magic = handle.read(4)

                if magic in PCAP_MAGIC or magic == PCAPNG_MAGIC:
                    captures.append({
                        "path": str(path),
                        "bytes": size,
                        "format": (
                            "classic PCAP"
                            if magic in PCAP_MAGIC else "PCAPNG"
                        ),
                    })

                # Match the entire path—not just the filename.
                if "CTU-IoT-Malware-Capture-49-1" in str(path):
                    capture49_files.append({
                        "path": str(path),
                        "bytes": size,
                    })

                if magic == b"PK\x03\x04" or path.suffix.lower() == ".zip":
                    try:
                        with zipfile.ZipFile(path) as archive:
                            hits = [
                                (member.filename, member.file_size)
                                for member in archive.infolist()
                                if not member.is_dir()
                                and (
                                    "CTU-IoT-Malware-Capture-49-1"
                                    in member.filename
                                    or member.filename.lower().endswith(
                                        (".pcap", ".pcapng", ".cap")
                                    )
                                )
                            ]
                        archives.append({
                            "path": str(path),
                            "hits": hits,
                        })
                    except Exception as error:
                        errors.append(
                            f"Archive {path}: {type(error).__name__}: {error}"
                        )

            except Exception as error:
                errors.append(
                    f"{path}: {type(error).__name__}: {error}"
                )

    counts[str(root)] = count

print("MOUNTED LOCATIONS / FILE COUNTS")
for root, count in counts.items():
    print(f"{count!s:>12}  {root}")

print("\nALL CAPTURE FILES — IDENTIFIED BY CONTENT")
for item in sorted(captures, key=lambda x: x["path"]):
    print(
        f"{item['format']:12} | "
        f"{item['bytes']/1024**2:10.2f} MiB | {item['path']}"
    )
if not captures:
    print("No directly readable PCAP/PCAPNG files found.")

print("\nCAPTURE 49 FILES — FULL-PATH MATCH")
for item in sorted(capture49_files, key=lambda x: x["path"]):
    print(f"{item['bytes']:12,d} bytes | {item['path']}")
if not capture49_files:
    print("No direct file path contains the Capture 49 scenario name.")

print("\nARCHIVES AND RELEVANT INTERNAL MEMBERS")
for archive in archives:
    print(f"\nARCHIVE: {archive['path']}")
    for name, size in archive["hits"]:
        print(f"  {size:12,d} bytes | {name}")
    if not archive["hits"]:
        print("  No Capture 49 or PCAP-named members.")
if not archives:
    print("No ZIP archives found.")

print("\nREAD ERRORS")
for error in errors[:30]:
    print(error)
if not errors:
    print("None")

print("\nREAD-ONLY CHECK FINISHED — NO FILES CREATED, COPIED OR DELETED.")

# ===== CELL INPUT 36 =====
from pathlib import Path
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
import ast
import bisect
import gzip
import hashlib
import ipaddress
import json
import os
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def complete_capture49():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    scenario = "CTU-IoT-Malware-Capture-49-1"
    job = work / "E4_COMPACT_PACING_v1" / scenario
    job.mkdir(parents=True, exist_ok=True)

    def write_json(path, value):
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(value, indent=2))
        temp.replace(path)

    def sha(path):
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024**2), b""):
                digest.update(block)
        return digest.hexdigest()

    done = job / "receipt.json"
    if done.is_file():
        receipt = json.loads(done.read_text())
        if receipt.get("status") == "PACING_JOB_COMPLETE":
            print("Capture 49 already complete; not rerunning.")
            return

    def find_file(name, required_fragment):
        matches = [
            p for p in backup.rglob(name)
            if p.is_file() and required_fragment in str(p)
        ]
        if not matches:
            raise FileNotFoundError(
                f"No {name} within {required_fragment} in {backup}"
            )
        return sorted(matches, key=lambda p: (len(p.parts), str(p)))[0]

    sample_path = find_file(
        "frozen_clean_target_sample.csv", scenario
    )
    model_path = find_file(
        "frozen_source_models.joblib", "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1"
    )
    helper_path = find_file(
        "run_streaming_confirmatory_batch_A_v1_2_fixed.py", ""
    )
    frozen_path = find_file(
        "primary_outputs.npz",
        f"E4_COMPACT_INJECTIONS_v2/{scenario}/INJ_k1"
    )

    e1 = backup / "E1_BLIND_TARGETS_20261012T125026604016Z"

    def e1_asset(suffix):
        matches = [
            p for p in e1.rglob("*")
            if p.is_file()
            and scenario in str(p.relative_to(e1))
            and p.name.endswith(suffix)
        ]
        if len(matches) != 1:
            raise RuntimeError(
                f"Expected one Capture 49 {suffix}; found: "
                + repr([str(p) for p in matches])
            )
        return matches[0]

    pcap = e1_asset("slice.pcap")
    conn = e1_asset("conn.log")
    zeek_string = shutil.which("zeek")
    zeek = Path(zeek_string) if zeek_string else Path("/opt/zeek/bin/zeek")
    if not zeek.is_file():
        raise FileNotFoundError("Zeek executable is not installed.")

    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]

    def normalize(frame):
        frame = frame.copy()
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    sample = normalize(pd.read_csv(sample_path, dtype={"ks": str}))
    if len(sample) != 1024 or sample.ks.duplicated().any():
        raise ValueError("Frozen sample must contain 1,024 unique keys.")

    required = {"key", "skey", "mat", "pcap_iter", "pcap_header", "tcp", "log_iter"}
    tree = ast.parse(helper_path.read_text())
    definitions = [
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in required
    ]
    if {n.name for n in definitions} != required:
        raise ValueError("Saved packet helper definitions are incomplete.")

    ns = dict(globals())
    ns["MAGICS"] = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1),
    }
    exec(compile(ast.fix_missing_locations(
        ast.Module(body=definitions, type_ignores=[])
    ), "saved_packet_helpers", "exec"), ns)

    key, skey, mat = ns["key"], ns["skey"], ns["mat"]
    packets, header, tcp = ns["pcap_iter"], ns["pcap_header"], ns["tcp"]

    # Read the actual plain-text Zeek log; do not rely on its old .gz path.
    def read_conn(path):
        fields = None
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("#fields"):
                    fields = line.rstrip("\n").split("\t")[1:]
                elif not line.startswith("#") and line.strip():
                    if fields is None:
                        raise ValueError("Zeek log lacks #fields header.")
                    yield dict(zip(fields, line.rstrip("\n").split("\t")))

    with np.load(frozen_path, allow_pickle=False) as saved:
        frozen_keys = saved["ks"].astype(str)
        positions = pd.Index(frozen_keys).get_indexer(sample.ks)
        if (positions < 0).any() or len(set(frozen_keys)) != len(frozen_keys):
            raise ValueError("Frozen sample/injection keys differ.")
        if not np.array_equal(saved["y"][positions].astype(int), sample.y):
            raise ValueError("Frozen sample/injection labels differ.")
        saved_clean = {
            str(s): saved[f"seed_{s}_clean_probability"][positions]
            for s in [8101, 8102, 8103]
        }

    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected frozen model seeds.")

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            p = bank["PRIMARY"].predict_proba(mat(sample, F))[:, 1]
            difference = float(np.max(np.abs(p - saved_clean[str(seed)])))
            print(f"Seed {seed}: clean probability difference = {difference}")
            if difference > 1e-12:
                raise ValueError("Frozen clean prediction verification failed.")

    wanted = set(sample.ks)
    labels = dict(zip(sample.ks, sample.y))
    selected_rows = []
    for row in read_conn(conn):
        selected_rows.append(row) if False else None
        base = key(
            row["ts"], row["id.orig_h"], row["id.orig_p"],
            row["id.resp_h"], row["id.resp_p"], row["proto"]
        )
        for sep in ["|", ",", "_", "", "\t"]:
            if skey(base, sep) in wanted:
                selected_rows.append((row, sep, skey(base, sep)))
                break

    separators = {sep for _, sep, _ in selected_rows}
    flows = {k: row for row, _, k in selected_rows}
    if (
        len(separators) != 1 or len(selected_rows) != 1024
        or set(flows) != wanted
    ):
        raise ValueError("Clean selected-flow linkage is not unique.")
    separator = next(iter(separators))

    descriptions = defaultdict(list)
    for k, row in flows.items():
        if labels[k] != 1 or row["proto"].lower() != "tcp":
            continue
        start = int(Decimal(row["ts"]) * 10**9)
        duration = 0 if row["duration"] == "-" else int(
            Decimal(row["duration"]) * 10**9
        )
        endpoints = tuple(sorted([
            (row["id.orig_h"], int(row["id.orig_p"])),
            (row["id.resp_h"], int(row["id.resp_p"]))
        ]))
        descriptions[endpoints].append((start, start + duration + 1_000_000, k))
    for values in descriptions.values():
        values.sort()
    starts = {t: [v[0] for v in values] for t, values in descriptions.items()}
    h, endian, unit, network = header(pcap)

    def flow_for(ts, payload):
        info = tcp(payload, network)
        if info is None:
            return None
        src, sp, dst, dp, _, _ = info
        endpoints = tuple(sorted([(src, sp), (dst, dp)]))
        if endpoints not in descriptions:
            return None
        j = bisect.bisect_right(starts[endpoints], ts) - 1
        if j < 0:
            return None
        begin, end, k = descriptions[endpoints][j]
        return k if ts <= end else None

    counts, first = defaultdict(int), {}
    count = 0
    previous = None
    for i, ts, wire, payload in packets(pcap):
        if previous is not None and ts < previous:
            raise ValueError("Source timestamps are unordered.")
        previous = ts
        count += 1
        k = flow_for(ts, payload)
        if k is not None:
            counts[k] += 1
            first.setdefault(k, i)

    eligible = {k for k, n in counts.items() if n >= 2}
    reserve = pcap.stat().st_size * 3 + count * 160 + 1024**3
    free = shutil.disk_usage(work).free
    print(
        f"Packets={count:,}; eligible={len(eligible)}; "
        f"free={free/1024**3:.2f} GiB; "
        f"conservative reserve={reserve/1024**3:.2f} GiB",
        flush=True
    )
    if free < reserve:
        raise RuntimeError("Insufficient temporary-space reserve; replay not started.")

    temp = Path(tempfile.mkdtemp(prefix="pace49_", dir=job))
    db = None
    started = time.time()
    try:
        db = sqlite3.connect(temp / "order.sqlite")
        db.execute("PRAGMA journal_mode=OFF")
        db.execute("PRAGMA synchronous=OFF")
        db.execute("PRAGMA temp_store=FILE")
        db.execute("PRAGMA cache_size=-32768")
        db.execute("CREATE TABLE r(ts INTEGER, idx INTEGER, off INTEGER, cap INTEGER, wire INTEGER)")
        offset, batch, delayed = 24, [], 0
        for i, ts, wire, payload in packets(pcap):
            k = flow_for(ts, payload)
            delay = 10**9 if k in eligible and i != first[k] else 0
            delayed += int(delay != 0)
            batch.append((ts + delay, i, offset + 16, len(payload), wire))
            offset += 16 + len(payload)
            if len(batch) == 20000:
                db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
                batch.clear()
        if batch:
            db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
        db.commit()
        db.execute("CREATE INDEX ordered ON r(ts,idx)")
        db.commit()

        transformed = temp / "paced.pcap"
        seen, last_index = 0, {}
        with open(pcap, "rb") as source, open(transformed, "wb") as target:
            target.write(h)
            for ts, i, off, cap, wire in db.execute(
                "SELECT ts,idx,off,cap,wire FROM r ORDER BY ts,idx"
            ):
                source.seek(off - 16)
                sec, frac, original_cap, original_wire = struct.unpack(
                    endian + "IIII", source.read(16)
                )
                original_ts = sec * 10**9 + frac * unit
                payload = source.read(cap)
                if (
                    len(payload) != cap or original_cap != cap
                    or original_wire != wire or ts-original_ts not in {0, 10**9}
                ):
                    raise ValueError("Packet preservation/delay validation failed.")
                k = flow_for(original_ts, payload)
                if k is not None:
                    if i <= last_index.get(k, -1):
                        raise ValueError("Selected-flow packet ordering changed.")
                    last_index[k] = i
                target.write(struct.pack(
                    endian+"IIII", ts//10**9, (ts%10**9)//unit, cap, wire
                ))
                target.write(payload)
                seen += 1
        if seen != count:
            raise ValueError("Output packet count differs.")
        transformed_hash = sha(transformed)
        db.close()
        db = None
        (temp / "order.sqlite").unlink()

        def limit_zeek():
            resource.setrlimit(resource.RLIMIT_AS, (6*1024**3, 6*1024**3))

        print("Running Capture 49 Zeek replay...", flush=True)
        with open(job / "zeek_stdout.txt", "w") as stdout, open(
            job / "zeek_stderr.txt", "w"
        ) as stderr:
            process = subprocess.run(
                [str(zeek), "-C", "-r", str(transformed)],
                cwd=temp, stdout=stdout, stderr=stderr,
                timeout=1800, preexec_fn=limit_zeek
            )
        if process.returncode or not (temp / "conn.log").is_file():
            raise RuntimeError("Zeek failed; see retained zeek_stderr.txt.")

        mapped = {}
        for row in read_conn(temp / "conn.log"):
            k = skey(key(
                row["ts"], row["id.orig_h"], row["id.orig_p"],
                row["id.resp_h"], row["id.resp_p"], row["proto"]
            ), separator)
            if k in wanted:
                if k in mapped:
                    raise ValueError("Ambiguous attacked flow linkage.")
                mapped[k] = row
        if set(mapped) != wanted:
            write_json(job / "mapping_diagnostic.json", {
                "missing_keys": sorted(wanted-set(mapped)),
                "mapped_rows": len(mapped)
            })
            raise ValueError("Incomplete attacked linkage; no rows dropped.")

        attacked = normalize(pd.DataFrame([
            {**{c: mapped[k][c] for c in F}, "ks": k, "y": labels[k]}
            for k in sample.ks
        ]))
        attacked.to_csv(job / "attacked_selected_features.csv", index=False)
        arrays = {"ks": sample.ks.to_numpy(str), "y": sample.y.to_numpy(int)}
        results = []
        with threadpool_limits(limits=2):
            for seed, bank in bundle["models"].items():
                p0 = saved_clean[str(seed)]
                p1 = bank["PRIMARY"].predict_proba(mat(attacked, F))[:, 1]
                a0 = float(((p0 >= .5) == sample.y).mean())
                a1 = float(((p1 >= .5) == sample.y).mean())
                results.append({
                    "scenario": scenario, "attack": "PACE_1s", "seed": int(seed),
                    "clean_accuracy": a0, "attack_accuracy": a1,
                    "true_damage": a0-a1, "eligible_flows": len(eligible),
                    "delayed_packets": delayed, "mapped_fraction": 1.0
                })
                arrays[f"seed_{seed}_clean_probability"] = p0
                arrays[f"seed_{seed}_attack_probability"] = p1
        pd.DataFrame(results).to_csv(job / "detector_results.csv", index=False)
        np.savez_compressed(job / "primary_outputs.npz", **arrays)
        write_json(done, {
            "status": "PACING_JOB_COMPLETE", "scenario": scenario,
            "attack": "PACE_1s", "sample_path": str(sample_path),
            "sample_sha256": sha(sample_path), "source_pcap": str(pcap),
            "source_pcap_sha256": sha(pcap),
            "transformed_pcap_sha256": transformed_hash,
            "eligible_flows": len(eligible), "delayed_packets": delayed,
            "original_packet_count": count, "mapping_fraction": 1.0,
            "per_selected_flow_order_verified": True,
            "no_packet_advanced": True, "models_retrained": False,
            "temporary_replays_retained": False,
            "seconds": round(time.time()-started, 2),
            "protocol_scope": "Same compact PACE procedure as seven saved jobs"
        })
        print(pd.DataFrame(results).to_string(index=False))
        print("CAPTURE 49 PACE COMPLETE")
    except Exception as error:
        write_json(job / "failure.json", {
            "status": "INCOMPLETE_NOT_A_RESULT", "error": str(error)
        })
        raise
    finally:
        if db is not None:
            db.close()
        shutil.rmtree(temp, ignore_errors=True)

complete_capture49()

# ===== CELL INPUT 37 =====
from pathlib import Path
from datetime import datetime, timezone
import json
import pandas as pd

work = Path("/kaggle/working")
backup = Path(
    "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
    "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
)
targets = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]
tables, receipts = [], []

for scenario in targets:
    candidates = [
        work / "E4_COMPACT_PACING_v1" / scenario,
        backup / "E4_COMPACT_PACING_v1" / scenario,
    ]
    chosen = None
    for job in candidates:
        receipt_path = job / "receipt.json"
        result_path = job / "detector_results.csv"
        if receipt_path.is_file() and result_path.is_file():
            receipt = json.loads(receipt_path.read_text())
            if (
                receipt.get("status") == "PACING_JOB_COMPLETE"
                and receipt.get("scenario") == scenario
            ):
                chosen = job
                break
    if chosen is None:
        raise RuntimeError(f"Pacing still incomplete: {scenario}")

    table = pd.read_csv(chosen / "detector_results.csv")
    if (
        len(table) != 3
        or set(table.seed) != {8101, 8102, 8103}
        or not table.scenario.eq(scenario).all()
        or not table.attack.eq("PACE_1s").all()
        or not table.mapped_fraction.eq(1.0).all()
    ):
        raise ValueError(f"Invalid saved pacing result table: {scenario}")
    tables.append(table)
    receipts.append({
        "scenario": scenario,
        "eligible_flows": receipt["eligible_flows"],
        "delayed_packets": receipt["delayed_packets"],
        "source_directory": str(chosen)
    })

combined = pd.concat(tables, ignore_index=True)
summary = combined.groupby("scenario", as_index=False).agg(
    clean_accuracy=("clean_accuracy", "mean"),
    attack_accuracy=("attack_accuracy", "mean"),
    true_damage=("true_damage", "mean")
).merge(pd.DataFrame(receipts), on="scenario", validate="one_to_one")
summary["null_transformation"] = summary.delayed_packets.eq(0)

out = work / (
    "E4_PACING_COMPLETE_"
    + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
)
out.mkdir()
combined.to_csv(out / "all_seed_results.csv", index=False)
summary.to_csv(out / "scenario_summary.csv", index=False)
(out / "receipt.json").write_text(json.dumps({
    "status": "EIGHT_PACING_DETECTOR_JOBS_COMPLETE",
    "scenario_count": 8,
    "seed_rows": 24,
    "null_transformation_scenarios": summary.loc[
        summary.null_transformation, "scenario"
    ].tolist(),
    "mean_scenario_damage": float(summary.true_damage.mean()),
    "full_monitor_comparison_complete": False,
    "original_protocol_statistics_complete": False,
    "adaptive_E5_complete": False,
    "faithful_MD3_complete": False,
    "edge_hardware_measurement_complete": False
}, indent=2))

print(summary.to_string(index=False))
print(f"\nSaved pacing summary: {out}")

# ===== CELL INPUT 38 =====
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def complete_pacing_estimator_panel():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    views = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_timeproto": ["duration", "proto"],
    }

    def read_csv(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        return pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )

    def normalize(frame):
        frame = frame.copy()
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def matrix(frame, cols):
        numeric = [c for c in cols if c != "proto"]
        parts = []
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in cols:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def locate_clean(scenario):
        fragment = (
            "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_"
            "20261012T181242007570Z"
        )
        for root in [backup, work]:
            matches = [
                p for p in root.rglob("frozen_clean_target_sample.csv*")
                if p.is_file()
                and scenario in str(p)
                and fragment in str(p)
            ]
            if matches:
                return min(matches, key=lambda p: (len(p.parts), str(p)))
        raise FileNotFoundError(f"No preserved clean sample for {scenario}")

    def locate_job(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            rp = job / "receipt.json"
            if rp.is_file():
                receipt = json.loads(rp.read_text())
                if (
                    receipt.get("status") == "PACING_JOB_COMPLETE"
                    and receipt.get("scenario") == scenario
                    and (job / "primary_outputs.npz").is_file()
                ):
                    return job, receipt
        raise RuntimeError(f"No completed pacing prediction artifact: {scenario}")

    model_candidates = [
        work / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib",
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    ]
    model_path = next((p for p in model_candidates if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Frozen model bundle unavailable.")
    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected frozen model seed set.")

    rows, checks, inputs = [], [], []

    with threadpool_limits(limits=2):
        for scenario in targets:
            job, receipt = locate_job(scenario)
            clean_path = locate_clean(scenario)
            attacked_paths = sorted(job.glob("attacked_selected_features.csv*"))
            if len(attacked_paths) != 1:
                raise RuntimeError(
                    f"Expected one attacked feature CSV in {job}; "
                    f"found {len(attacked_paths)}"
                )
            attack_path = attacked_paths[0]
            clean = normalize(read_csv(clean_path))
            attacked = normalize(read_csv(attack_path))

            for name, frame in [("clean", clean), ("attack", attacked)]:
                if (
                    len(frame) != 1024 or frame.ks.duplicated().any()
                    or not frame.y.isin([0, 1]).all()
                ):
                    raise ValueError(f"Invalid {name} sample: {scenario}")

            if set(clean.ks) != set(attacked.ks):
                raise ValueError(f"Clean/attack key sets differ: {scenario}")
            attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
            y = clean.y.to_numpy(int)
            if not np.array_equal(y, attacked.y.to_numpy(int)):
                raise ValueError(f"Paired labels differ: {scenario}")

            with np.load(job / "primary_outputs.npz", allow_pickle=False) as saved:
                keys = saved["ks"].astype(str)
                if len(keys) != 1024 or len(set(keys)) != 1024:
                    raise ValueError("Invalid saved prediction key set.")
                positions = pd.Index(keys).get_indexer(clean.ks)
                if (positions < 0).any():
                    raise ValueError("Prediction keys do not match sample.")
                if not np.array_equal(saved["y"][positions].astype(int), y):
                    raise ValueError("Saved labels differ from clean sample.")

                for seed, bank in bundle["models"].items():
                    seed_text = str(seed)
                    probabilities, estimates, accuracy = [], [], []

                    for state, frame in [("clean", clean), ("attack", attacked)]:
                        p = bank["PRIMARY"].predict_proba(matrix(frame, F))[:, 1]
                        stored = saved[
                            f"seed_{seed_text}_{state}_probability"
                        ][positions]
                        difference = float(np.max(np.abs(p-stored)))
                        if not np.isfinite(p).all() or difference > 1e-12:
                            raise ValueError(
                                f"Stored prediction mismatch: "
                                f"{scenario}/{seed}/{state}: {difference}"
                            )

                        votes = np.column_stack([
                            bank[name].predict(matrix(frame, cols))
                            for name, cols in views.items()
                        ])
                        if not np.isin(votes, [0, 1]).all():
                            raise ValueError("View model predictions are not binary.")
                        majority = votes.sum(axis=1) >= 2
                        decision = p >= .5

                        estimates.append({
                            "AC": float(np.maximum(p, 1-p).mean()),
                            "AGREE": float((majority == decision).mean()),
                        })
                        accuracy.append(float((decision == y).mean()))
                        probabilities.append(p)
                        checks.append({
                            "scenario": scenario, "seed": int(seed),
                            "state": state,
                            "max_saved_probability_difference": difference,
                        })

                    for estimator in ["AC", "AGREE"]:
                        e0, e1 = (
                            estimates[0][estimator], estimates[1][estimator]
                        )
                        a0, a1 = accuracy
                        rows.append({
                            "scenario": scenario, "attack": "PACE_1s",
                            "seed": int(seed), "estimator": estimator,
                            "clean_accuracy": a0, "attack_accuracy": a1,
                            "true_damage": a0-a1,
                            "clean_estimate": e0, "attack_estimate": e1,
                            "estimated_damage": e0-e1,
                            "clean_signed_bias": e0-a0,
                            "attack_signed_bias": e1-a1,
                            "differential_abs_error": abs((e1-a1)-(e0-a0)),
                            "eligible_flows": receipt["eligible_flows"],
                            "delayed_packets": receipt["delayed_packets"],
                            "null_transformation": receipt["delayed_packets"] == 0,
                        })

            inputs.append({
                "scenario": scenario, "clean": str(clean_path),
                "attacked": str(attack_path), "job": str(job)
            })
            print(f"Verified and evaluated: {scenario}", flush=True)

    results = pd.DataFrame(rows)
    validation = pd.DataFrame(checks)
    if len(results) != 48 or len(validation) != 48:
        raise ValueError("Expected 48 estimator rows and 48 prediction checks.")

    scenario_table = results.groupby(
        ["scenario", "attack", "estimator"], as_index=False
    ).agg(
        clean_accuracy=("clean_accuracy", "mean"),
        attack_accuracy=("attack_accuracy", "mean"),
        true_damage=("true_damage", "mean"),
        clean_estimate=("clean_estimate", "mean"),
        attack_estimate=("attack_estimate", "mean"),
        differential_abs_error=("differential_abs_error", "mean"),
        delayed_packets=("delayed_packets", "first"),
        null_transformation=("null_transformation", "first"),
    )
    comparison = scenario_table.pivot(
        index="scenario", columns="estimator",
        values="differential_abs_error"
    ).reset_index()
    comparison["AC_minus_AGREE_error"] = comparison.AC-comparison.AGREE

    out = work / (
        "E4_PACING_ESTIMATOR_PANEL_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    results.to_csv(out / "per_seed_results.csv", index=False)
    validation.to_csv(out / "prediction_verification.csv", index=False)
    scenario_table.to_csv(out / "scenario_results.csv", index=False)
    comparison.to_csv(out / "paired_scenario_comparison.csv", index=False)
    (out / "receipt.json").write_text(json.dumps({
        "status": "EIGHT_SCENARIO_PACING_AC_AGREE_PANEL_COMPLETE",
        "scenario_count": 8,
        "per_seed_estimator_rows": len(results),
        "prediction_checks": len(validation),
        "all_saved_probabilities_reproduced": True,
        "models_retrained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "inputs": inputs,
        "scope": "Compact pacing panel; not yet original-protocol confirmation",
        "significance_tests_run": False,
        "all_remaining_tasks_complete": False,
    }, indent=2))

    print("\nPACING ESTIMATOR RESULTS — SEED AVERAGES")
    print(scenario_table.to_string(index=False))
    print("\nPAIRED SCENARIO ERRORS")
    print(comparison.to_string(index=False))
    print(f"\nCompleted panel saved: {out}")

complete_pacing_estimator_panel()

# ===== CELL INPUT 39 =====
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def complete_pacing_estimator_panel():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    views = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_timeproto": ["duration", "proto"],
    }

    def read_csv(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        return pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )

    def normalize(frame):
        frame = frame.copy()
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def matrix(frame, cols):
        numeric = [c for c in cols if c != "proto"]
        parts = []
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in cols:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def locate_clean(scenario):
        fragment = (
            "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_"
            "20261012T181242007570Z"
        )
        for root in [backup, work]:
            matches = [
                p for p in root.rglob("frozen_clean_target_sample.csv*")
                if p.is_file()
                and scenario in str(p)
                and fragment in str(p)
            ]
            if matches:
                return min(matches, key=lambda p: (len(p.parts), str(p)))
        raise FileNotFoundError(f"No preserved clean sample for {scenario}")

    def locate_job(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            rp = job / "receipt.json"
            if rp.is_file():
                receipt = json.loads(rp.read_text())
                if (
                    receipt.get("status") == "PACING_JOB_COMPLETE"
                    and receipt.get("scenario") == scenario
                    and (job / "primary_outputs.npz").is_file()
                ):
                    return job, receipt
        raise RuntimeError(f"No completed pacing prediction artifact: {scenario}")

    model_candidates = [
        work / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib",
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    ]
    model_path = next((p for p in model_candidates if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Frozen model bundle unavailable.")
    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected frozen model seed set.")

    rows, checks, inputs = [], [], []

    with threadpool_limits(limits=2):
        for scenario in targets:
            job, receipt = locate_job(scenario)
            clean_path = locate_clean(scenario)
            attacked_paths = sorted(job.glob("attacked_selected_features.csv*"))
            if len(attacked_paths) != 1:
                raise RuntimeError(
                    f"Expected one attacked feature CSV in {job}; "
                    f"found {len(attacked_paths)}"
                )
            attack_path = attacked_paths[0]
            clean = normalize(read_csv(clean_path))
            attacked = normalize(read_csv(attack_path))

            for name, frame in [("clean", clean), ("attack", attacked)]:
                if (
                    len(frame) != 1024 or frame.ks.duplicated().any()
                    or not frame.y.isin([0, 1]).all()
                ):
                    raise ValueError(f"Invalid {name} sample: {scenario}")

            if set(clean.ks) != set(attacked.ks):
                raise ValueError(f"Clean/attack key sets differ: {scenario}")
            attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
            y = clean.y.to_numpy(int)
            if not np.array_equal(y, attacked.y.to_numpy(int)):
                raise ValueError(f"Paired labels differ: {scenario}")

            with np.load(job / "primary_outputs.npz", allow_pickle=False) as saved:
                keys = saved["ks"].astype(str)
                if len(keys) != 1024 or len(set(keys)) != 1024:
                    raise ValueError("Invalid saved prediction key set.")
                positions = pd.Index(keys).get_indexer(clean.ks)
                if (positions < 0).any():
                    raise ValueError("Prediction keys do not match sample.")
                if not np.array_equal(saved["y"][positions].astype(int), y):
                    raise ValueError("Saved labels differ from clean sample.")

                for seed, bank in bundle["models"].items():
                    seed_text = str(seed)
                    probabilities, estimates, accuracy = [], [], []

                    for state, frame in [("clean", clean), ("attack", attacked)]:
                        p = bank["PRIMARY"].predict_proba(matrix(frame, F))[:, 1]
                        stored = saved[
                            f"seed_{seed_text}_{state}_probability"
                        ][positions]
                        difference = float(np.max(np.abs(p-stored)))
                        if not np.isfinite(p).all() or difference > 1e-12:
                            raise ValueError(
                                f"Stored prediction mismatch: "
                                f"{scenario}/{seed}/{state}: {difference}"
                            )

                        votes = np.column_stack([
                            bank[name].predict(matrix(frame, cols))
                            for name, cols in views.items()
                        ])
                        if not np.isin(votes, [0, 1]).all():
                            raise ValueError("View model predictions are not binary.")
                        majority = votes.sum(axis=1) >= 2
                        decision = p >= .5

                        estimates.append({
                            "AC": float(np.maximum(p, 1-p).mean()),
                            "AGREE": float((majority == decision).mean()),
                        })
                        accuracy.append(float((decision == y).mean()))
                        probabilities.append(p)
                        checks.append({
                            "scenario": scenario, "seed": int(seed),
                            "state": state,
                            "max_saved_probability_difference": difference,
                        })

                    for estimator in ["AC", "AGREE"]:
                        e0, e1 = (
                            estimates[0][estimator], estimates[1][estimator]
                        )
                        a0, a1 = accuracy
                        rows.append({
                            "scenario": scenario, "attack": "PACE_1s",
                            "seed": int(seed), "estimator": estimator,
                            "clean_accuracy": a0, "attack_accuracy": a1,
                            "true_damage": a0-a1,
                            "clean_estimate": e0, "attack_estimate": e1,
                            "estimated_damage": e0-e1,
                            "clean_signed_bias": e0-a0,
                            "attack_signed_bias": e1-a1,
                            "differential_abs_error": abs((e1-a1)-(e0-a0)),
                            "eligible_flows": receipt["eligible_flows"],
                            "delayed_packets": receipt["delayed_packets"],
                            "null_transformation": receipt["delayed_packets"] == 0,
                        })

            inputs.append({
                "scenario": scenario, "clean": str(clean_path),
                "attacked": str(attack_path), "job": str(job)
            })
            print(f"Verified and evaluated: {scenario}", flush=True)

    results = pd.DataFrame(rows)
    validation = pd.DataFrame(checks)
    if len(results) != 48 or len(validation) != 48:
        raise ValueError("Expected 48 estimator rows and 48 prediction checks.")

    scenario_table = results.groupby(
        ["scenario", "attack", "estimator"], as_index=False
    ).agg(
        clean_accuracy=("clean_accuracy", "mean"),
        attack_accuracy=("attack_accuracy", "mean"),
        true_damage=("true_damage", "mean"),
        clean_estimate=("clean_estimate", "mean"),
        attack_estimate=("attack_estimate", "mean"),
        differential_abs_error=("differential_abs_error", "mean"),
        delayed_packets=("delayed_packets", "first"),
        null_transformation=("null_transformation", "first"),
    )
    comparison = scenario_table.pivot(
        index="scenario", columns="estimator",
        values="differential_abs_error"
    ).reset_index()
    comparison["AC_minus_AGREE_error"] = comparison.AC-comparison.AGREE

    out = work / (
        "E4_PACING_ESTIMATOR_PANEL_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    results.to_csv(out / "per_seed_results.csv", index=False)
    validation.to_csv(out / "prediction_verification.csv", index=False)
    scenario_table.to_csv(out / "scenario_results.csv", index=False)
    comparison.to_csv(out / "paired_scenario_comparison.csv", index=False)
    (out / "receipt.json").write_text(json.dumps({
        "status": "EIGHT_SCENARIO_PACING_AC_AGREE_PANEL_COMPLETE",
        "scenario_count": 8,
        "per_seed_estimator_rows": len(results),
        "prediction_checks": len(validation),
        "all_saved_probabilities_reproduced": True,
        "models_retrained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "inputs": inputs,
        "scope": "Compact pacing panel; not yet original-protocol confirmation",
        "significance_tests_run": False,
        "all_remaining_tasks_complete": False,
    }, indent=2))

    print("\nPACING ESTIMATOR RESULTS — SEED AVERAGES")
    print(scenario_table.to_string(index=False))
    print("\nPAIRED SCENARIO ERRORS")
    print(comparison.to_string(index=False))
    print(f"\nCompleted panel saved: {out}")

complete_pacing_estimator_panel()

# ===== CELL INPUT 40 =====
import ast
import copy
import joblib
from pathlib import Path

model_candidates = [
    Path(
        "/kaggle/working/"
        "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/"
        "frozen_source_models.joblib"
    ),
    Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z/"
        "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/"
        "frozen_source_models.joblib"
    ),
]
model_path = next((p for p in model_candidates if p.is_file()), None)
if model_path is None:
    raise FileNotFoundError("Frozen model bundle not found.")

model_bundle = joblib.load(model_path)
timing_keys = set()

for seed, bank in model_bundle["models"].items():
    inventory = {
        str(name): getattr(model, "n_features_in_", None)
        for name, model in bank.items()
    }
    print(f"Seed {seed}: model keys / input-column counts = {inventory}")

    if "V_orig" not in bank or "V_resp" not in bank:
        raise RuntimeError(
            f"Seed {seed} lacks the expected V_orig/V_resp models. "
            "No models or results have been changed."
        )

    candidates = [
        name for name, model in bank.items()
        if str(name).startswith("V_")
        and name not in {"V_orig", "V_resp"}
        and getattr(model, "n_features_in_", None) == 4
    ]
    if len(candidates) != 1:
        raise RuntimeError(
            f"Seed {seed}: cannot uniquely identify the duration/protocol "
            f"view. Candidates={candidates}; inventory={inventory}"
        )
    timing_keys.add(candidates[0])

if len(timing_keys) != 1:
    raise RuntimeError(
        f"The timing/protocol view key differs across seeds: {timing_keys}"
    )

actual_timing_key = next(iter(timing_keys))
print(f"\nResolved timing/protocol model key: {actual_timing_key}")

# Retrieve the previous panel function's source from this notebook session.
history = get_ipython().history_manager.input_hist_raw
function_node = None

for source in reversed(history):
    try:
        tree = ast.parse(source)
    except SyntaxError:
        continue
    matches = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "complete_pacing_estimator_panel"
    ]
    if matches:
        function_node = copy.deepcopy(matches[-1])
        break

if function_node is None:
    raise RuntimeError(
        "The original panel definition is not in this runtime's cell history. "
        "Do not rerun packet experiments."
    )

class CorrectViewKey(ast.NodeTransformer):
    def __init__(self):
        self.replacements = 0

    def visit_Constant(self, node):
        if node.value == "V_timeproto":
            self.replacements += 1
            return ast.copy_location(
                ast.Constant(value=actual_timing_key), node
            )
        return node

patch = CorrectViewKey()
function_node = patch.visit(function_node)

if patch.replacements != 1:
    raise RuntimeError(
        f"Expected exactly one timing-view key in the original function; "
        f"found {patch.replacements}. No panel execution performed."
    )

module = ast.fix_missing_locations(
    ast.Module(body=[function_node], type_ignores=[])
)
exec(compile(module, "corrected_pacing_estimator_panel", "exec"), globals())

complete_pacing_estimator_panel()

# ===== CELL INPUT 41 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json

import numpy as np
import pandas as pd

WORK = Path("/kaggle/working")
PANEL = WORK / "E4_PACING_ESTIMATOR_PANEL_20261013T130527426625Z"
BACKUP = Path(
    "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
    "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
)
TARGETS = [
    f"CTU-IoT-Malware-Capture-{n}-1"
    for n in [7, 9, 33, 36, 39, 43, 48, 49]
]
OUT = WORK / (
    "E4_COMPLETION_AND_PACING_STATISTICS_"
    + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
)

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()

def completed_job(relative, expected_status, scenario, attack):
    for root in [WORK, BACKUP]:
        job = root / relative
        receipt_path = job / "receipt.json"
        output_path = job / "primary_outputs.npz"

        if not receipt_path.is_file() or not output_path.is_file():
            continue

        receipt = json.loads(receipt_path.read_text())
        if (
            receipt.get("status") == expected_status
            and receipt.get("scenario") == scenario
            and receipt.get("attack") == attack
        ):
            return job, receipt

    raise RuntimeError(
        f"No verified completed receipt/output pair: {scenario}/{attack}"
    )

def exact_sign_flip(gains):
    gains = np.asarray(gains, dtype=float)
    if gains.shape != (8,) or not np.isfinite(gains).all():
        raise ValueError("Expected eight finite scenario-level gains.")

    signs = np.asarray(
        list(itertools.product([-1.0, 1.0], repeat=len(gains)))
    )
    permuted_means = (signs * gains).mean(axis=1)
    observed = float(gains.mean())
    tolerance = 1e-15

    return {
        "mean_AC_minus_AGREE_error": observed,
        "one_sided_p_AGREE_lower_error": float(
            np.mean(permuted_means >= observed - tolerance)
        ),
        "two_sided_p": float(
            np.mean(
                np.abs(permuted_means) >= abs(observed) - tolerance
            )
        ),
        "sign_patterns": len(permuted_means),
        "positive_gain_scenarios": int((gains > 0).sum()),
        "negative_gain_scenarios": int((gains < 0).sum()),
        "zero_gain_scenarios": int((gains == 0).sum()),
    }

required_panel_files = [
    PANEL / "per_seed_results.csv",
    PANEL / "prediction_verification.csv",
    PANEL / "receipt.json",
]
for path in required_panel_files:
    if not path.is_file():
        raise FileNotFoundError(str(path))

panel_receipt = json.loads((PANEL / "receipt.json").read_text())
if not panel_receipt.get("all_saved_probabilities_reproduced"):
    raise ValueError("Panel receipt does not verify saved probabilities.")

results = pd.read_csv(PANEL / "per_seed_results.csv")
checks = pd.read_csv(PANEL / "prediction_verification.csv")

keys = ["scenario", "attack", "seed", "estimator"]
if (
    len(results) != 48
    or results.duplicated(keys).any()
    or set(results.scenario) != set(TARGETS)
    or set(results.seed) != {8101, 8102, 8103}
    or set(results.estimator) != {"AC", "AGREE"}
    or not results.attack.eq("PACE_1s").all()
):
    raise ValueError("Unexpected pacing panel structure.")

if (
    len(checks) != 48
    or not np.isfinite(checks.max_saved_probability_difference).all()
    or not (checks.max_saved_probability_difference <= 1e-12).all()
):
    raise ValueError("Saved-probability verification failed.")

completion_rows = []
for scenario in TARGETS:
    for attack in ["INJ_k1", "INJ_k3"]:
        job, receipt = completed_job(
            Path("E4_COMPACT_INJECTIONS_v2") / scenario / attack,
            "INJECTION_JOB_COMPLETE", scenario, attack
        )
        completion_rows.append({
            "scenario": scenario,
            "attack": attack,
            "status": receipt["status"],
            "job": str(job),
            "receipt_sha256": sha256_file(job / "receipt.json"),
            "prediction_sha256": sha256_file(job / "primary_outputs.npz"),
        })

    job, receipt = completed_job(
        Path("E4_COMPACT_PACING_v1") / scenario,
        "PACING_JOB_COMPLETE", scenario, "PACE_1s"
    )
    completion_rows.append({
        "scenario": scenario,
        "attack": "PACE_1s",
        "status": receipt["status"],
        "job": str(job),
        "receipt_sha256": sha256_file(job / "receipt.json"),
        "prediction_sha256": sha256_file(job / "primary_outputs.npz"),
    })

results["clean_absolute_error"] = (
    results.clean_estimate - results.clean_accuracy
).abs()
results["attack_absolute_error"] = (
    results.attack_estimate - results.attack_accuracy
).abs()

# Average errors over the three seeds before testing.
# Independent units are the eight scenarios, not the 24 seed rows.
scenario_errors = results.groupby(
    ["scenario", "estimator"], as_index=False
).agg(
    differential_abs_error=("differential_abs_error", "mean"),
    clean_absolute_error=("clean_absolute_error", "mean"),
    attack_absolute_error=("attack_absolute_error", "mean"),
    true_damage=("true_damage", "mean"),
    delayed_packets=("delayed_packets", "first"),
)

paired = scenario_errors.pivot(
    index="scenario", columns="estimator",
    values="differential_abs_error"
).reindex(TARGETS)
if paired.isna().any().any():
    raise ValueError("Incomplete paired scenario table.")

paired["AC_minus_AGREE_error"] = paired.AC - paired.AGREE
statistics = exact_sign_flip(paired.AC_minus_AGREE_error.to_numpy())

absolute_summary = scenario_errors.groupby(
    "estimator", as_index=False
).agg(
    mean_clean_absolute_error=("clean_absolute_error", "mean"),
    mean_attack_absolute_error=("attack_absolute_error", "mean"),
    mean_differential_error=("differential_abs_error", "mean"),
)

completion = pd.DataFrame(completion_rows)
OUT.mkdir(exist_ok=False)
completion.to_csv(OUT / "E4_completed_job_manifest.csv", index=False)
results.to_csv(OUT / "pacing_seed_results_with_absolute_errors.csv", index=False)
scenario_errors.to_csv(OUT / "pacing_scenario_errors.csv", index=False)
paired.reset_index().to_csv(
    OUT / "pacing_paired_scenario_gains.csv", index=False
)
absolute_summary.to_csv(
    OUT / "pacing_absolute_and_differential_error_summary.csv", index=False
)

receipt = {
    "status": "COMPACT_E4_COMPLETION_FROZEN",
    "injection_jobs_complete": 16,
    "pacing_jobs_complete": 8,
    "pacing_estimator_panel_complete": True,
    "pacing_statistics": statistics,
    "statistics_scope": (
        "Descriptive compact pacing comparison; eight scenario units, "
        "three-seed mean errors, exact sign-flip enumeration."
    ),
    "Holm_correction_applied": False,
    "Holm_reason": (
        "The complete three-transformation primary family has not yet "
        "been assembled and reconciled with the original protocol."
    ),
    "original_protocol_eligibility_reconciled": False,
    "adaptive_real_PCAP_E5_complete": False,
    "faithful_MD3_complete": False,
    "full_monitor_E6_complete": False,
    "actual_edge_hardware_measurement_complete": False,
    "models_retrained": False,
    "PCAP_replays": 0,
    "files_deleted": 0,
}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2))

print("E4 COMPLETED JOB COUNTS")
print(completion.groupby("attack").size().to_string())

print("\nPACING EXACT SIGN-FLIP STATISTICS")
print(json.dumps(statistics, indent=2))

print("\nABSOLUTE VERSUS DIFFERENTIAL ERROR")
print(absolute_summary.to_string(index=False))

print(f"\nSaved completion freeze: {OUT}")

# ===== CELL INPUT 42 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def run_three_treatment_tests():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    treatments = ["INJ_k1", "INJ_k3", "PACE_1s"]
    seeds = {8101, 8102, 8103}

    features = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    views = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }

    def sha(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024**2), b""):
                h.update(block)
        return h.hexdigest()

    def read_features(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        missing = set(features + ["ks", "y"]) - set(frame.columns)
        if missing:
            raise ValueError(f"Missing columns in {path}: {sorted(missing)}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for column in features:
            if column != "proto":
                frame[column] = pd.to_numeric(
                    frame[column].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        if (
            len(frame) != 1024 or frame.ks.duplicated().any()
            or int(frame.y.eq(0).sum()) != 512
            or int(frame.y.eq(1).sum()) != 512
        ):
            raise ValueError(f"Invalid frozen sample structure: {path}")
        return frame

    def matrix(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def clean_path(scenario):
        fragment = "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1"
        for root in [backup, work]:
            matches = [
                p for p in root.rglob("frozen_clean_target_sample.csv*")
                if p.is_file() and scenario in str(p)
                and fragment in str(p)
            ]
            if matches:
                return min(matches, key=lambda p: (len(p.parts), str(p)))
        raise FileNotFoundError(f"No preserved clean sample: {scenario}")

    def job_path(scenario, treatment):
        relative = (
            Path("E4_COMPACT_PACING_v1") / scenario
            if treatment == "PACE_1s"
            else Path("E4_COMPACT_INJECTIONS_v2") / scenario / treatment
        )
        expected = (
            "PACING_JOB_COMPLETE" if treatment == "PACE_1s"
            else "INJECTION_JOB_COMPLETE"
        )
        for root in [work, backup]:
            job = root / relative
            receipt_file = job / "receipt.json"
            if not receipt_file.is_file():
                continue
            receipt = json.loads(receipt_file.read_text())
            attacked = sorted(job.glob("attacked_selected_features.csv*"))
            if (
                receipt.get("status") == expected
                and receipt.get("scenario") == scenario
                and receipt.get("attack") == treatment
                and (job / "primary_outputs.npz").is_file()
                and len(attacked) == 1
            ):
                return job, attacked[0], receipt
        raise RuntimeError(
            f"Completed job with estimator features unavailable: "
            f"{scenario}/{treatment}. No replay has started."
        )

    model_paths = [
        root / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
        for root in [work, backup]
    ]
    model_path = next((p for p in model_paths if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Frozen model bundle unavailable.")
    bundle = joblib.load(model_path)

    if {int(s) for s in bundle["models"]} != seeds:
        raise ValueError("Unexpected frozen model seed set.")
    expected_widths = {
        "PRIMARY": 11, "V_orig": 3, "V_resp": 4, "V_time_proto": 4
    }
    for seed, bank in bundle["models"].items():
        for name, width in expected_widths.items():
            if name not in bank:
                raise ValueError(f"Missing model: seed={seed}, name={name}")
            if getattr(bank[name], "n_features_in_", None) != width:
                raise ValueError(f"Unexpected model input width: {seed}/{name}")

    rows, validation, provenance = [], [], []

    with threadpool_limits(limits=2):
        for scenario in targets:
            cp = clean_path(scenario)
            clean = read_features(cp)
            y = clean.y.to_numpy(int)

            for treatment in treatments:
                job, ap, receipt = job_path(scenario, treatment)
                attacked = read_features(ap)
                if set(clean.ks) != set(attacked.ks):
                    raise ValueError(f"Paired keys differ: {scenario}/{treatment}")
                attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
                if not np.array_equal(attacked.y.to_numpy(int), y):
                    raise ValueError("Paired labels differ.")

                with np.load(
                    job / "primary_outputs.npz", allow_pickle=False
                ) as saved:
                    keys = saved["ks"].astype(str)
                    if len(keys) != 1024 or len(set(keys)) != 1024:
                        raise ValueError("Invalid saved prediction keys.")
                    positions = pd.Index(keys).get_indexer(clean.ks)
                    if (positions < 0).any():
                        raise ValueError("Saved prediction alignment failed.")
                    if not np.array_equal(
                        saved["y"][positions].astype(int), y
                    ):
                        raise ValueError("Saved prediction labels differ.")

                    for seed, bank in bundle["models"].items():
                        state_results = []
                        for state, frame in [
                            ("clean", clean), ("attack", attacked)
                        ]:
                            p = bank["PRIMARY"].predict_proba(
                                matrix(frame, features)
                            )[:, 1]
                            stored = saved[
                                f"seed_{seed}_{state}_probability"
                            ][positions]
                            difference = float(np.max(np.abs(p-stored)))
                            if (
                                not np.isfinite(p).all()
                                or not np.isfinite(stored).all()
                                or difference > 1e-12
                            ):
                                raise ValueError(
                                    f"Saved prediction mismatch: "
                                    f"{scenario}/{treatment}/{seed}/{state}"
                                )

                            decision = p >= .5
                            votes = np.column_stack([
                                bank[name].predict(matrix(frame, columns))
                                for name, columns in views.items()
                            ])
                            if not np.isin(votes, [0, 1]).all():
                                raise ValueError("Nonbinary view predictions.")
                            majority = votes.sum(axis=1) >= 2
                            state_results.append({
                                "accuracy": float((decision == y).mean()),
                                "AC": float(np.maximum(p, 1-p).mean()),
                                "AGREE": float((decision == majority).mean()),
                            })
                            validation.append({
                                "scenario": scenario, "attack": treatment,
                                "seed": int(seed), "state": state,
                                "max_probability_difference": difference,
                            })

                        s0, s1 = state_results
                        for estimator in ["AC", "AGREE"]:
                            e0, e1 = s0[estimator], s1[estimator]
                            a0, a1 = s0["accuracy"], s1["accuracy"]
                            rows.append({
                                "scenario": scenario, "attack": treatment,
                                "seed": int(seed), "estimator": estimator,
                                "clean_accuracy": a0, "attack_accuracy": a1,
                                "true_damage": a0-a1,
                                "clean_estimate": e0, "attack_estimate": e1,
                                "clean_absolute_error": abs(e0-a0),
                                "attack_absolute_error": abs(e1-a1),
                                "differential_abs_error": abs(
                                    (e1-a1)-(e0-a0)
                                ),
                            })

                provenance.append({
                    "scenario": scenario, "attack": treatment,
                    "clean_file": str(cp), "attacked_file": str(ap),
                    "receipt_sha256": sha(job / "receipt.json"),
                    "predictions_sha256": sha(job / "primary_outputs.npz"),
                })
                print(f"Evaluated {scenario}/{treatment}", flush=True)

    results = pd.DataFrame(rows)
    if len(results) != 144 or len(validation) != 144:
        raise ValueError("Expected 144 estimator rows and 144 prediction checks.")
    if results.duplicated(
        ["scenario", "attack", "seed", "estimator"]
    ).any():
        raise ValueError("Duplicate estimator result rows.")

    scenario_results = results.groupby(
        ["scenario", "attack", "estimator"], as_index=False
    ).agg(
        differential_abs_error=("differential_abs_error", "mean"),
        clean_absolute_error=("clean_absolute_error", "mean"),
        attack_absolute_error=("attack_absolute_error", "mean"),
        true_damage=("true_damage", "mean"),
    )
    paired = scenario_results.pivot(
        index=["scenario", "attack"], columns="estimator",
        values="differential_abs_error"
    ).reset_index()
    paired["AC_minus_AGREE_error"] = paired.AC-paired.AGREE

    signs = np.asarray(list(itertools.product([-1., 1.], repeat=8)))
    tests = []
    for treatment in treatments:
        part = paired[paired.attack.eq(treatment)].set_index(
            "scenario"
        ).reindex(targets)
        gain = part.AC_minus_AGREE_error.to_numpy(float)
        if len(gain) != 8 or not np.isfinite(gain).all():
            raise ValueError("Incomplete eight-scenario comparison.")
        observed = float(gain.mean())
        null_means = (signs * gain).mean(axis=1)
        tests.append({
            "attack": treatment,
            "mean_gain_AC_minus_AGREE": observed,
            "one_sided_p": float(
                (null_means >= observed-1e-15).mean()
            ),
            "two_sided_p": float(
                (np.abs(null_means) >= abs(observed)-1e-15).mean()
            ),
            "positive_scenarios": int((gain > 0).sum()),
            "negative_scenarios": int((gain < 0).sum()),
            "zero_scenarios": int((gain == 0).sum()),
            "scenario_units": 8,
            "sign_patterns": 256,
        })

    tests = pd.DataFrame(tests)
    order = np.argsort(tests.one_sided_p.to_numpy(), kind="stable")
    sorted_p = tests.one_sided_p.to_numpy()[order]
    adjusted_sorted = np.minimum(
        1.0, np.maximum.accumulate(sorted_p * np.arange(3, 0, -1))
    )
    adjusted = np.empty(3)
    adjusted[order] = adjusted_sorted
    tests["Holm_adjusted_one_sided_p"] = adjusted
    tests["Holm_reject_at_0_05"] = adjusted <= .05

    summary = scenario_results.groupby(
        ["attack", "estimator"], as_index=False
    ).agg(
        mean_differential_error=("differential_abs_error", "mean"),
        mean_clean_absolute_error=("clean_absolute_error", "mean"),
        mean_attack_absolute_error=("attack_absolute_error", "mean"),
        mean_true_damage=("true_damage", "mean"),
    )

    out = work / (
        "E4_THREE_TREATMENT_COMPACT_ANALYSIS_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    results.to_csv(out / "per_seed_results.csv", index=False)
    scenario_results.to_csv(out / "scenario_results.csv", index=False)
    paired.to_csv(out / "paired_scenario_gains.csv", index=False)
    tests.to_csv(out / "three_sign_flip_tests_with_Holm.csv", index=False)
    summary.to_csv(out / "absolute_and_differential_error_summary.csv", index=False)
    pd.DataFrame(validation).to_csv(
        out / "saved_prediction_verification.csv", index=False
    )
    pd.DataFrame(provenance).to_csv(out / "input_provenance.csv", index=False)
    (out / "receipt.json").write_text(json.dumps({
        "status": "THREE_TREATMENT_COMPACT_COMPARISON_COMPLETE",
        "treatments": treatments,
        "independent_units_per_test": 8,
        "seed_aggregation": "Mean of per-seed errors within each scenario",
        "primary_comparison": "AC error minus AGREE error",
        "alternative": "AGREE has lower differential error",
        "Holm_family_size": 3,
        "scope": (
            "Compact-panel analysis after outcomes were visible; "
            "not automatically original-protocol confirmation."
        ),
        "original_eligibility_discrepancy_resolved": False,
        "model_keys": list(expected_widths),
        "models_retrained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "all_remaining_experiments_complete": False,
    }, indent=2))

    print("\nALL THREE TREATMENT TESTS")
    print(tests.to_string(index=False))
    print("\nABSOLUTE AND DIFFERENTIAL ERROR SUMMARY")
    print(summary.to_string(index=False))
    print(f"\nCompleted three-treatment analysis: {out}")

run_three_treatment_tests()

# ===== CELL INPUT 43 =====
from pathlib import Path
from datetime import datetime, timezone
import gc
import importlib.metadata
import json
import os
import platform
import time

import joblib
import numpy as np
import pandas as pd
import psutil
from threadpoolctl import threadpool_limits

def run_resource_experiment_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    features = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    views = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }
    configurations = ["PRIMARY_ONLY", "PRIMARY_PLUS_AC", "PRIMARY_PLUS_AGREE"]
    repeats = 15
    warmups = 3

    def locate_clean(scenario):
        fragment = "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1"
        for root in [backup, work]:
            matches = [
                p for p in root.rglob("frozen_clean_target_sample.csv*")
                if p.is_file() and scenario in str(p)
                and fragment in str(p)
            ]
            if matches:
                return min(matches, key=lambda p: (len(p.parts), str(p)))
        raise FileNotFoundError(f"Clean sample not found: {scenario}")

    def read_raw(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        if (
            len(frame) != 1024 or frame.ks.duplicated().any()
            or not set(features).issubset(frame.columns)
        ):
            raise ValueError(f"Invalid clean sample: {path}")
        return frame

    def preprocess(raw):
        frame = raw[features].copy()
        frame["proto"] = frame.proto.astype(str).str.lower()
        for column in features:
            if column != "proto":
                frame[column] = pd.to_numeric(
                    frame[column].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def matrix(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    model_candidates = [
        root / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
        for root in [work, backup]
    ]
    model_path = next((p for p in model_candidates if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Frozen model bundle unavailable.")

    bundle = joblib.load(model_path)
    if {int(s) for s in bundle["models"]} != {8101, 8102, 8103}:
        raise ValueError("Unexpected frozen seed set.")

    for seed, bank in bundle["models"].items():
        for name, width in {
            "PRIMARY": 11, "V_orig": 3, "V_resp": 4, "V_time_proto": 4
        }.items():
            if (
                name not in bank
                or getattr(bank[name], "n_features_in_", None) != width
            ):
                raise ValueError(f"Model schema mismatch: {seed}/{name}")

    raw_samples = {}
    sample_paths = {}
    for scenario in targets:
        sample_paths[scenario] = locate_clean(scenario)
        raw_samples[scenario] = read_raw(sample_paths[scenario])

    def execute_pipeline(raw, bank, configuration):
        frame = preprocess(raw)
        primary_probability = bank["PRIMARY"].predict_proba(
            matrix(frame, features)
        )[:, 1]
        if not np.isfinite(primary_probability).all():
            raise ValueError("Nonfinite primary probabilities.")

        primary_decision = primary_probability >= .5
        record = {
            "configuration": configuration,
            "rows": len(frame),
            "primary_positive_fraction": float(primary_decision.mean()),
        }
        vote_array = None

        if configuration == "PRIMARY_PLUS_AC":
            record["accuracy_estimate"] = float(
                np.maximum(primary_probability, 1-primary_probability).mean()
            )

        elif configuration == "PRIMARY_PLUS_AGREE":
            vote_array = np.column_stack([
                bank[name].predict(matrix(frame, columns))
                for name, columns in views.items()
            ])
            if not np.isin(vote_array, [0, 1]).all():
                raise ValueError("Nonbinary view predictions.")
            majority = vote_array.sum(axis=1) >= 2
            record["accuracy_estimate"] = float(
                (primary_decision == majority).mean()
            )
            record["view_positive_fractions"] = [
                float(vote_array[:, i].mean())
                for i in range(vote_array.shape[1])
            ]

        encoded = json.dumps(
            record, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
        return primary_probability, vote_array, encoded

    process = psutil.Process(os.getpid())
    timing_rows, memory_rows = [], []
    rng = np.random.default_rng(53107)

    # All configurations receive identical samples, seeds, and thread limits.
    # Configuration order is randomized per repetition to reduce order bias.
    with threadpool_limits(limits=2):
        for scenario in targets:
            raw = raw_samples[scenario]
            for seed, bank in bundle["models"].items():
                for configuration in configurations:
                    for _ in range(warmups):
                        execute_pipeline(raw, bank, configuration)

                for repetition in range(repeats):
                    for configuration in rng.permutation(configurations):
                        start = time.perf_counter_ns()
                        p, votes, encoded = execute_pipeline(
                            raw, bank, str(configuration)
                        )
                        elapsed_ns = time.perf_counter_ns()-start
                        timing_rows.append({
                            "scenario": scenario,
                            "seed": int(seed),
                            "configuration": str(configuration),
                            "repetition": repetition,
                            "rows": len(raw),
                            "elapsed_ms": elapsed_ns / 1e6,
                            "ms_per_1000_rows": elapsed_ns / 1e6 * 1000 / len(raw),
                            "evidence_record_bytes": len(encoded),
                        })

                for configuration in configurations:
                    gc.collect()
                    rss_before = process.memory_info().rss
                    p, votes, encoded = execute_pipeline(
                        raw, bank, configuration
                    )
                    rss_after = process.memory_info().rss
                    memory_rows.append({
                        "scenario": scenario,
                        "seed": int(seed),
                        "configuration": configuration,
                        "process_RSS_before_bytes": rss_before,
                        "process_RSS_after_bytes": rss_after,
                        "RSS_change_bytes": rss_after-rss_before,
                        "returned_probability_bytes": p.nbytes,
                        "returned_vote_bytes": 0 if votes is None else votes.nbytes,
                        "evidence_record_bytes": len(encoded),
                    })

            print(f"Finished all three resource tests: {scenario}", flush=True)

    timing = pd.DataFrame(timing_rows)
    memory = pd.DataFrame(memory_rows)

    medians = timing.groupby(
        ["scenario", "seed", "configuration"], as_index=False
    ).agg(
        median_ms_per_1000=("ms_per_1000_rows", "median"),
        p95_ms_per_1000=(
            "ms_per_1000_rows", lambda s: float(s.quantile(.95))
        ),
    )

    paired = medians.pivot(
        index=["scenario", "seed"], columns="configuration",
        values="median_ms_per_1000"
    ).reset_index()
    paired["AC_incremental_ms_per_1000"] = (
        paired.PRIMARY_PLUS_AC-paired.PRIMARY_ONLY
    )
    paired["AGREE_incremental_ms_per_1000"] = (
        paired.PRIMARY_PLUS_AGREE-paired.PRIMARY_ONLY
    )
    paired["AC_total_to_primary_ratio"] = (
        paired.PRIMARY_PLUS_AC/paired.PRIMARY_ONLY
    )
    paired["AGREE_total_to_primary_ratio"] = (
        paired.PRIMARY_PLUS_AGREE/paired.PRIMARY_ONLY
    )

    summary = medians.groupby("configuration", as_index=False).agg(
        median_unit_ms_per_1000=("median_ms_per_1000", "median"),
        mean_unit_ms_per_1000=("median_ms_per_1000", "mean"),
        maximum_unit_p95_ms_per_1000=("p95_ms_per_1000", "max"),
        scenario_seed_units=("median_ms_per_1000", "size"),
    )

    environment = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "logical_CPUs": psutil.cpu_count(logical=True),
        "physical_CPUs": psutil.cpu_count(logical=False),
        "RAM_total_bytes": psutil.virtual_memory().total,
        "thread_limit": 2,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["numpy", "pandas", "scikit-learn", "joblib"]
        },
    }

    out = work / (
        "E6_AC_AGREE_PIPELINE_RESOURCES_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    timing.to_csv(out / "raw_timings.csv", index=False)
    medians.to_csv(out / "scenario_seed_latency.csv", index=False)
    paired.to_csv(out / "paired_incremental_overhead.csv", index=False)
    memory.to_csv(out / "process_memory_observations.csv", index=False)
    summary.to_csv(out / "latency_summary.csv", index=False)
    (out / "environment.json").write_text(json.dumps(environment, indent=2))
    (out / "receipt.json").write_text(json.dumps({
        "status": "THREE_AC_AGREE_RESOURCE_EXPERIMENTS_COMPLETE",
        "configurations": configurations,
        "scenarios": len(targets),
        "seeds": 3,
        "repetitions_per_unit_configuration": repeats,
        "warmups_per_unit_configuration": warmups,
        "timing_rows": len(timing),
        "included": [
            "numeric normalization", "protocol one-hot encoding",
            "log1p feature construction", "primary inference",
            "AC computation or three-view inference and majority agreement",
            "JSON evidence-record serialization"
        ],
        "excluded": [
            "CSV disk loading", "model loading", "packet capture",
            "Zeek feature extraction", "drift-gate calibration and computation",
            "actual edge-device measurement", "energy measurement"
        ],
        "memory_caveat": (
            "RSS observations are process-level before/after measurements, "
            "not isolated model memory or sampled peak memory."
        ),
        "scope": "Kaggle CPU; AC and AGREE pipelines only",
        "full_drift_gated_monitor_E6_complete": False,
        "models_retrained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "sample_paths": {k: str(v) for k, v in sample_paths.items()},
    }, indent=2))

    print("\nTHREE RESOURCE EXPERIMENTS — LATENCY SUMMARY")
    print(summary.to_string(index=False))
    print("\nPAIRED OVERHEAD — MEAN ACROSS SCENARIO/SEED UNITS")
    print(paired[[
        "AC_incremental_ms_per_1000",
        "AGREE_incremental_ms_per_1000",
        "AC_total_to_primary_ratio",
        "AGREE_total_to_primary_ratio",
    ]].mean().to_string())
    print(f"\nCompleted resource batch: {out}")

run_resource_experiment_batch()

# ===== CELL INPUT 44 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

def export_remaining_method_definitions():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    roots = [work, backup]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    archive_path = work / f"REMAINING_METHOD_DEFINITIONS_{stamp}.zip"

    max_file_bytes = 4 * 1024**2
    max_package_bytes = 20 * 1024**2

    runner_names = [
        "run_frozen_trace_confirmation_v1_1.py",
        "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
    ]
    directory_names = [
        "TRACE_CONFIRMATORY_PROTOCOL_v1",
        "TRACE_CONFIRMATORY_PROTOCOL_v1_1_ESTIMATOR_AMENDMENT",
        "TRACE_CONFIRMATORY_SOURCE_MONITOR_CALIBRATION_v1_1",
    ]
    standalone_names = [
        "TRACE_CONFIRMATORY_PROTOCOL_AMENDMENT_v1_1.json",
        "TRACE_CONFIRMATORY_EXECUTION_FIX_v1_1.json",
    ]
    text_extensions = {
        ".py", ".json", ".yaml", ".yml", ".md",
        ".txt", ".csv", ".toml", ".ini"
    }

    selected = []
    inventory = []
    missing = []

    def locate_file(filename):
        for root in roots:
            direct = root / filename
            if direct.is_file():
                return direct
        for root in roots:
            if root.is_dir():
                matches = [
                    p for p in root.rglob(filename)
                    if p.is_file()
                ]
                if matches:
                    return min(
                        matches, key=lambda p: (len(p.parts), str(p))
                    )
        return None

    def locate_directory(dirname):
        for root in roots:
            direct = root / dirname
            if direct.is_dir():
                return direct
        for root in roots:
            if root.is_dir():
                matches = [
                    p for p in root.rglob(dirname)
                    if p.is_dir()
                ]
                if matches:
                    return min(
                        matches, key=lambda p: (len(p.parts), str(p))
                    )
        return None

    def register(path, archive_name):
        size = path.stat().st_size
        record = {
            "source": str(path),
            "archive_name": archive_name,
            "bytes": size,
            "included": False,
        }
        if path.suffix.lower() not in text_extensions:
            record["reason"] = "Binary artifact inventoried, not loaded or copied."
        elif size > max_file_bytes:
            record["reason"] = "Exceeds 4 MiB per-file review limit."
        else:
            selected.append((path, archive_name))
            record["included"] = True
            record["reason"] = "Small method/configuration source."
        inventory.append(record)

    for filename in runner_names + standalone_names:
        path = locate_file(filename)
        if path is None:
            missing.append(filename)
        else:
            register(path, f"standalone/{filename}")

    for dirname in directory_names:
        directory = locate_directory(dirname)
        if directory is None:
            missing.append(dirname)
            continue

        for path in sorted(directory.rglob("*")):
            if path.is_file() and not path.is_symlink():
                relative = path.relative_to(directory).as_posix()
                register(path, f"{dirname}/{relative}")

    payload_bytes = sum(path.stat().st_size for path, _ in selected)
    if payload_bytes > max_package_bytes:
        raise RuntimeError(
            f"Review payload is {payload_bytes / 1024**2:.2f} MiB, "
            "above the 20 MiB limit. Nothing was packaged or deleted."
        )
    if not selected:
        raise RuntimeError(
            "No method-definition files found. No experiment was run."
        )

    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": (
            "Inspect exact frozen monitor/protocol definitions before "
            "implementing E5, faithful MD3, and full-monitor timing."
        ),
        "missing_requested_items": missing,
        "inventory": inventory,
        "text_payload_bytes": payload_bytes,
        "model_objects_loaded": False,
        "scripts_executed": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "all_experiments_complete": False,
    }

    with zipfile.ZipFile(
        archive_path, "x",
        compression=zipfile.ZIP_DEFLATED,
        allowZip64=True
    ) as archive:
        for path, name in selected:
            content = path.read_bytes()
            archive.writestr(name, content)
        archive.writestr(
            "review_manifest.json",
            json.dumps(manifest, indent=2)
        )

    with zipfile.ZipFile(archive_path, "r") as archive:
        bad_member = archive.testzip()
        if bad_member is not None:
            raise RuntimeError(f"ZIP integrity failure: {bad_member}")

    digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()

    # A readable companion lets the method definitions be reviewed directly
    # without requiring binary ZIP support in the chat.
    text_path = archive_path.with_suffix(".txt")
    with open(text_path, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(manifest, indent=2))
        for path, name in selected:
            handle.write(f"\n\n{'=' * 72}\nFILE: {name}\n{'=' * 72}\n")
            handle.write(path.read_text(encoding="utf-8", errors="replace"))

    print("METHOD-DEFINITION PACKAGE READY")
    print(f"ZIP: {archive_path.name}")
    print(f"Readable text: {text_path.name}")
    print(f"ZIP size: {archive_path.stat().st_size / 1024**2:.3f} MiB")
    print(f"SHA-256: {digest}")
    print(f"Included text files: {len(selected)}")
    print(f"Missing requested items: {missing}")
    print("\nNo training, replay, deletion, or large dataset copying occurred.")

export_remaining_method_definitions()

# ===== CELL INPUT 45 =====
from pathlib import Path
import zipfile

package = Path(
    "/kaggle/working/"
    "REMAINING_METHOD_DEFINITIONS_20261013T132457293630Z.zip"
)

if not package.is_file():
    raise FileNotFoundError(
        "The method-definition package is not in this runtime. "
        "Attach the text file you generated instead."
    )

with zipfile.ZipFile(package, "r") as archive:
    members = [
        member for member in archive.infolist()
        if not member.is_dir()
        and member.filename.endswith(
            (".py", ".json", ".yaml", ".yml", ".md", ".txt")
        )
        and member.filename != "review_manifest.json"
    ]

    total_bytes = sum(member.file_size for member in members)
    if total_bytes > 2 * 1024**2:
        raise RuntimeError(
            "The definitions exceed the 2 MiB print limit. "
            "Attach the generated text file rather than pasting it."
        )

    for member in members:
        print("\n" + "=" * 80)
        print("FILE:", member.filename)
        print("=" * 80)
        print(archive.read(member).decode("utf-8", errors="replace"))

# ===== CELL INPUT 46 =====
from pathlib import Path
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
import ast
import bisect
import gzip
import hashlib
import ipaddress
import json
import struct
from datetime import datetime, timezone

import numpy as np
import pandas as pd

def audit_all_injection_eligibility():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    helper = backup / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
    if not helper.is_file():
        helper = work / helper.name
    if not helper.is_file():
        raise FileNotFoundError("Saved streaming packet helpers unavailable.")

    required = {"key", "skey", "pcap_iter", "pcap_header", "tcp"}
    tree = ast.parse(helper.read_text())
    definitions = [
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in required
    ]
    if {n.name for n in definitions} != required:
        raise ValueError("Incomplete packet-helper definitions.")

    ns = dict(globals())
    ns["MAGICS"] = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1),
    }
    exec(compile(ast.fix_missing_locations(
        ast.Module(body=definitions, type_ignores=[])
    ), "eligibility_packet_helpers", "exec"), ns)
    key, skey = ns["key"], ns["skey"]
    packets, header, tcp = ns["pcap_iter"], ns["pcap_header"], ns["tcp"]

    def read_csv(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        return pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )

    def read_log(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        opener = gzip.open if compressed else open
        fields = None
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("#fields"):
                    fields = line.strip().split()[1:]
                elif not line.startswith("#") and line.strip():
                    if fields is None:
                        raise ValueError(f"Missing Zeek fields: {path}")
                    yield dict(zip(fields, line.rstrip().split()))

    def find_sample(scenario):
        for root in [backup, work]:
            matches = [
                p for p in root.rglob("frozen_clean_target_sample.csv*")
                if scenario in str(p)
                and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
                and p.is_file()
            ]
            if matches:
                return min(matches, key=lambda p: (len(p.parts), str(p)))
        raise FileNotFoundError(f"Frozen sample unavailable: {scenario}")

    def find_e1(scenario, suffix):
        e1 = backup / "E1_BLIND_TARGETS_20261012T125026604016Z"
        matches = [
            p for p in e1.rglob("*")
            if p.is_file() and scenario in str(p)
            and p.name.endswith(suffix)
        ]
        if len(matches) != 1:
            raise ValueError(
                f"Expected one {scenario}/{suffix}; found {len(matches)}"
            )
        return matches[0]

    def find_receipt(scenario, attack):
        for root in [work, backup]:
            path = (
                root / "E4_COMPACT_INJECTIONS_v2"
                / scenario / attack / "receipt.json"
            )
            if path.is_file():
                value = json.loads(path.read_text())
                if (
                    value.get("status") == "INJECTION_JOB_COMPLETE"
                    and value.get("scenario") == scenario
                    and value.get("attack") == attack
                ):
                    return path, value
        raise ValueError(f"Completed injection receipt missing: {scenario}/{attack}")

    out = work / (
        "E4_WRITTEN_PROTOCOL_ELIGIBILITY_AUDIT_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    flow_rows, job_rows = [], []

    for scenario in targets:
        sample_path = find_sample(scenario)
        sample = read_csv(sample_path)
        if len(sample) != 1024 or sample.ks.duplicated().any():
            raise ValueError(f"Invalid frozen sample: {scenario}")
        sample["y"] = pd.to_numeric(sample.y, errors="raise").astype(int)
        labels = dict(zip(sample.ks.astype(str), sample.y))
        wanted = set(labels)

        conn = find_e1(scenario, "conn.log")
        pcap = find_e1(scenario, "slice.pcap")
        flows, separators = {}, set()

        for row in read_log(conn):
            base = key(
                row["ts"], row["id.orig_h"], row["id.orig_p"],
                row["id.resp_h"], row["id.resp_p"], row["proto"]
            )
            for sep in ["|", "::", ","]:
                k = skey(base, sep)
                if k in wanted:
                    if k in flows:
                        raise ValueError("Duplicate selected conn-log key.")
                    flows[k] = row
                    separators.add(sep)
                    break
        if set(flows) != wanted or len(separators) != 1:
            raise ValueError(f"Nonunique clean-flow linkage: {scenario}")

        descriptions = defaultdict(list)
        for k, row in flows.items():
            if labels[k] != 1 or row["proto"].lower() != "tcp":
                continue
            start = int(Decimal(row["ts"]) * 10**9)
            duration = (
                0 if row["duration"] == "-"
                else int(Decimal(row["duration"]) * 10**9)
            )
            endpoints = tuple(sorted([
                (row["id.orig_h"], int(row["id.orig_p"])),
                (row["id.resp_h"], int(row["id.resp_p"]))
            ]))
            descriptions[endpoints].append(
                (start, start + duration + 1_000_000, k)
            )
        for values in descriptions.values():
            values.sort()
        starts = {
            t: [v[0] for v in values]
            for t, values in descriptions.items()
        }
        _, _, _, network = header(pcap)
        total, originator, header_only = (
            defaultdict(int), defaultdict(int), defaultdict(int)
        )

        print(f"Auditing original packets: {scenario}", flush=True)
        for _, timestamp, _, payload in packets(pcap):
            info = tcp(payload, network)
            if info is None:
                continue
            src, sp, dst, dp, data_bytes, _ = info
            endpoints = tuple(sorted([(src, sp), (dst, dp)]))
            if endpoints not in descriptions:
                continue
            j = bisect.bisect_right(starts[endpoints], timestamp) - 1
            if j < 0:
                continue
            start, end, k = descriptions[endpoints][j]
            if timestamp > end:
                continue
            total[k] += 1
            row = flows[k]
            if src == row["id.orig_h"] and sp == int(row["id.orig_p"]):
                originator[k] += 1
                header_only[k] += int(data_bytes == 0)

        eligible = {
            k for k in flows
            if labels[k] == 1 and flows[k]["proto"].lower() == "tcp"
            and originator[k] >= 2 and header_only[k] >= 1
        }
        for k in descriptions.values():
            for _, _, flow_key in k:
                flow_rows.append({
                    "scenario": scenario, "ks": flow_key,
                    "total_tcp_packets": total[flow_key],
                    "originator_tcp_packets": originator[flow_key],
                    "header_only_originator_packets": header_only[flow_key],
                    "written_injection_eligible": flow_key in eligible,
                    "written_pacing_eligible": total[flow_key] >= 2,
                })

        for attack in ["INJ_k1", "INJ_k3"]:
            receipt_path, receipt = find_receipt(scenario, attack)
            counts = receipt.get("injection_counts")
            if not isinstance(counts, dict):
                job_rows.append({
                    "scenario": scenario, "attack": attack,
                    "status": "UNRESOLVED_NO_PER_FLOW_INJECTION_RECORD",
                    "written_eligible_flows": len(eligible),
                    "injected_flows": receipt.get("injected_flows"),
                    "ineligible_injected_flows": None,
                })
                continue

            injected = {str(k) for k, n in counts.items() if int(n) > 0}
            if not injected.issubset(wanted):
                raise ValueError("Injection receipt contains keys outside sample.")
            violations = sorted(injected-eligible)
            job_rows.append({
                "scenario": scenario, "attack": attack,
                "status": (
                    "ELIGIBILITY_MATCH" if not violations
                    else "WRITTEN_ELIGIBILITY_VIOLATION"
                ),
                "written_eligible_flows": len(eligible),
                "injected_flows": len(injected),
                "ineligible_injected_flows": len(violations),
            })
            if violations:
                pd.DataFrame({"ks": violations}).to_csv(
                    out / f"{scenario}_{attack}_ineligible_injected_keys.csv",
                    index=False
                )

        pd.DataFrame(flow_rows).to_csv(out / "selected_flow_counts.csv", index=False)
        pd.DataFrame(job_rows).to_csv(out / "injection_eligibility_results.csv", index=False)

    jobs = pd.DataFrame(job_rows)
    (out / "receipt.json").write_text(json.dumps({
        "status": "EIGHT_TARGET_INJECTION_ELIGIBILITY_AUDIT_COMPLETE",
        "pacing_written_rule": "Total TCP packets >=2",
        "injection_written_rule": (
            "Malicious TCP; >=2 originator packets; "
            "at least one header-only originator packet"
        ),
        "violating_jobs": int(
            jobs.status.eq("WRITTEN_ELIGIBILITY_VIOLATION").sum()
        ),
        "unresolved_jobs": int(
            jobs.status.eq("UNRESOLVED_NO_PER_FLOW_INJECTION_RECORD").sum()
        ),
        "PCAP_replays": 0,
        "models_retrained": False,
        "existing_results_changed": False,
        "files_deleted": 0,
        "all_remaining_tasks_complete": False,
    }, indent=2))

    print("\nALL SIXTEEN INJECTION ELIGIBILITY RESULTS")
    print(jobs.to_string(index=False))
    print(f"\nSaved: {out}")

audit_all_injection_eligibility()

# ===== CELL INPUT 47 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
import ast
import bisect
import gzip
import hashlib
import ipaddress
import itertools
import json
import resource
import shutil
import struct
import subprocess
import tempfile

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def complete_eligible_injection_panel():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    audit = work / "E4_WRITTEN_PROTOCOL_ELIGIBILITY_AUDIT_20261013T133031063652Z"
    pace = work / "E4_PACING_ESTIMATOR_PANEL_20261013T130527426625Z"
    out = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    out.mkdir(exist_ok=True)

    counts = pd.read_csv(audit / "selected_flow_counts.csv", dtype={"ks": str})
    audits = pd.read_csv(audit / "injection_eligibility_results.csv")
    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    V = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"]
    }
    model_path = backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    helper = backup / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
    bundle = joblib.load(model_path)

    def write_json(path, obj):
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(obj, indent=2))
        temporary.replace(path)

    def sha(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8*1024**2), b""):
                h.update(block)
        return h.hexdigest()

    def csv(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        return pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )

    def normalize(frame):
        frame = frame.copy()
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def mat(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def log_rows(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        opener = gzip.open if compressed else open
        fields = None
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("#fields"):
                    fields = line.strip().split()[1:]
                elif not line.startswith("#") and line.strip():
                    if fields is None:
                        raise ValueError("Missing Zeek fields.")
                    yield dict(zip(fields, line.rstrip().split()))

    def find_sample(scenario):
        matches = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not matches:
            raise FileNotFoundError(scenario)
        return min(matches, key=lambda p: (len(p.parts), str(p)))

    def old_job(scenario, attack):
        for root in [work, backup]:
            job = root / "E4_COMPACT_INJECTIONS_v2" / scenario / attack
            if (job / "receipt.json").is_file():
                receipt = json.loads((job / "receipt.json").read_text())
                if receipt.get("status") == "INJECTION_JOB_COMPLETE":
                    return job, receipt
        raise ValueError("Completed compact injection unavailable.")

    def evaluate(clean, attacked, scenario, attack, mode, injected):
        if set(clean.ks) != set(attacked.ks):
            raise ValueError("Paired feature keys differ.")
        attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
        y = clean.y.to_numpy(int)
        if not np.array_equal(y, attacked.y.to_numpy(int)):
            raise ValueError("Paired labels differ.")
        rows, arrays = [], {"ks": clean.ks.to_numpy(str), "y": y}
        with threadpool_limits(limits=2):
            for seed, bank in bundle["models"].items():
                values = []
                for frame in [clean, attacked]:
                    p = bank["PRIMARY"].predict_proba(mat(frame, F))[:, 1]
                    decision = p >= .5
                    votes = np.column_stack([
                        bank[name].predict(mat(frame, columns))
                        for name, columns in V.items()
                    ])
                    values.append((
                        p, float((decision == y).mean()),
                        float(np.maximum(p, 1-p).mean()),
                        float((decision == (votes.sum(axis=1) >= 2)).mean())
                    ))
                p0, a0, ac0, ag0 = values[0]
                p1, a1, ac1, ag1 = values[1]
                arrays[f"seed_{seed}_clean_probability"] = p0
                arrays[f"seed_{seed}_attack_probability"] = p1
                for estimator, e0, e1 in [
                    ("AC", ac0, ac1), ("AGREE", ag0, ag1)
                ]:
                    rows.append({
                        "scenario": scenario, "attack": attack,
                        "seed": int(seed), "estimator": estimator,
                        "clean_accuracy": a0, "attack_accuracy": a1,
                        "true_damage": a0-a1,
                        "clean_estimate": e0, "attack_estimate": e1,
                        "differential_abs_error": abs((e1-a1)-(e0-a0)),
                        "execution_mode": mode,
                        "injected_flows": injected,
                    })
        return pd.DataFrame(rows), arrays

    required = {"key", "skey", "pcap_iter", "pcap_header", "tcp"}
    tree = ast.parse(helper.read_text())
    definitions = [
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in required
    ]
    if {n.name for n in definitions} != required:
        raise ValueError("Incomplete saved helpers.")
    ns = dict(globals())
    ns["MAGICS"] = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1)
    }
    exec(compile(ast.fix_missing_locations(
        ast.Module(body=definitions, type_ignores=[])
    ), "eligible_injection_helpers", "exec"), ns)
    key, skey = ns["key"], ns["skey"]
    packets, header, tcp = ns["pcap_iter"], ns["pcap_header"], ns["tcp"]

    for scenario in targets:
        sample_path = find_sample(scenario)
        clean = normalize(csv(sample_path))
        if len(clean) != 1024 or clean.ks.duplicated().any():
            raise ValueError("Invalid clean sample.")

        eligible_mask = (
            counts.scenario.eq(scenario)
            & counts.written_injection_eligible.astype(str).str.lower().eq("true")
        )
        eligible = set(counts.loc[eligible_mask, "ks"])
        wanted = set(clean.ks)
        if not eligible.issubset(wanted):
            raise ValueError("Audit eligibility keys outside frozen sample.")

        for kdup in [1, 3]:
            attack = f"INJ_k{kdup}"
            job = out / scenario / attack
            job.mkdir(parents=True, exist_ok=True)
            done = job / "receipt.json"
            if done.is_file():
                r = json.loads(done.read_text())
                if r.get("status") == "ELIGIBLE_INJECTION_JOB_COMPLETE":
                    print(f"Reusing completed corrected job: {scenario}/{attack}")
                    continue
                raise ValueError("Unexpected corrected receipt; not overwriting.")

            previous_job, previous_receipt = old_job(scenario, attack)
            audit_row = audits[
                audits.scenario.eq(scenario) & audits.attack.eq(attack)
            ]
            if len(audit_row) != 1:
                raise ValueError("Missing unique audit row.")
            mode, injected = "", 0

            if not eligible:
                attacked = clean.copy()
                mode = "EXACT_IDENTITY_ZERO_ELIGIBLE_FLOWS"

            elif audit_row.iloc[0]["status"] == "ELIGIBILITY_MATCH":
                candidates = sorted(previous_job.glob("attacked_selected_features.csv*"))
                if len(candidates) != 1:
                    raise ValueError("Saved attacked features unavailable.")
                attacked = normalize(csv(candidates[0]))
                mode = "REUSED_AUDITED_ELIGIBILITY_MATCH"
                injected = int(previous_receipt["injected_flows"])

            else:
                mode = "NEW_ELIGIBILITY_CORRECTED_PCAP_REPLAY"
                e1 = backup / "E1_BLIND_TARGETS_20261012T125026604016Z"

                def asset(suffix):
                    found = [
                        p for p in e1.rglob("*")
                        if p.is_file() and scenario in str(p)
                        and p.name.endswith(suffix)
                    ]
                    if len(found) != 1:
                        raise ValueError(f"Cannot resolve {scenario}/{suffix}")
                    return found[0]

                pcap, conn = asset("slice.pcap"), asset("conn.log")
                h, endian, unit, net = header(pcap)
                flows, separator = {}, None
                for row in log_rows(conn):
                    base = key(
                        row["ts"], row["id.orig_h"], row["id.orig_p"],
                        row["id.resp_h"], row["id.resp_p"], row["proto"]
                    )
                    for sep in ["|", "::", ","]:
                        kk = skey(base, sep)
                        if kk in wanted:
                            if kk in flows:
                                raise ValueError("Ambiguous clean flow.")
                            flows[kk] = row
                            if separator is not None and separator != sep:
                                raise ValueError("Inconsistent key separator.")
                            separator = sep
                            break
                if set(flows) != wanted:
                    raise ValueError("Incomplete clean flow mapping.")

                descriptions = defaultdict(list)
                for kk in eligible:
                    row = flows[kk]
                    start = int(Decimal(row["ts"])*10**9)
                    duration = (
                        0 if row["duration"] == "-"
                        else int(Decimal(row["duration"])*10**9)
                    )
                    endpoints = tuple(sorted([
                        (row["id.orig_h"], int(row["id.orig_p"])),
                        (row["id.resp_h"], int(row["id.resp_p"]))
                    ]))
                    descriptions[endpoints].append(
                        (start, start+duration+1_000_000, kk)
                    )
                for values in descriptions.values():
                    values.sort()
                starts = {t: [v[0] for v in vs] for t, vs in descriptions.items()}
                last_header = {}
                for i, ts, wire, payload in packets(pcap):
                    info = tcp(payload, net)
                    if info is None:
                        continue
                    src, sp, dst, dp, data_bytes, _ = info
                    endpoints = tuple(sorted([(src, sp), (dst, dp)]))
                    if endpoints not in descriptions:
                        continue
                    j = bisect.bisect_right(starts[endpoints], ts)-1
                    if j < 0:
                        continue
                    start, end, kk = descriptions[endpoints][j]
                    row = flows[kk]
                    if (
                        ts <= end and src == row["id.orig_h"]
                        and sp == int(row["id.orig_p"]) and data_bytes == 0
                    ):
                        last_header[kk] = i
                if set(last_header) != eligible:
                    raise ValueError("Audited header-only packet not found.")

                if shutil.disk_usage(work).free < pcap.stat().st_size*3+1024**3:
                    raise RuntimeError("Insufficient replay disk reserve.")
                zeek = shutil.which("zeek") or "/opt/zeek/bin/zeek"
                temp = Path(tempfile.mkdtemp(prefix="eligible_replay_", dir=job))
                try:
                    transformed = temp / "transformed.pcap"
                    selected_indices = {i: kk for kk, i in last_header.items()}
                    inserted = set()
                    pending = None
                    original_hash, copied_hash = hashlib.sha256(), hashlib.sha256()
                    previous_output = None

                    with open(transformed, "wb") as target:
                        target.write(h)

                        def emit(ts, wire, payload):
                            nonlocal previous_output
                            if previous_output is not None and ts < previous_output:
                                raise ValueError("Output timestamps unordered.")
                            target.write(struct.pack(
                                endian+"IIII", ts//10**9, (ts%10**9)//unit,
                                len(payload), wire
                            ))
                            target.write(payload)
                            previous_output = ts

                        for i, ts, wire, payload in packets(pcap):
                            if pending is not None:
                                kk, pts, pwire, ppayload = pending
                                if pts+kdup*1000 <= ts:
                                    for q in range(1, kdup+1):
                                        emit(pts+q*1000, pwire, ppayload)
                                    inserted.add(kk)
                                pending = None
                            signature = struct.pack("!II", len(payload), wire)+payload
                            original_hash.update(signature)
                            emit(ts, wire, payload)
                            copied_hash.update(signature)
                            if i in selected_indices:
                                pending = (selected_indices[i], ts, wire, payload)
                        if pending is not None:
                            kk, pts, pwire, ppayload = pending
                            for q in range(1, kdup+1):
                                emit(pts+q*1000, pwire, ppayload)
                            inserted.add(kk)

                    if original_hash.digest() != copied_hash.digest():
                        raise ValueError("Original-byte preservation failed.")

                    def limit():
                        resource.setrlimit(
                            resource.RLIMIT_AS, (6*1024**3, 6*1024**3)
                        )
                    print(f"Replaying corrected {scenario}/{attack}", flush=True)
                    with open(job/"zeek_stdout.txt", "w") as stdout, open(
                        job/"zeek_stderr.txt", "w"
                    ) as stderr:
                        process = subprocess.run(
                            [str(zeek), "-C", "-r", str(transformed)],
                            cwd=temp, stdout=stdout, stderr=stderr,
                            timeout=1800, preexec_fn=limit
                        )
                    if process.returncode or not (temp/"conn.log").is_file():
                        raise RuntimeError("Zeek failed; retained stderr available.")
                    mapped = {}
                    for row in log_rows(temp/"conn.log"):
                        kk = skey(key(
                            row["ts"], row["id.orig_h"], row["id.orig_p"],
                            row["id.resp_h"], row["id.resp_p"], row["proto"]
                        ), separator)
                        if kk in wanted:
                            if kk in mapped:
                                raise ValueError("Ambiguous attacked flow.")
                            mapped[kk] = row
                    if set(mapped) != wanted:
                        raise ValueError("Incomplete attacked flow mapping.")
                    attacked = normalize(pd.DataFrame([
                        {**{c: mapped[kk][c] for c in F}, "ks": kk, "y": int(y)}
                        for kk, y in zip(clean.ks, clean.y)
                    ]))
                    injected = len(inserted)
                    write_json(job/"transformation_checks.json", {
                        "eligible_keys": sorted(eligible),
                        "injected_keys": sorted(inserted),
                        "skipped_unsafe_gap_keys": sorted(eligible-inserted),
                        "original_bytes_preserved": True,
                        "original_packet_order_preserved": True,
                        "transformed_pcap_sha256": sha(transformed),
                    })
                finally:
                    shutil.rmtree(temp, ignore_errors=True)

            results, arrays = evaluate(
                clean, attacked, scenario, attack, mode, injected
            )

            # Verify reused predictions before accepting a reused job.
            if mode == "REUSED_AUDITED_ELIGIBILITY_MATCH":
                with np.load(
                    previous_job/"primary_outputs.npz", allow_pickle=False
                ) as saved:
                    positions = pd.Index(saved["ks"].astype(str)).get_indexer(clean.ks)
                    if (positions < 0).any():
                        raise ValueError("Reused prediction keys mismatch.")
                    for seed in bundle["models"]:
                        for state in ["clean", "attack"]:
                            name = f"seed_{seed}_{state}_probability"
                            if not np.allclose(
                                arrays[name], saved[name][positions],
                                atol=1e-12, rtol=0
                            ):
                                raise ValueError("Reused prediction verification failed.")

            results.to_csv(job/"estimator_results.csv", index=False)
            attacked.to_csv(job/"attacked_selected_features.csv", index=False)
            np.savez_compressed(job/"primary_outputs.npz", **arrays)
            write_json(done, {
                "status": "ELIGIBLE_INJECTION_JOB_COMPLETE",
                "scenario": scenario, "attack": attack,
                "execution_mode": mode,
                "eligible_flows": len(eligible), "injected_flows": injected,
                "clean_sample": str(sample_path),
                "old_results_preserved": True,
                "new_analytical_identity_not_packet_replayed": not bool(eligible),
                "models_retrained": False,
                "source_audit": str(audit),
            })
            print(f"Completed {scenario}/{attack}: {mode}", flush=True)

    injection = pd.concat([
        pd.read_csv(out/scenario/attack/"estimator_results.csv")
        for scenario in targets for attack in ["INJ_k1", "INJ_k3"]
    ], ignore_index=True)
    pacing = pd.read_csv(pace/"per_seed_results.csv")
    combined = pd.concat([injection, pacing], ignore_index=True)
    if len(combined) != 144:
        raise ValueError("Expected 144 combined estimator rows.")

    scenario_errors = combined.groupby(
        ["scenario", "attack", "estimator"], as_index=False
    ).differential_abs_error.mean()
    gains = scenario_errors.pivot(
        index=["scenario", "attack"], columns="estimator",
        values="differential_abs_error"
    ).reset_index()
    gains["AC_minus_AGREE_error"] = gains.AC-gains.AGREE
    signs = np.asarray(list(itertools.product([-1., 1.], repeat=8)))
    tests = []
    for attack in ["INJ_k1", "INJ_k3", "PACE_1s"]:
        g = gains[gains.attack.eq(attack)].set_index("scenario").reindex(
            targets
        ).AC_minus_AGREE_error.to_numpy(float)
        if not np.isfinite(g).all():
            raise ValueError("Incomplete scenario inference.")
        observed = float(g.mean())
        null = (signs*g).mean(axis=1)
        tests.append({
            "attack": attack, "mean_gain": observed,
            "one_sided_p": float((null >= observed-1e-15).mean()),
            "positive_scenarios": int((g > 0).sum()),
            "negative_scenarios": int((g < 0).sum()),
            "zero_scenarios": int((g == 0).sum()),
        })
    tests = pd.DataFrame(tests)
    order = np.argsort(tests.one_sided_p.to_numpy())
    adjusted = np.empty(3)
    adjusted[order] = np.minimum(1, np.maximum.accumulate(
        tests.one_sided_p.to_numpy()[order]*np.array([3, 2, 1])
    ))
    tests["Holm_adjusted_p"] = adjusted
    tests["Holm_reject_at_0_05"] = adjusted <= .05

    combined.to_csv(out/"corrected_three_treatment_results.csv", index=False)
    gains.to_csv(out/"corrected_scenario_gains.csv", index=False)
    tests.to_csv(out/"corrected_three_test_Holm.csv", index=False)
    write_json(out/"completion_receipt.json", {
        "status": "ELIGIBILITY_CORRECTED_INJECTION_PANEL_COMPLETE",
        "injection_jobs": 16,
        "old_compact_results_preserved": True,
        "statistics_scope": (
            "Eligibility-corrected semantic-view AC/AGREE panel. "
            "Agreement-amendment and chronology reconciliation remain."
        ),
        "E5_complete": False,
        "faithful_MD3_complete": False,
        "full_drift_gate_timing_complete": False,
        "edge_hardware_complete": False,
        "all_study_tasks_complete": False,
    })
    print("\nCORRECTED THREE-TREATMENT TESTS")
    print(tests.to_string(index=False))
    print(f"\nSaved corrected panel: {out}")

complete_eligible_injection_panel()

# ===== CELL INPUT 48 =====
from pathlib import Path
from datetime import datetime, timezone
import json

import numpy as np
import pandas as pd

def reconcile_agreement_definitions():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    pace_panel = work / "E4_PACING_ESTIMATOR_PANEL_20261013T130527426625Z"

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    treatments = ["INJ_k1", "INJ_k3", "PACE_1s"]
    seeds = [8101, 8102, 8103]

    corrected_results = corrected / "corrected_three_treatment_results.csv"
    if not corrected_results.is_file():
        raise FileNotFoundError(
            "Eligibility-corrected three-treatment result table unavailable."
        )
    executed = pd.read_csv(corrected_results)
    semantic = executed[executed.estimator.eq("AGREE")].copy()
    key_columns = ["scenario", "attack", "seed"]
    if len(semantic) != 72 or semantic.duplicated(key_columns).any():
        raise ValueError("Expected 72 unique semantic-view AGREE rows.")

    def prediction_path(scenario, treatment):
        if treatment != "PACE_1s":
            path = corrected / scenario / treatment / "primary_outputs.npz"
            if not path.is_file():
                raise FileNotFoundError(str(path))
            return path

        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            path = job / "primary_outputs.npz"
            if receipt_path.is_file() and path.is_file():
                receipt = json.loads(receipt_path.read_text())
                if (
                    receipt.get("status") == "PACING_JOB_COMPLETE"
                    and receipt.get("scenario") == scenario
                ):
                    return path
        raise FileNotFoundError(f"Completed pacing predictions: {scenario}")

    rows = []
    provenance = []

    for scenario in targets:
        for treatment in treatments:
            path = prediction_path(scenario, treatment)
            with np.load(path, allow_pickle=False) as saved:
                keys = saved["ks"].astype(str)
                y = saved["y"].astype(int)
                if (
                    len(keys) != 1024 or len(set(keys)) != 1024
                    or y.shape != (1024,)
                    or not np.isin(y, [0, 1]).all()
                ):
                    raise ValueError(f"Invalid prediction membership: {path}")

                state_probabilities = {}
                for state in ["clean", "attack"]:
                    probabilities = np.column_stack([
                        saved[f"seed_{seed}_{state}_probability"]
                        for seed in seeds
                    ]).astype(float)
                    if (
                        probabilities.shape != (1024, 3)
                        or not np.isfinite(probabilities).all()
                        or ((probabilities < 0) | (probabilities > 1)).any()
                    ):
                        raise ValueError("Invalid saved probabilities.")
                    state_probabilities[state] = probabilities

            for index, seed in enumerate(seeds):
                values = {}
                for state in ["clean", "attack"]:
                    decisions = state_probabilities[state] >= .5
                    primary = decisions[:, index]
                    other_indices = [j for j in range(3) if j != index]
                    other = decisions[:, other_indices]

                    # Two remaining primary detectors have no unique majority
                    # when they disagree. Do not choose a post-hoc tie policy.
                    tied = other[:, 0] != other[:, 1]
                    resolved = ~tied
                    resolved_agreement = (
                        resolved & (primary == other[:, 0])
                    ).mean()
                    tie_fraction = tied.mean()

                    lower = float(resolved_agreement)
                    upper = float(resolved_agreement + tie_fraction)
                    accuracy = float((primary == y).mean())

                    values[state] = {
                        "lower": lower,
                        "upper": upper,
                        "tie_fraction": float(tie_fraction),
                        "resolved_coverage": float(resolved.mean()),
                        "resolved_agreement": (
                            float((primary[resolved] == other[resolved, 0]).mean())
                            if resolved.any() else np.nan
                        ),
                        "accuracy": accuracy,
                    }

                c, a = values["clean"], values["attack"]
                actual_damage = c["accuracy"] - a["accuracy"]

                # Estimated clean-minus-attack accuracy change can lie anywhere
                # in this interval if tied records receive unspecified labels.
                estimated_damage_lower = c["lower"] - a["upper"]
                estimated_damage_upper = c["upper"] - a["lower"]

                minimum_error = max(
                    estimated_damage_lower-actual_damage,
                    actual_damage-estimated_damage_upper,
                    0.0
                )
                maximum_error = max(
                    abs(estimated_damage_lower-actual_damage),
                    abs(estimated_damage_upper-actual_damage)
                )

                rows.append({
                    "scenario": scenario,
                    "attack": treatment,
                    "seed": seed,
                    "clean_accuracy": c["accuracy"],
                    "attack_accuracy": a["accuracy"],
                    "true_damage": actual_damage,
                    "LOO_clean_agreement_lower": c["lower"],
                    "LOO_clean_agreement_upper": c["upper"],
                    "LOO_attack_agreement_lower": a["lower"],
                    "LOO_attack_agreement_upper": a["upper"],
                    "clean_tie_fraction": c["tie_fraction"],
                    "attack_tie_fraction": a["tie_fraction"],
                    "clean_resolved_coverage": c["resolved_coverage"],
                    "attack_resolved_coverage": a["resolved_coverage"],
                    "clean_resolved_agreement": c["resolved_agreement"],
                    "attack_resolved_agreement": a["resolved_agreement"],
                    "LOO_differential_error_lower_bound": float(minimum_error),
                    "LOO_differential_error_upper_bound": float(maximum_error),
                })

            provenance.append({
                "scenario": scenario, "attack": treatment,
                "prediction_file": str(path)
            })
            print(f"Reconciled definitions: {scenario}/{treatment}", flush=True)

    bounds = pd.DataFrame(rows)
    semantic = semantic[key_columns + [
        "clean_estimate", "attack_estimate", "differential_abs_error"
    ]].rename(columns={
        "clean_estimate": "semantic_AGREE_clean_estimate",
        "attack_estimate": "semantic_AGREE_attack_estimate",
        "differential_abs_error": "semantic_AGREE_differential_error",
    })
    joined = bounds.merge(
        semantic, on=key_columns, how="left", validate="one_to_one"
    )
    if joined.semantic_AGREE_differential_error.isna().any():
        raise ValueError("Missing executed semantic-view AGREE result.")

    scenario_table = joined.groupby(
        ["scenario", "attack"], as_index=False
    ).agg(
        semantic_AGREE_error=("semantic_AGREE_differential_error", "mean"),
        LOO_error_lower_bound=("LOO_differential_error_lower_bound", "mean"),
        LOO_error_upper_bound=("LOO_differential_error_upper_bound", "mean"),
        clean_tie_fraction=("clean_tie_fraction", "mean"),
        attack_tie_fraction=("attack_tie_fraction", "mean"),
    )
    summary = scenario_table.groupby("attack", as_index=False).agg(
        semantic_AGREE_error=("semantic_AGREE_error", "mean"),
        LOO_error_lower_bound=("LOO_error_lower_bound", "mean"),
        LOO_error_upper_bound=("LOO_error_upper_bound", "mean"),
        clean_tie_fraction=("clean_tie_fraction", "mean"),
        attack_tie_fraction=("attack_tie_fraction", "mean"),
    )

    out = work / (
        "AGREEMENT_DEFINITION_RECONCILIATION_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    joined.to_csv(out / "per_seed_definition_comparison.csv", index=False)
    scenario_table.to_csv(out / "scenario_definition_comparison.csv", index=False)
    summary.to_csv(out / "definition_summary.csv", index=False)
    pd.DataFrame(provenance).to_csv(out / "prediction_provenance.csv", index=False)

    (out / "receipt.json").write_text(json.dumps({
        "status": "AGREEMENT_DEFINITION_COMPARISON_COMPLETE",
        "scenario_treatment_combinations": 24,
        "scenario_treatment_seed_rows": len(joined),
        "executed_definition": (
            "Primary agreement with majority of V_orig, V_resp, V_time_proto"
        ),
        "alternative_examined": (
            "Primary agreement with the other two frozen primary-seed models"
        ),
        "alternative_scope": (
            "Explicit three-primary-bank interpretation of the amendment; "
            "not claimed to be a previously executed frozen estimator."
        ),
        "tie_policy": "Unspecified; interval bounds reported, no policy selected",
        "bound_caveat": (
            "Conservative bounds allow arbitrary tied-record assignments; "
            "they are not an implemented estimator or a performance guarantee."
        ),
        "primary_results_replaced": False,
        "new_significance_tests": False,
        "models_retrained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "E5_complete": False,
        "faithful_MD3_complete": False,
        "full_drift_gate_timing_complete": False,
        "all_remaining_tasks_complete": False,
    }, indent=2))

    print("\nAGREEMENT-DEFINITION SUMMARY")
    print(summary.to_string(index=False))
    print(f"\nCompleted reconciliation comparison: {out}")

reconcile_agreement_definitions()

# ===== CELL INPUT 49 =====
from pathlib import Path
from datetime import datetime, timezone
import json

import numpy as np
import pandas as pd

def run_verified_treatment_frontiers():
    work = Path("/kaggle/working")
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    result_path = corrected / "corrected_three_treatment_results.csv"

    if not result_path.is_file():
        raise FileNotFoundError(str(result_path))

    results = pd.read_csv(result_path)
    expected_keys = ["scenario", "attack", "seed", "estimator"]
    if (
        len(results) != 144
        or results.duplicated(expected_keys).any()
        or set(results.attack) != {"INJ_k1", "INJ_k3", "PACE_1s"}
        or set(results.estimator) != {"AC", "AGREE"}
        or set(results.seed) != {8101, 8102, 8103}
    ):
        raise ValueError("Unexpected corrected three-treatment panel.")

    required = [
        "clean_accuracy", "attack_accuracy",
        "clean_estimate", "attack_estimate", "true_damage"
    ]
    if not np.isfinite(results[required].to_numpy(float)).all():
        raise ValueError("Nonfinite corrected panel values.")

    expected_damage = results.clean_accuracy-results.attack_accuracy
    if not np.allclose(
        expected_damage, results.true_damage, atol=1e-12, rtol=0
    ):
        raise ValueError("Stored damage differs from paired accuracy difference.")

    ac = results[results.estimator.eq("AC")].copy()
    agree = results[results.estimator.eq("AGREE")].copy()
    keys = ["scenario", "attack", "seed"]

    menu = ac[keys + required].rename(columns={
        "clean_estimate": "AC_clean",
        "attack_estimate": "AC_attack"
    }).merge(
        agree[keys + ["clean_estimate", "attack_estimate"]],
        on=keys, validate="one_to_one"
    ).rename(columns={
        "clean_estimate": "AGREE_clean",
        "attack_estimate": "AGREE_attack"
    })

    menu["AC_absolute_signal_change"] = (
        menu.AC_clean-menu.AC_attack
    ).abs()
    menu["AGREE_absolute_signal_change"] = (
        menu.AGREE_clean-menu.AGREE_attack
    ).abs()
    menu["positive_accuracy_damage"] = menu.true_damage > 1e-12

    # Identity is a feasible no-action option, not a generated attack.
    identities = []
    for (scenario, seed), group in menu.groupby(["scenario", "seed"]):
        for column in ["clean_accuracy", "AC_clean", "AGREE_clean"]:
            values = group[column].to_numpy(float)
            if not np.allclose(values, values[0], atol=1e-12, rtol=0):
                raise ValueError(
                    f"Clean states differ across treatments: "
                    f"{scenario}/{seed}/{column}"
                )
        row = group.iloc[0]
        identities.append({
            "scenario": scenario,
            "attack": "IDENTITY",
            "seed": seed,
            "clean_accuracy": row.clean_accuracy,
            "attack_accuracy": row.clean_accuracy,
            "true_damage": 0.0,
            "AC_clean": row.AC_clean,
            "AC_attack": row.AC_clean,
            "AGREE_clean": row.AGREE_clean,
            "AGREE_attack": row.AGREE_clean,
            "AC_absolute_signal_change": 0.0,
            "AGREE_absolute_signal_change": 0.0,
            "positive_accuracy_damage": False,
        })
    menu = pd.concat([menu, pd.DataFrame(identities)], ignore_index=True)

    # Fixed descriptive thresholds; not calibrated false-alarm thresholds,
    # and not claimed to have been preregistered.
    thresholds = [0.0, 0.001, 0.005, 0.01, 0.02, 0.05]
    frontier_rows = []
    feasibility_rows = []

    for (scenario, seed), group in menu.groupby(["scenario", "seed"]):
        best_damage = float(group.true_damage.max())
        best_attacks = sorted(
            group.loc[
                np.isclose(group.true_damage, best_damage, atol=1e-12, rtol=0),
                "attack"
            ].tolist()
        )
        transformed = group[~group.attack.eq("IDENTITY")]

        feasibility_rows.append({
            "scenario": scenario,
            "seed": int(seed),
            "maximum_menu_damage": best_damage,
            "maximizing_options": "|".join(best_attacks),
            "positive_damage_available": best_damage > 1e-12,
            "positive_damage_transformation_count": int(
                transformed.positive_accuracy_damage.sum()
            ),
            "worst_transformation_damage": float(
                transformed.true_damage.min()
            ),
        })

        for monitor, signal_column in [
            ("AC", "AC_absolute_signal_change"),
            ("SEMANTIC_AGREE", "AGREE_absolute_signal_change"),
        ]:
            for threshold in thresholds:
                feasible = group[
                    group[signal_column] <= threshold+1e-12
                ]
                maximum = float(feasible.true_damage.max())
                winners = feasible[
                    np.isclose(
                        feasible.true_damage, maximum, atol=1e-12, rtol=0
                    )
                ].sort_values("attack")

                frontier_rows.append({
                    "scenario": scenario,
                    "seed": int(seed),
                    "monitor": monitor,
                    "absolute_signal_change_budget": threshold,
                    "maximum_hidden_menu_damage": maximum,
                    "positive_hidden_damage_available": maximum > 1e-12,
                    "maximizing_options": "|".join(winners.attack),
                    "feasible_menu_options": len(feasible),
                })

    feasibility = pd.DataFrame(feasibility_rows)
    frontier = pd.DataFrame(frontier_rows)

    scenario_feasibility = feasibility.groupby(
        "scenario", as_index=False
    ).agg(
        mean_seed_maximum_menu_damage=("maximum_menu_damage", "mean"),
        seeds_with_positive_damage=("positive_damage_available", "sum"),
    )
    scenario_frontier = frontier.groupby(
        ["scenario", "monitor", "absolute_signal_change_budget"],
        as_index=False
    ).agg(
        mean_seed_maximum_hidden_damage=("maximum_hidden_menu_damage", "mean"),
        seeds_with_positive_hidden_damage=(
            "positive_hidden_damage_available", "sum"
        ),
    )
    summary = scenario_frontier.groupby(
        ["monitor", "absolute_signal_change_budget"], as_index=False
    ).agg(
        mean_scenario_hidden_damage=("mean_seed_maximum_hidden_damage", "mean"),
        scenarios_with_positive_mean_hidden_damage=(
            "mean_seed_maximum_hidden_damage",
            lambda s: int((s > 1e-12).sum())
        ),
    )

    reconciliation_dirs = sorted(
        work.glob("AGREEMENT_DEFINITION_RECONCILIATION_*")
    )
    loo_summary = None
    if reconciliation_dirs:
        path = reconciliation_dirs[-1] / "definition_summary.csv"
        if path.is_file():
            loo_summary = pd.read_csv(path)

    out = work / (
        "E5_PREPARATION_VERIFIED_MENU_FRONTIERS_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()

    menu.to_csv(out / "verified_treatment_menu.csv", index=False)
    feasibility.to_csv(out / "per_seed_damage_feasibility.csv", index=False)
    scenario_feasibility.to_csv(
        out / "scenario_damage_feasibility.csv", index=False
    )
    frontier.to_csv(out / "per_seed_stealth_frontiers.csv", index=False)
    scenario_frontier.to_csv(
        out / "scenario_stealth_frontiers.csv", index=False
    )
    summary.to_csv(out / "stealth_frontier_summary.csv", index=False)
    if loo_summary is not None:
        loo_summary.to_csv(out / "LOO_definition_bounds_context.csv", index=False)

    (out / "receipt.json").write_text(json.dumps({
        "status": "VERIFIED_FINITE_MENU_FEASIBILITY_AND_FRONTIERS_COMPLETE",
        "menu": ["IDENTITY", "INJ_k1", "INJ_k3", "PACE_1s"],
        "identity_role": "No-action option",
        "monitors_examined": ["AC", "SEMANTIC_AGREE"],
        "signal_change_budgets": thresholds,
        "selection_uses_evaluation_labels": True,
        "interpretation": (
            "Outcome-informed finite-menu oracle diagnostic. "
            "Not a deployable label-free attacker, not a new packet search, "
            "and not an upper bound on untested transformations."
        ),
        "thresholds_are_calibrated_false_alarm_thresholds": False,
        "new_real_PCAP_adaptive_E5_complete": False,
        "faithful_MD3_complete": False,
        "full_drift_gate_timing_complete": False,
        "PCAP_replays": 0,
        "models_retrained": False,
        "existing_results_changed": False,
        "files_deleted": 0,
    }, indent=2))

    print("\nTEST 1 — AVAILABLE ACCURACY DAMAGE")
    print(scenario_feasibility.to_string(index=False))
    print("\nTESTS 2 AND 3 — AC / AGREE STEALTH FRONTIERS")
    print(summary.to_string(index=False))
    print("\nONE-PERCENTAGE-POINT SIGNAL BUDGET")
    print(
        scenario_frontier[
            scenario_frontier.absolute_signal_change_budget.eq(.01)
        ].to_string(index=False)
    )
    print(f"\nCompleted batch: {out}")

run_verified_treatment_frontiers()

# ===== CELL INPUT 50 =====
from pathlib import Path
from datetime import datetime, timezone
import importlib.metadata
import inspect
import json
import subprocess
import sys

import joblib
import pandas as pd

def prepare_actual_md3_implementation():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )

    try:
        installed_version = importlib.metadata.version("menelaus")
        installed_now = False
    except importlib.metadata.PackageNotFoundError:
        subprocess.run(
            [
                sys.executable, "-m", "pip", "install",
                "--disable-pip-version-check", "--no-cache-dir",
                "menelaus"
            ],
            check=True
        )
        installed_version = importlib.metadata.version("menelaus")
        installed_now = True

    from menelaus.concept_drift.md3 import MD3

    model_candidates = [
        root / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
        for root in [work, backup]
    ]
    model_path = next((p for p in model_candidates if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Known frozen source model bundle unavailable.")

    bundle = joblib.load(model_path)

    # Inspect only the known frozen source bundle.
    # Record schemas, not potentially large reference-record contents.
    schema_rows = []

    def summarize(value, location, depth=0):
        row = {
            "location": location,
            "type": f"{type(value).__module__}.{type(value).__name__}",
        }

        if isinstance(value, pd.DataFrame):
            row.update({
                "rows": len(value),
                "columns": [str(c) for c in value.columns],
                "label_columns_present": [
                    c for c in ["y", "label", "Label"] if c in value.columns
                ],
            })
        elif isinstance(value, dict):
            row["keys"] = [str(k) for k in value.keys()]
        elif hasattr(value, "shape"):
            row["shape"] = list(value.shape)
        elif isinstance(value, (str, int, float, bool)) or value is None:
            row["value"] = value
        elif isinstance(value, (list, tuple)):
            row["length"] = len(value)

        schema_rows.append(row)

        if isinstance(value, dict) and depth < 3:
            for key, child in value.items():
                # Models need only their schema, not recursive internals.
                summarize(child, f"{location}/{key}", depth+1)

    summarize(bundle, "frozen_source_bundle")

    api = {
        "constructor": str(inspect.signature(MD3)),
        "methods": {},
    }
    for name in [
        "set_reference", "update", "give_oracle_label",
        "reset", "calculate_margin_density",
    ]:
        method = getattr(MD3, name, None)
        if method is not None:
            api["methods"][name] = str(inspect.signature(method))

    source = inspect.getsource(MD3)
    module_path = inspect.getsourcefile(MD3)

    out = work / (
        "MD3_IMPLEMENTATION_PREPARATION_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()

    (out / "installed_MD3_class_source.py").write_text(
        source, encoding="utf-8"
    )
    (out / "MD3_API.json").write_text(json.dumps(api, indent=2))
    (out / "frozen_source_bundle_schema.json").write_text(
        json.dumps(schema_rows, indent=2, default=str)
    )
    receipt = {
        "status": "MD3_IMPLEMENTATION_AND_SOURCE_SCHEMA_CAPTURED",
        "menelaus_version": installed_version,
        "package_installed_by_this_cell": installed_now,
        "MD3_module_path": module_path,
        "frozen_model_bundle": str(model_path),
        "target_samples_loaded": False,
        "models_trained": False,
        "PCAP_replays": 0,
        "files_deleted": 0,
        "MD3_experiment_complete": False,
        "publication_fidelity_verified": False,
        "reason": (
            "Installed library source/API must be checked before evaluation. "
            "No probability band, calibration allocation, or oracle-label "
            "policy has been invented."
        ),
    }
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2))

    print("INSTALLED MD3 API")
    print(json.dumps(api, indent=2))

    print("\nFROZEN SOURCE BUNDLE SCHEMA")
    print(json.dumps(schema_rows, indent=2, default=str))

    print("\nACTUAL INSTALLED MD3 IMPLEMENTATION")
    print(source)

    print("\nPREPARATION RECEIPT")
    print(json.dumps(receipt, indent=2))
    print(f"\nSmall implementation records saved: {out}")

prepare_actual_md3_implementation()

# ===== CELL INPUT 51 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
import ast
import bisect
import gzip
import hashlib
import ipaddress
import itertools
import json
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def run_new_e5_pacing_search():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    root = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"
    root.mkdir(exist_ok=True)

    targets = [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]
    delays = [0.0, 0.1, 1.0, 3.0, 10.0]
    penalties = [0.0, 1.0, 10.0]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    V = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }

    def dump(path, value):
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(value, indent=2))
        temp.replace(path)

    def sha(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8*1024**2), b""):
                h.update(block)
        return h.hexdigest()

    policy = {
        "experiment": "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1",
        "targets": targets,
        "delay_seconds": delays,
        "penalty_weights": penalties,
        "monitors": ["AC", "SEMANTIC_AGREE"],
        "objective": "actual_accuracy_damage - lambda * absolute_monitor_change",
        "selection": "maximum objective; ties prefer smaller delay",
        "eligibility": "selected malicious TCP flow with >=2 total packets",
        "operation": "delay every selected-flow packet after its first",
        "labels_used": "oracle damage evaluation and candidate selection",
        "scope": "Post-exposure bounded search; not original confirmation",
        "full_drift_gate_targeted": False,
        "maximum_new_packet_replays": 8,
    }
    policy_path = root / "search_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing search policy differs; refusing overwrite.")
    else:
        dump(policy_path, policy)

    model = backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    helper = backup / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
    bundle = joblib.load(model)
    zeek = shutil.which("zeek") or "/opt/zeek/bin/zeek"
    if not Path(zeek).is_file():
        raise FileNotFoundError("Zeek executable unavailable.")

    required = {"key", "skey", "pcap_iter", "pcap_header", "tcp"}
    tree = ast.parse(helper.read_text())
    definitions = [
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in required
    ]
    if {n.name for n in definitions} != required:
        raise ValueError("Saved packet helpers incomplete.")
    ns = dict(globals())
    ns["MAGICS"] = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1),
    }
    exec(compile(ast.fix_missing_locations(
        ast.Module(body=definitions, type_ignores=[])
    ), "E5_saved_packet_helpers", "exec"), ns)
    key, skey = ns["key"], ns["skey"]
    packets, header, tcp = ns["pcap_iter"], ns["pcap_header"], ns["tcp"]

    def normalize(frame):
        frame = frame.copy()
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def read_csv(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        return normalize(pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        ))

    def mat(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def read_log(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        opener = gzip.open if compressed else open
        fields = None
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("#fields"):
                    fields = line.strip().split()[1:]
                elif not line.startswith("#") and line.strip():
                    if fields is None:
                        raise ValueError("Missing Zeek fields.")
                    yield dict(zip(fields, line.rstrip().split()))

    def predictions(frame):
        result = {}
        with threadpool_limits(limits=2):
            for seed, bank in bundle["models"].items():
                p = bank["PRIMARY"].predict_proba(mat(frame, F))[:, 1]
                decision = p >= .5
                votes = np.column_stack([
                    bank[name].predict(mat(frame, cols))
                    for name, cols in V.items()
                ])
                result[str(seed)] = {
                    "probability": p,
                    "accuracy": float((decision == frame.y.to_numpy()).mean()),
                    "AC": float(np.maximum(p, 1-p).mean()),
                    "SEMANTIC_AGREE": float(
                        (decision == (votes.sum(axis=1) >= 2)).mean()
                    ),
                }
        return result

    def limit_zeek():
        resource.setrlimit(resource.RLIMIT_AS, (6*1024**3, 6*1024**3))

    all_results = []

    for scenario in targets:
        sample_candidates = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not sample_candidates:
            raise FileNotFoundError(f"Frozen sample unavailable: {scenario}")
        sample_path = min(
            sample_candidates, key=lambda p: (len(p.parts), str(p))
        )
        clean = read_csv(sample_path)
        if len(clean) != 1024 or clean.ks.duplicated().any():
            raise ValueError("Invalid frozen sample.")
        wanted = set(clean.ks)
        labels = dict(zip(clean.ks, clean.y))

        e1 = backup / "E1_BLIND_TARGETS_20261012T125026604016Z"
        def asset(suffix):
            candidates = [
                p for p in e1.rglob("*")
                if p.is_file() and scenario in str(p)
                and p.name.endswith(suffix)
            ]
            if len(candidates) != 1:
                raise ValueError(f"Ambiguous E1 asset: {scenario}/{suffix}")
            return candidates[0]

        pcap, conn = asset("slice.pcap"), asset("conn.log")
        flows, separators = {}, set()
        for row in read_log(conn):
            base = key(
                row["ts"], row["id.orig_h"], row["id.orig_p"],
                row["id.resp_h"], row["id.resp_p"], row["proto"]
            )
            for sep in ["|", "::", ","]:
                kk = skey(base, sep)
                if kk in wanted:
                    if kk in flows:
                        raise ValueError("Duplicate selected clean flow.")
                    flows[kk] = row
                    separators.add(sep)
                    break
        if set(flows) != wanted or len(separators) != 1:
            raise ValueError("Clean flow linkage failed.")
        separator = next(iter(separators))
        h, endian, unit, network = header(pcap)

        descriptions = defaultdict(list)
        for kk, row in flows.items():
            if labels[kk] != 1 or row["proto"].lower() != "tcp":
                continue
            start = int(Decimal(row["ts"])*10**9)
            duration = (
                0 if row["duration"] == "-"
                else int(Decimal(row["duration"])*10**9)
            )
            endpoints = tuple(sorted([
                (row["id.orig_h"], int(row["id.orig_p"])),
                (row["id.resp_h"], int(row["id.resp_p"]))
            ]))
            descriptions[endpoints].append(
                (start, start+duration+1_000_000, kk)
            )
        for values in descriptions.values():
            values.sort()
        starts = {t: [v[0] for v in vs] for t, vs in descriptions.items()}

        def flow_for(ts, payload):
            info = tcp(payload, network)
            if info is None:
                return None
            src, sp, dst, dp, _, _ = info
            endpoints = tuple(sorted([(src, sp), (dst, dp)]))
            if endpoints not in descriptions:
                return None
            j = bisect.bisect_right(starts[endpoints], ts)-1
            if j < 0:
                return None
            start, end, kk = descriptions[endpoints][j]
            return kk if ts <= end else None

        packet_counts, first = defaultdict(int), {}
        packet_count, previous = 0, None
        for i, ts, wire, payload in packets(pcap):
            if previous is not None and ts < previous:
                raise ValueError("Source timestamps unordered.")
            previous = ts
            packet_count += 1
            kk = flow_for(ts, payload)
            if kk is not None:
                packet_counts[kk] += 1
                first.setdefault(kk, i)
        eligible = {kk for kk, n in packet_counts.items() if n >= 2}
        base_predictions = predictions(clean)

        # Verify the baseline against already completed injection predictions.
        frozen = (
            backup / "E4_COMPACT_INJECTIONS_v2"
            / scenario / "INJ_k1/primary_outputs.npz"
        )
        with np.load(frozen, allow_pickle=False) as saved:
            positions = pd.Index(saved["ks"].astype(str)).get_indexer(clean.ks)
            if (positions < 0).any():
                raise ValueError("Frozen baseline key mismatch.")
            for seed, values in base_predictions.items():
                if not np.allclose(
                    values["probability"],
                    saved[f"seed_{seed}_clean_probability"][positions],
                    atol=1e-12, rtol=0
                ):
                    raise ValueError("Frozen baseline probability mismatch.")

        for delay in delays:
            job = root / scenario / f"delay_{delay:g}s"
            job.mkdir(parents=True, exist_ok=True)
            done = job / "receipt.json"
            if done.is_file():
                receipt = json.loads(done.read_text())
                if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                    raise ValueError("Unexpected candidate receipt.")
                all_results.extend(pd.read_csv(job/"results.csv").to_dict("records"))
                print(f"Reused {scenario}, delay={delay:g}s", flush=True)
                continue

            delayed_packets = 0
            if delay == 0:
                attacked = clean.copy()
                execution_mode = "IDENTITY_NO_REPLAY"
            else:
                reserve = pcap.stat().st_size*3 + packet_count*160 + 1024**3
                if shutil.disk_usage(work).free < reserve:
                    raise RuntimeError("Insufficient conservative replay reserve.")
                temp = Path(tempfile.mkdtemp(prefix="E5_candidate_", dir=job))
                db = None
                try:
                    db = sqlite3.connect(temp/"order.sqlite")
                    db.execute("PRAGMA journal_mode=OFF")
                    db.execute("PRAGMA synchronous=OFF")
                    db.execute("PRAGMA temp_store=FILE")
                    db.execute("PRAGMA cache_size=-32768")
                    db.execute(
                        "CREATE TABLE r(ts INTEGER, idx INTEGER, off INTEGER, "
                        "cap INTEGER, wire INTEGER)"
                    )
                    offset, batch = 24, []
                    delay_ns = int(Decimal(str(delay))*10**9)
                    for i, ts, wire, payload in packets(pcap):
                        kk = flow_for(ts, payload)
                        d = delay_ns if kk in eligible and i != first[kk] else 0
                        delayed_packets += int(d != 0)
                        batch.append((ts+d, i, offset+16, len(payload), wire))
                        offset += 16+len(payload)
                        if len(batch) == 20000:
                            db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
                            batch.clear()
                    if batch:
                        db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
                    db.commit()
                    db.execute("CREATE INDEX ordered ON r(ts,idx)")
                    db.commit()
                    transformed = temp/"candidate.pcap"
                    seen, last_index, previous_ts = 0, {}, None

                    with open(pcap, "rb") as source, open(transformed, "wb") as target:
                        target.write(h)
                        for ts, i, off, cap, wire in db.execute(
                            "SELECT ts,idx,off,cap,wire FROM r ORDER BY ts,idx"
                        ):
                            source.seek(off-16)
                            sec, frac, old_cap, old_wire = struct.unpack(
                                endian+"IIII", source.read(16)
                            )
                            original_ts = sec*10**9+frac*unit
                            payload = source.read(cap)
                            if (
                                len(payload) != cap or old_cap != cap
                                or old_wire != wire
                                or ts-original_ts not in {0, delay_ns}
                            ):
                                raise ValueError("Packet preservation/delay failed.")
                            if previous_ts is not None and ts < previous_ts:
                                raise ValueError("Output timestamps unordered.")
                            previous_ts = ts
                            kk = flow_for(original_ts, payload)
                            if kk is not None:
                                if i <= last_index.get(kk, -1):
                                    raise ValueError("Selected-flow order changed.")
                                last_index[kk] = i
                            target.write(struct.pack(
                                endian+"IIII", ts//10**9, (ts%10**9)//unit,
                                cap, wire
                            ))
                            target.write(payload)
                            seen += 1
                    if seen != packet_count:
                        raise ValueError("Packet count changed.")
                    transformed_hash = sha(transformed)
                    db.close()
                    db = None
                    (temp/"order.sqlite").unlink()

                    print(f"NEW E5 replay: {scenario}, delay={delay:g}s", flush=True)
                    with open(job/"zeek_stdout.txt", "w") as stdout, open(
                        job/"zeek_stderr.txt", "w"
                    ) as stderr:
                        process = subprocess.run(
                            [str(zeek), "-C", "-r", str(transformed)],
                            cwd=temp, stdout=stdout, stderr=stderr,
                            timeout=1800, preexec_fn=limit_zeek
                        )
                    if process.returncode or not (temp/"conn.log").is_file():
                        raise RuntimeError("Zeek failed; retained stderr available.")

                    mapped = {}
                    for row in read_log(temp/"conn.log"):
                        kk = skey(key(
                            row["ts"], row["id.orig_h"], row["id.orig_p"],
                            row["id.resp_h"], row["id.resp_p"], row["proto"]
                        ), separator)
                        if kk in wanted:
                            if kk in mapped:
                                raise ValueError("Ambiguous candidate flow.")
                            mapped[kk] = row
                    if set(mapped) != wanted:
                        dump(job/"mapping_failure.json", {
                            "missing_keys": sorted(wanted-set(mapped))
                        })
                        raise ValueError("Candidate exact linkage failed.")
                    attacked = normalize(pd.DataFrame([
                        {**{c: mapped[kk][c] for c in F}, "ks": kk, "y": labels[kk]}
                        for kk in clean.ks
                    ]))
                    execution_mode = "NEW_REAL_PCAP_ZEEK_REPLAY"
                    dump(job/"packet_checks.json", {
                        "source_pcap_sha256": sha(pcap),
                        "transformed_pcap_sha256": transformed_hash,
                        "packet_count_preserved": True,
                        "original_packet_bytes_preserved": True,
                        "selected_flow_order_preserved": True,
                        "no_packet_advanced": True,
                        "mapping_fraction": 1.0,
                        "application_semantic_validity_claimed": False,
                    })
                finally:
                    if db is not None:
                        db.close()
                    shutil.rmtree(temp, ignore_errors=True)

            candidate_predictions = predictions(attacked)
            rows = []
            for seed, baseline in base_predictions.items():
                candidate = candidate_predictions[seed]
                damage = baseline["accuracy"]-candidate["accuracy"]
                rows.append({
                    "scenario": scenario, "seed": int(seed),
                    "delay_seconds": delay,
                    "clean_accuracy": baseline["accuracy"],
                    "candidate_accuracy": candidate["accuracy"],
                    "true_damage": damage,
                    "AC_absolute_change": abs(candidate["AC"]-baseline["AC"]),
                    "AGREE_absolute_change": abs(
                        candidate["SEMANTIC_AGREE"]-baseline["SEMANTIC_AGREE"]
                    ),
                    "eligible_flows": len(eligible),
                    "delayed_packets": delayed_packets,
                    "execution_mode": execution_mode,
                })
            pd.DataFrame(rows).to_csv(job/"results.csv", index=False)
            attacked.to_csv(job/"candidate_selected_features.csv", index=False)
            dump(done, {
                "status": "E5_CANDIDATE_COMPLETE",
                "scenario": scenario, "delay_seconds": delay,
                "search_policy_sha256": sha(policy_path),
                "execution_mode": execution_mode,
                "models_retrained": False,
                "temporary_replay_retained": False,
            })
            all_results.extend(rows)
            print(pd.DataFrame(rows).to_string(index=False), flush=True)

    results = pd.DataFrame(all_results)
    if len(results) != 30 or results.duplicated(
        ["scenario", "seed", "delay_seconds"]
    ).any():
        raise ValueError("Expected 30 unique candidate/seed evaluations.")

    selections = []
    for (scenario, seed), group in results.groupby(["scenario", "seed"]):
        for monitor, signal in [
            ("AC", "AC_absolute_change"),
            ("SEMANTIC_AGREE", "AGREE_absolute_change")
        ]:
            for penalty in penalties:
                ranked = group.copy()
                ranked["objective"] = ranked.true_damage-penalty*ranked[signal]
                winner = ranked.sort_values(
                    ["objective", "delay_seconds"], ascending=[False, True]
                ).iloc[0]
                selections.append({
                    "scenario": scenario, "seed": int(seed),
                    "monitor": monitor, "penalty": penalty,
                    "selected_delay_seconds": float(winner.delay_seconds),
                    "selected_damage": float(winner.true_damage),
                    "selected_monitor_change": float(winner[signal]),
                    "objective": float(winner.objective),
                })

    selections = pd.DataFrame(selections)
    summary = selections.groupby(
        ["monitor", "penalty"], as_index=False
    ).agg(
        mean_selected_damage=("selected_damage", "mean"),
        maximum_selected_damage=("selected_damage", "max"),
        mean_monitor_change=("selected_monitor_change", "mean"),
        positive_damage_units=("selected_damage", lambda s: int((s > 1e-12).sum())),
        identity_selected_units=(
            "selected_delay_seconds", lambda s: int(s.eq(0).sum())
        ),
    )
    results.to_csv(root/"all_candidate_results.csv", index=False)
    selections.to_csv(root/"adaptive_objective_selections.csv", index=False)
    summary.to_csv(root/"adaptive_search_summary.csv", index=False)
    dump(root/"completion_receipt.json", {
        "status": "EXPLORATORY_AC_AGREE_PACING_SEARCH_COMPLETE",
        "target_count": 2,
        "delay_candidates_per_target": 5,
        "candidate_seed_rows": len(results),
        "monitor_penalty_configurations": 6,
        "oracle_labels_used_for_selection": True,
        "post_exposure_experiment": True,
        "original_preregistered_E5_complete": False,
        "full_drift_gate_adaptive_evaluation_complete": False,
        "faithful_MD3_complete": False,
        "models_retrained": False,
        "all_study_requirements_complete": False,
    })
    print("\nE5 NEW PACKET-SEARCH SUMMARY")
    print(summary.to_string(index=False))
    print(f"\nSaved: {root}")

run_new_e5_pacing_search()

# ===== CELL INPUT 52 =====
from pathlib import Path
from datetime import datetime, timezone
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def validate_new_e5_results():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    search = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"
    recorded_path = search / "all_candidate_results.csv"
    if not recorded_path.is_file():
        raise FileNotFoundError("Completed E5 candidate table unavailable.")

    recorded = pd.read_csv(recorded_path)
    targets = [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]
    delays = [0.0, 0.1, 1.0, 3.0, 10.0]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    V = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }
    model = backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    bundle = joblib.load(model)

    def read_frame(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        if len(frame) != 1024 or frame.ks.duplicated().any():
            raise ValueError(f"Invalid candidate membership: {path}")
        return frame

    def matrix(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    def evaluate(frame, bank):
        p = bank["PRIMARY"].predict_proba(matrix(frame, F))[:, 1]
        votes = np.column_stack([
            bank[name].predict(matrix(frame, columns))
            for name, columns in V.items()
        ])
        decision = p >= .5
        estimates = {
            "AC": float(np.maximum(p, 1-p).mean()),
            "SEMANTIC_AGREE": float(
                (decision == (votes.sum(axis=1) >= 2)).mean()
            ),
        }
        return p, decision, votes, estimates

    feature_rows, decision_rows, estimator_rows = [], [], []

    with threadpool_limits(limits=2):
        for scenario in targets:
            clean_path = (
                search / scenario / "delay_0s/candidate_selected_features.csv"
            )
            clean = read_frame(clean_path)
            y = clean.y.to_numpy(int)

            for delay in delays:
                job = search / scenario / f"delay_{delay:g}s"
                receipt_path = job / "receipt.json"
                if not receipt_path.is_file():
                    raise ValueError(f"Incomplete candidate: {job}")
                receipt = json.loads(receipt_path.read_text())
                if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                    raise ValueError(f"Unaccepted candidate receipt: {job}")

                attacked = read_frame(job / "candidate_selected_features.csv")
                if set(attacked.ks) != set(clean.ks):
                    raise ValueError("Candidate key set differs.")
                attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
                if not np.array_equal(attacked.y.to_numpy(int), y):
                    raise ValueError("Candidate labels differ.")

                for feature in F:
                    a = clean[feature].to_numpy()
                    b = attacked[feature].to_numpy()
                    changed = a != b
                    row = {
                        "scenario": scenario, "delay_seconds": delay,
                        "feature": feature,
                        "changed_rows": int(changed.sum()),
                        "changed_benign_rows": int((changed & (y == 0)).sum()),
                        "changed_malicious_rows": int((changed & (y == 1)).sum()),
                    }
                    if feature != "proto":
                        difference = b.astype(float)-a.astype(float)
                        row.update({
                            "minimum_change": float(difference.min()),
                            "maximum_change": float(difference.max()),
                        })
                    feature_rows.append(row)

                for seed, bank in bundle["models"].items():
                    p0, d0, v0, estimates0 = evaluate(clean, bank)
                    p1, d1, v1, estimates1 = evaluate(attacked, bank)
                    correct0, correct1 = d0 == y, d1 == y
                    a0, a1 = float(correct0.mean()), float(correct1.mean())
                    damage = a0-a1

                    old = recorded[
                        recorded.scenario.eq(scenario)
                        & recorded.seed.eq(int(seed))
                        & recorded.delay_seconds.eq(delay)
                    ]
                    if len(old) != 1:
                        raise ValueError("Missing unique recorded candidate row.")
                    if not np.isclose(
                        damage, old.iloc[0].true_damage, atol=1e-12, rtol=0
                    ):
                        raise ValueError("Recomputed damage differs from search.")

                    changed = d0 != d1
                    decision_rows.append({
                        "scenario": scenario, "seed": int(seed),
                        "delay_seconds": delay,
                        "clean_accuracy": a0, "attack_accuracy": a1,
                        "true_damage": damage,
                        "primary_decision_changed_rows": int(changed.sum()),
                        "malicious_positive_to_negative": int(
                            ((y == 1) & d0 & ~d1).sum()
                        ),
                        "malicious_negative_to_positive": int(
                            ((y == 1) & ~d0 & d1).sum()
                        ),
                        "benign_negative_to_positive": int(
                            ((y == 0) & ~d0 & d1).sum()
                        ),
                        "benign_positive_to_negative": int(
                            ((y == 0) & d0 & ~d1).sum()
                        ),
                        "correct_to_wrong_rows": int(
                            (correct0 & ~correct1).sum()
                        ),
                        "wrong_to_correct_rows": int(
                            (~correct0 & correct1).sum()
                        ),
                        "V_orig_changed_decisions": int((v0[:, 0] != v1[:, 0]).sum()),
                        "V_resp_changed_decisions": int((v0[:, 1] != v1[:, 1]).sum()),
                        "V_time_proto_changed_decisions": int(
                            (v0[:, 2] != v1[:, 2]).sum()
                        ),
                        "max_primary_probability_change": float(
                            np.max(np.abs(p0-p1))
                        ),
                    })

                    for estimator in ["AC", "SEMANTIC_AGREE"]:
                        e0, e1 = estimates0[estimator], estimates1[estimator]
                        estimated_damage = e0-e1
                        estimator_rows.append({
                            "scenario": scenario, "seed": int(seed),
                            "delay_seconds": delay, "estimator": estimator,
                            "clean_accuracy": a0, "attack_accuracy": a1,
                            "true_damage": damage,
                            "clean_estimate": e0, "attack_estimate": e1,
                            "estimated_accuracy_damage": estimated_damage,
                            "absolute_monitor_change": abs(estimated_damage),
                            "damage_underestimation": damage-estimated_damage,
                            "differential_abs_error": abs(
                                estimated_damage-damage
                            ),
                            "clean_absolute_error": abs(e0-a0),
                            "attack_absolute_error": abs(e1-a1),
                        })

                print(
                    f"Validated all three checks: {scenario}, delay={delay:g}s",
                    flush=True
                )

    feature_table = pd.DataFrame(feature_rows)
    decisions = pd.DataFrame(decision_rows)
    estimates = pd.DataFrame(estimator_rows)

    if len(decisions) != 30 or len(estimates) != 60:
        raise ValueError("Unexpected validation row counts.")

    out = work / (
        "E5_PACKET_SEARCH_VALIDATION_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    feature_table.to_csv(out / "feature_change_audit.csv", index=False)
    decisions.to_csv(out / "decision_and_label_damage_audit.csv", index=False)
    estimates.to_csv(out / "signed_monitor_response.csv", index=False)

    non_duration = feature_table[
        feature_table.feature.ne("duration")
        & feature_table.changed_rows.gt(0)
    ]
    (out / "receipt.json").write_text(json.dumps({
        "status": "E5_SEARCH_NUMERICAL_VALIDATION_COMPLETE",
        "candidate_seed_checks": len(decisions),
        "all_recorded_damage_reproduced": True,
        "non_duration_feature_change_rows": len(non_duration),
        "new_PCАP_replays": 0,
        "models_retrained": False,
        "files_deleted": 0,
        "application_semantic_validity_established": False,
        "full_drift_gate_evaluated": False,
        "faithful_MD3_complete": False,
        "all_study_requirements_complete": False,
    }, indent=2))

    print("\nTEST 1 — CAPTURE 49, 10s: DECISION DAMAGE")
    print(decisions[
        decisions.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & decisions.delay_seconds.eq(10)
    ].to_string(index=False))

    print("\nTEST 2 — CAPTURE 49, 10s: SIGNED MONITOR RESPONSE")
    print(estimates[
        estimates.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & estimates.delay_seconds.eq(10)
    ].to_string(index=False))

    print("\nTEST 3 — NON-DURATION FEATURE CHANGES")
    print(
        non_duration.to_string(index=False)
        if not non_duration.empty else "None: only duration changed."
    )
    print(f"\nCompleted validation batch: {out}")

validate_new_e5_results()

# ===== CELL INPUT 53 =====
from pathlib import Path
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
from datetime import datetime, timezone
import ast
import bisect
import gzip
import hashlib
import ipaddress
import json
import resource
import shutil
import sqlite3
import struct
import subprocess
import tempfile

import numpy as np
import pandas as pd

def inspect_capture49_fragments():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    scenario = "CTU-IoT-Malware-Capture-49-1"
    e1 = backup / "E1_BLIND_TARGETS_20261012T125026604016Z"
    helper = backup / "run_streaming_confirmatory_batch_A_v1_2_fixed.py"
    search = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1" / scenario
    clean = pd.read_csv(
        search / "delay_0s/candidate_selected_features.csv",
        dtype={"ks": str}
    )
    candidate = pd.read_csv(
        search / "delay_10s/candidate_selected_features.csv",
        dtype={"ks": str}
    ).set_index("ks").loc[clean.ks].reset_index()

    def asset(suffix):
        found = [
            p for p in e1.rglob("*")
            if p.is_file() and scenario in str(p)
            and p.name.endswith(suffix)
        ]
        if len(found) != 1:
            raise ValueError(f"Ambiguous source asset: {suffix}")
        return found[0]

    pcap, conn = asset("slice.pcap"), asset("conn.log")
    required = {"key", "skey", "pcap_iter", "pcap_header", "tcp"}
    tree = ast.parse(helper.read_text())
    definitions = [
        n for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in required
    ]
    if {n.name for n in definitions} != required:
        raise ValueError("Incomplete saved packet helpers.")
    ns = dict(globals())
    ns["MAGICS"] = {
        b"\xd4\xc3\xb2\xa1": ("<", 1000),
        b"\xa1\xb2\xc3\xd4": (">", 1000),
        b"\x4d\x3c\xb2\xa1": ("<", 1),
        b"\xa1\xb2\x3c\x4d": (">", 1),
    }
    exec(compile(ast.fix_missing_locations(
        ast.Module(body=definitions, type_ignores=[])
    ), "fragment_diagnostic_helpers", "exec"), ns)
    key, skey = ns["key"], ns["skey"]
    packets, header, tcp = ns["pcap_iter"], ns["pcap_header"], ns["tcp"]

    def read_log(path):
        fields = None
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("#fields"):
                    fields = line.strip().split()[1:]
                elif not line.startswith("#") and line.strip():
                    if fields is None:
                        raise ValueError("Missing log field header.")
                    yield dict(zip(fields, line.rstrip().split()))

    def num(value):
        return 0.0 if value in {"-", "", None} else float(value)

    def endpoints(row):
        return tuple(sorted([
            (row["id.orig_h"], int(row["id.orig_p"])),
            (row["id.resp_h"], int(row["id.resp_p"]))
        ]))

    wanted = set(clean.ks)
    flows, separators = {}, set()
    for row in read_log(conn):
        base = key(
            row["ts"], row["id.orig_h"], row["id.orig_p"],
            row["id.resp_h"], row["id.resp_p"], row["proto"]
        )
        for sep in ["|", "::", ","]:
            kk = skey(base, sep)
            if kk in wanted:
                if kk in flows:
                    raise ValueError("Ambiguous original selected flow.")
                flows[kk] = row
                separators.add(sep)
                break
    if set(flows) != wanted or len(separators) != 1:
        raise ValueError("Original selected-flow linkage failed.")
    separator = next(iter(separators))

    descriptions = defaultdict(list)
    labels = dict(zip(clean.ks, clean.y.astype(int)))
    for kk, row in flows.items():
        if labels[kk] != 1 or row["proto"].lower() != "tcp":
            continue
        start = int(Decimal(row["ts"])*10**9)
        end = start + int(Decimal(str(num(row["duration"])))*10**9)
        descriptions[endpoints(row)].append((start, end+1_000_000, kk))
    for values in descriptions.values():
        values.sort()
    starts = {t: [v[0] for v in vs] for t, vs in descriptions.items()}
    h, endian, unit, network = header(pcap)

    def packet_flow(ts, payload):
        info = tcp(payload, network)
        if info is None:
            return None
        src, sp, dst, dp, _, _ = info
        ep = tuple(sorted([(src, sp), (dst, dp)]))
        if ep not in descriptions:
            return None
        j = bisect.bisect_right(starts[ep], ts)-1
        if j < 0:
            return None
        begin, end, kk = descriptions[ep][j]
        return kk if ts <= end else None

    counts, first = defaultdict(int), {}
    packet_count = 0
    for i, ts, wire, payload in packets(pcap):
        packet_count += 1
        kk = packet_flow(ts, payload)
        if kk is not None:
            counts[kk] += 1
            first.setdefault(kk, i)
    eligible = {kk for kk, n in counts.items() if n >= 2}
    reserve = pcap.stat().st_size*3 + packet_count*160 + 1024**3
    if shutil.disk_usage(work).free < reserve:
        raise RuntimeError("Insufficient conservative replay reserve.")

    out = work / (
        "E5_CAPTURE49_FRAGMENT_DIAGNOSTIC_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    temp = Path(tempfile.mkdtemp(prefix="fragment_replay_", dir=out))
    db = None
    try:
        db = sqlite3.connect(temp/"order.sqlite")
        db.execute("PRAGMA journal_mode=OFF")
        db.execute("PRAGMA synchronous=OFF")
        db.execute("PRAGMA temp_store=FILE")
        db.execute("PRAGMA cache_size=-32768")
        db.execute("CREATE TABLE r(ts INTEGER, idx INTEGER, off INTEGER, cap INTEGER, wire INTEGER)")
        offset, batch = 24, []
        for i, ts, wire, payload in packets(pcap):
            kk = packet_flow(ts, payload)
            delay = 10*10**9 if kk in eligible and i != first[kk] else 0
            batch.append((ts+delay, i, offset+16, len(payload), wire))
            offset += 16+len(payload)
            if len(batch) == 20000:
                db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
                batch.clear()
        if batch:
            db.executemany("INSERT INTO r VALUES(?,?,?,?,?)", batch)
        db.commit()
        db.execute("CREATE INDEX ordered ON r(ts,idx)")
        db.commit()

        transformed = temp/"paced10s.pcap"
        with open(pcap, "rb") as source, open(transformed, "wb") as target:
            target.write(h)
            for ts, off, cap, wire in db.execute(
                "SELECT ts,off,cap,wire FROM r ORDER BY ts,idx"
            ):
                source.seek(off)
                payload = source.read(cap)
                if len(payload) != cap:
                    raise ValueError("Truncated source packet.")
                target.write(struct.pack(
                    endian+"IIII", ts//10**9, (ts%10**9)//unit, cap, wire
                ))
                target.write(payload)
        db.close()
        db = None
        (temp/"order.sqlite").unlink()

        digest = hashlib.sha256()
        with open(transformed, "rb") as handle:
            for block in iter(lambda: handle.read(8*1024**2), b""):
                digest.update(block)
        original_checks = json.loads(
            (search/"delay_10s/packet_checks.json").read_text()
        )
        if digest.hexdigest() != original_checks["transformed_pcap_sha256"]:
            raise ValueError("Diagnostic PCAP differs from the tested 10s candidate.")

        def limit():
            resource.setrlimit(resource.RLIMIT_AS, (6*1024**3, 6*1024**3))

        zeek = shutil.which("zeek") or "/opt/zeek/bin/zeek"
        print("Replaying exactly the tested Capture 49 10s PCAP...", flush=True)
        with open(out/"zeek_stdout.txt", "w") as stdout, open(
            out/"zeek_stderr.txt", "w"
        ) as stderr:
            process = subprocess.run(
                [str(zeek), "-C", "-r", str(transformed)],
                cwd=temp, stdout=stdout, stderr=stderr,
                timeout=1800, preexec_fn=limit
            )
        if process.returncode or not (temp/"conn.log").is_file():
            raise RuntimeError("Zeek replay failed; inspect retained stderr.")

        fragments = []
        for row in read_log(temp/"conn.log"):
            if row["proto"].lower() != "tcp":
                continue
            ep = endpoints(row)
            if ep not in descriptions:
                continue
            timestamp = int(Decimal(row["ts"])*10**9)
            possible = [
                kk for begin, end, kk in descriptions[ep]
                if begin-1_000_000 <= timestamp <= end+10*10**9
            ]
            if not possible:
                continue
            for kk in possible:
                original = flows[kk]
                same_direction = (
                    row["id.orig_h"] == original["id.orig_h"]
                    and row["id.orig_p"] == original["id.orig_p"]
                )
                row_key = skey(key(
                    row["ts"], row["id.orig_h"], row["id.orig_p"],
                    row["id.resp_h"], row["id.resp_p"], row["proto"]
                ), separator)
                fragments.append({
                    **row,
                    "associated_original_ks": kk,
                    "association_ambiguous": len(possible) != 1,
                    "is_original_start_key": row_key == kk,
                    "original_direction_pkts": num(
                        row["orig_pkts"] if same_direction else row["resp_pkts"]
                    ),
                    "original_direction_ip_bytes": num(
                        row["orig_ip_bytes"] if same_direction else row["resp_ip_bytes"]
                    ),
                })

        fragment_table = pd.DataFrame(fragments)
        fragment_table.to_csv(out/"associated_connection_records.csv", index=False)
        clean_index = clean.set_index("ks")
        summaries = []
        for kk in sorted(eligible):
            part = fragment_table[
                fragment_table.associated_original_ks.eq(kk)
            ] if not fragment_table.empty else pd.DataFrame()
            ambiguous = (
                bool(part.association_ambiguous.any()) if not part.empty else False
            )
            summed_pkts = (
                float(part.original_direction_pkts.sum()) if not part.empty else 0.
            )
            summed_bytes = (
                float(part.original_direction_ip_bytes.sum()) if not part.empty else 0.
            )
            summaries.append({
                "ks": kk,
                "associated_records": len(part),
                "ambiguous_association": ambiguous,
                "clean_orig_pkts": num(clean_index.loc[kk, "orig_pkts"]),
                "associated_orig_pkts_sum": summed_pkts,
                "clean_orig_ip_bytes": num(clean_index.loc[kk, "orig_ip_bytes"]),
                "associated_orig_ip_bytes_sum": summed_bytes,
                "packet_counter_reconciles": (
                    not ambiguous and
                    summed_pkts == num(clean_index.loc[kk, "orig_pkts"])
                ),
                "IP_byte_counter_reconciles": (
                    not ambiguous and
                    summed_bytes == num(clean_index.loc[kk, "orig_ip_bytes"])
                ),
            })
        summary = pd.DataFrame(summaries)
        summary.to_csv(out/"per_original_flow_counter_reconciliation.csv", index=False)
        receipt = {
            "status": "CAPTURE49_FRAGMENT_DIAGNOSTIC_COMPLETE",
            "tested_candidate_PCАP_hash_reproduced": True,
            "eligible_original_flows": len(eligible),
            "flows_with_multiple_associated_records": int(
                summary.associated_records.gt(1).sum()
            ),
            "ambiguous_flow_associations": int(summary.ambiguous_association.sum()),
            "flows_with_reconciled_packet_counters": int(
                summary.packet_counter_reconciles.sum()
            ),
            "flows_with_reconciled_IP_byte_counters": int(
                summary.IP_byte_counter_reconciles.sum()
            ),
            "association_scope": "Endpoint/time diagnostic; not packet-level lineage proof",
            "fragment_labels_assigned": False,
            "aggregated_features_used_for_prediction": False,
            "existing_E5_results_modified": False,
            "temporary_PCАP_retained": False,
        }
        (out/"receipt.json").write_text(json.dumps(receipt, indent=2))
        print("\nFRAGMENT DIAGNOSTIC")
        print(json.dumps(receipt, indent=2))
        print(f"\nSaved: {out}")
    finally:
        if db is not None:
            db.close()
        shutil.rmtree(temp, ignore_errors=True)

inspect_capture49_fragments()

# ===== CELL INPUT 54 =====
from pathlib import Path
import json

import joblib
import pandas as pd

def inspect_source_only_reference_contract():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    model_paths = [
        root / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
        for root in [work, backup]
    ]
    model_path = next((p for p in model_paths if p.is_file()), None)
    if model_path is None:
        raise FileNotFoundError("Frozen source model bundle unavailable.")

    bundle = joblib.load(model_path)

    print("SOURCE TRAINING METADATA — ACTUAL BUNDLE CONTENT")
    print(json.dumps(
        bundle.get("source_train_metadata"),
        indent=2,
        default=lambda value: (
            value.item() if hasattr(value, "item") else str(value)
        )
    ))

    print("\nSOURCE-REFERENCE AND CALIBRATION ARTIFACTS")
    source_fragments = [
        "TRACE_CONFIRMATORY_SOURCE_CALIBRATION",
        "TRACE_CONFIRMATORY_SOURCE_MONITOR_CALIBRATION",
        "TRACE_CONFIRMATORY_CALIBRATION_HASHKEY_FIX",
        "TRACE_CONFIRMATORY_SOURCE_MODELS",
    ]

    # Inspect only source-related directories, not E1 or target experiment trees.
    source_directories = [
        p for p in backup.iterdir()
        if p.is_dir()
        and any(fragment in p.name for fragment in source_fragments)
    ]

    for directory in sorted(source_directories):
        print(f"\nDIRECTORY: {directory}")
        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue

            print(
                f"  FILE: {path.relative_to(directory)} "
                f"({path.stat().st_size:,} bytes)"
            )

            if path.suffix.lower() == ".json" and path.stat().st_size <= 200_000:
                try:
                    value = json.loads(path.read_text())
                    print(json.dumps(value, indent=2, default=str))
                except Exception as error:
                    print(f"    JSON read error: {error}")

            elif path.name.lower().endswith((".csv", ".csv.gz")):
                try:
                    with open(path, "rb") as handle:
                        compressed = handle.read(2) == b"\x1f\x8b"
                    frame = pd.read_csv(
                        path,
                        compression="gzip" if compressed else None,
                        nrows=3
                    )
                    print(f"    Columns: {list(frame.columns)}")
                    # Print configuration/summary tables only, not source samples.
                    if not any(
                        column in frame.columns
                        for column in ["ks", "orig_bytes", "orig_pkts"]
                    ):
                        print(frame.to_string(index=False))
                except Exception as error:
                    print(f"    CSV schema read error: {error}")

    print("\nNo target records loaded, models fitted, packet replayed, or files changed.")

inspect_source_only_reference_contract()

# ===== CELL INPUT 55 =====
from pathlib import Path
from datetime import datetime, timezone
import importlib.metadata
import inspect
import json
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from menelaus.concept_drift.md3 import MD3
from threadpoolctl import threadpool_limits

def run_md3_warning_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    calibration = (
        backup / "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z"
    )
    model_path = (
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    )
    source_path = calibration / "source_reference_sample.csv"
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    e5 = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    half_width = 0.1
    sensitivity = 2
    folds = 10
    split_seed = 64201

    out = work / "MD3_PROBABILITY_MARGIN_WARNING_EVALUATION_v1"
    out.mkdir(exist_ok=True)

    policy = {
        "method": "Menelaus MD3 with probability-margin adaptation",
        "menelaus_version": importlib.metadata.version("menelaus"),
        "margin": "abs(P(malicious)-0.5) <= 0.1",
        "sensitivity": sensitivity,
        "cross_validation_folds": folds,
        "source_reference_split": "80% reference / 20% source-only holdout",
        "source_split_seed": split_seed,
        "stratification": "source scenario and binary label",
        "stream_order": "saved row order, paired clean and attacked keys",
        "oracle_stage": "not executed; stop at first unlabeled warning",
        "scope": "New post-exposure warning evaluation, not preregistered replication",
        "reference_training_overlap": (
            "Not excluded: preserved source-reference records may overlap "
            "the deployed models' original training allocation."
        ),
        "original_SVM_MD3_reproduction": False,
    }
    policy_path = out / "evaluation_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing MD3 policy differs; refusing overwrite.")
    else:
        policy_path.write_text(json.dumps(policy, indent=2))

    (out / "installed_MD3_source.py").write_text(
        inspect.getsource(MD3), encoding="utf-8"
    )

    def read_frame(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        missing = set(F + ["ks", "y"]) - set(frame.columns)
        if missing:
            raise ValueError(f"Missing columns in {path}: {sorted(missing)}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        if not frame.y.isin([0, 1]).all():
            raise ValueError("Nonbinary labels.")
        return frame

    def matrix(frame):
        numeric = [c for c in F if c != "proto"]
        return pd.DataFrame(
            np.hstack([
                np.log1p(frame[numeric].to_numpy(float)),
                np.column_stack([
                    frame.proto.eq(p).to_numpy(float)
                    for p in ["tcp", "udp", "icmp"]
                ]),
            ]),
            columns=numeric + ["proto_tcp", "proto_udp", "proto_icmp"]
        )

    def margin_signal(detector, sample, classifier):
        frame = pd.DataFrame(
            [sample], columns=detector.reference_batch_features.columns
        )
        p = float(classifier.predict_proba(frame)[0, 1])
        return int(abs(p-0.5) <= half_width)

    source = read_frame(source_path)
    if len(source) != 12288 or "source_scenario" not in source.columns:
        raise ValueError("Unexpected frozen source-reference structure.")

    strata = source.source_scenario.astype(str) + "|" + source.y.astype(str)
    reference_indices, holdout_indices = train_test_split(
        np.arange(len(source)), test_size=0.2,
        random_state=split_seed, stratify=strata
    )
    # Shuffle both source allocations deterministically; target order is unchanged.
    reference = source.iloc[reference_indices].reset_index(drop=True)
    source_holdout = source.iloc[holdout_indices].reset_index(drop=True)
    reference_X = matrix(reference)
    reference_batch = reference_X.copy()
    reference_batch["target"] = reference.y.to_numpy(int)

    pd.DataFrame({
        "ks": reference.ks,
        "source_scenario": reference.source_scenario,
        "allocation": "MD3_reference"
    }).to_csv(out / "reference_membership.csv", index=False)
    pd.DataFrame({
        "ks": source_holdout.ks,
        "source_scenario": source_holdout.source_scenario,
        "allocation": "source_holdout"
    }).to_csv(out / "source_holdout_membership.csv", index=False)

    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected frozen model seeds.")

    conditions = []

    def find_clean(scenario):
        matches = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not matches:
            raise FileNotFoundError(f"No clean sample: {scenario}")
        return min(matches, key=lambda p: (len(p.parts), str(p)))

    def pace_features(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            if not receipt_path.is_file():
                continue
            receipt = json.loads(receipt_path.read_text())
            files = sorted(job.glob("attacked_selected_features.csv*"))
            if receipt.get("status") == "PACING_JOB_COMPLETE" and len(files) == 1:
                return files[0]
        raise FileNotFoundError(f"No completed pacing features: {scenario}")

    for scenario in targets:
        clean = read_frame(find_clean(scenario))
        for attack in ["INJ_k1", "INJ_k3", "PACE_1s"]:
            attacked_path = (
                pace_features(scenario) if attack == "PACE_1s"
                else corrected / scenario / attack / "attacked_selected_features.csv"
            )
            conditions.append((
                "CORRECTED_E4", scenario, attack, clean, read_frame(attacked_path)
            ))

    for scenario in [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]:
        clean = read_frame(
            e5 / scenario / "delay_0s/candidate_selected_features.csv"
        )
        for delay in [0.0, 0.1, 1.0, 3.0, 10.0]:
            job = e5 / scenario / f"delay_{delay:g}s"
            receipt = json.loads((job / "receipt.json").read_text())
            if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                raise ValueError("Incomplete E5 candidate.")
            conditions.append((
                "EXPLORATORY_E5", scenario, f"delay_{delay:g}s",
                clean, read_frame(job / "candidate_selected_features.csv")
            ))

    def warning_stream(detector, signals):
        # This is exactly the installed MD3 unlabeled update recurrence.
        # Signals are batched through the frozen classifier for speed.
        density = float(detector.reference_distribution["md"])
        reference_density = density
        threshold = (
            detector.sensitivity * float(detector.reference_distribution["md_std"])
        )
        forgetting = float(detector.forgetting_factor)
        first_warning = None
        max_deviation = 0.0
        consumed = 0

        for index, signal in enumerate(signals):
            density = forgetting*density + (1-forgetting)*int(signal)
            deviation = abs(density-reference_density)
            max_deviation = max(max_deviation, deviation)
            consumed = index+1
            if deviation > threshold:
                first_warning = index+1
                break

        return {
            "warning": first_warning is not None,
            "first_warning_row": first_warning,
            "rows_consumed_until_warning_or_end": consumed,
            "terminal_margin_density": density,
            "maximum_margin_density_deviation": max_deviation,
            "warning_threshold": threshold,
        }

    result_rows, source_rows, reference_rows = [], [], []

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            seed = str(seed)
            checkpoint = out / f"seed_{seed}_results.csv"
            source_checkpoint = out / f"seed_{seed}_source_holdout.csv"
            reference_checkpoint = out / f"seed_{seed}_reference.json"

            if (
                checkpoint.is_file() and source_checkpoint.is_file()
                and reference_checkpoint.is_file()
            ):
                result_rows.extend(pd.read_csv(checkpoint).to_dict("records"))
                source_rows.extend(pd.read_csv(source_checkpoint).to_dict("records"))
                reference_rows.append(json.loads(reference_checkpoint.read_text()))
                print(f"Reused completed MD3 seed {seed}", flush=True)
                continue

            classifier = bank["PRIMARY"]
            detector = MD3(
                classifier,
                margin_calculation_function=margin_signal,
                sensitivity=sensitivity,
                k=folds
            )
            print(
                f"MD3 seed {seed}: fitting source-only CV clones and calibrating...",
                flush=True
            )
            started = time.perf_counter()
            detector.set_reference(reference_batch, target_name="target")
            reference_record = {
                "seed": int(seed),
                **{k: float(v) for k, v in detector.reference_distribution.items()},
                "reference_setup_seconds": time.perf_counter()-started,
                "source_reference_rows": len(reference),
                "source_holdout_rows": len(source_holdout),
            }
            reference_rows.append(reference_record)

            # Check accelerated recurrence against the installed update API
            # on the source holdout before applying it to target streams.
            holdout_X = matrix(source_holdout)
            holdout_p = classifier.predict_proba(holdout_X)[:, 1]
            holdout_signals = np.abs(holdout_p-.5) <= half_width
            fast = warning_stream(detector, holdout_signals)

            library_first = None
            for index in range(len(holdout_X)):
                detector.update(holdout_X.iloc[[index]])
                if detector.waiting_for_oracle:
                    library_first = index+1
                    break
            if library_first != fast["first_warning_row"]:
                raise ValueError("Batched recurrence differs from installed MD3.")
            if not np.isclose(
                detector.curr_margin_density,
                fast["terminal_margin_density"],
                atol=1e-12, rtol=0
            ):
                raise ValueError("MD3 terminal density verification failed.")

            source_record = {
                "seed": int(seed),
                "stream_rows": len(source_holdout),
                **fast,
                "library_update_equivalence_verified": True,
            }
            source_rows.append(source_record)
            seed_rows = []

            for group, scenario, condition, clean, attacked in conditions:
                if set(clean.ks) != set(attacked.ks):
                    raise ValueError("Paired condition keys differ.")
                attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
                y = clean.y.to_numpy(int)
                if not np.array_equal(y, attacked.y.to_numpy(int)):
                    raise ValueError("Paired condition labels differ.")

                p0 = classifier.predict_proba(matrix(clean))[:, 1]
                p1 = classifier.predict_proba(matrix(attacked))[:, 1]
                a0 = float(((p0 >= .5) == y).mean())
                a1 = float(((p1 >= .5) == y).mean())

                for state, p in [("clean", p0), ("attack", p1)]:
                    signals = np.abs(p-.5) <= half_width
                    warning = warning_stream(detector, signals)
                    seed_rows.append({
                        "group": group, "scenario": scenario,
                        "condition": condition, "seed": int(seed),
                        "state": state, "stream_rows": len(p),
                        "clean_accuracy": a0, "attack_accuracy": a1,
                        "true_damage": a0-a1,
                        "stream_margin_density": float(signals.mean()),
                        **warning,
                    })

            result_rows.extend(seed_rows)
            pd.DataFrame(seed_rows).to_csv(checkpoint, index=False)
            pd.DataFrame([source_record]).to_csv(source_checkpoint, index=False)
            reference_checkpoint.write_text(json.dumps(reference_record, indent=2))
            print(f"MD3 seed {seed}: all 34 paired conditions complete", flush=True)

    results = pd.DataFrame(result_rows)
    if len(results) != 204:
        raise ValueError(f"Expected 204 stream evaluations; found {len(results)}.")

    # CSV resume may represent booleans as strings; normalize explicitly.
    results["warning"] = (
        results.warning.astype(str).str.lower().map({"true": True, "false": False})
    )
    if results.warning.isna().any():
        raise ValueError("Unrecognized warning value.")

    results.to_csv(out / "all_stream_warning_results.csv", index=False)
    pd.DataFrame(source_rows).to_csv(
        out / "source_holdout_warning_results.csv", index=False
    )
    pd.DataFrame(reference_rows).to_csv(
        out / "reference_distribution_statistics.csv", index=False
    )
    summary = results.groupby(
        ["group", "state"], as_index=False
    ).agg(
        stream_warning_fraction=("warning", "mean"),
        streams=("warning", "size"),
    )
    summary.to_csv(out / "warning_summary.csv", index=False)

    (out / "completion_receipt.json").write_text(json.dumps({
        "status": "MD3_PROBABILITY_MARGIN_WARNING_BATCH_COMPLETE",
        "stream_evaluations": len(results),
        "source_reference_rows": len(reference),
        "source_holdout_rows": len(source_holdout),
        "source_only_CV_clone_fitting": True,
        "deployed_models_retrained": False,
        "library_update_equivalence_verified": True,
        "target_labels_used_for_reference_or_warning": False,
        "target_labels_used_for_damage_metrics": True,
        "oracle_confirmation_executed": False,
        "original_SVM_MD3_reproduction": False,
        "reference_training_disjointness_established": False,
        "source_holdout_warning_note": (
            "Three full-stream warning outcomes, not a calibrated per-window FPR."
        ),
        "PCAP_replays": 0,
        "files_deleted": 0,
        "full_drift_gate_complete": False,
        "all_study_requirements_complete": False,
    }, indent=2))

    print("\nMD3 WARNING SUMMARY")
    print(summary.to_string(index=False))
    print("\nSOURCE HOLDOUT WARNINGS")
    print(pd.DataFrame(source_rows).to_string(index=False))
    print("\nCAPTURE 49 — 10s CANDIDATE")
    print(results[
        results.group.eq("EXPLORATORY_E5")
        & results.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & results.condition.eq("delay_10s")
    ].to_string(index=False))
    print(f"\nCompleted MD3 warning batch: {out}")

run_md3_warning_batch()

# ===== CELL INPUT 56 =====
from pathlib import Path
from datetime import datetime, timezone
import importlib.metadata
import inspect
import json
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from menelaus.concept_drift.md3 import MD3
from threadpoolctl import threadpool_limits

def run_md3_warning_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    calibration = (
        backup / "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z"
    )
    model_path = (
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    )
    source_path = calibration / "source_reference_sample.csv"
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    e5 = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    half_width = 0.1
    sensitivity = 2
    folds = 10
    split_seed = 64201

    out = work / "MD3_PROBABILITY_MARGIN_WARNING_EVALUATION_v1"
    out.mkdir(exist_ok=True)

    policy = {
        "method": "Menelaus MD3 with probability-margin adaptation",
        "menelaus_version": importlib.metadata.version("menelaus"),
        "margin": "abs(P(malicious)-0.5) <= 0.1",
        "sensitivity": sensitivity,
        "cross_validation_folds": folds,
        "source_reference_split": "80% reference / 20% source-only holdout",
        "source_split_seed": split_seed,
        "stratification": "source scenario and binary label",
        "stream_order": "saved row order, paired clean and attacked keys",
        "oracle_stage": "not executed; stop at first unlabeled warning",
        "scope": "New post-exposure warning evaluation, not preregistered replication",
        "reference_training_overlap": (
            "Not excluded: preserved source-reference records may overlap "
            "the deployed models' original training allocation."
        ),
        "original_SVM_MD3_reproduction": False,
    }
    policy_path = out / "evaluation_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing MD3 policy differs; refusing overwrite.")
    else:
        policy_path.write_text(json.dumps(policy, indent=2))

    (out / "installed_MD3_source.py").write_text(
        inspect.getsource(MD3), encoding="utf-8"
    )

    def read_frame(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        missing = set(F + ["ks", "y"]) - set(frame.columns)
        if missing:
            raise ValueError(f"Missing columns in {path}: {sorted(missing)}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        if not frame.y.isin([0, 1]).all():
            raise ValueError("Nonbinary labels.")
        return frame

    def matrix(frame):
        numeric = [c for c in F if c != "proto"]
        return pd.DataFrame(
            np.hstack([
                np.log1p(frame[numeric].to_numpy(float)),
                np.column_stack([
                    frame.proto.eq(p).to_numpy(float)
                    for p in ["tcp", "udp", "icmp"]
                ]),
            ]),
            columns=numeric + ["proto_tcp", "proto_udp", "proto_icmp"]
        )

    def margin_signal(detector, sample, classifier):
        frame = pd.DataFrame(
            [sample], columns=detector.reference_batch_features.columns
        )
        p = float(classifier.predict_proba(frame)[0, 1])
        return int(abs(p-0.5) <= half_width)

    source = read_frame(source_path)
    if len(source) != 12288 or "source_scenario" not in source.columns:
        raise ValueError("Unexpected frozen source-reference structure.")

    strata = source.source_scenario.astype(str) + "|" + source.y.astype(str)
    reference_indices, holdout_indices = train_test_split(
        np.arange(len(source)), test_size=0.2,
        random_state=split_seed, stratify=strata
    )
    # Shuffle both source allocations deterministically; target order is unchanged.
    reference = source.iloc[reference_indices].reset_index(drop=True)
    source_holdout = source.iloc[holdout_indices].reset_index(drop=True)
    reference_X = matrix(reference)
    reference_batch = reference_X.copy()
    reference_batch["target"] = reference.y.to_numpy(int)

    pd.DataFrame({
        "ks": reference.ks,
        "source_scenario": reference.source_scenario,
        "allocation": "MD3_reference"
    }).to_csv(out / "reference_membership.csv", index=False)
    pd.DataFrame({
        "ks": source_holdout.ks,
        "source_scenario": source_holdout.source_scenario,
        "allocation": "source_holdout"
    }).to_csv(out / "source_holdout_membership.csv", index=False)

    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected frozen model seeds.")

    conditions = []

    def find_clean(scenario):
        matches = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not matches:
            raise FileNotFoundError(f"No clean sample: {scenario}")
        return min(matches, key=lambda p: (len(p.parts), str(p)))

    def pace_features(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            if not receipt_path.is_file():
                continue
            receipt = json.loads(receipt_path.read_text())
            files = sorted(job.glob("attacked_selected_features.csv*"))
            if receipt.get("status") == "PACING_JOB_COMPLETE" and len(files) == 1:
                return files[0]
        raise FileNotFoundError(f"No completed pacing features: {scenario}")

    for scenario in targets:
        clean = read_frame(find_clean(scenario))
        for attack in ["INJ_k1", "INJ_k3", "PACE_1s"]:
            attacked_path = (
                pace_features(scenario) if attack == "PACE_1s"
                else corrected / scenario / attack / "attacked_selected_features.csv"
            )
            conditions.append((
                "CORRECTED_E4", scenario, attack, clean, read_frame(attacked_path)
            ))

    for scenario in [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]:
        clean = read_frame(
            e5 / scenario / "delay_0s/candidate_selected_features.csv"
        )
        for delay in [0.0, 0.1, 1.0, 3.0, 10.0]:
            job = e5 / scenario / f"delay_{delay:g}s"
            receipt = json.loads((job / "receipt.json").read_text())
            if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                raise ValueError("Incomplete E5 candidate.")
            conditions.append((
                "EXPLORATORY_E5", scenario, f"delay_{delay:g}s",
                clean, read_frame(job / "candidate_selected_features.csv")
            ))

    def warning_stream(detector, signals):
        # This is exactly the installed MD3 unlabeled update recurrence.
        # Signals are batched through the frozen classifier for speed.
        density = float(detector.reference_distribution["md"])
        reference_density = density
        threshold = (
            detector.sensitivity * float(detector.reference_distribution["md_std"])
        )
        forgetting = float(detector.forgetting_factor)
        first_warning = None
        max_deviation = 0.0
        consumed = 0

        for index, signal in enumerate(signals):
            density = forgetting*density + (1-forgetting)*int(signal)
            deviation = abs(density-reference_density)
            max_deviation = max(max_deviation, deviation)
            consumed = index+1
            if deviation > threshold:
                first_warning = index+1
                break

        return {
            "warning": first_warning is not None,
            "first_warning_row": first_warning,
            "rows_consumed_until_warning_or_end": consumed,
            "terminal_margin_density": density,
            "maximum_margin_density_deviation": max_deviation,
            "warning_threshold": threshold,
        }

    result_rows, source_rows, reference_rows = [], [], []

    with threadpool_limits(limits=2):
        for seed, bank in bundle["models"].items():
            seed = str(seed)
            checkpoint = out / f"seed_{seed}_results.csv"
            source_checkpoint = out / f"seed_{seed}_source_holdout.csv"
            reference_checkpoint = out / f"seed_{seed}_reference.json"

            if (
                checkpoint.is_file() and source_checkpoint.is_file()
                and reference_checkpoint.is_file()
            ):
                result_rows.extend(pd.read_csv(checkpoint).to_dict("records"))
                source_rows.extend(pd.read_csv(source_checkpoint).to_dict("records"))
                reference_rows.append(json.loads(reference_checkpoint.read_text()))
                print(f"Reused completed MD3 seed {seed}", flush=True)
                continue

            classifier = bank["PRIMARY"]
            detector = MD3(
                classifier,
                margin_calculation_function=margin_signal,
                sensitivity=sensitivity,
                k=folds
            )
            print(
                f"MD3 seed {seed}: fitting source-only CV clones and calibrating...",
                flush=True
            )
            started = time.perf_counter()
            detector.set_reference(reference_batch, target_name="target")
            reference_record = {
                "seed": int(seed),
                **{k: float(v) for k, v in detector.reference_distribution.items()},
                "reference_setup_seconds": time.perf_counter()-started,
                "source_reference_rows": len(reference),
                "source_holdout_rows": len(source_holdout),
            }
            reference_rows.append(reference_record)

            # Check accelerated recurrence against the installed update API
            # on the source holdout before applying it to target streams.
            holdout_X = matrix(source_holdout)
            holdout_p = classifier.predict_proba(holdout_X)[:, 1]
            holdout_signals = np.abs(holdout_p-.5) <= half_width
            fast = warning_stream(detector, holdout_signals)

            library_first = None
            for index in range(len(holdout_X)):
                detector.update(holdout_X.iloc[[index]])
                if detector.waiting_for_oracle:
                    library_first = index+1
                    break
            if library_first != fast["first_warning_row"]:
                raise ValueError("Batched recurrence differs from installed MD3.")
            if not np.isclose(
                detector.curr_margin_density,
                fast["terminal_margin_density"],
                atol=1e-12, rtol=0
            ):
                raise ValueError("MD3 terminal density verification failed.")

            source_record = {
                "seed": int(seed),
                "stream_rows": len(source_holdout),
                **fast,
                "library_update_equivalence_verified": True,
            }
            source_rows.append(source_record)
            seed_rows = []

            for group, scenario, condition, clean, attacked in conditions:
                if set(clean.ks) != set(attacked.ks):
                    raise ValueError("Paired condition keys differ.")
                attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
                y = clean.y.to_numpy(int)
                if not np.array_equal(y, attacked.y.to_numpy(int)):
                    raise ValueError("Paired condition labels differ.")

                p0 = classifier.predict_proba(matrix(clean))[:, 1]
                p1 = classifier.predict_proba(matrix(attacked))[:, 1]
                a0 = float(((p0 >= .5) == y).mean())
                a1 = float(((p1 >= .5) == y).mean())

                for state, p in [("clean", p0), ("attack", p1)]:
                    signals = np.abs(p-.5) <= half_width
                    warning = warning_stream(detector, signals)
                    seed_rows.append({
                        "group": group, "scenario": scenario,
                        "condition": condition, "seed": int(seed),
                        "state": state, "stream_rows": len(p),
                        "clean_accuracy": a0, "attack_accuracy": a1,
                        "true_damage": a0-a1,
                        "stream_margin_density": float(signals.mean()),
                        **warning,
                    })

            result_rows.extend(seed_rows)
            pd.DataFrame(seed_rows).to_csv(checkpoint, index=False)
            pd.DataFrame([source_record]).to_csv(source_checkpoint, index=False)
            reference_checkpoint.write_text(json.dumps(reference_record, indent=2))
            print(f"MD3 seed {seed}: all 34 paired conditions complete", flush=True)

    results = pd.DataFrame(result_rows)
    if len(results) != 204:
        raise ValueError(f"Expected 204 stream evaluations; found {len(results)}.")

    # CSV resume may represent booleans as strings; normalize explicitly.
    results["warning"] = (
        results.warning.astype(str).str.lower().map({"true": True, "false": False})
    )
    if results.warning.isna().any():
        raise ValueError("Unrecognized warning value.")

    results.to_csv(out / "all_stream_warning_results.csv", index=False)
    pd.DataFrame(source_rows).to_csv(
        out / "source_holdout_warning_results.csv", index=False
    )
    pd.DataFrame(reference_rows).to_csv(
        out / "reference_distribution_statistics.csv", index=False
    )
    summary = results.groupby(
        ["group", "state"], as_index=False
    ).agg(
        stream_warning_fraction=("warning", "mean"),
        streams=("warning", "size"),
    )
    summary.to_csv(out / "warning_summary.csv", index=False)

    (out / "completion_receipt.json").write_text(json.dumps({
        "status": "MD3_PROBABILITY_MARGIN_WARNING_BATCH_COMPLETE",
        "stream_evaluations": len(results),
        "source_reference_rows": len(reference),
        "source_holdout_rows": len(source_holdout),
        "source_only_CV_clone_fitting": True,
        "deployed_models_retrained": False,
        "library_update_equivalence_verified": True,
        "target_labels_used_for_reference_or_warning": False,
        "target_labels_used_for_damage_metrics": True,
        "oracle_confirmation_executed": False,
        "original_SVM_MD3_reproduction": False,
        "reference_training_disjointness_established": False,
        "source_holdout_warning_note": (
            "Three full-stream warning outcomes, not a calibrated per-window FPR."
        ),
        "PCAP_replays": 0,
        "files_deleted": 0,
        "full_drift_gate_complete": False,
        "all_study_requirements_complete": False,
    }, indent=2))

    print("\nMD3 WARNING SUMMARY")
    print(summary.to_string(index=False))
    print("\nSOURCE HOLDOUT WARNINGS")
    print(pd.DataFrame(source_rows).to_string(index=False))
    print("\nCAPTURE 49 — 10s CANDIDATE")
    print(results[
        results.group.eq("EXPLORATORY_E5")
        & results.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & results.condition.eq("delay_10s")
    ].to_string(index=False))
    print(f"\nCompleted MD3 warning batch: {out}")

run_md3_warning_batch()

# ===== CELL INPUT 57 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def evaluate_full_gate_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    source_dir = (
        backup / "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z"
    )
    source_path = source_dir / "source_reference_sample.csv"
    model_path = (
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    )
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    e5 = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    V = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }
    configurations = [
        "COMPETENCE_ONLY",
        "DRIFT_ONLY",
        "COMBINED_HARD_GATE",
    ]
    window_rows = 128
    reference_windows = 512
    gate_z = 3.0
    sd_floor = 0.01
    reference_seed = 64301
    window_salt = "POST_EXPOSURE_GATE_WINDOWS_v1"
    timing_repetitions = 3

    out = work / "FULL_GATE_POST_EXPOSURE_EVALUATION_v1"
    out.mkdir(exist_ok=True)

    def file_hash(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8*1024**2), b""):
                h.update(block)
        return h.hexdigest()

    policy = {
        "status": "NEW_POST_EXPOSURE_IMPLEMENTATION",
        "views": V,
        "window_rows": window_rows,
        "reference_windows": reference_windows,
        "reference_seed": reference_seed,
        "reference_window_sampling": (
            "128 records without replacement per draw from preserved "
            "balanced source reference; draws may overlap"
        ),
        "target_windows": (
            "Sort by SHA256(window_salt + ks), then eight disjoint "
            "128-record windows; no labels used in ordering"
        ),
        "window_salt": window_salt,
        "drift_statistic": (
            "absolute view-positive-rate deviation divided by "
            "max(source-window SD, 0.01)"
        ),
        "competence_weight": "max(2 * source view accuracy - 1, 0)",
        "drift_weight": "exp(-0.5 * z**2)",
        "gate_z": gate_z,
        "sd_floor": sd_floor,
        "combined_weight": (
            "competence_weight * drift_weight * indicator(z <= gate_z)"
        ),
        "combined_abstention": "fewer than two views have positive gated weight",
        "pseudo_label": "weighted positive vote > 0.5; exact ties are benign",
        "estimate": "primary agreement with weighted pseudo-label",
        "source_reference_sha256": file_hash(source_path),
        "frozen_model_sha256": file_hash(model_path),
        "reference_training_disjointness_verified": False,
        "reference_profile_fit_validation_disjointness_verified": False,
        "configurations": configurations,
        "timing_repetitions": timing_repetitions,
        "full_gate_adaptive_attack_performed": False,
    }
    policy_path = out / "monitor_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing gate policy differs; refusing overwrite.")
    else:
        policy_path.write_text(json.dumps(policy, indent=2))

    def read_raw(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        if not set(F + ["ks", "y"]).issubset(frame.columns):
            raise ValueError(f"Missing required columns: {path}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        if frame.ks.duplicated().any() or not frame.y.isin([0, 1]).all():
            raise ValueError(f"Invalid membership/labels: {path}")
        return frame

    def preprocess(raw):
        frame = raw[F].copy()
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def matrix(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    source = read_raw(source_path)
    if len(source) != 12288:
        raise ValueError("Unexpected preserved source reference size.")
    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected seed set.")

    rng = np.random.default_rng(reference_seed)
    reference_indices = np.array([
        rng.choice(len(source), window_rows, replace=False)
        for _ in range(reference_windows)
    ])
    calibrations = {}
    calibration_rows = []

    with threadpool_limits(limits=2):
        source_features = preprocess(source)
        for seed, bank in bundle["models"].items():
            votes = np.column_stack([
                bank[name].predict(matrix(source_features, columns))
                for name, columns in V.items()
            ]).astype(int)
            rates = votes[reference_indices].mean(axis=1)
            accuracies = (votes == source.y.to_numpy()[:, None]).mean(axis=0)
            mu = rates.mean(axis=0)
            sd = rates.std(axis=0, ddof=0)
            competence = np.maximum(2*accuracies-1, 0)
            calibrations[str(seed)] = (mu, sd, competence)
            for j, name in enumerate(V):
                calibration_rows.append({
                    "seed": int(seed), "view": name,
                    "source_accuracy": float(accuracies[j]),
                    "competence_weight": float(competence[j]),
                    "source_window_rate_mean": float(mu[j]),
                    "source_window_rate_SD": float(sd[j]),
                })

    pd.DataFrame(calibration_rows).to_csv(
        out / "source_gate_calibration.csv", index=False
    )

    def pipeline(raw, bank, calibration, configuration):
        frame = preprocess(raw)
        p = bank["PRIMARY"].predict_proba(matrix(frame, F))[:, 1]
        decision = p >= .5
        votes = np.column_stack([
            bank[name].predict(matrix(frame, columns))
            for name, columns in V.items()
        ]).astype(int)
        mu, sd, competence = calibration
        rates = votes.mean(axis=0)
        z = np.abs(rates-mu)/np.maximum(sd, sd_floor)
        drift = np.exp(-0.5*z*z)

        if configuration == "COMPETENCE_ONLY":
            weights = competence.copy()
            abstained = weights.sum() <= 0
        elif configuration == "DRIFT_ONLY":
            weights = drift
            abstained = weights.sum() <= 0
        else:
            weights = competence*drift*(z <= gate_z)
            abstained = int((weights > 0).sum()) < 2

        estimate = None
        if not abstained:
            pseudo = (votes @ weights)/weights.sum() > .5
            estimate = float((decision == pseudo).mean())

        evidence = {
            "configuration": configuration,
            "estimate": estimate,
            "abstained": bool(abstained),
            "view_positive_rates": rates.tolist(),
            "view_z": z.tolist(),
            "weights": weights.tolist(),
        }
        serialized = json.dumps(
            evidence, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
        return estimate, abstained, decision, evidence, len(serialized)

    def find_clean(scenario):
        candidates = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not candidates:
            raise FileNotFoundError(scenario)
        return min(candidates, key=lambda p: (len(p.parts), str(p)))

    def pacing_path(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            files = sorted(job.glob("attacked_selected_features.csv*"))
            if receipt_path.is_file() and len(files) == 1:
                receipt = json.loads(receipt_path.read_text())
                if receipt.get("status") == "PACING_JOB_COMPLETE":
                    return files[0]
        raise FileNotFoundError(f"No pacing feature artifact: {scenario}")

    conditions = []
    for scenario in targets:
        clean = read_raw(find_clean(scenario))
        for treatment in ["INJ_k1", "INJ_k3", "PACE_1s"]:
            attack_path = (
                pacing_path(scenario) if treatment == "PACE_1s"
                else corrected / scenario / treatment / "attacked_selected_features.csv"
            )
            conditions.append((
                "CORRECTED_E4", scenario, treatment, clean, read_raw(attack_path)
            ))

    for scenario in [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]:
        clean = read_raw(e5/scenario/"delay_0s/candidate_selected_features.csv")
        for delay in [0.0, 0.1, 1.0, 3.0, 10.0]:
            job = e5/scenario/f"delay_{delay:g}s"
            receipt = json.loads((job/"receipt.json").read_text())
            if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                raise ValueError("Incomplete E5 candidate.")
            conditions.append((
                "EXPLORATORY_E5", scenario, f"delay_{delay:g}s",
                clean, read_raw(job/"candidate_selected_features.csv")
            ))

    result_rows, timing_rows, evidence_rows = [], [], []

    with threadpool_limits(limits=2):
        for group, scenario, condition, clean, attacked in conditions:
            if (
                len(clean) != 1024 or set(clean.ks) != set(attacked.ks)
            ):
                raise ValueError("Invalid paired target sample.")
            attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
            if not np.array_equal(clean.y, attacked.y):
                raise ValueError("Paired labels differ.")

            hashes = [
                hashlib.sha256((window_salt+k).encode()).hexdigest()
                for k in clean.ks
            ]
            order = np.argsort(hashes, kind="stable")
            windows = order.reshape(8, window_rows)

            for seed, bank in

# ===== CELL INPUT 58 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

def evaluate_full_gate_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    source_dir = (
        backup / "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z"
    )
    source_path = source_dir / "source_reference_sample.csv"
    model_path = (
        backup / "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1/frozen_source_models.joblib"
    )
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    e5 = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    V = {
        "V_orig": ["orig_pkts", "orig_bytes", "orig_ip_bytes"],
        "V_resp": ["resp_pkts", "resp_bytes", "resp_ip_bytes", "missed_bytes"],
        "V_time_proto": ["duration", "proto"],
    }
    configurations = [
        "COMPETENCE_ONLY",
        "DRIFT_ONLY",
        "COMBINED_HARD_GATE",
    ]
    window_rows = 128
    reference_windows = 512
    gate_z = 3.0
    sd_floor = 0.01
    reference_seed = 64301
    window_salt = "POST_EXPOSURE_GATE_WINDOWS_v1"
    timing_repetitions = 3

    out = work / "FULL_GATE_POST_EXPOSURE_EVALUATION_v1"
    out.mkdir(exist_ok=True)

    def file_hash(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8*1024**2), b""):
                h.update(block)
        return h.hexdigest()

    policy = {
        "status": "NEW_POST_EXPOSURE_IMPLEMENTATION",
        "views": V,
        "window_rows": window_rows,
        "reference_windows": reference_windows,
        "reference_seed": reference_seed,
        "reference_window_sampling": (
            "128 records without replacement per draw from preserved "
            "balanced source reference; draws may overlap"
        ),
        "target_windows": (
            "Sort by SHA256(window_salt + ks), then eight disjoint "
            "128-record windows; no labels used in ordering"
        ),
        "window_salt": window_salt,
        "drift_statistic": (
            "absolute view-positive-rate deviation divided by "
            "max(source-window SD, 0.01)"
        ),
        "competence_weight": "max(2 * source view accuracy - 1, 0)",
        "drift_weight": "exp(-0.5 * z**2)",
        "gate_z": gate_z,
        "sd_floor": sd_floor,
        "combined_weight": (
            "competence_weight * drift_weight * indicator(z <= gate_z)"
        ),
        "combined_abstention": "fewer than two views have positive gated weight",
        "pseudo_label": "weighted positive vote > 0.5; exact ties are benign",
        "estimate": "primary agreement with weighted pseudo-label",
        "source_reference_sha256": file_hash(source_path),
        "frozen_model_sha256": file_hash(model_path),
        "reference_training_disjointness_verified": False,
        "reference_profile_fit_validation_disjointness_verified": False,
        "configurations": configurations,
        "timing_repetitions": timing_repetitions,
        "full_gate_adaptive_attack_performed": False,
    }
    policy_path = out / "monitor_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing gate policy differs; refusing overwrite.")
    else:
        policy_path.write_text(json.dumps(policy, indent=2))

    def read_raw(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        if not set(F + ["ks", "y"]).issubset(frame.columns):
            raise ValueError(f"Missing required columns: {path}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        if frame.ks.duplicated().any() or not frame.y.isin([0, 1]).all():
            raise ValueError(f"Invalid membership/labels: {path}")
        return frame

    def preprocess(raw):
        frame = raw[F].copy()
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        return frame

    def matrix(frame, columns):
        parts = []
        numeric = [c for c in columns if c != "proto"]
        if numeric:
            parts.append(np.log1p(frame[numeric].to_numpy(float)))
        if "proto" in columns:
            parts.append(np.column_stack([
                frame.proto.eq(p).to_numpy(float)
                for p in ["tcp", "udp", "icmp"]
            ]))
        return np.hstack(parts)

    source = read_raw(source_path)
    if len(source) != 12288:
        raise ValueError("Unexpected preserved source reference size.")
    bundle = joblib.load(model_path)
    if {str(s) for s in bundle["models"]} != {"8101", "8102", "8103"}:
        raise ValueError("Unexpected seed set.")

    rng = np.random.default_rng(reference_seed)
    reference_indices = np.array([
        rng.choice(len(source), window_rows, replace=False)
        for _ in range(reference_windows)
    ])
    calibrations = {}
    calibration_rows = []

    with threadpool_limits(limits=2):
        source_features = preprocess(source)
        for seed, bank in bundle["models"].items():
            votes = np.column_stack([
                bank[name].predict(matrix(source_features, columns))
                for name, columns in V.items()
            ]).astype(int)
            rates = votes[reference_indices].mean(axis=1)
            accuracies = (votes == source.y.to_numpy()[:, None]).mean(axis=0)
            mu = rates.mean(axis=0)
            sd = rates.std(axis=0, ddof=0)
            competence = np.maximum(2*accuracies-1, 0)
            calibrations[str(seed)] = (mu, sd, competence)
            for j, name in enumerate(V):
                calibration_rows.append({
                    "seed": int(seed), "view": name,
                    "source_accuracy": float(accuracies[j]),
                    "competence_weight": float(competence[j]),
                    "source_window_rate_mean": float(mu[j]),
                    "source_window_rate_SD": float(sd[j]),
                })

    pd.DataFrame(calibration_rows).to_csv(
        out / "source_gate_calibration.csv", index=False
    )

    def pipeline(raw, bank, calibration, configuration):
        frame = preprocess(raw)
        p = bank["PRIMARY"].predict_proba(matrix(frame, F))[:, 1]
        decision = p >= .5
        votes = np.column_stack([
            bank[name].predict(matrix(frame, columns))
            for name, columns in V.items()
        ]).astype(int)
        mu, sd, competence = calibration
        rates = votes.mean(axis=0)
        z = np.abs(rates-mu)/np.maximum(sd, sd_floor)
        drift = np.exp(-0.5*z*z)

        if configuration == "COMPETENCE_ONLY":
            weights = competence.copy()
            abstained = weights.sum() <= 0
        elif configuration == "DRIFT_ONLY":
            weights = drift
            abstained = weights.sum() <= 0
        else:
            weights = competence*drift*(z <= gate_z)
            abstained = int((weights > 0).sum()) < 2

        estimate = None
        if not abstained:
            pseudo = (votes @ weights)/weights.sum() > .5
            estimate = float((decision == pseudo).mean())

        evidence = {
            "configuration": configuration,
            "estimate": estimate,
            "abstained": bool(abstained),
            "view_positive_rates": rates.tolist(),
            "view_z": z.tolist(),
            "weights": weights.tolist(),
        }
        serialized = json.dumps(
            evidence, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
        return estimate, abstained, decision, evidence, len(serialized)

    def find_clean(scenario):
        candidates = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not candidates:
            raise FileNotFoundError(scenario)
        return min(candidates, key=lambda p: (len(p.parts), str(p)))

    def pacing_path(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            files = sorted(job.glob("attacked_selected_features.csv*"))
            if receipt_path.is_file() and len(files) == 1:
                receipt = json.loads(receipt_path.read_text())
                if receipt.get("status") == "PACING_JOB_COMPLETE":
                    return files[0]
        raise FileNotFoundError(f"No pacing feature artifact: {scenario}")

    conditions = []
    for scenario in targets:
        clean = read_raw(find_clean(scenario))
        for treatment in ["INJ_k1", "INJ_k3", "PACE_1s"]:
            attack_path = (
                pacing_path(scenario) if treatment == "PACE_1s"
                else corrected / scenario / treatment / "attacked_selected_features.csv"
            )
            conditions.append((
                "CORRECTED_E4", scenario, treatment, clean, read_raw(attack_path)
            ))

    for scenario in [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1",
    ]:
        clean = read_raw(e5/scenario/"delay_0s/candidate_selected_features.csv")
        for delay in [0.0, 0.1, 1.0, 3.0, 10.0]:
            job = e5/scenario/f"delay_{delay:g}s"
            receipt = json.loads((job/"receipt.json").read_text())
            if receipt.get("status") != "E5_CANDIDATE_COMPLETE":
                raise ValueError("Incomplete E5 candidate.")
            conditions.append((
                "EXPLORATORY_E5", scenario, f"delay_{delay:g}s",
                clean, read_raw(job/"candidate_selected_features.csv")
            ))

    result_rows, timing_rows, evidence_rows = [], [], []

    with threadpool_limits(limits=2):
        for group, scenario, condition, clean, attacked in conditions:
            if (
                len(clean) != 1024 or set(clean.ks) != set(attacked.ks)
            ):
                raise ValueError("Invalid paired target sample.")
            attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
            if not np.array_equal(clean.y, attacked.y):
                raise ValueError("Paired labels differ.")

            hashes = [
                hashlib.sha256((window_salt+k).encode()).hexdigest()
                for k in clean.ks
            ]
            order = np.argsort(hashes, kind="stable")
            windows = order.reshape(8, window_rows)

            for seed, bank in bundle["models"].items():
                calibration = calibrations[str(seed)]
                for configuration in configurations:
                    for window_id, indices in enumerate(windows):
                        state_values = []
                        for state, frame in [("clean", clean), ("attack", attacked)]:
                            window = frame.iloc[indices].reset_index(drop=True)

                            estimate, abstained, decision, evidence, record_bytes = (
                                pipeline(window, bank, calibration, configuration)
                            )
                            actual = float(
                                (decision == window.y.to_numpy()).mean()
                            )
                            state_values.append((estimate, abstained, actual))
                            evidence_rows.append({
                                "group": group, "scenario": scenario,
                                "condition": condition, "seed": int(seed),
                                "configuration": configuration,
                                "window": window_id, "state": state,
                                **evidence,
                            })

                            # Measure the complete deployed tabular pipeline:
                            # preprocessing, inference, gate, estimation,
                            # evidence serialization. Labels are excluded.
                            for repetition in range(timing_repetitions):
                                start = time.perf_counter_ns()
                                pipeline(window, bank, calibration, configuration)
                                elapsed_ms = (time.perf_counter_ns()-start)/1e6
                                timing_rows.append({
                                    "group": group, "scenario": scenario,
                                    "condition": condition, "seed": int(seed),
                                    "configuration": configuration,
                                    "window": window_id, "state": state,
                                    "repetition": repetition,
                                    "ms_per_128_records": elapsed_ms,
                                    "ms_per_1000_records": elapsed_ms*1000/window_rows,
                                    "evidence_bytes": record_bytes,
                                })

                        e0, abstain0, a0 = state_values[0]
                        e1, abstain1, a1 = state_values[1]
                        retained = not abstain0 and not abstain1
                        result_rows.append({
                            "group": group, "scenario": scenario,
                            "condition": condition, "seed": int(seed),
                            "configuration": configuration, "window": window_id,
                            "clean_accuracy": a0, "attack_accuracy": a1,
                            "true_damage": a0-a1,
                            "clean_estimate": e0, "attack_estimate": e1,
                            "clean_abstained": abstain0,
                            "attack_abstained": abstain1,
                            "paired_estimate_retained": retained,
                            "differential_abs_error": (
                                abs((e1-a1)-(e0-a0)) if retained else np.nan
                            ),
                        })
            print(f"Gate evaluation and timings complete: {scenario}/{condition}",
                  flush=True)

    results = pd.DataFrame(result_rows)
    timings = pd.DataFrame(timing_rows)
    if len(results) != 2448:
        raise ValueError(f"Expected 2,448 paired gate rows; found {len(results)}.")

    results.to_csv(out/"paired_window_results.csv", index=False)
    timings.to_csv(out/"full_pipeline_timings.csv", index=False)
    with open(out/"window_evidence.jsonl", "w", encoding="utf-8") as handle:
        for record in evidence_rows:
            handle.write(json.dumps(record, allow_nan=False)+"\n")

    units = results.groupby(
        ["group", "scenario", "condition", "configuration"], as_index=False
    ).agg(
        retained_error=("differential_abs_error", "mean"),
        paired_coverage=("paired_estimate_retained", "mean"),
        clean_abstention=("clean_abstained", "mean"),
        attack_abstention=("attack_abstained", "mean"),
    )
    units.to_csv(out/"scenario_condition_results.csv", index=False)
    summary = units.groupby(
        ["group", "configuration"], as_index=False
    ).agg(
        mean_error_on_available_pairs=("retained_error", "mean"),
        mean_paired_coverage=("paired_coverage", "mean"),
        mean_clean_abstention=("clean_abstention", "mean"),
        mean_attack_abstention=("attack_abstention", "mean"),
        units_with_available_error=("retained_error", "count"),
    )
    latency = timings.groupby("configuration", as_index=False).agg(
        median_ms_per_1000=("ms_per_1000_records", "median"),
        mean_ms_per_1000=("ms_per_1000_records", "mean"),
        p95_ms_per_1000=("ms_per_1000_records", lambda s: float(s.quantile(.95))),
    )
    summary.to_csv(out/"monitor_summary.csv", index=False)
    latency.to_csv(out/"pipeline_latency_summary.csv", index=False)
    (out/"completion_receipt.json").write_text(json.dumps({
        "status": "NEW_FULL_GATE_EVALUATION_AND_TIMING_COMPLETE",
        "paired_window_rows": len(results),
        "timing_rows": len(timings),
        "source_calibration_only": True,
        "post_exposure_definition": True,
        "reference_training_disjointness_verified": False,
        "conditional_error_requires_coverage_reporting": True,
        "new_adaptive_attack_against_this_gate_performed": False,
        "timing_includes": [
            "numeric preprocessing", "protocol encoding", "primary inference",
            "three-view inference", "drift computation", "weighting",
            "abstention", "agreement estimation", "JSON evidence serialization"
        ],
        "timing_excludes": [
            "packet capture", "Zeek extraction", "disk loading",
            "model loading", "source calibration"
        ],
        "hardware_scope": "Kaggle CPU, not edge hardware",
        "PCAP_replays": 0,
        "deployed_models_retrained": False,
        "files_deleted": 0,
        "all_study_requirements_complete": False,
    }, indent=2))

    print("\nTHREE MONITOR CONFIGURATIONS")
    print(summary.to_string(index=False))
    print("\nFULL PIPELINE LATENCY")
    print(latency.to_string(index=False))
    print("\nCAPTURE 49, 10s — COVERAGE AND CONDITIONAL ERROR")
    print(units[
        units.group.eq("EXPLORATORY_E5")
        & units.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & units.condition.eq("delay_10s")
    ].to_string(index=False))
    print(f"\nCompleted full-gate batch: {out}")

evaluate_full_gate_batch()

# ===== CELL INPUT 59 =====
from pathlib import Path
from datetime import datetime, timezone
import json

import numpy as np
import pandas as pd

def complete_gate_followup_batch():
    work = Path("/kaggle/working")
    gate_root = work / "FULL_GATE_POST_EXPOSURE_EVALUATION_v1"
    source_path = gate_root / "paired_window_results.csv"
    if not source_path.is_file():
        raise FileNotFoundError(str(source_path))

    frame = pd.read_csv(source_path)
    keys = ["group", "scenario", "condition", "seed", "window"]
    configurations = [
        "COMPETENCE_ONLY", "DRIFT_ONLY", "COMBINED_HARD_GATE"
    ]

    def boolean(series, name):
        converted = series.astype(str).str.lower().map({
            "true": True, "false": False, "1": True, "0": False
        })
        if converted.isna().any():
            raise ValueError(f"Unrecognized boolean values: {name}")
        return converted.astype(bool)

    for column in [
        "clean_abstained", "attack_abstained", "paired_estimate_retained"
    ]:
        frame[column] = boolean(frame[column], column)

    if (
        len(frame) != 2448
        or frame.duplicated(keys + ["configuration"]).any()
        or set(frame.configuration) != set(configurations)
    ):
        raise ValueError("Unexpected full-gate result structure.")

    if not np.allclose(
        frame.clean_accuracy-frame.attack_accuracy,
        frame.true_damage, atol=1e-12, rtol=0
    ):
        raise ValueError("Paired damage values are inconsistent.")

    gate = frame[
        frame.configuration.eq("COMBINED_HARD_GATE")
    ].copy()
    gate["clean_accept"] = ~gate.clean_abstained
    gate["attack_accept"] = ~gate.attack_abstained
    gate["clean_abstain_attack_accept"] = (
        gate.clean_abstained & ~gate.attack_abstained
    )
    gate["clean_accept_attack_abstain"] = (
        ~gate.clean_abstained & gate.attack_abstained
    )
    gate["damage_gt_5pp"] = gate.true_damage > .05

    # Absolute error is defined whenever the ATTACK estimate is available,
    # even if the clean estimate is unavailable.
    gate["accepted_attack_absolute_error"] = np.where(
        gate.attack_accept,
        (gate.attack_estimate-gate.attack_accuracy).abs(),
        np.nan
    )
    gate["accepted_attack_overestimation"] = np.where(
        gate.attack_accept,
        gate.attack_estimate-gate.attack_accuracy,
        np.nan
    )

    reversals = gate.groupby(
        ["group", "scenario", "condition"], as_index=False
    ).agg(
        clean_acceptance=("clean_accept", "mean"),
        attack_acceptance=("attack_accept", "mean"),
        clean_abstain_attack_accept_fraction=(
            "clean_abstain_attack_accept", "mean"
        ),
        clean_accept_attack_abstain_fraction=(
            "clean_accept_attack_abstain", "mean"
        ),
        mean_damage=("true_damage", "mean"),
        accepted_attack_absolute_error=(
            "accepted_attack_absolute_error", "mean"
        ),
        accepted_attack_overestimation=(
            "accepted_attack_overestimation", "mean"
        ),
    )

    # Match identical scenario/seed/window pairs across configurations.
    mask = gate[keys + ["paired_estimate_retained"]].rename(columns={
        "paired_estimate_retained": "hard_gate_pair_retained"
    })
    matched = frame.merge(mask, on=keys, validate="many_to_one")
    matched_rows = matched[matched.hard_gate_pair_retained].copy()

    if not matched_rows.empty:
        if matched_rows.differential_abs_error.isna().any():
            raise ValueError("A retained matched pair has an undefined error.")
        matched_units = matched_rows.groupby(
            ["group", "scenario", "condition", "configuration"], as_index=False
        ).agg(
            matched_pair_error=("differential_abs_error", "mean"),
            retained_seed_window_pairs=("window", "size"),
        )
        matched_summary = matched_units.groupby(
            ["group", "configuration"], as_index=False
        ).agg(
            mean_unit_matched_error=("matched_pair_error", "mean"),
            units_with_retained_pairs=("matched_pair_error", "count"),
            retained_seed_window_pairs=("retained_seed_window_pairs", "sum"),
        )
    else:
        matched_units = pd.DataFrame()
        matched_summary = pd.DataFrame()

    # Gate-aware finite-menu search: select one delay for each scenario/seed,
    # not different delays for different windows.
    adaptive = gate[gate.group.eq("EXPLORATORY_E5")].copy()
    adaptive["accepted_damage_contribution"] = (
        adaptive.true_damage * adaptive.attack_accept.astype(float)
    )
    adaptive["accepted_positive_damage_contribution"] = (
        adaptive.true_damage.clip(lower=0)
        * adaptive.attack_accept.astype(float)
    )
    adaptive["damaging_accepted_window"] = (
        adaptive.damage_gt_5pp & adaptive.attack_accept
    )

    candidates = adaptive.groupby(
        ["scenario", "seed", "condition"], as_index=False
    ).agg(
        mean_actual_damage=("true_damage", "mean"),
        clean_acceptance=("clean_accept", "mean"),
        attack_acceptance=("attack_accept", "mean"),
        acceptance_weighted_damage=("accepted_damage_contribution", "mean"),
        acceptance_weighted_positive_damage=(
            "accepted_positive_damage_contribution", "mean"
        ),
        damaging_accepted_window_fraction=("damaging_accepted_window", "mean"),
        accepted_attack_absolute_error=("accepted_attack_absolute_error", "mean"),
        accepted_attack_overestimation=("accepted_attack_overestimation", "mean"),
    )
    candidates["delay_seconds"] = candidates.condition.str.extract(
        r"^delay_([0-9.]+)s$", expand=False
    ).astype(float)

    if (
        len(candidates) != 30
        or candidates.duplicated(["scenario", "seed", "delay_seconds"]).any()
    ):
        raise ValueError("Expected 30 gate-aware candidate/seed evaluations.")

    # Fixed objective for this explicitly post-exposure analysis:
    # maximize average damage weighted by attack-window acceptance.
    # Tie preference is smaller delay. No model or gate parameter changes.
    selected = (
        candidates.sort_values(
            [
                "scenario", "seed",
                "acceptance_weighted_damage", "delay_seconds"
            ],
            ascending=[True, True, False, True]
        )
        .groupby(["scenario", "seed"], as_index=False)
        .head(1)
        .reset_index(drop=True)
    )

    out = work / (
        "GATE_REVERSALS_MATCHED_COVERAGE_AND_ORACLE_SEARCH_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    gate.to_csv(out / "hard_gate_window_acceptance.csv", index=False)
    reversals.to_csv(out / "acceptance_reversal_summary.csv", index=False)
    matched_units.to_csv(out / "matched_coverage_unit_errors.csv", index=False)
    matched_summary.to_csv(out / "matched_coverage_summary.csv", index=False)
    candidates.to_csv(out / "gate_aware_candidate_objectives.csv", index=False)
    selected.to_csv(out / "gate_aware_selected_delays.csv", index=False)

    receipt = {
        "status": "THREE_GATE_FOLLOWUP_ANALYSES_COMPLETE",
        "analyses": [
            "clean/attack acceptance reversal",
            "identical retained-pair estimator comparison",
            "bounded gate-aware oracle selection over saved real-PCAP candidates"
        ],
        "adaptive_objective": (
            "Mean(window damage * attack-window acceptance indicator)"
        ),
        "candidate_delays_seconds": [0, 0.1, 1, 3, 10],
        "selection_unit": "One delay per scenario and primary-model seed",
        "selection_uses_evaluation_labels": True,
        "post_exposure_analysis": True,
        "new_packet_candidates_generated": False,
        "gate_recalibrated_or_retuned": False,
        "independent_confirmation": False,
        "PCAP_replays": 0,
        "models_retrained": False,
        "files_deleted": 0,
        "original_SVM_MD3_reproduction_complete": False,
        "edge_hardware_measurement_complete": False,
        "all_study_requirements_complete": False,
    }
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2))

    print("\nTEST 1 — CAPTURE 49 10s ACCEPTANCE REVERSAL")
    print(reversals[
        reversals.group.eq("EXPLORATORY_E5")
        & reversals.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & reversals.condition.eq("delay_10s")
    ].to_string(index=False))

    print("\nTEST 2 — IDENTICAL RETAINED-PAIR COMPARISON")
    print(
        matched_summary.to_string(index=False)
        if not matched_summary.empty else "No common retained pairs."
    )
    print("E5 has no paired hard-gate coverage; no paired E5 error is inferred.")

    print("\nTEST 3 — GATE-AWARE ORACLE DELAY SELECTION")
    print(selected.to_string(index=False))
    print(f"\nCompleted three-analysis batch: {out}")

complete_gate_followup_batch()

# ===== CELL INPUT 60 =====
from pathlib import Path
from datetime import datetime, timezone
import json

import numpy as np
import pandas as pd

def complete_gate_followup_batch():
    work = Path("/kaggle/working")
    gate_root = work / "FULL_GATE_POST_EXPOSURE_EVALUATION_v1"
    source_path = gate_root / "paired_window_results.csv"
    if not source_path.is_file():
        raise FileNotFoundError(str(source_path))

    frame = pd.read_csv(source_path)
    keys = ["group", "scenario", "condition", "seed", "window"]
    configurations = [
        "COMPETENCE_ONLY", "DRIFT_ONLY", "COMBINED_HARD_GATE"
    ]

    def boolean(series, name):
        converted = series.astype(str).str.lower().map({
            "true": True, "false": False, "1": True, "0": False
        })
        if converted.isna().any():
            raise ValueError(f"Unrecognized boolean values: {name}")
        return converted.astype(bool)

    for column in [
        "clean_abstained", "attack_abstained", "paired_estimate_retained"
    ]:
        frame[column] = boolean(frame[column], column)

    if (
        len(frame) != 2448
        or frame.duplicated(keys + ["configuration"]).any()
        or set(frame.configuration) != set(configurations)
    ):
        raise ValueError("Unexpected full-gate result structure.")

    if not np.allclose(
        frame.clean_accuracy-frame.attack_accuracy,
        frame.true_damage, atol=1e-12, rtol=0
    ):
        raise ValueError("Paired damage values are inconsistent.")

    gate = frame[
        frame.configuration.eq("COMBINED_HARD_GATE")
    ].copy()
    gate["clean_accept"] = ~gate.clean_abstained
    gate["attack_accept"] = ~gate.attack_abstained
    gate["clean_abstain_attack_accept"] = (
        gate.clean_abstained & ~gate.attack_abstained
    )
    gate["clean_accept_attack_abstain"] = (
        ~gate.clean_abstained & gate.attack_abstained
    )
    gate["damage_gt_5pp"] = gate.true_damage > .05

    # Absolute error is defined whenever the ATTACK estimate is available,
    # even if the clean estimate is unavailable.
    gate["accepted_attack_absolute_error"] = np.where(
        gate.attack_accept,
        (gate.attack_estimate-gate.attack_accuracy).abs(),
        np.nan
    )
    gate["accepted_attack_overestimation"] = np.where(
        gate.attack_accept,
        gate.attack_estimate-gate.attack_accuracy,
        np.nan
    )

    reversals = gate.groupby(
        ["group", "scenario", "condition"], as_index=False
    ).agg(
        clean_acceptance=("clean_accept", "mean"),
        attack_acceptance=("attack_accept", "mean"),
        clean_abstain_attack_accept_fraction=(
            "clean_abstain_attack_accept", "mean"
        ),
        clean_accept_attack_abstain_fraction=(
            "clean_accept_attack_abstain", "mean"
        ),
        mean_damage=("true_damage", "mean"),
        accepted_attack_absolute_error=(
            "accepted_attack_absolute_error", "mean"
        ),
        accepted_attack_overestimation=(
            "accepted_attack_overestimation", "mean"
        ),
    )

    # Match identical scenario/seed/window pairs across configurations.
    mask = gate[keys + ["paired_estimate_retained"]].rename(columns={
        "paired_estimate_retained": "hard_gate_pair_retained"
    })
    matched = frame.merge(mask, on=keys, validate="many_to_one")
    matched_rows = matched[matched.hard_gate_pair_retained].copy()

    if not matched_rows.empty:
        if matched_rows.differential_abs_error.isna().any():
            raise ValueError("A retained matched pair has an undefined error.")
        matched_units = matched_rows.groupby(
            ["group", "scenario", "condition", "configuration"], as_index=False
        ).agg(
            matched_pair_error=("differential_abs_error", "mean"),
            retained_seed_window_pairs=("window", "size"),
        )
        matched_summary = matched_units.groupby(
            ["group", "configuration"], as_index=False
        ).agg(
            mean_unit_matched_error=("matched_pair_error", "mean"),
            units_with_retained_pairs=("matched_pair_error", "count"),
            retained_seed_window_pairs=("retained_seed_window_pairs", "sum"),
        )
    else:
        matched_units = pd.DataFrame()
        matched_summary = pd.DataFrame()

    # Gate-aware finite-menu search: select one delay for each scenario/seed,
    # not different delays for different windows.
    adaptive = gate[gate.group.eq("EXPLORATORY_E5")].copy()
    adaptive["accepted_damage_contribution"] = (
        adaptive.true_damage * adaptive.attack_accept.astype(float)
    )
    adaptive["accepted_positive_damage_contribution"] = (
        adaptive.true_damage.clip(lower=0)
        * adaptive.attack_accept.astype(float)
    )
    adaptive["damaging_accepted_window"] = (
        adaptive.damage_gt_5pp & adaptive.attack_accept
    )

    candidates = adaptive.groupby(
        ["scenario", "seed", "condition"], as_index=False
    ).agg(
        mean_actual_damage=("true_damage", "mean"),
        clean_acceptance=("clean_accept", "mean"),
        attack_acceptance=("attack_accept", "mean"),
        acceptance_weighted_damage=("accepted_damage_contribution", "mean"),
        acceptance_weighted_positive_damage=(
            "accepted_positive_damage_contribution", "mean"
        ),
        damaging_accepted_window_fraction=("damaging_accepted_window", "mean"),
        accepted_attack_absolute_error=("accepted_attack_absolute_error", "mean"),
        accepted_attack_overestimation=("accepted_attack_overestimation", "mean"),
    )
    candidates["delay_seconds"] = candidates.condition.str.extract(
        r"^delay_([0-9.]+)s$", expand=False
    ).astype(float)

    if (
        len(candidates) != 30
        or candidates.duplicated(["scenario", "seed", "delay_seconds"]).any()
    ):
        raise ValueError("Expected 30 gate-aware candidate/seed evaluations.")

    # Fixed objective for this explicitly post-exposure analysis:
    # maximize average damage weighted by attack-window acceptance.
    # Tie preference is smaller delay. No model or gate parameter changes.
    selected = (
        candidates.sort_values(
            [
                "scenario", "seed",
                "acceptance_weighted_damage", "delay_seconds"
            ],
            ascending=[True, True, False, True]
        )
        .groupby(["scenario", "seed"], as_index=False)
        .head(1)
        .reset_index(drop=True)
    )

    out = work / (
        "GATE_REVERSALS_MATCHED_COVERAGE_AND_ORACLE_SEARCH_"
        + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    )
    out.mkdir()
    gate.to_csv(out / "hard_gate_window_acceptance.csv", index=False)
    reversals.to_csv(out / "acceptance_reversal_summary.csv", index=False)
    matched_units.to_csv(out / "matched_coverage_unit_errors.csv", index=False)
    matched_summary.to_csv(out / "matched_coverage_summary.csv", index=False)
    candidates.to_csv(out / "gate_aware_candidate_objectives.csv", index=False)
    selected.to_csv(out / "gate_aware_selected_delays.csv", index=False)

    receipt = {
        "status": "THREE_GATE_FOLLOWUP_ANALYSES_COMPLETE",
        "analyses": [
            "clean/attack acceptance reversal",
            "identical retained-pair estimator comparison",
            "bounded gate-aware oracle selection over saved real-PCAP candidates"
        ],
        "adaptive_objective": (
            "Mean(window damage * attack-window acceptance indicator)"
        ),
        "candidate_delays_seconds": [0, 0.1, 1, 3, 10],
        "selection_unit": "One delay per scenario and primary-model seed",
        "selection_uses_evaluation_labels": True,
        "post_exposure_analysis": True,
        "new_packet_candidates_generated": False,
        "gate_recalibrated_or_retuned": False,
        "independent_confirmation": False,
        "PCAP_replays": 0,
        "models_retrained": False,
        "files_deleted": 0,
        "original_SVM_MD3_reproduction_complete": False,
        "edge_hardware_measurement_complete": False,
        "all_study_requirements_complete": False,
    }
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2))

    print("\nTEST 1 — CAPTURE 49 10s ACCEPTANCE REVERSAL")
    print(reversals[
        reversals.group.eq("EXPLORATORY_E5")
        & reversals.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & reversals.condition.eq("delay_10s")
    ].to_string(index=False))

    print("\nTEST 2 — IDENTICAL RETAINED-PAIR COMPARISON")
    print(
        matched_summary.to_string(index=False)
        if not matched_summary.empty else "No common retained pairs."
    )
    print("E5 has no paired hard-gate coverage; no paired E5 error is inferred.")

    print("\nTEST 3 — GATE-AWARE ORACLE DELAY SELECTION")
    print(selected.to_string(index=False))
    print(f"\nCompleted three-analysis batch: {out}")

complete_gate_followup_batch()

# ===== CELL INPUT 61 =====
from pathlib import Path
from datetime import datetime, timezone
import importlib.metadata
import json
import time
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
from menelaus.concept_drift.md3 import MD3
from threadpoolctl import threadpool_limits

def complete_svm_margin_md3_batch():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    source_path = (
        backup / "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z"
        / "source_reference_sample.csv"
    )
    corrected = work / "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1"
    e5 = work / "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1"
    out = work / "MD3_LINEAR_SVM_WARNING_BASELINE_v1"
    out.mkdir(exist_ok=True)

    targets = [
        f"CTU-IoT-Malware-Capture-{n}-1"
        for n in [7, 9, 33, 36, 39, 43, 48, 49]
    ]
    F = [
        "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts",
        "orig_ip_bytes", "resp_ip_bytes", "missed_bytes", "proto"
    ]
    policy = {
        "baseline": "Linear-SVM-margin Menelaus MD3 warning stage",
        "source_split_seed": 64201,
        "source_reference_fraction": 0.8,
        "source_holdout_fraction": 0.2,
        "stratification": "source scenario and binary label",
        "SVM": {
            "C": 1.0,
            "dual": "auto",
            "max_iter": 20000,
            "random_state": 64401
        },
        "preprocessing": "log1p numeric fields, protocol one-hot, StandardScaler",
        "margin_inclusion": "abs(SVM decision_function(x)) <= 1",
        "MD3_sensitivity": 2,
        "MD3_reference_folds": 10,
        "oracle_confirmation": "not run; stop at first warning",
        "deployed_primary_models_retrained": False,
        "post_exposure_baseline": True,
        "original_paper_exact_hyperparameter_replication": False,
        "reference_overlap_with_primary_training_excluded": False,
        "source_holdout_disjoint_from_this_SVM_reference": True,
    }

    policy_path = out / "baseline_policy.json"
    if policy_path.is_file():
        if json.loads(policy_path.read_text()) != policy:
            raise ValueError("Existing baseline policy differs; refusing overwrite.")
    else:
        policy_path.write_text(json.dumps(policy, indent=2))

    complete_path = out / "completion_receipt.json"
    if complete_path.is_file():
        print("SVM-margin MD3 batch already complete; not retraining.")
        print(pd.read_csv(out / "warning_summary.csv").to_string(index=False))
        return

    def read_frame(path):
        with open(path, "rb") as handle:
            compressed = handle.read(2) == b"\x1f\x8b"
        frame = pd.read_csv(
            path, compression="gzip" if compressed else None,
            dtype={"ks": str}
        )
        missing = set(F + ["ks", "y"]) - set(frame.columns)
        if missing:
            raise ValueError(f"Missing columns in {path}: {sorted(missing)}")
        frame["ks"] = frame.ks.astype(str)
        frame["y"] = pd.to_numeric(frame.y, errors="raise").astype(int)
        frame["proto"] = frame.proto.astype(str).str.lower()
        for c in F:
            if c != "proto":
                frame[c] = pd.to_numeric(
                    frame[c].replace("-", np.nan), errors="coerce"
                ).fillna(0).clip(lower=0)
        if frame.ks.duplicated().any() or not frame.y.isin([0, 1]).all():
            raise ValueError(f"Invalid sample membership: {path}")
        return frame

    def matrix(frame):
        numeric = [c for c in F if c != "proto"]
        return pd.DataFrame(
            np.hstack([
                np.log1p(frame[numeric].to_numpy(float)),
                np.column_stack([
                    frame.proto.eq(p).to_numpy(float)
                    for p in ["tcp", "udp", "icmp"]
                ])
            ]),
            columns=numeric + ["proto_tcp", "proto_udp", "proto_icmp"]
        )

    # Menelaus expects a function with detector, sample, classifier arguments.
    # Use the standard SVM decision-function margin, not its supplied
    # coef_/intercept implementation and not a probability band.
    def svm_margin(detector, sample, classifier):
        sample_frame = pd.DataFrame(
            [sample], columns=detector.reference_batch_features.columns
        )
        score = float(classifier.decision_function(sample_frame)[0])
        return int(abs(score) <= 1.0)

    source = read_frame(source_path)
    if len(source) != 12288 or "source_scenario" not in source.columns:
        raise ValueError("Unexpected source-reference structure.")

    strata = source.source_scenario.astype(str) + "|" + source.y.astype(str)
    reference_indices, holdout_indices = train_test_split(
        np.arange(len(source)),
        test_size=0.2,
        random_state=64201,
        stratify=strata
    )
    reference = source.iloc[reference_indices].reset_index(drop=True)
    holdout = source.iloc[holdout_indices].reset_index(drop=True)
    if set(reference.ks) & set(holdout.ks):
        raise ValueError("SVM reference/source-holdout keys overlap.")

    X_reference = matrix(reference)
    X_holdout = matrix(holdout)
    classifier = Pipeline([
        ("scale", StandardScaler()),
        ("svm", LinearSVC(
            C=1.0, dual="auto", max_iter=20000, random_state=64401
        )),
    ])

    print("Training the separate source-only SVM baseline...", flush=True)
    with threadpool_limits(limits=2), warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        classifier.fit(X_reference, reference.y.to_numpy())
        detector = MD3(
            classifier,
            margin_calculation_function=svm_margin,
            sensitivity=2,
            k=10
        )
        reference_batch = X_reference.copy()
        reference_batch["target"] = reference.y.to_numpy()
        print("Calibrating MD3 with ten source-only CV folds...", flush=True)
        detector.set_reference(reference_batch, target_name="target")
        if any(issubclass(w.category, ConvergenceWarning) for w in caught):
            raise RuntimeError(
                "An SVM fit did not converge under the fixed settings. "
                "No target evaluation has been accepted."
            )

    joblib.dump(classifier, out / "source_only_linear_svm.joblib", compress=3)
    reference_statistics = {
        k: float(v) for k, v in detector.reference_distribution.items()
    }
    (out / "reference_statistics.json").write_text(
        json.dumps(reference_statistics, indent=2)
    )
    pd.DataFrame({
        "ks": reference.ks,
        "allocation": "SVM_MD3_reference"
    }).to_csv(out / "reference_membership.csv", index=False)
    pd.DataFrame({
        "ks": holdout.ks,
        "allocation": "source_holdout"
    }).to_csv(out / "source_holdout_membership.csv", index=False)

    def warning_recurrence(scores):
        signals = np.abs(scores) <= 1.0
        density = float(detector.reference_distribution["md"])
        mean = density
        threshold = (
            detector.sensitivity * float(detector.reference_distribution["md_std"])
        )
        forgetting = float(detector.forgetting_factor)
        first = None
        consumed = 0
        maximum_deviation = 0.0
        for index, signal in enumerate(signals):
            density = forgetting*density + (1-forgetting)*int(signal)
            deviation = abs(density-mean)
            maximum_deviation = max(maximum_deviation, deviation)
            consumed = index+1
            if deviation > threshold:
                first = index+1
                break
        return {
            "warning": first is not None,
            "first_warning_row": first,
            "rows_consumed": consumed,
            "terminal_margin_density": density,
            "maximum_density_deviation": maximum_deviation,
            "warning_threshold": threshold,
            "whole_stream_margin_density": float(signals.mean()),
        }

    with threadpool_limits(limits=2):
        holdout_scores = classifier.decision_function(X_holdout)
        expected = warning_recurrence(holdout_scores)

        # Verify accelerated recurrence against the actual library update.
        first_library_warning = None
        for index in range(len(X_holdout)):
            detector.update(X_holdout.iloc[[index]])
            if detector.waiting_for_oracle:
                first_library_warning = index+1
                break
        if first_library_warning != expected["first_warning_row"]:
            raise ValueError("Warning recurrence differs from installed MD3.")
        if not np.isclose(
            detector.curr_margin_density,
            expected["terminal_margin_density"],
            atol=1e-12, rtol=0
        ):
            raise ValueError("Margin-density recurrence verification failed.")

    source_result = {
        "group": "SOURCE_HOLDOUT",
        "scenario": "SOURCE_ONLY",
        "condition": "heldout_source_stream",
        "state": "source_holdout",
        "rows": len(holdout),
        "SVM_accuracy": float(
            (classifier.predict(X_holdout) == holdout.y.to_numpy()).mean()
        ),
        **expected,
    }

    def find_clean(scenario):
        matches = [
            p for p in backup.rglob("frozen_clean_target_sample.csv*")
            if scenario in str(p)
            and "TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1" in str(p)
        ]
        if not matches:
            raise FileNotFoundError(f"Clean sample unavailable: {scenario}")
        return min(matches, key=lambda p: (len(p.parts), str(p)))

    def pacing_features(scenario):
        for root in [work, backup]:
            job = root / "E4_COMPACT_PACING_v1" / scenario
            receipt_path = job / "receipt.json"
            paths = sorted(job.glob("attacked_selected_features.csv*"))
            if receipt_path.is_file() and len(paths) == 1:
                receipt = json.loads(receipt_path.read_text())
                if receipt.get("status") == "PACING_JOB_COMPLETE":
                    return paths[0]
        raise FileNotFoundError(f"Pacing features unavailable: {scenario}")

    conditions = []
    for scenario in targets:
        clean = read_frame(find_clean(scenario))
        for condition in ["INJ_k1", "INJ_k3", "PACE_1s"]:
            path = (
                pacing_features(scenario) if condition == "PACE_1s"
                else corrected/scenario/condition/"attacked_selected_features.csv"
            )
            conditions.append((
                "CORRECTED_E4", scenario, condition, clean, read_frame(path)
            ))

    for scenario in [
        "CTU-IoT-Malware-Capture-48-1",
        "CTU-IoT-Malware-Capture-49-1"
    ]:
        clean = read_frame(e5/scenario/"delay_0s/candidate_selected_features.csv")
        for delay in [0.0, 0.1, 1.0, 3.0, 10.0]:
            path = e5/scenario/f"delay_{delay:g}s"/"candidate_selected_features.csv"
            conditions.append((
                "EXPLORATORY_E5", scenario, f"delay_{delay:g}s",
                clean, read_frame(path)
            ))

    rows = []
    with threadpool_limits(limits=2):
        for group, scenario, condition, clean, attacked in conditions:
            if len(clean) != 1024 or set(clean.ks) != set(attacked.ks):
                raise ValueError("Invalid paired target membership.")
            attacked = attacked.set_index("ks").loc[clean.ks].reset_index()
            if not np.array_equal(clean.y, attacked.y):
                raise ValueError("Paired labels differ.")

            for state, frame in [("clean", clean), ("attack", attacked)]:
                X = matrix(frame)
                scores = classifier.decision_function(X)
                rows.append({
                    "group": group, "scenario": scenario,
                    "condition": condition, "state": state,
                    "rows": len(frame),
                    "SVM_accuracy": float(
                        (classifier.predict(X) == frame.y.to_numpy()).mean()
                    ),
                    **warning_recurrence(scores),
                })
            print(f"SVM MD3 evaluated: {scenario}/{condition}", flush=True)

    results = pd.DataFrame(rows)
    if len(results) != 68:
        raise ValueError("Expected 68 clean/attack stream evaluations.")
    summary = results.groupby(["group", "state"], as_index=False).agg(
        stream_warning_fraction=("warning", "mean"),
        streams=("warning", "size"),
        mean_SVM_accuracy=("SVM_accuracy", "mean"),
    )
    results.to_csv(out / "target_stream_results.csv", index=False)
    pd.DataFrame([source_result]).to_csv(
        out / "source_holdout_result.csv", index=False
    )
    summary.to_csv(out / "warning_summary.csv", index=False)

    pair = results.pivot(
        index=["group", "scenario", "condition"],
        columns="state", values="warning"
    ).reset_index()
    pair["attack_only_warning"] = pair.attack & ~pair.clean
    pair["clean_only_warning"] = pair.clean & ~pair.attack
    pair.to_csv(out / "paired_warning_changes.csv", index=False)

    (out / "completion_receipt.json").write_text(json.dumps({
        "status": "LINEAR_SVM_MARGIN_MD3_WARNING_BATCH_COMPLETE",
        "menelaus_version": importlib.metadata.version("menelaus"),
        "reference_rows": len(reference),
        "source_holdout_rows": len(holdout),
        "paired_target_conditions": 34,
        "target_stream_evaluations": 68,
        "separate_SVM_baseline_trained": True,
        "source_only_CV_clone_fitting": True,
        "deployed_primary_models_retrained": False,
        "actual_SVM_margin_used": True,
        "library_warning_recurrence_verified": True,
        "oracle_confirmation_executed": False,
        "original_paper_exact_hyperparameters_reproduced": False,
        "post_exposure_baseline": True,
        "reference_training_overlap_with_primary_possible": True,
        "PCAP_replays": 0,
        "files_deleted": 0,
    }, indent=2))

    print("\nEVALUATION 1 — HELD-OUT SOURCE STREAM")
    print(pd.DataFrame([source_result]).to_string(index=False))
    print("\nEVALUATIONS 2 AND 3 — E4 / E5 WARNING SUMMARY")
    print(summary.to_string(index=False))
    print("\nCAPTURE 49, 10s — SVM-MARGIN MD3")
    print(results[
        results.group.eq("EXPLORATORY_E5")
        & results.scenario.eq("CTU-IoT-Malware-Capture-49-1")
        & results.condition.eq("delay_10s")
    ].to_string(index=False))
    print(f"\nCompleted baseline batch: {out}")

complete_svm_margin_md3_batch()

# ===== CELL INPUT 62 =====
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile

def freeze_current_study_evidence():
    work = Path("/kaggle/working")
    backup = Path(
        "/kaggle/input/datasets/mdhamidborkottulla/full-backup/"
        "COMPLETE_RESEARCH_BACKUP_20261012T215527424389Z"
    )
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    package = work / f"STUDY_EVIDENCE_AND_CODE_FREEZE_{stamp}.zip"
    checksum = package.with_suffix(".zip.sha256")
    receipt_path = work / f"STUDY_EVIDENCE_FREEZE_{stamp}_receipt.json"

    exact_folders = [
        "E4_PROTOCOL_ELIGIBLE_INJECTIONS_v1",
        "E5_EXPLORATORY_REAL_PCAP_PACING_SEARCH_v1",
        "MD3_PROBABILITY_MARGIN_WARNING_EVALUATION_v1",
        "MD3_LINEAR_SVM_WARNING_BASELINE_v1",
        "FULL_GATE_POST_EXPOSURE_EVALUATION_v1",
    ]
    latest_patterns = [
        "E4_PACING_COMPLETE_*",
        "E4_PACING_ESTIMATOR_PANEL_*",
        "E4_COMPLETION_AND_PACING_STATISTICS_*",
        "E4_THREE_TREATMENT_COMPACT_ANALYSIS_*",
        "E6_AC_AGREE_PIPELINE_RESOURCES_*",
        "E4_WRITTEN_PROTOCOL_ELIGIBILITY_AUDIT_*",
        "AGREEMENT_DEFINITION_RECONCILIATION_*",
        "E5_PREPARATION_VERIFIED_MENU_FRONTIERS_*",
        "E5_PACKET_SEARCH_VALIDATION_*",
        "E5_CAPTURE49_FRAGMENT_DIAGNOSTIC_*",
        "GATE_REVERSALS_MATCHED_COVERAGE_AND_ORACLE_SEARCH_*",
    ]
    source_folders = [
        "TRACE_CONFIRMATORY_PROTOCOL_v1",
        "TRACE_CONFIRMATORY_PROTOCOL_v1_1_ESTIMATOR_AMENDMENT",
        "TRACE_CONFIRMATORY_SOURCE_CALIBRATION_20261012T175838844123Z",
        "TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1",
    ]
    allowed_extensions = {
        ".csv", ".gz", ".json", ".jsonl", ".md", ".txt",
        ".py", ".npz", ".joblib", ".yaml", ".yml"
    }
    maximum_payload = 256 * 1024**2

    selected_folders = []
    missing_optional = []

    for name in exact_folders:
        path = work / name
        if not path.is_dir():
            raise FileNotFoundError(f"Required completed result folder: {path}")
        selected_folders.append((path, f"results/{name}"))

    for pattern in latest_patterns:
        matches = [p for p in work.glob(pattern) if p.is_dir()]
        if matches:
            path = max(matches, key=lambda p: p.stat().st_mtime_ns)
            selected_folders.append((path, f"results/{path.name}"))
        else:
            missing_optional.append(pattern)

    for name in source_folders:
        path = backup / name
        if path.is_dir():
            selected_folders.append((path, f"frozen_sources/{name}"))
        else:
            missing_optional.append(name)

    files, excluded = [], []
    for folder, prefix in selected_folders:
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            relative = path.relative_to(folder).as_posix()
            if (
                path.suffix.lower() not in allowed_extensions
                or path.name.lower().endswith(
                    (".pcap", ".pcapng", ".cap", ".log", ".sqlite")
                )
                or path.name in {"zeek_stdout.txt", "zeek_stderr.txt"}
            ):
                excluded.append(str(path))
                continue
            files.append((path, f"{prefix}/{relative}"))

    for name in [
        "run_frozen_trace_confirmation_v1_1.py",
        "run_streaming_confirmatory_batch_A_v1_2_fixed.py",
    ]:
        path = backup / name
        if path.is_file():
            files.append((path, f"frozen_sources/scripts/{name}"))
        else:
            missing_optional.append(name)

    payload = sum(path.stat().st_size for path, _ in files)
    if payload > maximum_payload:
        raise RuntimeError(
            f"Selected payload is {payload/1024**2:.2f} MiB, "
            "above the 256 MiB limit. Nothing deleted."
        )
    if shutil.disk_usage(work).free < payload + 128*1024**2:
        raise RuntimeError("Insufficient reserve for the evidence package.")

    status = {
        "completed_scopes": [
            "Eligibility-corrected E4 semantic-view AC/AGREE panel",
            "Eight-scenario three-treatment sign-flip/Holm analysis",
            "AC/AGREE preprocessing-inclusive Kaggle CPU timings",
            "Two-target bounded post-exposure real-PCAP pacing search",
            "Candidate numerical and feature-change validation",
            "Capture49 endpoint/time-associated fragmentation diagnostic",
            "Probability-margin MD3 warning adaptation",
            "Linear-SVM-margin MD3 warning baseline",
            "Post-exposure full-gate evaluation and ablations",
            "Post-exposure full-gate CPU timing",
            "Finite-menu gate-aware oracle selection",
        ],
        "unresolved_or_unclaimed": [
            "Exact original-paper MD3 hyperparameter replication",
            "MD3 oracle-confirmed drift",
            "Broad or independently confirmed adaptive robustness",
            "Definitive packet-level fragment lineage",
            "Application-semantic attack validity",
            "Source-reference disjointness from deployed-model training",
            "Actual edge-device or energy measurement",
            "Final agreement-definition and protocol chronology reconciliation",
            "Submission-ready theory/manuscript/repository",
        ],
        "scope_rule": (
            "Completed scoped computations do not imply that every "
            "original research-plan requirement has been met."
        ),
        "all_original_requirements_complete": False,
    }

    report = """# Current study evidence: interpretation constraints

- Preserve original compact injection results separately from the
  eligibility-corrected panel.
- No corrected primary AGREE-benefit test survived Holm correction.
- The bounded 10-second Capture49 candidate reduced the frozen primary
  detectors' original-start-key accuracy by 0.5.
- Associated Zeek fragments reconciled original packet and IP-byte counters;
  this is not duration-only evasion or definitive packet-level lineage.
- Gate clean abstention prevents paired E5 differential-error evaluation.
- Attack acceptance does not by itself imply falsely high estimated accuracy.
- Matched retained E4 pairs show no advantage over the two ablations.
- Report MD3 warning adaptations, classifiers, source allocation, and lack
  of oracle confirmation explicitly.
- Report Kaggle CPU timing with its batch size and excluded components.
- Post-exposure implementations and searches are exploratory.
- Do not claim universal robustness, edge-hardware performance, or
  independent confirmation.

This package preserves evidence; it is not a declaration of study completion.
"""

    # Preserve executed source cells from the current runtime, without running
    # any code. This includes the implementation definitions used in this session.
    try:
        history = get_ipython().history_manager.input_hist_raw
        executed_source = "\n\n".join(
            f"# ===== SESSION INPUT {i} =====\n{cell}"
            for i, cell in enumerate(history)
            if cell.strip()
        )
    except Exception:
        executed_source = (
            "# Notebook session history unavailable. "
            "Save the executed .ipynb separately.\n"
        )

    history_bytes = executed_source.encode("utf-8")
    if payload + len(history_bytes) > maximum_payload:
        raise RuntimeError("Evidence plus session source exceeds package size limit.")

    manifest = []
    with zipfile.ZipFile(
        package, "x", compression=zipfile.ZIP_DEFLATED,
        compresslevel=6, allowZip64=True
    ) as archive:
        for path, name in files:
            content = path.read_bytes()
            archive.writestr(name, content)
            manifest.append({
                "archive_path": name,
                "source_path": str(path),
                "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            })

        archive.writestr(
            "reproducibility/current_session_inputs.py", history_bytes
        )
        archive.writestr(
            "STUDY_STATUS.json", json.dumps(status, indent=2)
        )
        archive.writestr("INTERPRETATION_CONSTRAINTS.md", report)
        archive.writestr("MANIFEST.json", json.dumps({
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "files": manifest,
            "missing_optional_items": missing_optional,
            "excluded_large_or_temporary_files": excluded,
            "session_source_sha256": hashlib.sha256(history_bytes).hexdigest(),
            "raw_inputs_remain_in_attached_Kaggle_datasets": True,
        }, indent=2))

    with zipfile.ZipFile(package, "r") as archive:
        bad_member = archive.testzip()
        if bad_member is not None:
            raise RuntimeError(f"ZIP integrity failure: {bad_member}")

    digest = hashlib.sha256()
    with open(package, "rb") as handle:
        for block in iter(lambda: handle.read(8*1024**2), b""):
            digest.update(block)
    archive_hash = digest.hexdigest()
    checksum.write_text(f"{archive_hash}  {package.name}\n")

    receipt = {
        "status": "CURRENT_STUDY_EVIDENCE_PACKAGE_VERIFIED",
        "package": package.name,
        "size_MiB": round(package.stat().st_size/1024**2, 3),
        "sha256": archive_hash,
        "archived_artifact_files": len(manifest),
        "session_execution_source_included": True,
        "missing_optional_items": missing_optional,
        "experiments_rerun": 0,
        "files_deleted": 0,
        "all_original_requirements_complete": False,
    }
    receipt_path.write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt, indent=2))
    print("\nSave the executed Kaggle notebook alongside this ZIP.")
    print("No new experiment was run.")

freeze_current_study_evidence()

# ===== CELL INPUT 63 =====
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import hashlib
import json
import os
import re
import shutil
import zipfile

from IPython.display import display, FileLink

def create_today_delta_backup():
    work = Path("/kaggle/working").resolve()
    input_roots = [
        Path("/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/last-day-backup"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/complete-backup"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/full-backup"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/one-last"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/ran-files"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/the-last-update"),
        Path("/kaggle/input/datasets/mdhamidborkottulla/whole-in-one"),
    ]

    missing_roots = [str(p) for p in input_roots if not p.is_dir()]
    if missing_roots:
        raise RuntimeError(
            "Verification cannot cover all eight backups because these "
            "datasets are not mounted:\n" + "\n".join(missing_roots)
        )

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    archive_path = work / f"TODAY_NEW_AND_CHANGED_OUTPUTS_{stamp}.zip"
    partial_path = work / f"TODAY_NEW_AND_CHANGED_OUTPUTS_{stamp}.zip.partial"
    checksum_path = work / f"TODAY_NEW_AND_CHANGED_OUTPUTS_{stamp}.zip.sha256"
    receipt_path = work / f"TODAY_NEW_AND_CHANGED_OUTPUTS_{stamp}_receipt.json"
    metadata_prefix = f"__DELTA_BACKUP_METADATA_{stamp}"

    excluded_dirs = {"__pycache__", ".ipynb_checkpoints", ".virtual_documents"}
    generated_paths = {
        archive_path, partial_path, checksum_path, receipt_path
    }

    def hash_file(path):
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024**2), b""):
                h.update(block)
        return h.hexdigest()

    def archive_container(path):
        lower = path.name.lower()
        return (
            lower.endswith((".zip", ".zip.partial", ".tar", ".tgz",
                            ".tar.gz", ".tar.bz2", ".tar.xz"))
            or re.search(r"\.z[0-9]{2,}$", lower) is not None
        )

    # Index existing uploaded regular files by size.
    # Reading uploaded backups does not consume working-directory disk space.
    baseline_by_size = defaultdict(list)
    root_counts = {}
    baseline_symlinks = defaultdict(list)

    print("INDEXING ALL EIGHT EXISTING BACKUPS...", flush=True)
    for root in input_roots:
        count = 0
        for current, dirs, names in os.walk(root, followlinks=False):
            current = Path(current)

            for dirname in list(dirs):
                path = current / dirname
                if path.is_symlink():
                    baseline_symlinks[os.readlink(path)].append(str(path))
                    dirs.remove(dirname)

            for name in names:
                path = current / name
                if path.is_symlink():
                    baseline_symlinks[os.readlink(path)].append(str(path))
                    continue
                if path.is_file():
                    baseline_by_size[path.stat().st_size].append(path)
                    count += 1

        root_counts[str(root)] = count
        print(f"{count:,} files indexed: {root.name}", flush=True)

    # Snapshot the working file list before generating backup metadata.
    working_files = []
    working_symlinks = []
    excluded = []

    for current, dirs, names in os.walk(work, followlinks=False):
        current = Path(current)

        for dirname in list(dirs):
            path = current / dirname
            if dirname in excluded_dirs:
                excluded.append({
                    "path": path.relative_to(work).as_posix(),
                    "reason": "transient_notebook_or_python_directory"
                })
                dirs.remove(dirname)
            elif path.is_symlink():
                working_symlinks.append(path)
                dirs.remove(dirname)

        for name in names:
            path = current / name
            if path in generated_paths:
                continue
            if archive_container(path):
                excluded.append({
                    "path": path.relative_to(work).as_posix(),
                    "reason": "existing_archive_container_not_nested_in_delta"
                })
            elif path.is_symlink():
                working_symlinks.append(path)
            elif path.is_file():
                working_files.append(path)

    working_files.sort(key=lambda p: p.relative_to(work).as_posix())
    selected = []
    already_backed_up = []
    baseline_hash_cache = {}

    print("\nVERIFYING WORKING FILES AGAINST EXISTING BACKUPS...", flush=True)

    for index, path in enumerate(working_files, start=1):
        before = path.stat()
        digest = hash_file(path)
        after = path.stat()
        if (
            before.st_size != after.st_size
            or before.st_mtime_ns != after.st_mtime_ns
        ):
            raise RuntimeError(
                f"File changed during verification: {path}. "
                "Stop other writing cells before rerunning."
            )

        candidates = baseline_by_size.get(after.st_size, [])
        # Same-name candidates are tried first, but a renamed identical file
        # also counts as already backed up.
        candidates = sorted(
            candidates,
            key=lambda p: (p.name != path.name, len(p.parts), str(p))
        )

        identical_source = None
        for candidate in candidates:
            cache_key = str(candidate)
            if cache_key not in baseline_hash_cache:
                baseline_hash_cache[cache_key] = hash_file(candidate)
            if baseline_hash_cache[cache_key] == digest:
                identical_source = candidate
                break

        record = {
            "path": path.relative_to(work).as_posix(),
            "bytes": after.st_size,
            "sha256": digest,
            "mtime_ns_at_verification": after.st_mtime_ns,
        }
        if identical_source is not None:
            record["existing_backup_copy"] = str(identical_source)
            already_backed_up.append(record)
        else:
            record["source_path"] = str(path)
            selected.append(record)

        if index % 250 == 0 or index == len(working_files):
            print(
                f"Verified {index:,}/{len(working_files):,}; "
                f"new/changed={len(selected):,}; "
                f"already backed up={len(already_backed_up):,}",
                flush=True
            )

    new_symlinks = []
    for path in working_symlinks:
        target = os.readlink(path)
        record = {
            "path": path.relative_to(work).as_posix(),
            "target": target,
        }
        if target in baseline_symlinks:
            excluded.append({
                **record,
                "reason": "same_symlink_target_present_in_uploaded_backup",
                "existing_backup_copy": baseline_symlinks[target][0]
            })
        else:
            new_symlinks.append(record)

    # Record this runtime's execution source without executing any of it.
    try:
        history = get_ipython().history_manager.input_hist_raw
        session_source = "\n\n".join(
            f"# ===== CELL INPUT {i} =====\n{cell}"
            for i, cell in enumerate(history)
            if cell.strip()
        )
        history_available = True
    except Exception:
        session_source = (
            "# Runtime input history unavailable; save the .ipynb separately.\n"
        )
        history_available = False

    session_bytes = session_source.encode("utf-8")
    payload_bytes = sum(r["bytes"] for r in selected)

    manifest = {
        "backup_type": "new_or_changed_files_relative_to_uploaded_backups",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "working_directory": str(work),
        "baseline_roots": root_counts,
        "included_regular_files": selected,
        "already_backed_up_regular_files": already_backed_up,
        "new_symlinks": new_symlinks,
        "excluded_items": excluded,
        "session_history_available": history_available,
        "session_source_sha256": hashlib.sha256(session_bytes).hexdigest(),
        "selection_rule": "No byte-identical size/SHA256 match in any mounted baseline",
        "date_filter_used": False,
    }
    manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")

    readme_bytes = (
        "INCREMENTAL RESEARCH BACKUP\n\n"
        "Restore your existing baseline backups first, then overlay the regular\n"
        "files from this ZIP onto /kaggle/working.\n"
        "The manifest identifies omitted files and their existing backup copies.\n"
        "No raw dataset under /kaggle/input is copied into this ZIP unless a\n"
        "new/changed working-directory file has no identical baseline copy.\n"
        "Existing archive containers are intentionally not nested.\n"
        "New symlinks are described in new_symlinks.json, not followed.\n"
        "Save the executed Kaggle .ipynb separately: cell-source history is not\n"
        "a complete notebook with outputs and metadata.\n"
        "A backup does not establish that all original study requirements are met.\n"
    ).encode("utf-8")

    estimated_bytes = (
        payload_bytes + len(session_bytes) + len(manifest_bytes)
        + 4096 * (len(selected) + 10)
    )
    required_free = int(estimated_bytes * 1.03) + 128 * 1024**2
    free_bytes = shutil.disk_usage(work).free

    print("\nBACKUP PLAN")
    print(f"New/changed files:  {len(selected):,}")
    print(f"Previously backed up files skipped: {len(already_backed_up):,}")
    print(f"New/changed file data: {payload_bytes / 1024**2:.2f} MiB")
    print(f"Free working disk: {free_bytes / 1024**3:.3f} GiB")

    if free_bytes < required_free:
        raise RuntimeError(
            "Insufficient safe space for the delta ZIP. "
            "No research files were deleted."
        )

    expected_members = {}
    try:
        with zipfile.ZipFile(
            partial_path, "x",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
            allowZip64=True
        ) as archive:
            for index, record in enumerate(selected, start=1):
                path = Path(record["source_path"])
                before = path.stat()
                if (
                    before.st_size != record["bytes"]
                    or before.st_mtime_ns != record["mtime_ns_at_verification"]
                ):
                    raise RuntimeError(f"File changed before archiving: {path}")

                digest = hashlib.sha256()
                written = 0
                with open(path, "rb") as source, archive.open(
                    record["path"], "w", force_zip64=True
                ) as target:
                    for block in iter(lambda: source.read(8 * 1024**2), b""):
                        target.write(block)
                        digest.update(block)
                        written += len(block)

                after = path.stat()
                if (
                    written != record["bytes"]
                    or digest.hexdigest() != record["sha256"]
                    or before.st_size != after.st_size
                    or before.st_mtime_ns != after.st_mtime_ns
                ):
                    raise RuntimeError(f"File changed during archiving: {path}")

                expected_members[record["path"]] = record["sha256"]
                if index % 100 == 0 or index == len(selected):
                    print(f"Archived {index:,}/{len(selected):,}", flush=True)

            metadata = {
                f"{metadata_prefix}/manifest.json": manifest_bytes,
                f"{metadata_prefix}/current_session_inputs.py": session_bytes,
                f"{metadata_prefix}/README.txt": readme_bytes,
                f"{metadata_prefix}/new_symlinks.json": json.dumps(
                    new_symlinks, indent=2
                ).encode("utf-8"),
            }
            for name, content in metadata.items():
                archive.writestr(name, content)
                expected_members[name] = hashlib.sha256(content).hexdigest()

        print("\nVERIFYING EVERY ZIP MEMBER...", flush=True)
        with zipfile.ZipFile(partial_path, "r") as archive:
            if set(archive.namelist()) != set(expected_members):
                raise RuntimeError("ZIP member list differs from expected manifest.")
            for name, expected_hash in expected_members.items():
                digest = hashlib.sha256()
                with archive.open(name, "r") as handle:
                    for block in iter(lambda: handle.read(8 * 1024**2), b""):
                        digest.update(block)
                if digest.hexdigest() != expected_hash:
                    raise RuntimeError(f"Archived SHA256 mismatch: {name}")

        partial_path.replace(archive_path)

    except Exception:
        # Remove only this cell's incomplete temporary archive.
        if partial_path.exists():
            partial_path.unlink()
        raise

    archive_hash = hash_file(archive_path)
    checksum_path.write_text(f"{archive_hash}  {archive_path.name}\n")
    receipt = {
        "status": "DELTA_BACKUP_COMPLETE_AND_SHA256_VERIFIED",
        "archive": archive_path.name,
        "archive_size_MiB": round(archive_path.stat().st_size / 1024**2, 3),
        "archive_sha256": archive_hash,
        "new_or_changed_regular_files_included": len(selected),
        "byte_identical_prior_files_skipped": len(already_backed_up),
        "baseline_datasets_verified": len(input_roots),
        "session_source_included": history_available,
        "research_files_deleted": 0,
        "restore_requires_existing_baseline_backups": True,
    }
    receipt_path.write_text(json.dumps(receipt, indent=2))

    print("\nBACKUP READY")
    print(json.dumps(receipt, indent=2))

    # Kaggle serves files beneath /kaggle/working at /files/.
    # Filenames are generated locally; no external download URL is invented.
    display(FileLink(
        archive_path.name, url_prefix="/files/",
        result_html_prefix="Download new/changed outputs ZIP: "
    ))
    display(FileLink(
        checksum_path.name, url_prefix="/files/",
        result_html_prefix="Download ZIP checksum: "
    ))
    display(FileLink(
        receipt_path.name, url_prefix="/files/",
        result_html_prefix="Download verification receipt: "
    ))

create_today_delta_backup()