# Original machine-generated results

Upload small original experimental CSV/JSON files here without modifying their values or filenames. Include generating code/configuration identities and SHA-256 hashes. No original files are manufactured from rounded manuscript values. Large per-unit, prediction or packet artifacts belong in the external archive with manifest links.
