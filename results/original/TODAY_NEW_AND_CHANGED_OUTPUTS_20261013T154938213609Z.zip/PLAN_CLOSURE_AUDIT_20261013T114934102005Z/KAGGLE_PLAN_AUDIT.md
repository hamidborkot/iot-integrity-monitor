# Kaggle A–G plan closure: evidence audit

This is an evidence-content workbench, not scientific approval. Completed development must not be rerun blindly. Missing filename matches may indicate naming differences or uninspected containers.

## Relevant remaining gates

- A1 — Development freeze/reproduction: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Preserve frozen development; no blanket retraining.
- A2 — Final prospective six-test protocol and results: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Choose original CIC primary family versus IoT-23 amendment explicitly; prove outcome chronology and sampling units.
- B1 — Reviewed source/dependency contract: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Review source identity, units, primitive/derived fields and executable constraints; coverage alone is not approval.
- B2 — Capture/extractor/label/model-row linkage: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Resolve label rules, capture/log mapping, clean replay and row identity.
- C1 — Existing feature-space consistency/retention: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Reuse candidate algebraic/type/range checks; not packet validity.
- C2 — Valid primitive transformations and re-extraction: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Actual transformations, extraction, protocol checks and label-preservation review; file presence is insufficient.
- D1 — Published baseline/label-use fidelity: CANDIDATE_EVIDENCE_FOUND_REVIEW_CONTENT. Gate: Separate MD3 warning from label-assisted confirmation; bind each estimate to its actual target; name proxies honestly.
- E1 — Existing hard-gate/adaptive/neural replay: CANDIDATE_EVIDENCE_FOUND_REVIEW_CONTENT. Gate: Reuse inspected feature-space development attacks and failures.
- E2 — Adaptive final constrained monitor evaluation: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Evaluate the final approved action space and hard gate with fixed query budgets.
- F1 — Locked NF same-parent boundary result: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Retain negative NF result; do not retune; it does not establish independent-corpus confirmation.
- F2 — Independent boundary requirement: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Audit exposure and physical/data dependencies; do not claim independent corpora from family panels.
- G1 — Existing model-family/resource development: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Reuse existing banks/resources; deterministic duplicate predictions are not fresh independent units.
- G2 — Final pipeline attribution/resource check: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Measure changed final pipeline only; source attribution requires verified channel truth; no unsupported energy claims.
- T1 — Generic output-only lemma: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Distinguish generic abstract worlds from IDS-specific attack attainability.
- T2 — IDS assumptions and weighted-integrity proposition: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Give precise observation/threat assumptions and probabilistic guarantee; no uniform accuracy certificate.
- S1 — Final independent-unit inference: CANDIDATE_EVIDENCE_FOUND_REVIEW_CONTENT. Gate: Conditional bank intervals are not final source-domain confirmation; report clustered effect sizes and frozen correction family.
- P1 — Claim/version/reproduction closure: NO_MATCHING_ARTIFACT_NAME; REVIEW_INDEX_BEFORE_DECLARING_ABSENT. Gate: Bind schemas, banks, threshold operators, profiles, code and each claim to a reproducible version.

## Content evidence


### trace_validity_cases_found.csv / SHA256 28356a17603c653c5a8abf235c0359517e7435476d45aa536b1da4e5c0081e21

case,original_records,transformed_records,unique_label_linked_records,unmatched_transformed_records,ambiguous_transformed_records,unlinked_original_records,mapped_published_label_counts,unchanged_counter_or_protocol_differences,mean_duration_change_seconds,duration_changes_checked,full_unique_mapping,all_packet_bytes_lengths_order_preserved,all_timestamp_transformations_verified,packets,packet_content_sequence_sha256,original_timestamp_inversions,transformed_timestamp_inversions,maximum_packet_delay_seconds,labels_replaced,live_application_functionality_tested,TCP_semantic_validity_certified,packet_valid_attack_approved,source_path
offset_null_control,10403,10403,10403,0,0,0,"{'benign': 2181, 'malicious': 8222}",{},0.0,4218,True,True,True,23623,dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca,0,0,1.0,False,False,False,False,/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work/TRACE_C0_PAIRED_VALIDITY_20261011T191854931117Z/paired_validity_results.csv
affine_pacing_5pct,10403,10403,10403,0,0,0,"{'benign': 2181, 'malicious': 8222}",{},0.0761288482693219,4218,True,True,True,23623,dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca,0,0,4319.763037,False,False,False,False,/kaggle/input/datasets/mdhamidborkottulla/all-kaggle-work/TRACE_C0_PAIRED_VALIDITY_20261011T191854931117Z/paired_validity_results.csv


### paired_validity_results.csv / SHA256 0e75b105fa77ae6c88ff47f1e8a3e00e7ea15b94cc8b23db0e7f756acc95f42c

case,original_records,transformed_records,unique_label_linked_records,unmatched_transformed_records,ambiguous_transformed_records,unlinked_original_records,mapped_published_label_counts,unchanged_counter_or_protocol_differences,mean_duration_change_seconds,duration_changes_checked,full_unique_mapping,all_packet_bytes_lengths_order_preserved,all_timestamp_transformations_verified,packets,packet_content_sequence_sha256,original_timestamp_inversions,transformed_timestamp_inversions,maximum_packet_delay_seconds,labels_replaced,live_application_functionality_tested,TCP_semantic_validity_certified,packet_valid_attack_approved
offset_null_control,10403,10403,10403,0,0,0,"{'benign': 2181, 'malicious': 8222}",{},0.0,4218,True,True,True,23623,dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca,0,0,1.0,False,False,False,False
affine_pacing_5pct,10403,10403,10403,0,0,0,"{'benign': 2181, 'malicious': 8222}",{},0.0761288482693219,4218,True,True,True,23623,dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca,0,0,4319.763037,False,False,False,False


### B_installed_field_coverage.csv / SHA256 12426d25e5b367c97efbd32b4e59346974dc98def17df93af46607189e6d0086

feature,exact_installed_declaration_excerpts,installed_source_evidence_found,review_required,packet_transform_approved
duration,3,True,True,False
orig_bytes,1,True,True,False
resp_bytes,1,True,True,False
orig_pkts,1,True,True,False
resp_pkts,1,True,True,False
orig_ip_bytes,1,True,True,False
resp_ip_bytes,1,True,True,False
missed_bytes,1,True,True,False
proto,4,True,True,False


### matched_coverage_gains.csv / SHA256 bb664bd37a65eb785132329705750e48ab30a7b1a71ecb32dc39ab7c7cf666ef

scenario,attack,gain,paired_windows,baseline
CTU-IoT-Malware-Capture-39-1,INJ_k1,0.329360642298878,18,AC
CTU-IoT-Malware-Capture-39-1,INJ_k3,0.3113556049457151,18,AC
CTU-IoT-Malware-Capture-49-1,INJ_k1,-0.2060507030610729,24,AC
CTU-IoT-Malware-Capture-49-1,INJ_k3,-0.1834269720828532,24,AC
CTU-IoT-Malware-Capture-7-1,INJ_k1,0.2289763746281143,21,AC
CTU-IoT-Malware-Capture-7-1,INJ_k3,0.1987654120501012,21,AC
CTU-IoT-Malware-Capture-39-1,INJ_k1,0.329360642298878,18,DoC
CTU-IoT-Malware-Capture-39-1,INJ_k3,0.3113556049457151,18,DoC
CTU-IoT-Malware-Capture-49-1,INJ_k1,-0.2060507030610729,24,DoC
CTU-IoT-Malware-Capture-49-1,INJ_k3,-0.1834269720828532,24,DoC
CTU-IoT-Malware-Capture-7-1,INJ_k1,0.2289763746281144,21,DoC
CTU-IoT-Malware-Capture-7-1,INJ_k3,0.1987654120501013,21,DoC
CTU-IoT-Malware-Capture-39-1,INJ_k1,0.1805555555555555,18,ATC
CTU-IoT-Malware-Capture-39-1,INJ_k3,0.1805555555555555,18,ATC
CTU-IoT-Malware-Capture-49-1,INJ_k1,-0.2213541666666666,24,ATC
CTU-IoT-Malware-Capture-49-1,INJ_k3,-0.2018229166666666,24,ATC
CTU-IoT-Malware-Capture-7-1,INJ_k1,0.0807291666666666,21,ATC
CTU-IoT-Malware-Capture-7-1,INJ_k3,0.0725446428571428,21,ATC
CTU-IoT-Malware-Capture-39-1,INJ_k1,0.3472222222222222,18,AGREE
CTU-IoT-Malware-Capture-39-1,INJ_k3,0.0138888888888888,18,AGREE
CTU-IoT-Malware-Capture-49-1,INJ_k1,0.1611328125,24,AGREE
CTU-IoT-Malware-Capture-49-1,INJ_k3,0.1611328125,24,AGREE
CTU-IoT-Malware-Capture-7-1,INJ_k1,0.2466517857142857,21,AGREE
CTU-IoT-Malware-Capture-7-1,INJ_k3,-0.0904017857142857,21,AGREE


### matched_coverage_scenario_results.csv / SHA256 2b83967a30e8ded4be2bd510aa5af740cf076a1ca8182a17264143a40684ecb8

scenario,attack,estimator,subset,total_windows,subset_windows,finite_estimate_pairs,mean_differential_error
CTU-IoT-Malware-Capture-33-1,INJ_k1,AC,all_windows,24,24,24,0.4821384200766558
CTU-IoT-Malware-Capture-33-1,INJ_k1,AC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,AC,gate_rejected_pairs,24,24,24,0.4821384200766558
CTU-IoT-Malware-Capture-33-1,INJ_k1,AGREE,all_windows,24,24,24,0.5
CTU-IoT-Malware-Capture-33-1,INJ_k1,AGREE,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,AGREE,gate_rejected_pairs,24,24,24,0.5
CTU-IoT-Malware-Capture-33-1,INJ_k1,ATC,all_windows,24,24,24,0.3333333333333333
CTU-IoT-Malware-Capture-33-1,INJ_k1,ATC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,ATC,gate_rejected_pairs,24,24,24,0.3333333333333333
CTU-IoT-Malware-Capture-33-1,INJ_k1,DoC,all_windows,24,24,24,0.4821384200766558
CTU-IoT-Malware-Capture-33-1,INJ_k1,DoC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,DoC,gate_rejected_pairs,24,24,24,0.4821384200766558
CTU-IoT-Malware-Capture-33-1,INJ_k1,HARD_GATED,all_windows,24,24,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,HARD_GATED,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k1,HARD_GATED,gate_rejected_pairs,24,24,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,AC,all_windows,24,24,24,0.28011174855773296
CTU-IoT-Malware-Capture-33-1,INJ_k3,AC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,AC,gate_rejected_pairs,24,24,24,0.28011174855773296
CTU-IoT-Malware-Capture-33-1,INJ_k3,AGREE,all_windows,24,24,24,0.1005859375
CTU-IoT-Malware-Capture-33-1,INJ_k3,AGREE,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,AGREE,gate_rejected_pairs,24,24,24,0.1005859375
CTU-IoT-Malware-Capture-33-1,INJ_k3,ATC,all_windows,24,24,24,0.201171875
CTU-IoT-Malware-Capture-33-1,INJ_k3,ATC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,ATC,gate_rejected_pairs,24,24,24,0.201171875
CTU-IoT-Malware-Capture-33-1,INJ_k3,DoC,all_windows,24,24,24,0.28011174855773296
CTU-IoT-Malware-Capture-33-1,INJ_k3,DoC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,DoC,gate_rejected_pairs,24,24,24,0.28011174855773296
CTU-IoT-Malware-Capture-33-1,INJ_k3,HARD_GATED,all_windows,24,24,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,HARD_GATED,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-33-1,INJ_k3,HARD_GATED,gate_rejected_pairs,24,24,0,
CTU-IoT-Malware-Capture-36-1,INJ_k1,AC,all_windows,24,24,24,0.4802658193516705
CTU-IoT-Malware-Capture-36-1,INJ_k1,AC,gate_retained_pairs,24,0,0,
CTU-IoT-Malware-Capture-36-1,INJ_k1,AC,gate_rejected_pairs,24,24,24,0.4802658193516705
CTU-IoT-Malware-Capture-36-1,INJ_k1,AGREE,all_windows,24,24,24,0.4990234375
CTU-IoT-Malware-Capture-36-1,INJ_k1,AGREE,gate_retained_pairs,24,0,0,


### matched_coverage_summary.csv / SHA256 8d86409a2a11711d1cd5583dfdfabc3139894e7ae877097d9bb6ab0cee629d55

attack,subset,estimator,mean_scenario_error,scenarios_with_finite_error,finite_estimate_pairs,subset_windows
INJ_k1,all_windows,AC,0.36402518814414664,8,192,192
INJ_k1,all_windows,AGREE,0.45332845052083337,8,192,192
INJ_k1,all_windows,ATC,0.24979654947916666,8,192,192
INJ_k1,all_windows,DoC,0.3635965154395248,8,192,192
INJ_k1,all_windows,HARD_GATED,0.2087880291005291,3,63,192
INJ_k1,gate_rejected_pairs,AC,0.4139588151878647,7,129,129
INJ_k1,gate_rejected_pairs,AGREE,0.46358816964285715,7,129,129
INJ_k1,gate_rejected_pairs,ATC,0.2855282738095238,7,129,129
INJ_k1,gate_rejected_pairs,DoC,0.4134689035254398,7,129,129
INJ_k1,gate_rejected_pairs,HARD_GATED,,0,0,129
INJ_k1,gate_retained_pairs,AC,0.326216800389169,3,63,63
INJ_k1,gate_retained_pairs,AGREE,0.4604569692460318,3,63,63
INJ_k1,gate_retained_pairs,ATC,0.22209821428571427,3,63,63
INJ_k1,gate_retained_pairs,DoC,0.326216800389169,3,63,63
INJ_k1,gate_retained_pairs,HARD_GATED,0.2087880291005291,3,63,63
INJ_k3,all_windows,AC,0.27503013787410974,8,192,192
INJ_k3,all_windows,AGREE,0.14786783854166666,8,192,192
INJ_k3,all_windows,ATC,0.19584147135416666,8,192,192
INJ_k3,all_windows,DoC,0.2750144549985498,8,192,192
INJ_k3,all_windows,HARD_GATED,0.20227761243386244,3,63,192
INJ_k3,gate_rejected_pairs,AC,0.309708101911513,7,129,129
INJ_k3,gate_rejected_pairs,AGREE,0.11644345238095237,7,129,129
INJ_k3,gate_rejected_pairs,ATC,0.2222842261904762,7,129,129
INJ_k3,gate_rejected_pairs,DoC,0.30969017862515885,7,129,129
INJ_k3,gate_rejected_pairs,HARD_GATED,,0,0,129
INJ_k3,gate_retained_pairs,AC,0.31117562740485016,3,63,63
INJ_k3,gate_retained_pairs,AGREE,0.2304842509920635,3,63,63
INJ_k3,gate_retained_pairs,ATC,0.21937003968253968,3,63,63
INJ_k3,gate_retained_pairs,DoC,0.3111756274048501,3,63,63
INJ_k3,gate_retained_pairs,HARD_GATED,0.20227761243386244,3,63,63


### matched_coverage_window_results.csv / SHA256 c06219256d72d559b80fefa94fe049850931d78765c7af87d07ccb79585fe4fe

scenario,attack,seed,window,estimator,clean_accuracy,attack_accuracy,true_damage,clean_estimate,attack_estimate,paired_estimate_available,differential_abs_error,gate_pair_retained
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,0,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,False
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,0,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,False
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,0,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,False
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,0,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,False
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,0,HARD_GATED,0.5,1.0,-0.5,0.5,,False,,False
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,1,AC,0.5,0.9921875,-0.4921875,0.9419925839310116,0.9627334534698916,True,0.4714466304611198,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,1,DoC,0.5,0.9921875,-0.4921875,0.954669077461013,0.9754099469998933,True,0.4714466304611198,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,1,ATC,0.5,0.9921875,-0.4921875,1.0,1.0,True,0.4921875,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,1,AGREE,0.5,0.9921875,-0.4921875,0.5078125,0.5078125,True,0.4921875,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,1,HARD_GATED,0.5,0.9921875,-0.4921875,0.5078125,0.7578125,True,0.2421875,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,2,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,2,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,2,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,2,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,2,HARD_GATED,0.5,1.0,-0.5,0.5,0.7265625,True,0.2734375,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,3,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,3,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,3,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,3,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,3,HARD_GATED,0.5,1.0,-0.5,0.5,0.7578125,True,0.2421875,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,4,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,4,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,4,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,4,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,4,HARD_GATED,0.5,1.0,-0.5,0.5,0.75,True,0.25,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,5,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,5,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,5,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,5,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,5,HARD_GATED,0.5,1.0,-0.5,0.5,0.7421875,True,0.2578125,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,6,AC,0.5,1.0,-0.5,0.9410867225703078,0.9631194330168588,True,0.4779672895534491,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,6,DoC,0.5,1.0,-0.5,0.9537632161003096,0.9757959265468602,True,0.4779672895534492,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,6,ATC,0.5,1.0,-0.5,1.0,1.0,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,6,AGREE,0.5,1.0,-0.5,0.5,0.5,True,0.5,True
CTU-IoT-Malware-Capture-7-1,INJ_k1,8101,6,HARD_GATED,0.5,1.0,-0.5,0.5,0.7421875,True,0.2578125,True


### e10_matched_coverage.csv / SHA256 53d76ee05e3637c3813248452f6289fa99a3f04610321c962eb5a69a3b594f9a

dataset,condition,attack_seed,method,partition_seed,target_coverage,actual_coverage,trusted_risk,mean_damage_all_windows,mean_damage_kept_windows
CICIoMT2024,clean_source,-1,primary_confidence_window,-1,0.25,0.2564102564102564,0.02890625,0.0,0.0
CICIoMT2024,clean_source,-1,primary_confidence_window,-1,0.5,0.5128205128205128,0.037109375,0.0,0.0
CICIoMT2024,clean_source,-1,primary_confidence_window,-1,0.75,0.7692307692307693,0.0416666666666666,0.0,0.0
CICIoMT2024,clean_source,-1,primary_confidence_window,-1,0.85,0.8717948717948718,0.04296875,0.0,0.0
CICIoMT2024,clean_source,-1,primary_confidence_window,-1,1.0,1.0,0.0446714743589743,0.0,0.0
CICIoMT2024,clean_source,-1,semantic,-1,0.25,0.2564102564102564,0.0398437499999999,0.0,0.0
CICIoMT2024,clean_source,-1,semantic,-1,0.5,0.5128205128205128,0.0457031249999999,0.0,0.0
CICIoMT2024,clean_source,-1,semantic,-1,0.75,0.7692307692307693,0.0453124999999999,0.0,0.0
CICIoMT2024,clean_source,-1,semantic,-1,0.85,0.8717948717948718,0.0438878676470588,0.0,0.0
CICIoMT2024,clean_source,-1,semantic,-1,1.0,1.0,0.0446714743589743,0.0,0.0
CICIoMT2024,clean_source,-1,random,201,0.25,0.2564102564102564,0.04453125,0.0,0.0
CICIoMT2024,clean_source,-1,random,201,0.5,0.5128205128205128,0.0476562499999999,0.0,0.0
CICIoMT2024,clean_source,-1,random,201,0.75,0.7692307692307693,0.0455729166666666,0.0,0.0
CICIoMT2024,clean_source,-1,random,201,0.85,0.8717948717948718,0.0445772058823529,0.0,0.0
CICIoMT2024,clean_source,-1,random,201,1.0,1.0,0.0446714743589743,0.0,0.0
CICIoMT2024,clean_source,-1,random,202,0.25,0.2564102564102564,0.040625,0.0,0.0
CICIoMT2024,clean_source,-1,random,202,0.5,0.5128205128205128,0.044921875,0.0,0.0
CICIoMT2024,clean_source,-1,random,202,0.75,0.7692307692307693,0.0455729166666666,0.0,0.0
CICIoMT2024,clean_source,-1,random,202,0.85,0.8717948717948718,0.0454963235294118,0.0,0.0
CICIoMT2024,clean_source,-1,random,202,1.0,1.0,0.0446714743589743,0.0,0.0
CICIoMT2024,clean_source,-1,random,203,0.25,0.2564102564102564,0.04296875,0.0,0.0
CICIoMT2024,clean_source,-1,random,203,0.5,0.5128205128205128,0.0476562499999999,0.0,0.0
CICIoMT2024,clean_source,-1,random,203,0.75,0.7692307692307693,0.0450520833333333,0.0,0.0
CICIoMT2024,clean_source,-1,random,203,0.85,0.8717948717948718,0.0441176470588234,0.0,0.0
CICIoMT2024,clean_source,-1,random,203,1.0,1.0,0.0446714743589743,0.0,0.0
CICIoMT2024,natural_heldout_family,-1,primary_confidence_window,-1,0.25,0.2558139534883721,0.1608664772727273,,
CICIoMT2024,natural_heldout_family,-1,primary_confidence_window,-1,0.5,0.5,0.1702398255813954,,
CICIoMT2024,natural_heldout_family,-1,primary_confidence_window,-1,0.75,0.7558139534883721,0.1739182692307692,,
CICIoMT2024,natural_heldout_family,-1,primary_confidence_window,-1,0.85,0.8604651162790697,0.1770481418918918,,
CICIoMT2024,natural_heldout_family,-1,primary_confidence_window,-1,1.0,1.0,0.1808684593023255,,
CICIoMT2024,natural_heldout_family,-1,semantic,-1,0.25,0.2558139534883721,0.1793323863636363,,
CICIoMT2024,natural_heldout_family,-1,semantic,-1,0.5,0.5,0.1851380813953488,,
CICIoMT2024,natural_heldout_family,-1,semantic,-1,0.75,0.7558139534883721,0.1814903846153845,,
CICIoMT2024,natural_heldout_family,-1,semantic,-1,0.85,0.8604651162790697,0.1820101351351351,,
CICIoMT2024,natural_heldout_family,-1,semantic,-1,1.0,1.0,0.1808684593023255,,


### e10_matched_coverage.csv / SHA256 b94cfc9a490969b56bbb02da49b1e4d18f3cfd1d78afeb1575effcad350f56f3

dataset,condition,attack_seed,method,partition_seed,target_coverage,actual_coverage,trusted_risk,mean_damage_all_windows,mean_damage_kept_windows
CICIoT2023,clean_source,-1,primary_confidence_window,-1,0.25,0.2619047619047619,0.1008522727272727,0.0,0.0
CICIoT2023,clean_source,-1,primary_confidence_window,-1,0.5,0.5,0.1015625,0.0,0.0
CICIoT2023,clean_source,-1,primary_confidence_window,-1,0.75,0.7619047619047619,0.108642578125,0.0,0.0
CICIoT2023,clean_source,-1,primary_confidence_window,-1,0.85,0.8571428571428571,0.1121961805555555,0.0,0.0
CICIoT2023,clean_source,-1,primary_confidence_window,-1,1.0,1.0,0.1160714285714286,0.0,0.0
CICIoT2023,clean_source,-1,semantic,-1,0.25,0.2619047619047619,0.1257102272727273,0.0,0.0
CICIoT2023,clean_source,-1,semantic,-1,0.5,0.5,0.1238839285714286,0.0,0.0
CICIoT2023,clean_source,-1,semantic,-1,0.75,0.7619047619047619,0.117431640625,0.0,0.0
CICIoT2023,clean_source,-1,semantic,-1,0.85,0.8571428571428571,0.1180555555555555,0.0,0.0
CICIoT2023,clean_source,-1,semantic,-1,1.0,1.0,0.1160714285714286,0.0,0.0
CICIoT2023,clean_source,-1,random,201,0.25,0.2619047619047619,0.1157670454545454,0.0,0.0
CICIoT2023,clean_source,-1,random,201,0.5,0.5,0.1197916666666666,0.0,0.0
CICIoT2023,clean_source,-1,random,201,0.75,0.7619047619047619,0.1171875,0.0,0.0
CICIoT2023,clean_source,-1,random,201,0.85,0.8571428571428571,0.1169704861111111,0.0,0.0
CICIoT2023,clean_source,-1,random,201,1.0,1.0,0.1160714285714286,0.0,0.0
CICIoT2023,clean_source,-1,random,202,0.25,0.2619047619047619,0.1242897727272727,0.0,0.0
CICIoT2023,clean_source,-1,random,202,0.5,0.5,0.1171875,0.0,0.0
CICIoT2023,clean_source,-1,random,202,0.75,0.7619047619047619,0.121337890625,0.0,0.0
CICIoT2023,clean_source,-1,random,202,0.85,0.8571428571428571,0.1193576388888888,0.0,0.0
CICIoT2023,clean_source,-1,random,202,1.0,1.0,0.1160714285714286,0.0,0.0
CICIoT2023,clean_source,-1,random,203,0.25,0.2619047619047619,0.1214488636363636,0.0,0.0
CICIoT2023,clean_source,-1,random,203,0.5,0.5,0.1246279761904761,0.0,0.0
CICIoT2023,clean_source,-1,random,203,0.75,0.7619047619047619,0.117919921875,0.0,0.0
CICIoT2023,clean_source,-1,random,203,0.85,0.8571428571428571,0.1182725694444444,0.0,0.0
CICIoT2023,clean_source,-1,random,203,1.0,1.0,0.1160714285714286,0.0,0.0
CICIoT2023,natural_heldout_family,-1,primary_confidence_window,-1,0.25,0.2523364485981308,0.1623263888888888,,
CICIoT2023,natural_heldout_family,-1,primary_confidence_window,-1,0.5,0.5046728971962616,0.1695601851851852,,
CICIoT2023,natural_heldout_family,-1,primary_confidence_window,-1,0.75,0.7570093457943925,0.1727430555555555,,
CICIoT2023,natural_heldout_family,-1,primary_confidence_window,-1,0.85,0.8504672897196262,0.1728193681318681,,
CICIoT2023,natural_heldout_family,-1,primary_confidence_window,-1,1.0,1.0,0.1766209112149532,,
CICIoT2023,natural_heldout_family,-1,semantic,-1,0.25,0.2523364485981308,0.1918402777777778,,
CICIoT2023,natural_heldout_family,-1,semantic,-1,0.5,0.5046728971962616,0.1825810185185185,,
CICIoT2023,natural_heldout_family,-1,semantic,-1,0.75,0.7570093457943925,0.1776620370370371,,
CICIoT2023,natural_heldout_family,-1,semantic,-1,0.85,0.8504672897196262,0.1789148351648352,,
CICIoT2023,natural_heldout_family,-1,semantic,-1,1.0,1.0,0.1766209112149532,,


### e10_matched_coverage.csv / SHA256 6796c65e3ad457184bc0b4ab9f6118245aa9741188818af57ebc846874df2139

dataset,condition,attack_seed,method,partition_seed,target_coverage,actual_coverage,trusted_risk,mean_damage_all_windows,mean_damage_kept_windows
CSE,clean_source,-1,primary_confidence_window,-1,0.25,0.2727272727272727,0.0208333333333333,0.0,0.0
CSE,clean_source,-1,primary_confidence_window,-1,0.5,0.5454545454545454,0.01953125,0.0,0.0
CSE,clean_source,-1,primary_confidence_window,-1,0.75,0.8181818181818182,0.0199652777777777,0.0,0.0
CSE,clean_source,-1,primary_confidence_window,-1,0.85,0.9090909090909092,0.01953125,0.0,0.0
CSE,clean_source,-1,primary_confidence_window,-1,1.0,1.0,0.0191761363636363,0.0,0.0
CSE,clean_source,-1,semantic,-1,0.25,0.2727272727272727,0.0130208333333333,0.0,0.0
CSE,clean_source,-1,semantic,-1,0.5,0.5454545454545454,0.015625,0.0,0.0
CSE,clean_source,-1,semantic,-1,0.75,0.8181818181818182,0.0190972222222222,0.0,0.0
CSE,clean_source,-1,semantic,-1,0.85,0.9090909090909092,0.01953125,0.0,0.0
CSE,clean_source,-1,semantic,-1,1.0,1.0,0.0191761363636363,0.0,0.0
CSE,clean_source,-1,random,201,0.25,0.2727272727272727,0.0182291666666666,0.0,0.0
CSE,clean_source,-1,random,201,0.5,0.5454545454545454,0.01953125,0.0,0.0
CSE,clean_source,-1,random,201,0.75,0.8181818181818182,0.0199652777777777,0.0,0.0
CSE,clean_source,-1,random,201,0.85,0.9090909090909092,0.01953125,0.0,0.0
CSE,clean_source,-1,random,201,1.0,1.0,0.0191761363636363,0.0,0.0
CSE,clean_source,-1,random,202,0.25,0.2727272727272727,0.0130208333333333,0.0,0.0
CSE,clean_source,-1,random,202,0.5,0.5454545454545454,0.0169270833333333,0.0,0.0
CSE,clean_source,-1,random,202,0.75,0.8181818181818182,0.0190972222222222,0.0,0.0
CSE,clean_source,-1,random,202,0.85,0.9090909090909092,0.01875,0.0,0.0
CSE,clean_source,-1,random,202,1.0,1.0,0.0191761363636363,0.0,0.0
CSE,clean_source,-1,random,203,0.25,0.2727272727272727,0.0130208333333333,0.0,0.0
CSE,clean_source,-1,random,203,0.5,0.5454545454545454,0.01953125,0.0,0.0
CSE,clean_source,-1,random,203,0.75,0.8181818181818182,0.0199652777777777,0.0,0.0
CSE,clean_source,-1,random,203,0.85,0.9090909090909092,0.01953125,0.0,0.0
CSE,clean_source,-1,random,203,1.0,1.0,0.0191761363636363,0.0,0.0
CSE,natural_day_Botnet,-1,primary_confidence_window,-1,0.25,0.2608695652173913,0.529296875,,
CSE,natural_day_Botnet,-1,primary_confidence_window,-1,0.5,0.5,0.5152853260869565,,
CSE,natural_day_Botnet,-1,primary_confidence_window,-1,0.75,0.7608695652173914,0.5245535714285714,,
CSE,natural_day_Botnet,-1,primary_confidence_window,-1,0.85,0.8695652173913043,0.52734375,,
CSE,natural_day_Botnet,-1,primary_confidence_window,-1,1.0,1.0,0.5280230978260869,,
CSE,natural_day_Botnet,-1,semantic,-1,0.25,0.2608695652173913,0.53515625,,
CSE,natural_day_Botnet,-1,semantic,-1,0.5,0.5,0.5224184782608696,,
CSE,natural_day_Botnet,-1,semantic,-1,0.75,0.7608695652173914,0.528125,,
CSE,natural_day_Botnet,-1,semantic,-1,0.85,0.8695652173913043,0.526171875,,
CSE,natural_day_Botnet,-1,semantic,-1,1.0,1.0,0.5280230978260869,,


### e10_matched_coverage.csv / SHA256 50fa789d65d0a2cda37e37c9e0141c6ea7d16555eeb3ea61bdf651f9626ee2ee

dataset,condition,attack_seed,method,partition_seed,target_coverage,actual_coverage,trusted_risk,mean_damage_all_windows,mean_damage_kept_windows
NSL,clean_source,-1,primary_confidence_window,-1,0.25,0.2727272727272727,0.0572916666666666,0.0,0.0
NSL,clean_source,-1,primary_confidence_window,-1,0.5,0.5454545454545454,0.05078125,0.0,0.0
NSL,clean_source,-1,primary_confidence_window,-1,0.75,0.8181818181818182,0.0572916666666666,0.0,0.0
NSL,clean_source,-1,primary_confidence_window,-1,0.85,0.9090909090909092,0.0570312499999999,0.0,0.0
NSL,clean_source,-1,primary_confidence_window,-1,1.0,1.0,0.0596590909090909,0.0,0.0
NSL,clean_source,-1,semantic,-1,0.25,0.2727272727272727,0.0625,0.0,0.0
NSL,clean_source,-1,semantic,-1,0.5,0.5454545454545454,0.0533854166666666,0.0,0.0
NSL,clean_source,-1,semantic,-1,0.75,0.8181818181818182,0.0590277777777777,0.0,0.0
NSL,clean_source,-1,semantic,-1,0.85,0.9090909090909092,0.05859375,0.0,0.0
NSL,clean_source,-1,semantic,-1,1.0,1.0,0.0596590909090909,0.0,0.0
NSL,clean_source,-1,random,201,0.25,0.2727272727272727,0.0625,0.0,0.0
NSL,clean_source,-1,random,201,0.5,0.5454545454545454,0.05859375,0.0,0.0
NSL,clean_source,-1,random,201,0.75,0.8181818181818182,0.0581597222222222,0.0,0.0
NSL,clean_source,-1,random,201,0.85,0.9090909090909092,0.0578125,0.0,0.0
NSL,clean_source,-1,random,201,1.0,1.0,0.0596590909090909,0.0,0.0
NSL,clean_source,-1,random,202,0.25,0.2727272727272727,0.0625,0.0,0.0
NSL,clean_source,-1,random,202,0.5,0.5454545454545454,0.05859375,0.0,0.0
NSL,clean_source,-1,random,202,0.75,0.8181818181818182,0.0590277777777777,0.0,0.0
NSL,clean_source,-1,random,202,0.85,0.9090909090909092,0.05859375,0.0,0.0
NSL,clean_source,-1,random,202,1.0,1.0,0.0596590909090909,0.0,0.0
NSL,clean_source,-1,random,203,0.25,0.2727272727272727,0.0625,0.0,0.0
NSL,clean_source,-1,random,203,0.5,0.5454545454545454,0.05859375,0.0,0.0
NSL,clean_source,-1,random,203,0.75,0.8181818181818182,0.0572916666666666,0.0,0.0
NSL,clean_source,-1,random,203,0.85,0.9090909090909092,0.05859375,0.0,0.0
NSL,clean_source,-1,random,203,1.0,1.0,0.0596590909090909,0.0,0.0
NSL,natural_official_test,-1,primary_confidence_window,-1,0.25,0.2580645161290322,0.2281901041666666,,
NSL,natural_official_test,-1,primary_confidence_window,-1,0.5,0.5053763440860215,0.234375,,
NSL,natural_official_test,-1,primary_confidence_window,-1,0.75,0.7526881720430108,0.2345982142857142,,
NSL,natural_official_test,-1,primary_confidence_window,-1,0.85,0.8602150537634409,0.23486328125,,
NSL,natural_official_test,-1,primary_confidence_window,-1,1.0,1.0,0.2355510752688172,,
NSL,natural_official_test,-1,semantic,-1,0.25,0.2580645161290322,0.2532552083333333,,
NSL,natural_official_test,-1,semantic,-1,0.5,0.5053763440860215,0.2415226063829787,,
NSL,natural_official_test,-1,semantic,-1,0.75,0.7526881720430108,0.2415178571428571,,
NSL,natural_official_test,-1,semantic,-1,0.85,0.8602150537634409,0.2372070312499999,,
NSL,natural_official_test,-1,semantic,-1,1.0,1.0,0.2355510752688172,,


### e10_matched_coverage.csv / SHA256 d90ea56a1e225dfe64bc3f640e16cd3d13934b4e00be4753e26f584d90d4cb2b

dataset,condition,attack_seed,method,partition_seed,target_coverage,actual_coverage,trusted_risk,mean_damage_all_windows,mean_damage_kept_windows
TONIoT,clean_source,-1,primary_confidence_window,-1,0.25,0.25,0.1393229166666666,0.0,0.0
TONIoT,clean_source,-1,primary_confidence_window,-1,0.5,0.5,0.1575520833333333,0.0,0.0
TONIoT,clean_source,-1,primary_confidence_window,-1,0.75,0.75,0.1688368055555555,0.0,0.0
TONIoT,clean_source,-1,primary_confidence_window,-1,0.85,0.875,0.1703869047619047,0.0,0.0
TONIoT,clean_source,-1,primary_confidence_window,-1,1.0,1.0,0.1751302083333333,0.0,0.0
TONIoT,clean_source,-1,semantic,-1,0.25,0.25,0.1888020833333333,0.0,0.0
TONIoT,clean_source,-1,semantic,-1,0.5,0.5,0.1842447916666666,0.0,0.0
TONIoT,clean_source,-1,semantic,-1,0.75,0.75,0.1749131944444444,0.0,0.0
TONIoT,clean_source,-1,semantic,-1,0.85,0.875,0.1767113095238095,0.0,0.0
TONIoT,clean_source,-1,semantic,-1,1.0,1.0,0.1751302083333333,0.0,0.0
TONIoT,clean_source,-1,random,201,0.25,0.25,0.1953125,0.0,0.0
TONIoT,clean_source,-1,random,201,0.5,0.5,0.181640625,0.0,0.0
TONIoT,clean_source,-1,random,201,0.75,0.75,0.1762152777777778,0.0,0.0
TONIoT,clean_source,-1,random,201,0.85,0.875,0.173735119047619,0.0,0.0
TONIoT,clean_source,-1,random,201,1.0,1.0,0.1751302083333333,0.0,0.0
TONIoT,clean_source,-1,random,202,0.25,0.25,0.1888020833333333,0.0,0.0
TONIoT,clean_source,-1,random,202,0.5,0.5,0.1790364583333333,0.0,0.0
TONIoT,clean_source,-1,random,202,0.75,0.75,0.17578125,0.0,0.0
TONIoT,clean_source,-1,random,202,0.85,0.875,0.1755952380952381,0.0,0.0
TONIoT,clean_source,-1,random,202,1.0,1.0,0.1751302083333333,0.0,0.0
TONIoT,clean_source,-1,random,203,0.25,0.25,0.1888020833333333,0.0,0.0
TONIoT,clean_source,-1,random,203,0.5,0.5,0.1790364583333333,0.0,0.0
TONIoT,clean_source,-1,random,203,0.75,0.75,0.17578125,0.0,0.0
TONIoT,clean_source,-1,random,203,0.85,0.875,0.1755952380952381,0.0,0.0
TONIoT,clean_source,-1,random,203,1.0,1.0,0.1751302083333333,0.0,0.0
TONIoT,natural_heldout_family,-1,primary_confidence_window,-1,0.25,0.25,0.4303385416666666,,
TONIoT,natural_heldout_family,-1,primary_confidence_window,-1,0.5,0.5,0.4375,,
TONIoT,natural_heldout_family,-1,primary_confidence_window,-1,0.75,0.75,0.4379340277777778,,
TONIoT,natural_heldout_family,-1,primary_confidence_window,-1,0.85,0.8541666666666666,0.4401676829268293,,
TONIoT,natural_heldout_family,-1,primary_confidence_window,-1,1.0,1.0,0.44677734375,,
TONIoT,natural_heldout_family,-1,semantic,-1,0.25,0.25,0.4602864583333333,,
TONIoT,natural_heldout_family,-1,semantic,-1,0.5,0.5,0.4495442708333333,,
TONIoT,natural_heldout_family,-1,semantic,-1,0.75,0.75,0.451171875,,
TONIoT,natural_heldout_family,-1,semantic,-1,0.85,0.8541666666666666,0.4508384146341463,,
TONIoT,natural_heldout_family,-1,semantic,-1,1.0,1.0,0.44677734375,,


- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / latest_C0_receipt.packet_content_identity_checks_computed: 2
- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / latest_C0_receipt.confirmatory_results_generated: False
- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / latest_C0_receipt.packet_valid_attack_approved: False
- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / zeek_binary: /opt/zeek/bin/zeek
- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / zeek_status: INSTALLED_THIS_RUNTIME
- 0356836b1dab8ac0ad130469f57256b2e6711b0300987701a348139aef42608e / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 0a8549242532354492deac19c785d098e441e676cd7cdf1168ba73638bf2c3db / required_marker_status.TRACE_CONFIRMATORY_SOURCE_MODELS_v1_1: True
- 0a8549242532354492deac19c785d098e441e676cd7cdf1168ba73638bf2c3db / required_marker_status.TRACE_CONFIRMATORY_E2_E3_CLEAN_TARGETS_v1_1_20261012T181242007570Z: True
- 0a8549242532354492deac19c785d098e441e676cd7cdf1168ba73638bf2c3db / required_marker_status.TRACE_CONFIRMATORY_TARGET_ASSETS_v1_2: True
- 0a8549242532354492deac19c785d098e441e676cd7cdf1168ba73638bf2c3db / required_marker_status.run_streaming_confirmatory_batch_A_v1_2_fixed.py: True
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [0].confirmatory_scenario_selected: False
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [0].packet_validity_approved: False
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [1].confirmatory_scenario_selected: False
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [1].packet_validity_approved: False
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [2].confirmatory_scenario_selected: False
- dd0b47817ec968a112836ca28cf25413b56e4d963375c8b3c2c749fd621afbc3 / [2].packet_validity_approved: False
- 7cc80bcb06fe63edfcfc753a666c369042c20408f6a3a7f380161d441cfe0b90 / prospective_design: frozen source detector will be trained on design scenarios only
- 41ac8420f57a62cdfcb9323baa936c208e7a7172c8114ef16843ff00e5a00339 / original_packet_count: 1376592
- 41ac8420f57a62cdfcb9323baa936c208e7a7172c8114ef16843ff00e5a00339 / inserted_packets: 512
- 41ac8420f57a62cdfcb9323baa936c208e7a7172c8114ef16843ff00e5a00339 / original_packet_bytes_preserved: True
- 41ac8420f57a62cdfcb9323baa936c208e7a7172c8114ef16843ff00e5a00339 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 1f26aa2e67a00742e5eb778d7094de571330bd4347c280dea1ad589be8c4e958 / original_packet_count: 1376592
- 1f26aa2e67a00742e5eb778d7094de571330bd4347c280dea1ad589be8c4e958 / inserted_packets: 927
- 1f26aa2e67a00742e5eb778d7094de571330bd4347c280dea1ad589be8c4e958 / original_packet_bytes_preserved: True
- 1f26aa2e67a00742e5eb778d7094de571330bd4347c280dea1ad589be8c4e958 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- a737ae10a7d6140b3b1b47787723c172787b118819afc3dfa1d551276d4d2860 / original_packet_count: 6894123
- a737ae10a7d6140b3b1b47787723c172787b118819afc3dfa1d551276d4d2860 / inserted_packets: 512
- a737ae10a7d6140b3b1b47787723c172787b118819afc3dfa1d551276d4d2860 / original_packet_bytes_preserved: True
- a737ae10a7d6140b3b1b47787723c172787b118819afc3dfa1d551276d4d2860 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 38dd676e43e6846da954b00f7113e4a3b64d4861b6235a4e89f3a61532d7158b / original_packet_count: 6894123
- 38dd676e43e6846da954b00f7113e4a3b64d4861b6235a4e89f3a61532d7158b / inserted_packets: 1383
- 38dd676e43e6846da954b00f7113e4a3b64d4861b6235a4e89f3a61532d7158b / original_packet_bytes_preserved: True
- 38dd676e43e6846da954b00f7113e4a3b64d4861b6235a4e89f3a61532d7158b / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- f73dbc12e0c0826af2cc83181c1f586d739e5284fe6f144f5209ac5c08e4f3c5 / original_packet_count: 6717148
- f73dbc12e0c0826af2cc83181c1f586d739e5284fe6f144f5209ac5c08e4f3c5 / inserted_packets: 512
- f73dbc12e0c0826af2cc83181c1f586d739e5284fe6f144f5209ac5c08e4f3c5 / original_packet_bytes_preserved: True
- f73dbc12e0c0826af2cc83181c1f586d739e5284fe6f144f5209ac5c08e4f3c5 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 881e43de5eb6ed059b2cb37245e4045d0bca4849ec63f1c1d6fa066703a0306e / original_packet_count: 6717148
- 881e43de5eb6ed059b2cb37245e4045d0bca4849ec63f1c1d6fa066703a0306e / inserted_packets: 1536
- 881e43de5eb6ed059b2cb37245e4045d0bca4849ec63f1c1d6fa066703a0306e / original_packet_bytes_preserved: True
- 881e43de5eb6ed059b2cb37245e4045d0bca4849ec63f1c1d6fa066703a0306e / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 0be2bca204c0ba6ff91ecd10cae68ebcf9458f6a230ef39b24f99cd634c41606 / original_packet_count: 1364273
- 0be2bca204c0ba6ff91ecd10cae68ebcf9458f6a230ef39b24f99cd634c41606 / inserted_packets: 512
- 0be2bca204c0ba6ff91ecd10cae68ebcf9458f6a230ef39b24f99cd634c41606 / original_packet_bytes_preserved: True
- 0be2bca204c0ba6ff91ecd10cae68ebcf9458f6a230ef39b24f99cd634c41606 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 770302aeb625e3c491fa8b80191519e38c7f375214a58276014c65bb9b2791c4 / original_packet_count: 1364273
- 770302aeb625e3c491fa8b80191519e38c7f375214a58276014c65bb9b2791c4 / inserted_packets: 1299
- 770302aeb625e3c491fa8b80191519e38c7f375214a58276014c65bb9b2791c4 / original_packet_bytes_preserved: True
- 770302aeb625e3c491fa8b80191519e38c7f375214a58276014c65bb9b2791c4 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 7dfd5dee205373103d8b0aff4201715b93500952870e21643315e118b92de826 / original_packet_count: 2888752
- 7dfd5dee205373103d8b0aff4201715b93500952870e21643315e118b92de826 / inserted_packets: 512
- 7dfd5dee205373103d8b0aff4201715b93500952870e21643315e118b92de826 / original_packet_bytes_preserved: True
- 7dfd5dee205373103d8b0aff4201715b93500952870e21643315e118b92de826 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- a97ac82184de03ee6bef5000488c9b55fa2cc44cf2efc5965122d85400b60c33 / original_packet_count: 2888752
- a97ac82184de03ee6bef5000488c9b55fa2cc44cf2efc5965122d85400b60c33 / inserted_packets: 201
- a97ac82184de03ee6bef5000488c9b55fa2cc44cf2efc5965122d85400b60c33 / original_packet_bytes_preserved: True
- a97ac82184de03ee6bef5000488c9b55fa2cc44cf2efc5965122d85400b60c33 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- d97d7ecb50813b9761237da70766f985dcb0becb78c2ad5dbcf319593fedcae3 / original_packet_count: 3391734
- d97d7ecb50813b9761237da70766f985dcb0becb78c2ad5dbcf319593fedcae3 / inserted_packets: 512
- d97d7ecb50813b9761237da70766f985dcb0becb78c2ad5dbcf319593fedcae3 / original_packet_bytes_preserved: True
- d97d7ecb50813b9761237da70766f985dcb0becb78c2ad5dbcf319593fedcae3 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 4922897bb16525a284c42630ffe15a8bbb97bfa5e90c38d8b3fbd652be26af95 / original_packet_count: 3391734
- 4922897bb16525a284c42630ffe15a8bbb97bfa5e90c38d8b3fbd652be26af95 / inserted_packets: 1473
- 4922897bb16525a284c42630ffe15a8bbb97bfa5e90c38d8b3fbd652be26af95 / original_packet_bytes_preserved: True
- 4922897bb16525a284c42630ffe15a8bbb97bfa5e90c38d8b3fbd652be26af95 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- bea97251897d39ad8b1f407be61ac936b60fa6f24da10f24cbe9727acab6c634 / original_packet_count: 1378113
- bea97251897d39ad8b1f407be61ac936b60fa6f24da10f24cbe9727acab6c634 / inserted_packets: 512
- bea97251897d39ad8b1f407be61ac936b60fa6f24da10f24cbe9727acab6c634 / original_packet_bytes_preserved: True
- bea97251897d39ad8b1f407be61ac936b60fa6f24da10f24cbe9727acab6c634 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- d1c79dd100ce70a25a203c4a2075cc9bfdb4fe362e873be8cac03de12fe99b2b / original_packet_count: 1378113
- d1c79dd100ce70a25a203c4a2075cc9bfdb4fe362e873be8cac03de12fe99b2b / inserted_packets: 1488
- d1c79dd100ce70a25a203c4a2075cc9bfdb4fe362e873be8cac03de12fe99b2b / original_packet_bytes_preserved: True
- d1c79dd100ce70a25a203c4a2075cc9bfdb4fe362e873be8cac03de12fe99b2b / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- cf4f413cf2a377680d7b9af6577d24102badd4a00c3e9e5067649af9d8035612 / original_packet_count: 1363358
- cf4f413cf2a377680d7b9af6577d24102badd4a00c3e9e5067649af9d8035612 / inserted_packets: 512
- cf4f413cf2a377680d7b9af6577d24102badd4a00c3e9e5067649af9d8035612 / original_packet_bytes_preserved: True
- cf4f413cf2a377680d7b9af6577d24102badd4a00c3e9e5067649af9d8035612 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 93003ef5af2014c0f8ca47215be55a4e5040a6f3df50b1115daedba88337bd84 / original_packet_count: 1363358
- 93003ef5af2014c0f8ca47215be55a4e5040a6f3df50b1115daedba88337bd84 / inserted_packets: 591
- 93003ef5af2014c0f8ca47215be55a4e5040a6f3df50b1115daedba88337bd84 / original_packet_bytes_preserved: True
- 93003ef5af2014c0f8ca47215be55a4e5040a6f3df50b1115daedba88337bd84 / validity_scope: Offline byte-preserving duplicate insertion and exact selected-flow linkage; not application-semantic validity.
- 345b9a4f35b6899bd1075babf193eaa8118f54e30b77c1d8a8773c8bea999271 / original_packet_count: 1376592
- 345b9a4f35b6899bd1075babf193eaa8118f54e30b77c1d8a8773c8bea999271 / delayed_packets: 0
- 345b9a4f35b6899bd1075babf193eaa8118f54e30b77c1d8a8773c8bea999271 / no_packet_advanced: True
- 345b9a4f35b6899bd1075babf193eaa8118f54e30b77c1d8a8773c8bea999271 / validity_scope: Offline byte/order/delay checks; not application semantics
- fb08b7ca522e72e7ed57d589431bdfeeed824f6c1a1e8437cc7a1a551756027c / original_packet_count: 6894123
- fb08b7ca522e72e7ed57d589431bdfeeed824f6c1a1e8437cc7a1a551756027c / delayed_packets: 2
- fb08b7ca522e72e7ed57d589431bdfeeed824f6c1a1e8437cc7a1a551756027c / no_packet_advanced: True
- fb08b7ca522e72e7ed57d589431bdfeeed824f6c1a1e8437cc7a1a551756027c / validity_scope: Offline byte/order/delay checks; not application semantics
- d813beb1a12b4ef4ab0cb3cd29d9f83402f7ef3eda38e91a649d1dd4e03b387c / original_packet_count: 6717148
- d813beb1a12b4ef4ab0cb3cd29d9f83402f7ef3eda38e91a649d1dd4e03b387c / delayed_packets: 0
- d813beb1a12b4ef4ab0cb3cd29d9f83402f7ef3eda38e91a649d1dd4e03b387c / no_packet_advanced: True
- d813beb1a12b4ef4ab0cb3cd29d9f83402f7ef3eda38e91a649d1dd4e03b387c / validity_scope: Offline byte/order/delay checks; not application semantics
- 98a7ae8bf997dc2dae4e275782b95dc99099ba328f6e9f61867c6ffc6782337b / original_packet_count: 1364273
- 98a7ae8bf997dc2dae4e275782b95dc99099ba328f6e9f61867c6ffc6782337b / delayed_packets: 0
- 98a7ae8bf997dc2dae4e275782b95dc99099ba328f6e9f61867c6ffc6782337b / no_packet_advanced: True
- 98a7ae8bf997dc2dae4e275782b95dc99099ba328f6e9f61867c6ffc6782337b / validity_scope: Offline byte/order/delay checks; not application semantics
- eba9d411c2348bf7d424500acdd20439f28bfe3abfbc437032d39aa5f0ae3615 / original_packet_count: 2888752
- eba9d411c2348bf7d424500acdd20439f28bfe3abfbc437032d39aa5f0ae3615 / delayed_packets: 1552
- eba9d411c2348bf7d424500acdd20439f28bfe3abfbc437032d39aa5f0ae3615 / no_packet_advanced: True
- eba9d411c2348bf7d424500acdd20439f28bfe3abfbc437032d39aa5f0ae3615 / validity_scope: Offline byte/order/delay checks; not application semantics
- 29e156190696a0c725049f10269e6e671f05f22c65b6300c46a4d9c43bb454e7 / original_packet_count: 1378113
- 29e156190696a0c725049f10269e6e671f05f22c65b6300c46a4d9c43bb454e7 / delayed_packets: 1
- 29e156190696a0c725049f10269e6e671f05f22c65b6300c46a4d9c43bb454e7 / no_packet_advanced: True
- 29e156190696a0c725049f10269e6e671f05f22c65b6300c46a4d9c43bb454e7 / validity_scope: Offline byte/order/delay checks; not application semantics
- acf9a4a72dccccdec1eb79cd1db38a82556905ce87987bf1f7252d82f53ab36d / original_packet_count: 1363358
- acf9a4a72dccccdec1eb79cd1db38a82556905ce87987bf1f7252d82f53ab36d / delayed_packets: 0
- acf9a4a72dccccdec1eb79cd1db38a82556905ce87987bf1f7252d82f53ab36d / no_packet_advanced: True
- acf9a4a72dccccdec1eb79cd1db38a82556905ce87987bf1f7252d82f53ab36d / validity_scope: Offline byte/order/delay checks; not application semantics
- cb3e8af5afe26f485c89c05be6b79fd3709061474194b7462858280e05077d2d / prospective_confirmation: False
- cb3e8af5afe26f485c89c05be6b79fd3709061474194b7462858280e05077d2d / independent_pairs: 1
- 484a15c7291cfc6598208b9eaf54eaef8708afde030dfed1e1ef400250459ca1 / result_directories_found.TRACE_PACKET_PACING_: 1
- 484a15c7291cfc6598208b9eaf54eaef8708afde030dfed1e1ef400250459ca1 / result_directories_found.TRACE_PACKET_HARNESS_V31_: 1
- 484a15c7291cfc6598208b9eaf54eaef8708afde030dfed1e1ef400250459ca1 / result_directories_found.TRACE_PACKET_INJECTION_1_1_: 1
- f9224794e71ae02f4f594d424b35019019500bd52215287c5415a45183a4a4cf / prospective_confirmation: False
- f9224794e71ae02f4f594d424b35019019500bd52215287c5415a45183a4a4cf / independent_pairs: 1
- 4bce6d6980fbf8fe9573d58208d33c7683223e874dce4bd1fbe923e15a9a44bf / result_directories_found.TRACE_PACKET_PACING_: 1
- 4bce6d6980fbf8fe9573d58208d33c7683223e874dce4bd1fbe923e15a9a44bf / result_directories_found.TRACE_PACKET_HARNESS_V31_: 1
- 4bce6d6980fbf8fe9573d58208d33c7683223e874dce4bd1fbe923e15a9a44bf / result_directories_found.TRACE_PACKET_INJECTION_1_1_: 1
- 82a8e8fb7d5d5e74d60a22a55655fd9b9933f74a091ee7c05382f2653b7dae11 / prospective_confirmation: False
- 82a8e8fb7d5d5e74d60a22a55655fd9b9933f74a091ee7c05382f2653b7dae11 / independent_pairs: 1
- bc30eb22341daa59624fc6f8531e14c269c45d5c07ef1431e9683684fdbfddca / result_directories_found.TRACE_PACKET_PACING_: 1
- bc30eb22341daa59624fc6f8531e14c269c45d5c07ef1431e9683684fdbfddca / result_directories_found.TRACE_PACKET_HARNESS_V31_: 1
- bc30eb22341daa59624fc6f8531e14c269c45d5c07ef1431e9683684fdbfddca / result_directories_found.TRACE_PACKET_INJECTION_1_1_: 1
- f1f1d039c1640f9f5af71f089fffd7c56782fc043c1aff9a184b26db66a502cf / Zeek_conn_logs_read: True
- 6e9371059d92405b54dbcc0cc555f3fdfab5b81f5662a6912d11b6dcad1b77c5 / Zeek_labeled_conn_logs_streamed: True
- 32074050a9d8536f7c9dd0f5b50af7f9e97ff716cc1678737462df1ce45ca3e9 / Zeek_labeled_conn_logs_read: True
- 5f70f4e8349deba56fe7642f7a9abb989d3d4680072212c1ce82c893d4bcbf99 / Zeek_rerun: False
- 5eb7db0b0cc6093acaba63c6c908cbc504fff1a85788108603e80dad984b1ffa / Zeek_rerun: False
- 29df1c3812ff6d532d9ec90dda7f09e9dc8666efdfa937490cc7311e26176393 / Zeek_rerun: False
- 29df1c3812ff6d532d9ec90dda7f09e9dc8666efdfa937490cc7311e26176393 / syntax_valid: True
- 1039cf88defc1c5428bc1dff29f4cc80cb6094adc3715dd7a95dec07140a53b5 / Zeek_rerun: False
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[0].packets: 1378113
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[1].packets: 1363358
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[2].packets: 1376592
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[3].packets: 6894123
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[4].packets: 6717148
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[5].packets: 1364273
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[6].packets: 2888752
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / target_slices[7].packets: 3391734
- 824df259cf27872c1395888d0715baa96fc5b9decfe8b527c03394358d65ebf0 / eligibility.validity_gate: packet multiset as designed; no original packet advanced; per-flow original packet order preserved; output timestamps nondecreasing; exact or inherited label mapping; mapped fraction >=0.999
- 7f93bf187df1836b18c2582b64c8ebd852ebd371fdda4dba32c7cecf14b822c7 / Zeek_rerun: False
- bbcc2df5d8ca979fe5c8e4ccbe2941059f635bf707303d551f3ff5826385ee2d / validity.packet_count_original: 1378113
- bbcc2df5d8ca979fe5c8e4ccbe2941059f635bf707303d551f3ff5826385ee2d / validity.byte_source: duplicates are exact bytes from original selected packets
- 311630053c9a16b45b9c52e48404d9260c46fc1b7fc7187f0ea6b11345078fad / validity.packet_count_original: 1378113
- 311630053c9a16b45b9c52e48404d9260c46fc1b7fc7187f0ea6b11345078fad / validity.byte_source: duplicates are exact bytes from original selected packets
- 413916c4843c2705667d461281a183ba0084bfd8cd8bd153487c736cd7d26a44 / Zeek_rerun: False
- 4b3cce6b81444aef9af3dc9c08d09a844314573316d13dc44d8e2088649a0f1f / Zeek_rerun: False
- b6ae7b86cc75784fba8588e28e7ea965af539e8f7529699ae35de8d45ef24554 / Zeek_rerun: False
- e8aea4f891d44489ac64c28e013f1ee637993de14f6f64937bab426ba5638b73 / Zeek_rerun: False
- cd87429842f85761f29981a7e58811b2ee0518cc368198e478fbb5ed861476e8 / Zeek_rerun: False
- ab244c1963c02ef9e315d125f5cfa58588a3e7899f7dcbb19310caec3535a959 / Zeek_rerun: False
- 7c253d41f519ac69fef75ae09b67fb4fb4fc3acfa8514fff8ebd1fd814650937 / Zeek_rerun: False
- 19c64952edf52ff9586b2ccc8fc1bb0ce1192a75fa467465401676ceb3b5179f / Zeek_rerun: False
- 9dd5fb27d45a51d38deba157f990618a1cdf506fb70b7724459da41d7a02d3d7 / Zeek_rerun: False
- 55814860edc3dad168525538f2d61878d6b340e1dcb5798e34eb818ad9e31134 / Zeek_rerun: False
- a123dc2a7ac1b85232796e333568e935cc022b270e5b631bd09353e96dc3d6be / Zeek_rerun: False
- 9377a9c92c4db0710f7737110ea3a67d9484c5ae37e6d43e9f5e997987d7c637 / Zeek_rerun: False
- 7cdc1fad917019e14541b644c2dae0cb4313edf33d36166cfb46f148fe47c7df / Zeek_rerun: False
- 42f2e8dccc3463d9a42865953db84b6fc700e3c32f6a56da9b2fa69f7f09093b / Zeek_rerun: False
- 4e85886a53ecfe93102759b676c090fb3c44201f9c070f3dd16b1aa7ff40dec9 / Zeek_rerun: False
- 64a7f93a0bb9551975c3616ced47186d9d5f0956a39fa1359223abf7b7c98e5a / syntax_valid: True
- 64a7f93a0bb9551975c3616ced47186d9d5f0956a39fa1359223abf7b7c98e5a / Zeek_rerun: False
- 9c583f88bee4b8894b0028a9162abe060d7ad9561c882dc6b639590a3eaf0568 / validity.packet_count_original: 1378113
- 9c583f88bee4b8894b0028a9162abe060d7ad9561c882dc6b639590a3eaf0568 / validity.byte_source: duplicates are exact bytes from original selected packets
- 49a1ab7f4e843f6ae3deb26d9273db91f9474dc21cda66d70e411bf2583bac36 / validity.packet_count_original: 1378113
- 49a1ab7f4e843f6ae3deb26d9273db91f9474dc21cda66d70e411bf2583bac36 / validity.byte_source: duplicates are exact bytes from original selected packets
- 2eaf5988031975ba1bfff5b9a5b1ebf998397cbc3aa26682461f2ff420b53864 / Zeek_rerun: False
- 9e3bde59680df809d6e0eaf759580ad9fe5bb6a4398c9d06a27d3a14dd205012 / Zeek_rerun: False
- 7c6f71a380db130cadf771891bd1652082a2a008fcd7c4d399aecd1439ee70ae / Zeek_rerun: False
- a915700c5ad698dfd74e142ef0dc4d558a5e0d5f60a8e306da2bb8f01717a85b / prospective_confirmation: False
- 11358d428b34cc14106c1a6f21a5c39e77935f0ffc6d444cdbf17cb703558841 / models_for_confirmatory_use_trained: False
- 11358d428b34cc14106c1a6f21a5c39e77935f0ffc6d444cdbf17cb703558841 / attacks_on_real_packets_executed: False
- 11358d428b34cc14106c1a6f21a5c39e77935f0ffc6d444cdbf17cb703558841 / prospective_confirmation: False
- 73da16d83d649458ddaaafccf2d009b4164cf03d1aa613456192d8fe9b14cac4 / inference_feasibility[0].minimum_independent_pairs_for_any_significant_exact_sign_flip: 5
- 73da16d83d649458ddaaafccf2d009b4164cf03d1aa613456192d8fe9b14cac4 / inference_feasibility[1].minimum_independent_pairs_for_any_significant_exact_sign_flip: 6
- 73da16d83d649458ddaaafccf2d009b4164cf03d1aa613456192d8fe9b14cac4 / inference_feasibility[2].minimum_independent_pairs_for_any_significant_exact_sign_flip: 6
- 73da16d83d649458ddaaafccf2d009b4164cf03d1aa613456192d8fe9b14cac4 / inference_feasibility[3].minimum_independent_pairs_for_any_significant_exact_sign_flip: 7
- 73da16d83d649458ddaaafccf2d009b4164cf03d1aa613456192d8fe9b14cac4 / prospective_confirmation: False
- 36d9526adeaf8dca24feb3f1786cc1a523a177fb063dfa61fcdcfc5afc023d57 / models_for_confirmatory_use_trained: False
- 36d9526adeaf8dca24feb3f1786cc1a523a177fb063dfa61fcdcfc5afc023d57 / attacks_on_real_packets_executed: False
- 36d9526adeaf8dca24feb3f1786cc1a523a177fb063dfa61fcdcfc5afc023d57 / prospective_confirmation: False
- 14d063e35ec618507aee71169c4531718b9251ce0818e212981b02801aee2f24 / confirmatory_scenario_selection: False
- 0198b4cfec4214ce34f11ff05d3a800be8884f1dd3303bd4f174abf5055c9e7a / packet_content_identity_checks_computed: 2
- 0198b4cfec4214ce34f11ff05d3a800be8884f1dd3303bd4f174abf5055c9e7a / confirmatory_results_generated: False
- 0198b4cfec4214ce34f11ff05d3a800be8884f1dd3303bd4f174abf5055c9e7a / packet_valid_attack_approved: False
- 73361f0387d215e274a8d130cb765de5f5775183fa1862631f8e800087250389 / packets: 23623
- 73361f0387d215e274a8d130cb765de5f5775183fa1862631f8e800087250389 / all_packet_bytes_lengths_order_preserved: True
- 73361f0387d215e274a8d130cb765de5f5775183fa1862631f8e800087250389 / packet_content_sequence_sha256: dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / all_packet_bytes_lengths_order_preserved: True
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / packets: 23623
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / packet_content_sequence_sha256: dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / maximum_packet_delay_seconds: 4319.763037
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / TCP_semantic_validity_certified: False
- d43c9e7fa1dc91eac82e6553c9bf913d58cd0f91367874c22664c334e62c8ca6 / packet_valid_attack_approved: False
- 551881db0a96ec05a0a3bbd41c93ad0cadcceccb9ccb28139dbc9c2d42005516 / packets: 23623
- 551881db0a96ec05a0a3bbd41c93ad0cadcceccb9ccb28139dbc9c2d42005516 / all_packet_bytes_lengths_order_preserved: True
- 551881db0a96ec05a0a3bbd41c93ad0cadcceccb9ccb28139dbc9c2d42005516 / packet_content_sequence_sha256: dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / all_packet_bytes_lengths_order_preserved: True
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / packets: 23623
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / packet_content_sequence_sha256: dc0ba4db28dd34b567b651ed95346a4f2f8f9de519959d82210be3d1c62af2ca
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / maximum_packet_delay_seconds: 1.0
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / TCP_semantic_validity_certified: False
- 35f430a46c568b85253b257708469427e796f9ac808f3df785b05b866d5de5eb / packet_valid_attack_approved: False
- e75925983cdde0301397297d120e7353c5baaa3b57eeecc81e1d550eebbf3d4b / packet_content_identity_checks_computed: 2
- e75925983cdde0301397297d120e7353c5baaa3b57eeecc81e1d550eebbf3d4b / confirmatory_results_generated: False
- e75925983cdde0301397297d120e7353c5baaa3b57eeecc81e1d550eebbf3d4b / packet_valid_attack_approved: False
- 64bbf41ca961c3655ebadb565b44627a48fa8488ebc8807e60f96cd232bee622 / packet_content_identity_checks_computed: 2
- 64bbf41ca961c3655ebadb565b44627a48fa8488ebc8807e60f96cd232bee622 / confirmatory_results_generated: False
- 64bbf41ca961c3655ebadb565b44627a48fa8488ebc8807e60f96cd232bee622 / packet_valid_attack_approved: False
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / confirmatory_scenario_selected: False
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / packet_validity_approved: False
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / full_trace_mapping_approved: False
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / zeek_binary: /opt/zeek/bin/zeek
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / zeek_runnable: True
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / invalid_reference_keys: 0
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / invalid_generated_keys: 0
- 1b8615495c2dc33abadc54986ed5b96e44db2069633076b5748fbff91a2ddfa9 / label_semantics_approved: False
- 42210d2b5ad9434cd42ee856c151b616a9ac225519b5781e2ad8320cc0828778 / confirmatory_selection: False
- 6c7dce84b0081c1484d9c356157ccb91965a2a045685e4f0916487b081010d20 / schema_amendment_final_approved: False
- 6c7dce84b0081c1484d9c356157ccb91965a2a045685e4f0916487b081010d20 / publisher_label_rules_auto_approved: False
- 6c7dce84b0081c1484d9c356157ccb91965a2a045685e4f0916487b081010d20 / Zeek_rerun: False
- 75010462b2f35f001c5878369d0a3dcd3f04f8c5773c93c7ab1e0e9977c19c34 / those_scenarios_ineligible_as_blind_confirmatory_targets: True
- 75010462b2f35f001c5878369d0a3dcd3f04f8c5773c93c7ab1e0e9977c19c34 / confirmatory_outcome_generated: False
- 69351c79ea9f3135abe5a74637381f777be611a447078860bb5f269776cf2624 / label_semantics_final_approved: False
- 69351c79ea9f3135abe5a74637381f777be611a447078860bb5f269776cf2624 / packet_validity_approved: False
- 69351c79ea9f3135abe5a74637381f777be611a447078860bb5f269776cf2624 / confirmatory_scenario_selected: False
- 571f9db485ad88d4b91086b0a4f56cf0ad7c479c66939c47d785145b81ae57a1 / zeek_runnable: False
- 571f9db485ad88d4b91086b0a4f56cf0ad7c479c66939c47d785145b81ae57a1 / trace_validity_approved: False
- ff2962091bd2681359456cf5d5a95f453f439fe09df2442d2ade53e5cc11b398 / zeek_runnable: False
- ff2962091bd2681359456cf5d5a95f453f439fe09df2442d2ade53e5cc11b398 / trace_validity_approved: False
- 40d1f347eaadaeb6b0a846690be35ee8f564bde5b5c56552f3442db6e4c5d440 / zeek_runnable: False
- 40d1f347eaadaeb6b0a846690be35ee8f564bde5b5c56552f3442db6e4c5d440 / trace_validity_approved: False
- 1735b9a739079a1d9228862b4e98622562e034469c31dba1ca3a97bc6c619123 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 4d586d651a8c6789fe20229f9e08a7ef6c64ac79a549f379953fd954d297259b / confirmatory_scenario_selected: False
- 4d586d651a8c6789fe20229f9e08a7ef6c64ac79a549f379953fd954d297259b / packet_validity_approved: False
- 85129824d8e8f79bfaed97d95d2a88f8c063e5370276597303647cdd6084b527 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 8e1a8961b70b488616689283f5e33a968e1520d1b3aedf21b16d0a5a6bea32ba / confirmatory_scenario_selected: False
- 8e1a8961b70b488616689283f5e33a968e1520d1b3aedf21b16d0a5a6bea32ba / packet_validity_approved: False
- 9078db86acc21ae1641d02571de3e58563f1dc5686745ee94643885a8e9c13e4 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- a31470b953355f53fb8268cf0762e02b7e3dbbaf2c974c3785a4863e1ee1e9b0 / confirmatory_scenario_selected: False
- a31470b953355f53fb8268cf0762e02b7e3dbbaf2c974c3785a4863e1ee1e9b0 / packet_validity_approved: False
- da62a0112daf75207a0629dd7877730a703a6f42c994eae07b2d596a11b4bc4c / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 796b3067f17c55189cff1e450511bc1a259cb5c6b7e28836a04482065dfff566 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 746c5bafb485707be0272c31b9a1eef71574d05ea66edd69d8d3461620a2a99e / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 9ed1aed92323b319b659ddf8f71004c211f253a643ac67d424949568c6009056 / packet_validity_approved: False
- 9ed1aed92323b319b659ddf8f71004c211f253a643ac67d424949568c6009056 / confirmatory_scenarios_selected: False
- 36b6bcdfd99f2f2349532b597cd840706751016ac583f8afdef5dc548f3eef8a / confirmatory_scenario_selected: False
- 36b6bcdfd99f2f2349532b597cd840706751016ac583f8afdef5dc548f3eef8a / packet_validity_approved: False
- 77082d266c8911a13f58f85f79fd1a8e2d4a3c138598f9f2f852bfe340334126 / confirmatory_scenario_selected: False
- 77082d266c8911a13f58f85f79fd1a8e2d4a3c138598f9f2f852bfe340334126 / packet_validity_approved: False
- 511191c3c10b74972bf9b50e138138836f1a0536e149c06835d1f15af8ccbbfa / confirmatory_scenario_selected: False
- 511191c3c10b74972bf9b50e138138836f1a0536e149c06835d1f15af8ccbbfa / packet_validity_approved: False
- dd9d1ff1c2afce8d4afbb4b0d492863df4194dcb7f80e006e296ab1bdf35e1ff / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 3359591e67f16cb70f9cdda4b5e705228524f59e27c06b5b5a0dfdda35ae4436 / confirmatory_scenario_selected: False
- 3359591e67f16cb70f9cdda4b5e705228524f59e27c06b5b5a0dfdda35ae4436 / packet_validity_approved: False
- 933eabab469acbdf637b7080d821fc19a3f67fb9e33eb4f29dbeb9e45bf5bc95 / zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 1394332fbf3a457868bad2e10011fc011131fda4b4f3638dc7a3c6226fdfef2e / prospective_confirmation: False
- 1394332fbf3a457868bad2e10011fc011131fda4b4f3638dc7a3c6226fdfef2e / independent_pairs: 1
- 1394332fbf3a457868bad2e10011fc011131fda4b4f3638dc7a3c6226fdfef2e / models_for_confirmatory_use_trained: False
- f31d9d05ed5a29cd3ef06f6084570e2619097e1a0c93415d5b232eef5638704b / prospective_confirmation: False
- f31d9d05ed5a29cd3ef06f6084570e2619097e1a0c93415d5b232eef5638704b / independent_pairs: 1
- f31d9d05ed5a29cd3ef06f6084570e2619097e1a0c93415d5b232eef5638704b / models_for_confirmatory_use_trained: False
- 3e991cad91837be882a79d360a0286adf3bbffbb51e4b97945d7d3bdb35819c6 / independent_pairs: 1
- 3e991cad91837be882a79d360a0286adf3bbffbb51e4b97945d7d3bdb35819c6 / prospective_confirmation: False
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / injection_flows_with_header_only_originator_packet: 2056
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / packet_assignment_consistency: 1.0
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / all_packet_checks_passed: True
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / zeek_SYN_timeout_default_s: 5.0
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / models_for_confirmatory_use_trained: False
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / prospective_confirmation: False
- 3df6cb4483b2026e8b3471eb9aa804a504e82f0d6c170e343ede50226cdddc53 / TCP_semantic_validity_certified: False
- 4d73296d5c924e0da6cfe50319b2e875c39e6f01dc4e092c0ab4cc95a1e681d6 / flows_with_header_only_originator_packet: 93104
- 4d73296d5c924e0da6cfe50319b2e875c39e6f01dc4e092c0ab4cc95a1e681d6 / all_packet_checks_passed: True
- 4d73296d5c924e0da6cfe50319b2e875c39e6f01dc4e092c0ab4cc95a1e681d6 / models_for_confirmatory_use_trained: False
- 4d73296d5c924e0da6cfe50319b2e875c39e6f01dc4e092c0ab4cc95a1e681d6 / prospective_confirmation: False
- 4d73296d5c924e0da6cfe50319b2e875c39e6f01dc4e092c0ab4cc95a1e681d6 / TCP_semantic_validity_certified: False
- 967ab05f149c5d19784e14f02be1afc538aef2b8840d4461eff9f09a10fd63cd / packet_assignment_consistency: 1.0
- 967ab05f149c5d19784e14f02be1afc538aef2b8840d4461eff9f09a10fd63cd / all_packet_checks_passed: True
- 967ab05f149c5d19784e14f02be1afc538aef2b8840d4461eff9f09a10fd63cd / models_for_confirmatory_use_trained: False
- 967ab05f149c5d19784e14f02be1afc538aef2b8840d4461eff9f09a10fd63cd / prospective_confirmation: False
- 967ab05f149c5d19784e14f02be1afc538aef2b8840d4461eff9f09a10fd63cd / TCP_semantic_validity_certified: False
- f98ac694b9f19bb7f5e2cbc125309e1e39d8f417323861ecce3e76ac9be9b1ad / packet_transform_contract_approved: False
- f98ac694b9f19bb7f5e2cbc125309e1e39d8f417323861ecce3e76ac9be9b1ad / Zeek_rerun: False
- e3248cf0038b972e4b3bff9b5c33ed7b6dd8e4e17642787d457b338d2619fed1 / zeek_binary: 
- e3248cf0038b972e4b3bff9b5c33ed7b6dd8e4e17642787d457b338d2619fed1 / zeek_runnable: False
- f1a03b8426636f7d15cca9d9a3c34a3a0fd52ac1610e73815fc319f27107adeb / zeek_runnable: False
- f1a03b8426636f7d15cca9d9a3c34a3a0fd52ac1610e73815fc319f27107adeb / label_semantics_approved: False
- f1a03b8426636f7d15cca9d9a3c34a3a0fd52ac1610e73815fc319f27107adeb / v1_v2_equivalence_approved: False
- 483176cfbcdec87a3de475a1c4f7490ed069c8d0efcbb5326c806a41560efb89 / Zeek_rerun: False
- cc240e967e30ce6eb0ffc90e9675cb5d23e718e6119292b324eaed755f328086 / Zeek_rerun: False
- 67ffa2dc2ead2d42ebc1edb6c204ad07e69707530fe17bfbfe817d1854e1394c / Zeek_version: /opt/zeek/bin/zeek version 8.0.10
- 67ffa2dc2ead2d42ebc1edb6c204ad07e69707530fe17bfbfe817d1854e1394c / feature_contract_final_approved: False
- 67ffa2dc2ead2d42ebc1edb6c204ad07e69707530fe17bfbfe817d1854e1394c / Zeek_rerun: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / independent_corpus_boundary_created_by_restoration: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / prospective_confirmation_created_by_restoration: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / NF_boundary_result.precommitted_threshold: 0.8
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / NF_boundary_result.positive_independent_clustered_CI_established: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / NF_boundary_result.family_panels_proven_independent: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / NF_boundary_result.packet_validity_established: False
- 80381e394234a49e24cbc8c9419a44b387bb02316872824555a28009d34bad02 / NF_boundary_result.NetFlow_semantic_validity_established: False
- 215c94c67f379a5ad0463beefbb6f4842fea3ba4ae6e811abe9c20d1b8530232 / validation: Real ID-to-ID algebraic identity; not author-code bitwise reproduction
- c282007a298971bbe52e4fe52baeaa528b3342c9d30821b70cec96e23c6f48e7 / witness_validation: Round/project and re-evaluate with the original sklearn model
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1101: 3931b0e7c0fc0e5d3735af04699ab229ba9e2048c106240b80640f8003c2d34a
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1102: 0d87e0159f90385362e3a767e24d4650123a5dd0f9a4337c931be7897cbd737b
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1103: 085a85c589bbaa217fb55829657e8dad4acdd7bf96d158a3856ca0f30ac6140b
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1101: 0c016fc84146889d415bd150873bbe9c56c6766d975750fd52eb6632e9325336
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1102: 0477297d394ad9fcad30ed14c4d04765f253d1d0b0f1442bcb09f4e0bfd91c7e
- e3728b954effb765fef7bc9ad9662c6b85570182613c2b27fd102b334ba3b2cf / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1103: 6f9c76cda49ce4932cc6888d49be86fb5388ba9bfc215bb39442e63689efaec4
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1101: 97612d5032effb51a2c306392e5baba14a4540c19fa0b11807fd715e04e2873d
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1102: 859537bf87060c70132ea39beb2a1ff67521ce6f7fb111c64abda7d38784a6be
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1103: 2efabd8c3fc39446785fa1a92bfd43fdea21693e6f184d0348b828192e15884e
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1101: 0a56b884cc1f15044b6f8f1b3a5de09bdfa2fd886d7d7b11680e468eabb0c8b4
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1102: 7bfa210c3d1f8aed19396274e6f2faacaa27c6e9e39b5615d2d9e88310d5eea7
- 54ba475b50219a0afc793db0910c9482859890d6c8af0e8e2dc29f6c147968f6 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1103: 0a1a85efcde63f34dd58756e83268278632d7a931c40d0c93d6a6f51b5a946ab
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1101: 0e8428896034fe7024c4c045de882baa9ca64db53d0adc78a3986dbb98390acb
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1102: 0f19ab74bdcaf1e4fb7da53ce7c031d9721e8397c4e6f1c1daaff56248ab95cf
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1103: ae6141cc269a7f5729cab632ef1d92762a9ea0a57b399ab6c29056fcf7da88c0
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1101: fea2195d44467f4a28f98cd06abc79b679bc62bd38af2e3b398aaf4f526ca430
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1102: 69eced7f33d76aee0e61044a5c739d245acdd10d50fb24408cee2e8d90b0a710
- 0486e3c009038bac4c0cfcfa34500a4c20738e4937c807a071d8a471178bcd4b / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1103: 8115f89436545182d3ca960c6fe4ebbbc95d5d627b3619b09682d9d3d940218e
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1101: 76420bda144a11158a974cbba6e7209fe90fd3f330be061432269fa960acea19
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1102: 2987d5c5d9c3fff0affe95851e4bac154fe263f78ad5ad657c720ecacbe74f30
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1103: 5f0b7bec8d720e70eec483278b9055177ada87cde8d026fada0250dd1f1c7331
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1101: ead90bd70bf7204fa6be3643fc5151e4330e61de414083a405b8879138cf92f4
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1102: cb6923cb57a008125f1993b9a428c7dbeb7543abadf429dc87ae2154d78d3744
- d499098e7d15ac3f4c994bb9418b9fb509b8b6cfcdd1f8d2e13353914533ba0f / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1103: cfff64d1351ed2f761eb2b2723e257cfde0c2e224e5ea23b744327ea168f1ff7
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1101: 26a0a5328eeaf2dfa0447bbedf88832561715afe2ea5e47edf5d1791e49097c9
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1102: 6a086d0dcd36a749172185a7209bb30e2f32263809ca795beafd9d5f257e29a6
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.25_seed_1103: a0b5fbac08149e826d42d3c4cca6699a51284fe9e4171361afcaff70980ef190
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1101: efc638e2af53b8f09b7e8f0e8e9b425c1b2fc9ab4fb47a112d9a80db2285110e
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1102: 246436fe89a7ad4accc07e861a549fbb60f9d98d88d0ee97f26c9882bd34f6f6
- d80b8034c2882529b0712a306480b9f7ba3c9ab876b29ff845f165b133e2eed3 / attack_sha256.genuine_surrogate_transfer_independent_half_train_surrogate_eps_0.50_seed_1103: fe401bcc4931374301ed3be8ed640cb9194c49ff455b337670358bf44b824183
- e955b1992b7d9f42ac4dc012603585bc2f5bfec2035b98ba26f02be3bdc08b42 / validation: Replay saved per-record offsets; check budgets/types/immutable values and original actual accuracies

## Audit limits

[
  {
    "locator": "/kaggle/working/TRACE_LINKAGE_BATCH_v1/candidate_linkage_summary.csv",
    "issue": "CSV_PARSE: No columns to parse from file"
  },
  {
    "locator": "/kaggle/working/TRACE_LINKAGE_BATCH_v1/scenario_gate_summary.csv",
    "issue": "CSV_PARSE: No columns to parse from file"
  },
  {
    "locator": "/kaggle/working/resume_verified_20261011T144807877506Z/development/real_record_mixture_and_order_stress_v1/TONIoT/MLP_seed_10/row_selection_manifest.csv",
    "issue": "METADATA_BUDGET_EXHAUSTED"
  }
]