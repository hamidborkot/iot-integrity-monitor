# Manuscript tables

Upload CSVs for Tables I-IV here. Tables I-II are textual comparison/design tables, not metric measurements. Preserve the separate panels of Table III and distinguish FP/TN counts from FP/(FP+TN) fractions in Table IV. Layout-only revisions may change wording without changing results.
