# Formal results and their limits

## Lemma 1: output-only non-identifiability
Let O be the observable detector/view outputs and any fixed trusted-reference information.
Let A(W) be frozen-detector accuracy in admissible target world W. Suppose W0 and W1
induce identical distributions of O but have accuracies A0 != A1. Every possibly randomized
estimator T(O) satisfies max_j E_j |T-Aj| >= |A0-A1|/2.
Proof: the estimator has the same distribution in both worlds. Pointwise,
|t-A0|+|t-A1| >= |A0-A1|. Take expectations and use max(u,v)>=(u+v)/2.

For a finite binary construction with fixed target inputs and predictions f(xi), admit label
assignments yi=f(xi) and yi=1-f(xi). Accuracies are 1 and 0 with identical outputs.
These are alternative statistical worlds, not an attacker permission to change labels.
Admissibility is essential. This familiar argument is a foundation, not a novelty claim.

## Proposition 2: a conditional weighted-vote bound
Condition on information H that fixes nonnegative weights wg and clean/attacked sets C,A.
For clean views assume P(Zg != Y | H) <= eg. Let WC=sum_C wg, WA=sum_A wg and
L=sum_C wg*1{Zg != Y}. Suppose WC>WA. An adversary can assign arbitrary votes
in A, but clean-view error assumptions must still hold under the evaluated distribution.
The label-aligned total margin is at least WC-WA-2L. A vote error, counting ties as errors,
therefore requires L >= (WC-WA)/2. Markov's inequality gives

P(vote error | H) <= min(1, 2 sum_C wg eg / (WC-WA)).

Proof: use the worst-case attacked contribution -WA and the clean contribution WC-2L;
then E[L|H] <= sum_C wg eg and apply Markov. No independent-clean-view assumption is used.

The planned inequality sum_C wg(1-2eg)>WA gives positive expected worst-case margin
and makes this upper bound less than 1. It does NOT imply zero error or error below 1/2.
For this bound to establish error below 1/2, the stronger sufficient condition is
sum_C wg eg < (WC-WA)/4. This remains a conditional, generally loose bound.

## Important limitation for adaptive weights
Runtime weights depend on view outputs. Training error estimates cannot be substituted for
conditional target errors eg without a justified transport/conditioning assumption.
Conditioning only on the weights can change clean-view error probabilities.
The empirical algorithm does not observe C,A or target errors. Consequently this
proposition is NOT a deployable certificate or a proof of adversarial robustness.

## IDS-specific attainability
For fixed target labels and a declared transformation set T, define the detector/view
observation map phi(T(x)). If two admissible traffic/evidence worlds have equal phi and
different accuracies, Lemma 1 applies to the restricted class. Existence must be proved or
supported by verified witnesses satisfying the declared transformation and label semantics.
Approximately preserved signatures are empirical near-blindness witnesses, not exact
indistinguishability proofs. Range/type consistency is not packet functionality preservation.

## Ethical and scope statements
No physical network attack, valid packet reconstruction, causal attribution, or universal
accuracy recovery is established by the closing code. Empirical witnesses are real saved
benchmark records with declared feature-space transformations. All failures remain visible.

## Attribution requirement
The generic two-world argument and Markov bound are standard mathematical reasoning.
Verify prior art before claiming originality. Research novelty must be established for the
specific IDS formulation, empirical scope, conditional method and boundary evidence.
