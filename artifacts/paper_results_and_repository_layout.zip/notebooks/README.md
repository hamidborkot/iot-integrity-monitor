# Notebooks

Upload executed notebooks and clean reproduction notebooks here. Keep large outputs in result artifacts rather than embedding all raw records in notebook cells. Remove secrets before publication. Distinguish historical development notebooks from the paper reproduction entry point.
