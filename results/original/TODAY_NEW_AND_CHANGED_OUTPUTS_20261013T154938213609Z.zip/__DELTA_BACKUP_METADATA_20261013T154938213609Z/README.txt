INCREMENTAL RESEARCH BACKUP

Restore your existing baseline backups first, then overlay the regular
files from this ZIP onto /kaggle/working.
The manifest identifies omitted files and their existing backup copies.
No raw dataset under /kaggle/input is copied into this ZIP unless a
new/changed working-directory file has no identical baseline copy.
Existing archive containers are intentionally not nested.
New symlinks are described in new_symlinks.json, not followed.
Save the executed Kaggle .ipynb separately: cell-source history is not
a complete notebook with outputs and metadata.
A backup does not establish that all original study requirements are met.
