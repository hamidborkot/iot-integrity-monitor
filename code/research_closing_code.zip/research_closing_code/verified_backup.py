"""Create and fully CRC-test a final result backup without raw data/models."""
import argparse,hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True)
a=p.parse_args();root=Path(a.root).resolve();output=Path(a.output).resolve()
if not root.is_dir():raise FileNotFoundError(root)
if output.exists():raise FileExistsError(output)
allowed={'.csv','.json','.jsonl','.md','.py','.ipynb','.yaml','.yml','.txt','.pdf','.sha256'}
paths=[x for x in root.rglob('*') if x.is_file() and not x.is_symlink() and x.suffix.lower() in allowed and x.resolve()!=output]
manifest=[]
output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,allowZip64=True) as z:
    for x in sorted(paths):
        payload=x.read_bytes();name=str(x.relative_to(root))
        manifest.append({'path':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
        z.writestr(name,payload)
    z.writestr('BACKUP_MANIFEST.json',json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),
        'raw_data_and_models_excluded':True,'private_only':True,'files':manifest},indent=2))
with zipfile.ZipFile(output) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('CRC failure: '+bad)
h=hashlib.sha256()
with output.open('rb') as f:
    for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
output.with_suffix(output.suffix+'.sha256').write_text(h.hexdigest()+'  '+output.name+'\n')
print(json.dumps({'zip':str(output),'bytes':output.stat().st_size,'files':len(manifest),
    'CRC_verified':True,'sha256':h.hexdigest(),'source_models_not_included':True},indent=2))
