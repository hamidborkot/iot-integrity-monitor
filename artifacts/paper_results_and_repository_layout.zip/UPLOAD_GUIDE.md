# Paper artifact upload guide

Paper: From Flow Records to Original Connections: Extraction-Aware Auditing of Frozen IoT Intrusion Detectors.

This guide adds an artifact layout without replacing the existing README, license, requirements, documentation, or development archive.

## Upload destinations
- code/: maintained Python modules and entry points.
- configs/: frozen extraction, model, threshold, cohort, and environment configurations.
- notebooks/: executed and clean reproducibility notebooks, with bounded output.
- results/paper/tables/: CSVs corresponding to manuscript tables.
- results/paper/figures/: numerical inputs for figures; Figure 1 is conceptual artwork.
- results/supporting/: scoped supporting summaries and supplementary-ready tables.
- results/original/: small original machine-generated CSV/JSON outputs, preserving filenames and provenance.
- manuscript/: final LaTeX, bibliography, figures, and compiled PDF.
- manuscript/supplementary/: the final supplement and exact S1-S8 mapping.
- artifacts/manifests/: checksums, archive inventory, artifact-to-paper mappings, and access links.
- artifacts/archives/: documentation of external archive locations; not a destination for 20+GB of Git-tracked ZIPs.

## Evidence rules
A CSV transcribed from the manuscript or printed output is NOT the original experimental CSV. Preserve that distinction in results/README.md and the provenance manifest. Keep full-record and pattern-balanced populations, separate model banks, reporting policies, and horizons distinct. Undefined cells remain blank/NA, not zero. A count comparison is not detection scoring. Existing development results remain historical evidence, not prospective confirmation.

## Large artifacts
GitHub documents a 100MiB regular-Git file block and 25MiB browser-upload limit. Do not commit 20+GB of backups to Git history. Keep them in an appropriate external archive, such as a retained Kaggle dataset or a research archive, and commit links, sizes, SHA-256 values, and access/redistribution conditions. GitHub Releases have their own asset limits; check current documentation before choosing that route. No large archive is uploaded by this organization commit.

## Before public release
Review notebooks, JSON, scripts, and logs for credentials, personal data and redistribution restrictions. Do not assume the repository code license also licenses third-party datasets. A release is not independently reproduced merely because files are uploaded. Replace paper-facing transcriptions with the exact original generating CSVs when available, preserving both provenance and version identity.

Documentation: https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github
