# Ground-truth scope

Published benign/malicious ground truth exists for the original IoT-23 connections. This program audits the exact identity and label linkage for the two frozen1024-unit cohorts and saves matched original rows.

This is annotation provenance and consistency verification, not a new set of independent expert labels. Published class annotations do not independently adjudicate transformed packet ownership, Zeek UID purity or the unresolved historical unit. Existing attribution intervals and the separate implementation check remain as reported.

Mounted log hashes are recorded. Publisher-download byte identity is not asserted without a separately verified publisher checksum.
