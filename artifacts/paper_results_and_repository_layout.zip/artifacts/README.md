# Artifact inventory

Keep bulk archives outside regular Git history. Use manifests/ for artifact inventories, checksums, provenance and durable access links. Use archives/ for archive instructions, not unchecked large binary uploads.
