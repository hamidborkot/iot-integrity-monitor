# Frozen configurations

Upload exact model, cohort, predictor-schema, cutoff/comparator, extractor/timer, horizon and environment configurations. Preserve original hashes and distinguish pre-outcome freezes from retrospective provenance records.
