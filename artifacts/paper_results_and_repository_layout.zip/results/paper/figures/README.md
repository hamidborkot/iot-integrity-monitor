# Figure inputs

Upload numerical inputs for Figures 2-4 here and preserve exact weighting, model, cutoff, denominator and aggregation identities. Figure 1 is a conceptual workflow: its editable artwork belongs under manuscript/. Rounded manuscript transcriptions are not full-precision raw scores.
