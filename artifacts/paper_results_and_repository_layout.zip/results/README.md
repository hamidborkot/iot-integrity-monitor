# Results and provenance

`paper/` holds manuscript-facing table/figure inputs. `supporting/` holds supporting result tables. `original/` is reserved for small byte-original machine-generated outputs.

The downloadable preparation package contains transcriptions from the supplied manuscript, consolidated register and printed execution output. They are NOT newly run experiments or byte-original experimental CSVs. Their provenance is recorded in `artifacts/manifests/result_provenance.csv`. Do not silently replace attribution intervals or missing values with point estimates or zeros. Supporting tables must not be called the final S1-S8 supplement until its mapping is checked.
